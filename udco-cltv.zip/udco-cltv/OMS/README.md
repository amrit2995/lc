# OMS (Order Management System)

Models advertising order-management entities — accounts, campaigns, line items, buying-side objects, insertion orders, opportunities, and commerce promotion references.

## Pipeline Flow

```
Source BQ Tables ──► [VToB SPs] ──► Confirmed Tables (SCD2) ──► Views
```

### Data Flow Detail
1. Source data read from upstream BQ datasets
2. SPs validate, deduplicate, and SCD2-merge into confirmed tables via `_WRK` staging
3. `_LR_UPDATE` tables track which rows to expire during SCD2 processing
4. Views expose current-version records

## Directory Layout

```
OMS/
├── README.md
├── params_dev.json / params_qa.json / params_prod.json
├── config/                         ← 11 Airflow workflow & step configs
│   ├── OMS_CONF_WF.json            ← DAG definition
│   └── VToB_OMS_*_BQToBQ.json      ← BQ-to-BQ transform configs
└── scripts/
    ├── ddl/                        ← 25 table DDLs (main + _WRK + _LR_UPDATE)
    ├── sp/                         ← 9 stored procedures (SCD2 loads, DQ)
    └── view/                       ← 8 view definitions
```

## Key Entities

| Entity | DDL Pattern | SP | View |
|--------|-------------|-----|------|
| Account | `ddl_account*.sql` | `SP_CLTV_*_ACCOUNT.sql` | `view_account.sql` |
| Media Campaign | `ddl_media_campaign*.sql` | `SP_CLTV_*_MEDIA_CAMPAIGN.sql` | `view_media_campaign.sql` |
| Campaign Line Item | `ddl_campaign_line_item*.sql` | `SP_CLTV_*_CAMPAIGN_LINE_ITEM.sql` | `view_campaign_line_item.sql` |
| Buying Campaign | `ddl_buying_campaign*.sql` | `SP_CLTV_*_BUYING_CAMPAIGN.sql` | `view_buying_campaign.sql` |
| Buying Line Item | `ddl_buying_line_item*.sql` | `SP_CLTV_*_BUYING_LINE_ITEM.sql` | `view_buying_line_item.sql` |
| Insertion Order | `ddl_insertion_order*.sql` | `SP_CLTV_*_INSERTION_ORDER.sql` | `view_insertion_order.sql` |
| Opportunity | `ddl_opportunity*.sql` | `SP_CLTV_*_OPPORTUNITY.sql` | `view_opportunity.sql` |
| Commerce Promo Ref | `ddl_commerce_promotion_ref*.sql` | `SP_CLTV_*_COMMERCE_PROMO.sql` | `view_commerce_promotion_ref.sql` |

## Deployment

Ordered via `script_order_execution_oms.yaml` at the repo root.
