CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.COMMERCE_PROMOTION_REFERENCE`
(
 hub_campaign_id    OPTIONS(description="Unique identifier of the campaign in the marketing hub system."),
 brand_nm              OPTIONS(description="me of the brand being promoted in the campaign."),
 dw_first_effective_ts  OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts  OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999;"),
 vendor_nm             OPTIONS(description="Name of the vendor supplying the promoted product or service."),
 group_nm              OPTIONS(description="Group classification for the promoted product within merchandising hierarchy."),
 category_nm           OPTIONS(description="Category name for the promoted product within merchandising hierarchy."),
 department_nm         OPTIONS(description="Department name for the promoted product within merchandising hierarchy."),
 class_nm              OPTIONS(description="Class name for the promoted product within merchandising hierarchy."),
 attribution_list_nm   OPTIONS(description="Name of the attribution list associated with the promotion."),
 attribution_type_nm   OPTIONS(description="Type of attribution method applied to the promotion."),
 co_branded_advertiser_nm  OPTIONS(description="Name of the co-branding advertiser partnered in the promotion."),
 co_branded_tier_nm    OPTIONS(description="Tier classification for the co-branding advertiser."),
 co_branded_ind        OPTIONS(description="Indicator showing if the promotion is co-branded (Y/N)."),
 partner_id            OPTIONS(description="Unique identifier for the partner associated with the promotion."),
 partner_nm            OPTIONS(description="Name of the partner associated with the promotion."),
 source_created_ts     OPTIONS(description="The date and time record was created"),
 source_last_modified_ts  OPTIONS(description="The date and time record was modified") ,
 source_application_cd  OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_create_ts           OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts      OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind  OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm    OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm    OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind OPTIONS(description="The Current version indicator True or False")
)
OPTIONS (labels = [('appcode','uddi'),('bodname','oms'),('domainname','collect'),('environment','<<ENV>>')]) 
AS
SELECT
    hub_campaign_id
	,brand_nm
	,dw_first_effective_ts
	,dw_last_effective_ts
	,vendor_nm
	,group_nm
	,category_nm
	,department_nm
	,class_nm
	,attribution_list_nm
	,attribution_type_nm
	,co_branded_advertiser_nm
	,co_branded_tier_nm
	,co_branded_ind
	,partner_id
	,partner_nm
	,source_created_ts
	,source_last_modified_ts
	,source_application_cd
	,dw_create_ts
	,dw_last_update_ts
	,dw_logical_delete_ind
	,dw_source_create_nm
	,dw_source_update_nm
	,dw_current_version_ind
FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.COMMERCE_PROMOTION_REFERENCE`;