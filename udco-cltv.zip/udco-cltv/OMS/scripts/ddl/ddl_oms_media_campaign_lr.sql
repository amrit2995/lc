CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_MEDIA_CAMPAIGN_LR_INSERT_UPDATE`  
(
  media_campaign_id  STRING  NOT NULL  OPTIONS(description="Unique system-generated identifier for each campaign record. Typically acts as the primary key."),
  source_application_cd  STRING        OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
  dw_first_effective_ts TIMESTAMP NOT NULL OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
  dw_last_effective_ts  TIMESTAMP  NOT NULL OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
  dw_current_version_ind     BOOL      OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be current date -1 d.")
)
OPTIONS (
description="OMS media campaign load ready table for capturing insert and update records",
labels = [('appcode','uddi'),('bodname','oms'),('domainname','collect'),('environment','<<ENV>>')]
);

