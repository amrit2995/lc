CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_OPPORTUNITY_WRK`  
(
 opportunity_id STRING NOT NULL OPTIONS(description="The unique identifier of the opportunity."),
 dw_first_effective_ts TIMESTAMP NOT NULL OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts  TIMESTAMP  NOT NULL OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 deleted_ind           BOOL                       OPTIONS(description="Indicates whether the record is flagged as deleted in the source system."),
 account_id            STRING                     OPTIONS(description="Foreign key to oms_account.account_id representing the customer account."),
 record_type_id        STRING                     OPTIONS(description="Identifier of the record type/classification from the CRM source."),
 opportunity_nm        STRING                     OPTIONS(description="name/title of the opportunity."),
 primary_commercial_amt  NUMERIC(18,2)            OPTIONS(description="Primary commercial amount associated with the opportunity."),
 opportunity_type_cd   STRING                     OPTIONS(description="Categorization of the opportunity (e.g., New, Renewal)."),
 source_created_ts     TIMESTAMP                  OPTIONS(description="Timestamp when the opportunity record was created."),
 source_created_by_id  STRING                     OPTIONS(description="Identifier of the user who created the record."),
 source_last_modified_ts  TIMESTAMP               OPTIONS(description="Timestamp of the most recent update to the record."),
 albertsons_divisions_nm  STRING                  OPTIONS(description="Division name within Albertsons hierarchy relevant to the opportunity."),
 annual_budget_amt     NUMERIC(14,2)              OPTIONS(description="Annual budget allocated for the opportunity/program."),
 planned_budget_amt    NUMERIC(14,2)              OPTIONS(description="Planned budget amount for this opportunity."),
 campaign_start_dt     DATE                       OPTIONS(description="Start date of the associated campaign period."),
 campaign_end_dt       DATE                       OPTIONS(description="End date of the associated campaign period."),
 client_sub_tier_nm    STRING                     OPTIONS(description="Client sub-tier classification name."),
 client_tier_nm        STRING                     OPTIONS(description="Client tier classification name."),
 co_branded_ind         BOOL                       OPTIONS(description="Indicates whether the opportunity is co-branded."),
 hub_campaign_id       STRING                     OPTIONS(description="Identifier of the campaign in the central marketing hub."),
 parent_opportunity_id  STRING                    OPTIONS(description="Identifier of the parent opportunity when part of a hierarchy."),
 parent_ind            BOOL                       OPTIONS(description="Flags this record as a parent opportunity in a hierarchy."),
 total_line_item_budget_amt  NUMERIC(14,2)        OPTIONS(description="Sum of budgets for all line-item components of the opportunity."),
 objectives_txt        STRING                     OPTIONS(description="Textual statement of objectives/goals for the opportunity."),
 stage_nm              STRING                     OPTIONS(description="Current sales stage of the opportunity (e.g., Prospecting, Closed, Won)."),
 brand_nm              STRING                     OPTIONS(description="Brand name associated with the opportunity."),
 source_application_cd  STRING OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_create_ts     TIMESTAMP          OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts  TIMESTAMP        OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind  BOOL         OPTIONS(description="Set to True when we receive a delete record for the primary key"),
 dw_source_create_nm  STRING         OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm  STRING         OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind  BOOL     OPTIONS(description="The Current version indicator True or False")
)

OPTIONS (
description="Staging table for Opportunity identifier",
labels = [('appcode','uddi'),('bodname','oms'),('domainname','collect'),('environment','<<ENV>>')]
);
