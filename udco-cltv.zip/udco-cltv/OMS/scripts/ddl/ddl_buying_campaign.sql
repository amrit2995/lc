CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.BUYING_CAMPAIGN`                   
(
 buying_campaign_id    STRING  NOT NULL    OPTIONS(description="Primary key identifying the buying item"),
 dw_first_effective_ts TIMESTAMP NOT NULL OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts  TIMESTAMP  NOT NULL OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 owner_id              STRING              OPTIONS(description="ID of the user or system owning the record"),
 buying_campaign_advertiser_id STRING              OPTIONS(description="Foreign key referencing the advertiser entity"),
 ad_platform_campaign_id        STRING              OPTIONS(description="Foreign key referencing the campaign entity"),
 media_campaign_id     STRING              OPTIONS(description="Foreign key referencing the linked media campaign entity"),
 deleted_ind           BOOL                OPTIONS(description="Boolean flag indicating if the record is soft-deleted"),
 buying_item_nm        STRING              OPTIONS(description="Name or title of the buying item"),
 currency_iso_cd       STRING              OPTIONS(description="ISO currency code used for budget and cost fields (e.g., USD, EUR)"),
 campaign_url_txt           STRING              OPTIONS(description="Campaign url link"),
 source_created_ts     TIMESTAMP           OPTIONS(description="Timestamp when the record was first created"),
 source_created_by_id  STRING              OPTIONS(description="ID of the user who created the record"),
 source_last_modified_ts   TIMESTAMP       OPTIONS(description="Timestamp when the record was last modified"),
 source_last_modified_by_id   STRING       OPTIONS(description="ID of the user who last modified the record"),
 system_mod_ts         TIMESTAMP           OPTIONS(description="System timestamp for the most recent DML operation"),
 last_viewed_dt        TIMESTAMP           OPTIONS(description="Timestamp of when the record was last viewed"),
 last_referenced_dt    TIMESTAMP           OPTIONS(description="Timestamp of when the record was last referenced in another object"),
 user_record_access_id  STRING             OPTIONS(description="ID used for access control at the user-record level"),
 start_dt              DATE                OPTIONS(description="Scheduled start date of the buying item"),
 end_dt                DATE                OPTIONS(description="Scheduled end date of the buying item"),
 goal_kpi_amt          NUMERIC(14,2)       OPTIONS(description="Target value set for the selected KPI (e.g., 10,000 impressions)"),
 goal_kpi_cd           STRING              OPTIONS(description="Code representing the KPI type (e.g., CPM, CPC, CTR)"),
 status_cd             STRING              OPTIONS(description="Current status code of the buying campaign (e.g., Active, Paused, Completed)"),
 campaign_goal_cd      STRING              OPTIONS(description="Objective or goal code for the buying campaign (e.g., Awareness, Conversions)"),
 connection_type_cd    STRING              OPTIONS(description="Code indicating the type of platform connection (e.g., DV360, Meta)"),
 buying_campaign_ext_nm  STRING            OPTIONS(description="Extended name or full description of the buying campaign"),
 source_application_cd  STRING             OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_create_ts           TIMESTAMP          OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts      TIMESTAMP          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind  BOOL               OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm    STRING             OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm    STRING             OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind  BOOL     OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be current date -1 d."),
 PRIMARY KEY (buying_campaign_id, dw_first_effective_ts, dw_last_effective_ts) not enforced
)
PARTITION BY start_dt
CLUSTER BY buying_campaign_id 
OPTIONS (
description="Represents the overarching strategy grouping multiple insertion orders to achieve a common advertising objective across platforms.",
labels = [('appcode','uddi'),('bodname','oms'),('domainname','collect'),('environment','<<ENV>>')]
);