CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.commerce_promotion_reference_lr`     
(
 hub_campaign_id       STRING  NOT NULL         OPTIONS(description="Unique identifier of the campaign in the marketing hub system."),
 brand_nm              STRING  NOT NULL         OPTIONS(description="me of the brand being promoted in the campaign."),
 vendor_nm             STRING                   OPTIONS(description="Name of the vendor supplying the promoted product or service."),
 dw_first_effective_ts TIMESTAMP NOT NULL OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts  TIMESTAMP  NOT NULL OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 group_nm              STRING                   OPTIONS(description="Group classification for the promoted product within merchandising hierarchy."),
 category_nm           STRING                   OPTIONS(description="Category name for the promoted product within merchandising hierarchy."),
 department_nm         STRING                   OPTIONS(description="Department name for the promoted product within merchandising hierarchy."),
 class_nm              STRING                   OPTIONS(description="Class name for the promoted product within merchandising hierarchy."),
 partner_id            STRING                   OPTIONS(description="Unique identifier for the partner associated with the promotion."),
 source_application_cd  STRING                  OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_current_version_ind  BOOL                   OPTIONS(description="The Current version indicator True or False")
)
 
OPTIONS (
description="Commerce Promotion Reference load ready Table",
labels = [('appcode','uddi'),('bodname','oms'),('domainname','collect'),('environment','<<ENV>>')]
);