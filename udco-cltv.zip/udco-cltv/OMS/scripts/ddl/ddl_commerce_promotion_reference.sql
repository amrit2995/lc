CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.commerce_promotion_reference`     
(
 hub_campaign_id       STRING  NOT NULL         OPTIONS(description="Unique identifier of the campaign in the marketing hub system."),
 brand_nm              STRING  NOT NULL         OPTIONS(description="me of the brand being promoted in the campaign."),
 dw_first_effective_ts TIMESTAMP NOT NULL OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts  TIMESTAMP  NOT NULL OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 vendor_nm             STRING                   OPTIONS(description="Name of the vendor supplying the promoted product or service."),
 group_nm              STRING                   OPTIONS(description="Group classification for the promoted product within merchandising hierarchy."),
 category_nm           STRING                   OPTIONS(description="Category name for the promoted product within merchandising hierarchy."),
 department_nm         STRING                   OPTIONS(description="Department name for the promoted product within merchandising hierarchy."),
 class_nm              STRING                   OPTIONS(description="Class name for the promoted product within merchandising hierarchy."),
 attribution_list_nm   STRING                   OPTIONS(description="Name of the attribution list associated with the promotion."),
 attribution_type_nm   STRING                   OPTIONS(description="Type of attribution method applied to the promotion."),
 co_branded_advertiser_nm  STRING               OPTIONS(description="Name of the co-branding advertiser partnered in the promotion."),
 co_branded_tier_nm    STRING                   OPTIONS(description="Tier classification for the co-branding advertiser."),
 co_branded_ind        BOOL                     OPTIONS(description="Indicator showing if the promotion is co-branded (Y/N)."),
 partner_id            STRING                   OPTIONS(description="Unique identifier for the partner associated with the promotion."),
 partner_nm            STRING                   OPTIONS(description="Name of the partner associated with the promotion."),
 source_created_ts     TIMESTAMP                OPTIONS(description="The date and time record was created"),
 source_last_modified_ts  TIMESTAMP             OPTIONS(description="The date and time record was modified") ,
 source_application_cd  STRING                        OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_create_ts                      TIMESTAMP          OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts                 TIMESTAMP          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind             BOOL               OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm               STRING             OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm               STRING             OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind  BOOL                         OPTIONS(description="The Current version indicator True or False"),
 PRIMARY KEY (hub_campaign_id,brand_nm, dw_first_effective_ts, dw_last_effective_ts) NOT ENFORCED   
)
PARTITION BY DATE(dw_last_update_ts)
CLUSTER BY  hub_campaign_id,brand_nm 
OPTIONS (
description="Reference table mapping brand, vendor, category, and partner details to associated campaigns for promoted commerce content",
labels = [('appcode','uddi'),('bodname','oms'),('domainname','collect'),('environment','<<ENV>>')]
);

