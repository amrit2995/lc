CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_BUYING_LINE_ITEM_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_lr_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE lr_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE buying_line_item_records_expire string;
DECLARE buying_line_item_final_update string;
DECLARE buying_line_item_final_insert string;



SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_BUYING_LINE_ITEM_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.BUYING_LINE_ITEM';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.BUYING_LINE_ITEM_WRK';        
SET src_tbl         = '<<EMFI_PROJECT_ID>>.<<EMFI_DATASET>>.advendio_buying_item_c';
SET lr_tbl          = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.BUYING_LINE_ITEM_LR_INSERT_UPDATE';

IF DATE(max_audit_ts) = '0001-01-01' THEN
  EXECUTE IMMEDIATE ('''TRUNCATE TABLE ''' || tgt_tbl);
END IF;

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = FORMAT("""
      INSERT INTO %s
			(
        buying_line_item_id,
        dw_first_effective_ts,
        dw_last_effective_ts,
        buying_insertion_order_id,
        media_campaign_line_item_id,
        end_dt,
        media_format_cd,
        start_dt,
        status_nm,
        source_created_by_id,
        source_created_ts,
        deleted_ind,
        source_last_modified_by_id,
        source_last_modified_ts,
        buying_line_item_nm,
        system_mod_ts,
        currency_iso_cd,
        record_type_id,
        last_activity_dt,
        last_viewed_dt,
        last_referenced_dt,
        user_record_access_id,
        bid_amt,
        budget_amt,
        budget_impressions_cnt,
        click_cnt,
        completed_listens_cnt,
        completed_views_cnt,
        frequency_cap_txt,
        impression_cnt,
        last_delivery_update_ts,
        last_submit_dt,
        last_submit_status_cd,
        ad_platform_line_item_id,
        media_cost_amt,
        selected_targeting_txt,
        total_conversion_cnt,
        video_view_cnt,
        viewed_impression_cnt,
        ecpm_amt,
        bid_strategy_cd,
        daily_budget_amt,
        end_ts,
        optimization_strategy_cd,
        start_ts,
        min_margin_pct,
        optimization_method_cd,
        optimization_value_amt,
        prefer_delivery_over_perf_ind,
        revenue_type_cd,
        revenue_value_amt,
        audience_id,
        billable_event_cd,
        daily_budget_impressions_cnt,
        creative_id,
        creative_type_cd,
        inventory_id,
        max_bid_amt,
        position_nbr,
        pricing_type_cd,
        ad_size_txt,
        tag_type_cd,
        additional_item_id,
        country_cd,
        external_item_status_cd,
        external_ref_nbr,
        landing_page_url_txt,
        language_cd,
        last_status_update_ts,
        media_category_type_cd,
        creative_cnt,
        unit_cnt,
        pacing_cd,
        placement_cd,
        price_rate_amt,
        priority_nbr,
        target_platform_cd,
        unit_type_cd,
        one_imp_per_page_ind,
        pacing_value_amt,
        monthly_budget_amt,
        cpc_amt,
        line_item_type_cd,
        neg_broad_match_kw_txt,
        neg_exact_match_kw_txt,
        pos_exact_match_kw_txt,
        retailer_nm,
        trafficker_nm,
        unlimited_budget_ind,
        ad_platform_line_item_url_txt,
        buying_item_ext_nm,
        external_feature_id,
        feature_id,
        ad_postal_codes_txt,
        advanced_settings_txt,
        avg_goal_cpm_amt,
        viewability_targeting_cd,
        external_order_id,
        freq_cap_duration_hr,
        freq_cap_cnt,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind
      )
        SELECT  t.*
        FROM    
      (
        SELECT 
        buying_line_item_id,
        dw_first_effective_ts,
        CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN '9999-12-31 00:00:00' ELSE TIMESTAMP_SUB(dw_last_effective_ts, INTERVAL 1 SECOND) END AS dw_last_effective_ts,
        buying_insertion_order_id,
        media_campaign_line_item_id,
        end_dt,
        media_format_cd,
        start_dt,
        status_nm,
        source_created_by_id,
        source_created_ts,
        deleted_ind,
        source_last_modified_by_id,
        source_last_modified_ts,
        buying_line_item_nm,
        system_mod_ts,
        currency_iso_cd,
        record_type_id,
        last_activity_dt,
        last_viewed_dt,
        last_referenced_dt,
        user_record_access_id,
        bid_amt,
        budget_amt,
        budget_impressions_cnt,
        click_cnt,
        completed_listens_cnt,
        completed_views_cnt,
        frequency_cap_txt,
        impression_cnt,
        last_delivery_update_ts,
        last_submit_dt,
        last_submit_status_cd,
        ad_platform_line_item_id,
        media_cost_amt,
        selected_targeting_txt,
        total_conversion_cnt,
        video_view_cnt,
        viewed_impression_cnt,
        ecpm_amt,
        bid_strategy_cd,
        daily_budget_amt,
        end_ts,
        optimization_strategy_cd,
        start_ts,
        min_margin_pct,
        optimization_method_cd,
        optimization_value_amt,
        prefer_delivery_over_perf_ind,
        revenue_type_cd,
        revenue_value_amt,
        audience_id,
        billable_event_cd,
        daily_budget_impressions_cnt,
        creative_id,
        creative_type_cd,
        inventory_id,
        max_bid_amt,
        position_nbr,
        pricing_type_cd,
        ad_size_txt,
        tag_type_cd,
        additional_item_id,
        country_cd,
        external_item_status_cd,
        external_ref_nbr,
        landing_page_url_txt,
        language_cd,
        last_status_update_ts,
        media_category_type_cd,
        creative_cnt,
        unit_cnt,
        pacing_cd,
        placement_cd,
        price_rate_amt,
        priority_nbr,
        target_platform_cd,
        unit_type_cd,
        one_imp_per_page_ind,
        pacing_value_amt,
        monthly_budget_amt,
        cpc_amt,
        line_item_type_cd,
        neg_broad_match_kw_txt,
        neg_exact_match_kw_txt,
        pos_exact_match_kw_txt,
        retailer_nm,
        trafficker_nm,
        unlimited_budget_ind,
        ad_platform_line_item_url_txt,
        buying_item_ext_nm,
        external_feature_id,
        feature_id,
        ad_postal_codes_txt,
        advanced_settings_txt,
        avg_goal_cpm_amt,
        viewability_targeting_cd,
        external_order_id,
        freq_cap_duration_hr,
        freq_cap_cnt,
        source_application_cd,
        CURRENT_TIMESTAMP() AS dw_create_ts,
        CURRENT_TIMESTAMP() AS dw_last_update_ts,
        FALSE AS dw_logical_delete_ind,
        'OMS' AS dw_source_create_nm,
        'OMS' AS dw_source_update_nm,
        CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN TRUE ELSE FALSE END AS dw_current_version_ind
        FROM 
        (
        SELECT
         id  as buying_line_item_id
        ,advendio_buying_order_c  as buying_insertion_order_id
        ,advendio_campaign_item_c  as media_campaign_line_item_id
        ,advendio_end_date_c  as end_dt
        ,advendio_media_format_c  as media_format_cd
        ,advendio_start_date_c  as start_dt
        ,advendio_status_c as status_nm
        ,created_by_id  as source_created_by_id
        ,created_date  as source_created_ts
        ,is_deleted  as deleted_ind
        ,last_modified_by_id  as source_last_modified_by_id
        ,last_modified_date  as source_last_modified_ts
        ,name  as buying_line_item_nm
        ,system_modstamp  as system_mod_ts
        ,currency_iso_code  as currency_iso_cd
        ,record_type_id  as record_type_id
        ,last_activity_date  as last_activity_dt
        ,last_viewed_date  as last_viewed_dt
        ,last_referenced_date as last_referenced_dt
        ,cast(null as string) as user_record_access_id
        ,cast(advendio_bid_amount_c as numeric)  as bid_amt
        ,cast(advendio_budget_amount_c as numeric) as budget_amt
        ,advendio_budget_impressions_c  as budget_impressions_cnt
        ,advendio_clicks_c  as click_cnt
        ,advendio_completed_listens_c  as completed_listens_cnt
        ,advendio_completed_views_c  as completed_views_cnt
        ,advendio_frequency_capping_c  as frequency_cap_txt
        ,advendio_impressions_c  as impression_cnt
        ,advendio_last_delivery_update_c  as last_delivery_update_ts
        ,advendio_last_submit_date_c  as last_submit_dt
        ,advendio_last_submit_status_c  as last_submit_status_cd
        ,advendio_line_item_id_c  as ad_platform_line_item_id
        ,cast(advendio_media_cost_c as numeric)  as media_cost_amt
        ,advendio_selected_targeting_c  as selected_targeting_txt
        ,advendio_total_conversions_c  as total_conversion_cnt
        ,advendio_video_views_c  as video_view_cnt
        ,advendio_viewed_impressions_c  as viewed_impression_cnt
        ,cast(advendio_e_cpm_c as numeric) as ecpm_amt
        ,advendio_bid_strategy_c  as bid_strategy_cd
        ,cast(advendio_budget_amount_daily_c as numeric)  as daily_budget_amt
        ,advendio_end_time_c  as end_ts
        ,advendio_optimization_strategy_c  as optimization_strategy_cd
        ,advendio_start_time_c  as start_ts
        ,advendio_min_margin_pct_c  as min_margin_pct
        ,advendio_optimization_method_c  as optimization_method_cd
        ,cast(advendio_optimization_value_c as numeric)  as optimization_value_amt
        ,advendio_prefer_delivery_over_performance_c  as prefer_delivery_over_perf_ind
        ,advendio_revenue_type_c  as revenue_type_cd
        ,cast(advendio_revenue_value_c as numeric) as revenue_value_amt
        ,advendio_audience_ids_c  as audience_id
        ,advendio_billable_event_c  as billable_event_cd
        ,advendio_budget_impression_daily_c  as daily_budget_impressions_cnt
        ,advendio_creative_ids_c  as creative_id
        ,advendio_creative_type_c  as creative_type_cd
        ,advendio_inventory_ids_c  as inventory_id
        ,cast(advendio_max_bid_c as numeric)  as max_bid_amt
        ,advendio_position_number_c  as position_nbr
        ,advendio_pricing_type_c  as pricing_type_cd
        ,advendio_size_c  as ad_size_txt
        ,advendio_tag_types_c  as tag_type_cd
        ,advendio_additional_item_ids_c  as additional_item_id
        ,advendio_country_c  as country_cd
        ,advendio_external_item_status_c  as external_item_status_cd
        ,advendio_external_reference_no_c  as external_ref_nbr
        ,advendio_landing_page_url_c  as landing_page_url_txt
        ,advendio_language_c  as language_cd
        ,advendio_last_status_update_c  as last_status_update_ts
        ,advendio_media_or_category_type_c  as media_category_type_cd
        ,advendio_number_of_creatives_c  as creative_cnt
        ,advendio_number_of_units_c  as unit_cnt
        ,advendio_pacing_c  as pacing_cd
        ,advendio_placement_c  as placement_cd
        ,cast(advendio_price_rate_c as numeric) as price_rate_amt
        ,advendio_priority_c  as priority_nbr
        ,advendio_target_platform_c  as target_platform_cd
        ,advendio_unit_type_c  as unit_type_cd
        ,advendio_one_imp_per_page_c  as one_imp_per_page_ind
        ,cast(advendio_pacing_value_c as numeric) as pacing_value_amt
        ,cast(advendio_budget_amount_monthly_c as numeric) as monthly_budget_amt
        ,cast(advendio_cpc_c as numeric) as cpc_amt
        ,advendio_line_item_type_c  as line_item_type_cd
        ,advendio_negative_broad_match_c  as neg_broad_match_kw_txt
        ,advendio_negative_exact_match_c  as neg_exact_match_kw_txt
        ,advendio_positive_exact_match_c  as pos_exact_match_kw_txt
        ,advendio_retailer_c  as retailer_nm
        ,advendio_trafficker_c  as trafficker_nm
        ,advendio_unlimited_budget_c  as unlimited_budget_ind
        ,line_item_id_c  as ad_platform_line_item_url_txt
        ,advendio_buying_item_extended_name_c  as buying_item_ext_nm
        ,advendio_external_feature_identifier_c  as external_feature_id
        ,advendio_feature_identifier_c  as feature_id
        ,advendio_ad_postal_codes_c  as ad_postal_codes_txt
        ,advendio_advanced_settings_c  as advanced_settings_txt
        ,cast(advendio_avg_goal_cpm_c as numeric) as avg_goal_cpm_amt
        ,advendio_viewability_targeting_c  as viewability_targeting_cd
        ,external_order_id_c  as external_order_id
        ,frequency_cap_duration_c  as freq_cap_duration_hr
        ,frequency_cap_c as freq_cap_cnt
        ,'OMS' AS source_application_cd 
        ,CAST(last_modified_date AS TIMESTAMP) AS dw_first_effective_ts
        ,LAST_VALUE(last_modified_date) OVER (record_window) AS dw_last_effective_ts       
        FROM %s
        WHERE 1=1
        AND _fivetran_synced >= %T AND _fivetran_synced < %T
        AND is_deleted = FALSE
        AND last_modified_date IS NOT NULL
        WINDOW  record_window AS (PARTITION BY id ORDER BY last_modified_date ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        )  
      ) t
        --remove incoming records where the dw_first_effective_ts is earlier than the current version's dw_first_effective_ts in production
        LEFT JOIN %s p
        ON      p.buying_line_item_id = t.buying_line_item_id
        AND     p.source_application_cd = t.source_application_cd
        AND     p.dw_current_version_ind = TRUE
        WHERE   p.buying_line_item_id IS NULL
        OR      t.dw_first_effective_ts > p.dw_first_effective_ts
""",tgt_wrk_tbl,src_tbl,data_extract_start_ts,data_extract_end_ts,tgt_tbl);

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET sql_truncate_lr_tbl = '''TRUNCATE TABLE ''' || lr_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_lr_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of load read table "|| lr_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END; 

-- RECORDS TO EXPIRE
SET buying_line_item_records_expire = FORMAT("""
      INSERT INTO %s
      (
        buying_line_item_id,
        source_application_cd,
        dw_first_effective_ts,
        dw_last_effective_ts,
        dw_current_version_ind
      )
        SELECT  
        p.buying_line_item_id,
        p.source_application_cd,
        p.dw_first_effective_ts,
        TIMESTAMP_SUB(t.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts,
        FALSE AS dw_current_version_ind
        FROM    %s p
        INNER   JOIN (
        SELECT *
        FROM    %s
        QUALIFY ROW_NUMBER() OVER (PARTITION BY buying_line_item_id, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
        ) t
        ON     t.buying_line_item_id = p.buying_line_item_id
        AND    t.source_application_cd = p.source_application_cd
        WHERE  p.dw_current_version_ind = TRUE
         """,lr_tbl,tgt_tbl,tgt_wrk_tbl);

  
--FINAL UPDATE TARGET TABLE
SET buying_line_item_final_update = FORMAT("""
      UPDATE  %s p
      SET  dw_last_effective_ts = t.dw_last_effective_ts,
      dw_current_version_ind = FALSE,
      dw_last_update_ts = CURRENT_TIMESTAMP,
      dw_source_update_nm = 'OMS'
      FROM    %s t
      WHERE   t.buying_line_item_id = p.buying_line_item_id
      AND     t.source_application_cd = p.source_application_cd
      AND     t.dw_first_effective_ts = p.dw_first_effective_ts
      """,tgt_tbl,lr_tbl);

--FINAL INSERT TARGET TABLE
SET buying_line_item_final_insert = FORMAT("""
      INSERT  INTO %s
      (
        buying_line_item_id,
        dw_first_effective_ts,
        dw_last_effective_ts,
        buying_insertion_order_id,
        media_campaign_line_item_id,
        end_dt,
        media_format_cd,
        start_dt,
        status_nm,
        source_created_by_id,
        source_created_ts,
        deleted_ind,
        source_last_modified_by_id,
        source_last_modified_ts,
        buying_line_item_nm,
        system_mod_ts,
        currency_iso_cd,
        record_type_id,
        last_activity_dt,
        last_viewed_dt,
        last_referenced_dt,
        user_record_access_id,
        bid_amt,
        budget_amt,
        budget_impressions_cnt,
        click_cnt,
        completed_listens_cnt,
        completed_views_cnt,
        frequency_cap_txt,
        impression_cnt,
        last_delivery_update_ts,
        last_submit_dt,
        last_submit_status_cd,
        ad_platform_line_item_id,
        media_cost_amt,
        selected_targeting_txt,
        total_conversion_cnt,
        video_view_cnt,
        viewed_impression_cnt,
        ecpm_amt,
        bid_strategy_cd,
        daily_budget_amt,
        end_ts,
        optimization_strategy_cd,
        start_ts,
        min_margin_pct,
        optimization_method_cd,
        optimization_value_amt,
        prefer_delivery_over_perf_ind,
        revenue_type_cd,
        revenue_value_amt,
        audience_id,
        billable_event_cd,
        daily_budget_impressions_cnt,
        creative_id,
        creative_type_cd,
        inventory_id,
        max_bid_amt,
        position_nbr,
        pricing_type_cd,
        ad_size_txt,
        tag_type_cd,
        additional_item_id,
        country_cd,
        external_item_status_cd,
        external_ref_nbr,
        landing_page_url_txt,
        language_cd,
        last_status_update_ts,
        media_category_type_cd,
        creative_cnt,
        unit_cnt,
        pacing_cd,
        placement_cd,
        price_rate_amt,
        priority_nbr,
        target_platform_cd,
        unit_type_cd,
        one_imp_per_page_ind,
        pacing_value_amt,
        monthly_budget_amt,
        cpc_amt,
        line_item_type_cd,
        neg_broad_match_kw_txt,
        neg_exact_match_kw_txt,
        pos_exact_match_kw_txt,
        retailer_nm,
        trafficker_nm,
        unlimited_budget_ind,
        ad_platform_line_item_url_txt,
        buying_item_ext_nm,
        external_feature_id,
        feature_id,
        ad_postal_codes_txt,
        advanced_settings_txt,
        avg_goal_cpm_amt,
        viewability_targeting_cd,
        external_order_id,
        freq_cap_duration_hr,
        freq_cap_cnt,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind
      ) 
      SELECT  
        buying_line_item_id,
        dw_first_effective_ts,
        dw_last_effective_ts,
        buying_insertion_order_id,
        media_campaign_line_item_id,
        end_dt,
        media_format_cd,
        start_dt,
        status_nm,
        source_created_by_id,
        source_created_ts,
        deleted_ind,
        source_last_modified_by_id,
        source_last_modified_ts,
        buying_line_item_nm,
        system_mod_ts,
        currency_iso_cd,
        record_type_id,
        last_activity_dt,
        last_viewed_dt,
        last_referenced_dt,
        user_record_access_id,
        bid_amt,
        budget_amt,
        budget_impressions_cnt,
        click_cnt,
        completed_listens_cnt,
        completed_views_cnt,
        frequency_cap_txt,
        impression_cnt,
        last_delivery_update_ts,
        last_submit_dt,
        last_submit_status_cd,
        ad_platform_line_item_id,
        media_cost_amt,
        selected_targeting_txt,
        total_conversion_cnt,
        video_view_cnt,
        viewed_impression_cnt,
        ecpm_amt,
        bid_strategy_cd,
        daily_budget_amt,
        end_ts,
        optimization_strategy_cd,
        start_ts,
        min_margin_pct,
        optimization_method_cd,
        optimization_value_amt,
        prefer_delivery_over_perf_ind,
        revenue_type_cd,
        revenue_value_amt,
        audience_id,
        billable_event_cd,
        daily_budget_impressions_cnt,
        creative_id,
        creative_type_cd,
        inventory_id,
        max_bid_amt,
        position_nbr,
        pricing_type_cd,
        ad_size_txt,
        tag_type_cd,
        additional_item_id,
        country_cd,
        external_item_status_cd,
        external_ref_nbr,
        landing_page_url_txt,
        language_cd,
        last_status_update_ts,
        media_category_type_cd,
        creative_cnt,
        unit_cnt,
        pacing_cd,
        placement_cd,
        price_rate_amt,
        priority_nbr,
        target_platform_cd,
        unit_type_cd,
        one_imp_per_page_ind,
        pacing_value_amt,
        monthly_budget_amt,
        cpc_amt,
        line_item_type_cd,
        neg_broad_match_kw_txt,
        neg_exact_match_kw_txt,
        pos_exact_match_kw_txt,
        retailer_nm,
        trafficker_nm,
        unlimited_budget_ind,
        ad_platform_line_item_url_txt,
        buying_item_ext_nm,
        external_feature_id,
        feature_id,
        ad_postal_codes_txt,
        advanced_settings_txt,
        avg_goal_cpm_amt,
        viewability_targeting_cd,
        external_order_id,
        freq_cap_duration_hr,
        freq_cap_cnt,
        source_application_cd,
        CURRENT_TIMESTAMP() AS dw_create_ts,
        CURRENT_TIMESTAMP() AS dw_last_update_ts,
        FALSE AS dw_logical_delete_ind,
        'OMS' AS dw_source_create_nm,
        'OMS' AS dw_source_update_nm,
        dw_current_version_ind
        FROM   %s
      """,tgt_tbl,tgt_wrk_tbl);

BEGIN
EXECUTE IMMEDIATE (sql_begin); 
EXECUTE IMMEDIATE (buying_line_item_records_expire);
EXECUTE IMMEDIATE (buying_line_item_final_update);
EXECUTE IMMEDIATE (buying_line_item_final_insert);
SET record_count = @@row_count;

EXECUTE IMMEDIATE (sql_commit);
SET row_count = row_count + record_count;

EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET status  = "COMPLETED";
SET job_end = CURRENT_TIMESTAMP();
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('OMS','CONFIRMED',CURRENT_DATE(),"BUYING_LINE_ITEM");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;