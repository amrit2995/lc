CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_OMS_MEDIA_CAMPAIGN_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_lr_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE lr_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE oms_media_campaign_records_expire string;
DECLARE oms_media_campaign_final_update string;
DECLARE oms_media_campaign_final_insert string;



SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_OMS_MEDIA_CAMPAIGN_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.OMS_MEDIA_CAMPAIGN';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_MEDIA_CAMPAIGN_WRK';        
SET src_tbl         = '<<EMFI_PROJECT_ID>>.<<EMFI_DATASET>>.advendio_media_campaign_c';
SET lr_tbl          = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_MEDIA_CAMPAIGN_LR_INSERT_UPDATE';

IF DATE(max_audit_ts) = '0001-01-01' THEN
  EXECUTE IMMEDIATE ('''TRUNCATE TABLE ''' || tgt_tbl);
END IF;

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = FORMAT("""
      INSERT INTO %s
			(
        media_campaign_id,
        dw_first_effective_ts,
        dw_last_effective_ts,
        campaign_item_nbr,
        ad_server_nm,
        ad_server_order_id,
        ad_server_order_1_id,
        account_id,
        ad_manager_status_nm,
        ad_server_order_type_nm,
        ad_server_status_nm,
        advertised_brand_nm,
        agency_nm,
        billing_status_nm,
        bill_me_ind,
        budget_amt,
        campaign_end_dt,
        campaign_start_dt,
        close_dt,
        campaign_dsc,
        document_type_nm,
        invoice_recipient_nm,
        invoice_email_cc_txt,
        invoice_preference_txt,
        legal_entity_id,
        media_campaign_nbr,
        payment_due_date_txt,
        payment_interval_txt,
        payment_processing_type_nm,
        payment_start_txt,
        payment_terms_txt,
        payment_terms_dsc,
        pricelist_txt,
        quote_preference_id,
        reason_for_refusal_txt,
        stage_status_nm,
        terms_of_payment_txt,
        transaction_type_nm,
        reference_number_2_id,
        agency_insertion_order_ind,
        albertsons_division_nm,
        app_landing_page_url_txt, 
        banner_nm,
        campaign_line_item_total_amt,
        category_list_txt,
        category_nm,
        source_created_by_id,
        source_created_ts,
        currency_iso_cd,
        custom_landing_page_ind,
        divisional_co_branded_ind,
        hub_campaign_id,
        deleted_ind ,
        source_last_modified_by_id,
        source_last_modified_ts,
        live_dt,
        media_planning_stage_txt,
        media_campaign_nm,
        objectives_txt,
        opportunity_id,
        platform_nm,
        primary_ind,
        primary_kpi_dsc,
        probability_pct,
        record_type_id,
        secondary_kpi_dsc,
        show_detailed_information_ind,
        system_modstamp_ts,
        tactic_txt,
        verbal_commitment_txt,
        web_landing_page_url_txt,
        third_party_tagging_ind,
        third_party_vendor_list_txt,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind
      )
        SELECT  t.*
        FROM    
      (
        SELECT 
        media_campaign_id
        ,dw_first_effective_ts
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN '9999-12-31 00:00:00' ELSE TIMESTAMP_SUB(dw_last_effective_ts, INTERVAL 1 SECOND) END AS dw_last_effective_ts
        ,campaign_item_nbr
        ,ad_server_nm
        ,ad_server_order_id
        ,ad_server_order_1_id
        ,account_id
        ,ad_manager_status_nm
        ,ad_server_order_type_nm
        ,ad_server_status_nm
        ,advertised_brand_nm
        ,agency_nm
        ,billing_status_nm
        ,bill_me_ind
        ,budget_amt
        ,campaign_end_dt
        ,campaign_start_dt
        ,close_dt
        ,campaign_dsc
        ,document_type_nm
        ,invoice_recipient_nm
        ,invoice_email_cc_txt
        ,invoice_preference_txt
        ,legal_entity_id
        ,media_campaign_nbr
        ,payment_due_date_txt
        ,payment_interval_txt
        ,payment_processing_type_nm
        ,payment_start_txt
        ,payment_terms_txt
        ,payment_terms_dsc
        ,pricelist_txt
        ,quote_preference_id
        ,reason_for_refusal_txt
        ,stage_status_nm
        ,terms_of_payment_txt
        ,transaction_type_nm
        ,reference_number_2_id
        ,agency_insertion_order_ind
        ,albertsons_division_nm
        ,app_landing_page_url_txt
        ,banner_nm
        ,campaign_line_item_total_amt
        ,category_list_txt
        ,category_nm
        ,source_created_by_id
        ,source_created_ts
        ,currency_iso_cd
        ,custom_landing_page_ind
        ,divisional_co_branded_ind
        ,hub_campaign_id
        ,deleted_ind 
        ,source_last_modified_by_id
        ,source_last_modified_ts
        ,live_dt
        ,media_planning_stage_txt
        ,media_campaign_nm
        ,objectives_txt
        ,opportunity_id
        ,platform_nm
        ,primary_ind
        ,primary_kpi_dsc
        ,probability_pct
        ,record_type_id
        ,secondary_kpi_dsc
        ,show_detailed_information_ind
        ,system_modstamp_ts
        ,tactic_txt
        ,verbal_commitment_txt
        ,web_landing_page_url_txt
        ,third_party_tagging_ind
        ,third_party_vendor_list_txt
        ,source_application_cd
        ,CURRENT_TIMESTAMP() AS dw_create_ts
        ,CURRENT_TIMESTAMP() AS dw_last_update_ts
        ,FALSE AS dw_logical_delete_ind
        ,'OMS' AS dw_source_create_nm
        ,'OMS' AS dw_source_update_nm
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN TRUE ELSE FALSE END AS dw_current_version_ind
        FROM
        (
        SELECT 
        id AS MEDIA_CAMPAIGN_ID  
        ,absolute_campaign_item_number_c  AS CAMPAIGN_ITEM_NBR
        ,advendio_adserver_name_c  AS AD_SERVER_NM 
        ,adserver_order_id_c  AS AD_SERVER_ORDER_ID  
        ,adserver_order_id_1_c AS AD_SERVER_ORDER_1_ID
        ,advendio_account_c  AS ACCOUNT_ID 
        ,advendio_ad_manager_status_c  AS AD_MANAGER_STATUS_NM
        ,advendio_ad_server_order_type_c  AS AD_SERVER_ORDER_TYPE_NM
        ,advendio_adserver_status_c  AS AD_SERVER_STATUS_NM
        ,advendio_advertised_brand_c  AS ADVERTISED_BRAND_NM 
        ,advendio_agency_c  AS AGENCY_NM
        ,advendio_billing_status_c  AS BILLING_STATUS_NM
        ,advendio_bill_me_c  AS BILL_ME_IND 
        ,ROUND(CAST(advendio_budget_c AS NUMERIC),2) AS BUDGET_AMT  
        ,advendio_campaign_end_date_c  AS CAMPAIGN_END_DT 
        ,advendio_campaign_start_date_c  AS CAMPAIGN_START_DT
        ,advendio_close_date_c  AS CLOSE_DT 
        ,advendio_description_c  AS CAMPAIGN_DSC
        ,advendio_document_type_c  AS DOCUMENT_TYPE_NM
        ,advendio_invoice_recipient_c  AS INVOICE_RECIPIENT_NM
        ,advendio_invoice_email_cc_c  AS INVOICE_EMAIL_CC_TXT
        ,advendio_invoice_preference_c  AS INVOICE_PREFERENCE_TXT
        ,advendio_legal_entity_c  AS LEGAL_ENTITY_ID
        ,advendio_media_campaign_number_c  AS MEDIA_CAMPAIGN_NBR
        ,advendio_payment_due_date_c  AS PAYMENT_DUE_DATE_TXT
        ,advendio_payment_interval_c  AS PAYMENT_INTERVAL_TXT
        ,advendio_payment_processing_c  AS PAYMENT_PROCESSING_TYPE_NM
        ,advendio_payment_start_c  AS PAYMENT_START_TXT
        ,advendio_payment_terms_c  AS PAYMENT_TERMS_TXT 
        ,advendio_payment_terms_long_c  AS PAYMENT_TERMS_DSC
        ,advendio_pricelist_c  AS PRICELIST_TXT 
        ,advendio_quote_preference_c  AS QUOTE_PREFERENCE_ID
        ,advendio_reason_for_refusal_c  AS REASON_FOR_REFUSAL_TXT
        ,advendio_stage_c  AS STAGE_STATUS_NM
        ,advendio_terms_of_payment_c  AS TERMS_OF_PAYMENT_TXT 
        ,advendio_transaction_type_c  AS TRANSACTION_TYPE_NM
        ,advendio_your_reference_number_2_c AS REFERENCE_NUMBER_2_ID 
        ,agency_io_c  AS AGENCY_INSERTION_ORDER_IND
        ,albertsons_divisions_c  AS ALBERTSONS_DIVISION_NM 
        ,app_landing_page_c  AS APP_LANDING_PAGE_URL_TXT 
        ,banners_c  AS BANNER_NM
        ,ROUND(CAST(campaign_line_item_total_c AS NUMERIC),2) AS CAMPAIGN_LINE_ITEM_TOTAL_AMT  
        ,categories_c  AS CATEGORY_LIST_TXT 
        ,category_c  AS CATEGORY_NM 
        ,created_by_id  AS SOURCE_CREATED_BY_ID
        ,created_date  AS SOURCE_CREATED_TS 
        ,currency_iso_code  AS CURRENCY_ISO_CD 
        ,custom_landing_page_c  AS CUSTOM_LANDING_PAGE_IND
        ,divisional_co_branded_c  AS DIVISIONAL_CO_BRANDED_IND 
        ,hub_campaign_id_c  AS HUB_CAMPAIGN_ID
        ,is_deleted  AS DELETED_IND 
        ,last_modified_by_id  AS SOURCE_LAST_MODIFIED_BY_ID
        ,last_modified_date  AS SOURCE_LAST_MODIFIED_TS
        ,live_date_c AS LIVE_DT
        ,media_planning_stages_c  AS MEDIA_PLANNING_STAGE_TXT
        ,name  AS MEDIA_CAMPAIGN_NM
        ,objectives_c  AS OBJECTIVES_TXT 
        ,opportunity_c  AS OPPORTUNITY_ID 
        ,platform_c  AS PLATFORM_NM
        ,primary_c  AS PRIMARY_IND
        ,primary_kpi_c  AS PRIMARY_KPI_DSC 
        ,probability_percent_c AS PROBABILITY_PCT 
        ,record_type_id  AS RECORD_TYPE_ID  
        ,secondary_kpi_c  AS SECONDARY_KPI_DSC 
        ,show_detailed_information_c  AS SHOW_DETAILED_INFORMATION_IND 
        ,system_modstamp  AS SYSTEM_MODSTAMP_TS 
        ,tactic_c  AS TACTIC_TXT
        ,verbal_commitment_c  AS VERBAL_COMMITMENT_TXT
        ,web_landing_page_c  AS WEB_LANDING_PAGE_URL_TXT
        ,x_3_p_tagging_c  AS THIRD_PARTY_TAGGING_IND
        ,x_3_p_vendors_multi_select_c AS THIRD_PARTY_VENDOR_LIST_TXT
        ,CAST(last_modified_date AS TIMESTAMP) AS dw_first_effective_ts
        ,LAST_VALUE(last_modified_date) OVER (record_window) AS dw_last_effective_ts
        ,'OMS' AS SOURCE_APPLICATION_CD 
        FROM %s 
        WHERE 1=1
        AND _fivetran_synced >= %T AND _fivetran_synced < %T
        AND is_deleted = FALSE
        AND last_modified_date IS NOT NULL
        WINDOW  record_window AS (PARTITION BY id ORDER BY last_modified_date ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        )
      ) t
        --remove incoming records where the dw_first_effective_ts is earlier than the current version's dw_first_effective_ts in production
        LEFT JOIN %s p
        ON      p.media_campaign_id = t.media_campaign_id
        AND     p.source_application_cd = t.source_application_cd
        AND     p.dw_current_version_ind = TRUE
        WHERE   p.media_campaign_id IS NULL
        OR      t.dw_first_effective_ts > p.dw_first_effective_ts
""",tgt_wrk_tbl,src_tbl,data_extract_start_ts,data_extract_end_ts,tgt_tbl
  );

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET sql_truncate_lr_tbl = '''TRUNCATE TABLE ''' || lr_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_lr_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of load read table "|| lr_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END; 

-- RECORDS TO EXPIRE
SET oms_media_campaign_records_expire = FORMAT("""
      INSERT INTO %s
      (
        media_campaign_id,
        source_application_cd,
        dw_first_effective_ts,
        dw_last_effective_ts,
        dw_current_version_ind
      )
        SELECT  
        p.media_campaign_id,
        p.source_application_cd,
        p.dw_first_effective_ts,
        TIMESTAMP_SUB(t.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts,
        FALSE AS dw_current_version_ind
        FROM    %s p
        INNER   JOIN (
        SELECT *
        FROM    %s
        QUALIFY ROW_NUMBER() OVER (PARTITION BY media_campaign_id, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
        ) t
        ON     t.media_campaign_id = p.media_campaign_id
        AND    t.source_application_cd = p.source_application_cd
        WHERE  p.dw_current_version_ind = TRUE
         """,lr_tbl,tgt_tbl,tgt_wrk_tbl);

  
--FINAL UPDATE TARGET TABLE
SET oms_media_campaign_final_update = FORMAT("""
      UPDATE  %s p
      SET  dw_last_effective_ts = t.dw_last_effective_ts,
      dw_current_version_ind = FALSE,
      dw_last_update_ts = CURRENT_TIMESTAMP,
      dw_source_update_nm = 'OMS'
      FROM    %s t
      WHERE   t.media_campaign_id = p.media_campaign_id
      AND     t.source_application_cd = p.source_application_cd
      AND     t.dw_first_effective_ts = p.dw_first_effective_ts
      """,tgt_tbl,lr_tbl);

--FINAL INSERT TARGET TABLE
SET oms_media_campaign_final_insert = FORMAT("""
      INSERT  INTO %s
      (
        media_campaign_id,
        dw_first_effective_ts,
        dw_last_effective_ts,
        campaign_item_nbr,
        ad_server_nm,
        ad_server_order_id,
        ad_server_order_1_id,
        account_id,
        ad_manager_status_nm,
        ad_server_order_type_nm,
        ad_server_status_nm,
        advertised_brand_nm,
        agency_nm,
        billing_status_nm,
        bill_me_ind,
        budget_amt,
        campaign_end_dt,
        campaign_start_dt,
        close_dt,
        campaign_dsc,
        document_type_nm,
        invoice_recipient_nm,
        invoice_email_cc_txt,
        invoice_preference_txt,
        legal_entity_id,
        media_campaign_nbr,
        payment_due_date_txt,
        payment_interval_txt,
        payment_processing_type_nm,
        payment_start_txt,
        payment_terms_txt,
        payment_terms_dsc,
        pricelist_txt,
        quote_preference_id,
        reason_for_refusal_txt,
        stage_status_nm,
        terms_of_payment_txt,
        transaction_type_nm,
        reference_number_2_id,
        agency_insertion_order_ind,
        albertsons_division_nm,
        app_landing_page_url_txt, 
        banner_nm,
        campaign_line_item_total_amt,
        category_list_txt,
        category_nm,
        source_created_by_id,
        source_created_ts,
        currency_iso_cd,
        custom_landing_page_ind,
        divisional_co_branded_ind,
        hub_campaign_id,
        deleted_ind ,
        source_last_modified_by_id,
        source_last_modified_ts,
        live_dt,
        media_planning_stage_txt,
        media_campaign_nm,
        objectives_txt,
        opportunity_id,
        platform_nm,
        primary_ind,
        primary_kpi_dsc,
        probability_pct,
        record_type_id,
        secondary_kpi_dsc,
        show_detailed_information_ind,
        system_modstamp_ts,
        tactic_txt,
        verbal_commitment_txt,
        web_landing_page_url_txt,
        third_party_tagging_ind,
        third_party_vendor_list_txt,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind
      ) 
      SELECT  
        media_campaign_id,
        dw_first_effective_ts,
        dw_last_effective_ts,
        campaign_item_nbr,
        ad_server_nm,
        ad_server_order_id,
        ad_server_order_1_id,
        account_id,
        ad_manager_status_nm,
        ad_server_order_type_nm,
        ad_server_status_nm,
        advertised_brand_nm,
        agency_nm,
        billing_status_nm,
        bill_me_ind,
        budget_amt,
        campaign_end_dt,
        campaign_start_dt,
        close_dt,
        campaign_dsc,
        document_type_nm,
        invoice_recipient_nm,
        invoice_email_cc_txt,
        invoice_preference_txt,
        legal_entity_id,
        media_campaign_nbr,
        payment_due_date_txt,
        payment_interval_txt,
        payment_processing_type_nm,
        payment_start_txt,
        payment_terms_txt,
        payment_terms_dsc,
        pricelist_txt,
        quote_preference_id,
        reason_for_refusal_txt,
        stage_status_nm,
        terms_of_payment_txt,
        transaction_type_nm,
        reference_number_2_id,
        agency_insertion_order_ind,
        albertsons_division_nm,
        app_landing_page_url_txt, 
        banner_nm,
        campaign_line_item_total_amt,
        category_list_txt,
        category_nm,
        source_created_by_id,
        source_created_ts,
        currency_iso_cd,
        custom_landing_page_ind,
        divisional_co_branded_ind,
        hub_campaign_id,
        deleted_ind ,
        source_last_modified_by_id,
        source_last_modified_ts,
        live_dt,
        media_planning_stage_txt,
        media_campaign_nm,
        objectives_txt,
        opportunity_id,
        platform_nm,
        primary_ind,
        primary_kpi_dsc,
        probability_pct,
        record_type_id,
        secondary_kpi_dsc,
        show_detailed_information_ind,
        system_modstamp_ts,
        tactic_txt,
        verbal_commitment_txt,
        web_landing_page_url_txt,
        third_party_tagging_ind,
        third_party_vendor_list_txt,
        source_application_cd,
        CURRENT_TIMESTAMP() AS dw_create_ts,
        CURRENT_TIMESTAMP() AS dw_last_update_ts,
        FALSE AS dw_logical_delete_ind,
        'OMS' AS dw_source_create_nm,
        'OMS' AS dw_source_update_nm,
        dw_current_version_ind
        FROM   %s
      """,tgt_tbl,tgt_wrk_tbl);

BEGIN
EXECUTE IMMEDIATE (sql_begin); 
EXECUTE IMMEDIATE (oms_media_campaign_records_expire);
EXECUTE IMMEDIATE (oms_media_campaign_final_update);
EXECUTE IMMEDIATE (oms_media_campaign_final_insert);
SET record_count = @@row_count;

EXECUTE IMMEDIATE (sql_commit);
SET row_count = row_count + record_count;

EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET status  = "COMPLETED";
SET job_end = CURRENT_TIMESTAMP();
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('OMS','CONFIRMED',CURRENT_DATE(),"OMS_MEDIA_CAMPAIGN");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;