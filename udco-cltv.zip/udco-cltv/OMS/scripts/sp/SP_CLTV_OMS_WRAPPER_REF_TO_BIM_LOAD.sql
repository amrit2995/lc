CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_OMS_WRAPPER_REF_TO_BIM_LOAD`(job_id STRING)
OPTIONS (strict_mode=false)
BEGIN

DECLARE sql_max_audit_ts STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE row_count INT64 default 0;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE max_audit_ts TIMESTAMP;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE project_id STRING ;
DECLARE prcs_audit_tbl STRING;
-- DECLARE load_type STRING;

/* Parameters taken from config */
-- SET load_type = '''FULL_LOAD''';
SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_OMS_WRAPPER_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
                    FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();
/* Audit entry for RUNNING */
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
BEGIN
CALL `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_OMS_ACCOUNT_REF_TO_BIM_LOAD`(job_id);
CALL `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_OMS_MEDIA_CAMPAIGN_REF_TO_BIM_LOAD`(job_id);
CALL `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_OMS_MEDIA_CAMPAIGN_LINE_ITEM_REF_TO_BIM_LOAD`(job_id);
CALL `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_BUYING_CAMPAIGN_REF_TO_BIM_LOAD`(job_id);
CALL `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_BUYING_INSERTION_ORDER_REF_TO_BIM_LOAD`(job_id);
CALL `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_BUYING_LINE_ITEM_REF_TO_BIM_LOAD`(job_id);

EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = 'Error executing stored procedure ' || proc_name || ' Failed with error: ' || @@error.message ;
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;
SET job_end = CURRENT_TIMESTAMP();
SET status  = 'COMPLETED';
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;
