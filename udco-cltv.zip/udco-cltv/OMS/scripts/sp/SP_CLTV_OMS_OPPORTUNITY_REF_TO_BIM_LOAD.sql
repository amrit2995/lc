CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_OMS_OPPORTUNITY_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_lr_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE lr_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE oms_opportunity_records_expire string;
DECLARE oms_opportunity_final_update string;
DECLARE oms_opportunity_final_insert string;



SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_OMS_OPPORTUNITY_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.OMS_OPPORTUNITY';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_OPPORTUNITY_WRK';        
SET src_tbl         = '<<EMFI_PROJECT_ID>>.<<EMFI_DATASET>>.opportunity';
SET lr_tbl          = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_OPPORTUNITY_LR_INSERT_UPDATE';

IF DATE(max_audit_ts) = '0001-01-01' THEN
  EXECUTE IMMEDIATE ('''TRUNCATE TABLE ''' || tgt_tbl);
END IF;

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = FORMAT("""
      INSERT INTO %s
			(
        opportunity_id
        ,dw_first_effective_ts
        ,dw_last_effective_ts
        ,deleted_ind
        ,account_id
        ,record_type_id
        ,opportunity_nm
        ,primary_commercial_amt
        ,opportunity_type_cd
        ,source_created_ts
        ,source_created_by_id
        ,source_last_modified_ts
        ,albertsons_divisions_nm
        ,annual_budget_amt
        ,planned_budget_amt
        ,campaign_start_dt
        ,campaign_end_dt
        ,client_sub_tier_nm
        ,client_tier_nm
        ,co_branded_ind
        ,hub_campaign_id
        ,parent_opportunity_id
        ,parent_ind
        ,total_line_item_budget_amt
        ,objectives_txt
        ,stage_nm
        ,brand_nm
        ,source_application_cd
        ,dw_create_ts
        ,dw_last_update_ts
        ,dw_logical_delete_ind
        ,dw_source_create_nm
        ,dw_source_update_nm
        ,dw_current_version_ind
      )
        SELECT  t.*
        FROM    
      (
        SELECT 
        opportunity_id
        ,dw_first_effective_ts
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN '9999-12-31 00:00:00' ELSE TIMESTAMP_SUB(dw_last_effective_ts, INTERVAL 1 SECOND) END AS dw_last_effective_ts
        ,deleted_ind
        ,account_id
        ,record_type_id
        ,opportunity_nm
        ,primary_commercial_amt
        ,opportunity_type_cd
        ,source_created_ts
        ,source_created_by_id
        ,source_last_modified_ts
        ,albertsons_divisions_nm
        ,annual_budget_amt
        ,planned_budget_amt
        ,campaign_start_dt
        ,campaign_end_dt
        ,client_sub_tier_nm
        ,client_tier_nm
        ,co_branded_ind
        ,hub_campaign_id
        ,parent_opportunity_id
        ,parent_ind
        ,total_line_item_budget_amt
        ,objectives_txt
        ,stage_nm
        ,brand_nm
        ,source_application_cd
        ,CURRENT_TIMESTAMP() AS dw_create_ts
        ,CURRENT_TIMESTAMP() AS dw_last_update_ts
        ,FALSE AS dw_logical_delete_ind
        ,'OMS' AS dw_source_create_nm
        ,'OMS' AS dw_source_update_nm
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN TRUE ELSE FALSE END AS dw_current_version_ind
        FROM
        (
        SELECT 
                id  AS opportunity_id
                ,is_deleted AS deleted_ind
                ,account_id AS account_id
                ,record_type_id AS record_type_id
                ,name AS opportunity_nm
                ,ROUND(CAST(amount AS NUMERIC),2) AS primary_commercial_amt
                ,type AS opportunity_type_cd
                ,created_date AS source_created_ts
                ,created_by_id AS source_created_by_id
                ,last_modified_date AS source_last_modified_ts
                ,albertsons_divisions_c AS albertsons_divisions_nm
                ,ROUND(CAST(annual_budget_c AS NUMERIC),2) AS annual_budget_amt
                ,ROUND(CAST(budget_amount_c AS NUMERIC),2) AS planned_budget_amt
                ,campaign_start_date_c AS campaign_start_dt
                ,campaign_end_date_c AS campaign_end_dt
                ,client_sub_tier_c AS client_sub_tier_nm
                ,client_tier_c AS client_tier_nm
                ,co_branded_c  AS co_branded_ind
                ,hub_campaign_id_c  AS hub_campaign_id
                ,parent_opportunity_c AS parent_opportunity_id
                ,is_parent_c AS parent_ind
                ,ROUND(CAST(total_line_item_budget_c AS NUMERIC),2) AS total_line_item_budget_amt
                ,objectives_c AS objectives_txt
                ,stage_name AS stage_nm
                ,brand_c AS brand_nm
                ,CAST(last_modified_date AS TIMESTAMP) AS dw_first_effective_ts
                ,LAST_VALUE(last_modified_date) OVER (record_window) AS dw_last_effective_ts
                ,'OMS' AS source_application_cd
                FROM %s 
                WHERE 1=1
                AND _fivetran_synced >= %T AND _fivetran_synced < %T
                AND is_deleted = FALSE
                AND last_modified_date IS NOT NULL
                WINDOW  record_window AS (PARTITION BY id ORDER BY last_modified_date ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        )
      ) t
        --remove incoming records where the dw_first_effective_ts is earlier than the current version's dw_first_effective_ts in production
        LEFT JOIN %s p
        ON      p.opportunity_id = t.opportunity_id
        AND     p.source_application_cd = t.source_application_cd
        AND     p.dw_current_version_ind = TRUE
        WHERE   p.opportunity_id IS NULL
        OR      t.dw_first_effective_ts > p.dw_first_effective_ts
""",tgt_wrk_tbl,src_tbl,data_extract_start_ts,data_extract_end_ts,tgt_tbl
  );

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET sql_truncate_lr_tbl = '''TRUNCATE TABLE ''' || lr_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_lr_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of load read table "|| lr_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END; 

-- RECORDS TO EXPIRE
SET oms_opportunity_records_expire = FORMAT("""
      INSERT INTO %s
      (
        opportunity_id,
        source_application_cd,
        dw_first_effective_ts,
        dw_last_effective_ts,
        dw_current_version_ind
      )
        SELECT  
        p.opportunity_id,
        p.source_application_cd,
        p.dw_first_effective_ts,
        TIMESTAMP_SUB(t.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts,
        FALSE AS dw_current_version_ind
        FROM    %s p
        INNER   JOIN (
        SELECT *
        FROM    %s
        QUALIFY ROW_NUMBER() OVER (PARTITION BY opportunity_id, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
        ) t
        ON     t.opportunity_id = p.opportunity_id
        AND    t.source_application_cd = p.source_application_cd
        WHERE  p.dw_current_version_ind = TRUE
         """,lr_tbl,tgt_tbl,tgt_wrk_tbl);

  
--FINAL UPDATE TARGET TABLE
SET oms_opportunity_final_update = FORMAT("""
      UPDATE  %s p
      SET  dw_last_effective_ts = t.dw_last_effective_ts,
      dw_current_version_ind = FALSE,
      dw_last_update_ts = CURRENT_TIMESTAMP,
      dw_source_update_nm = 'OMS'
      FROM    %s t
      WHERE   t.opportunity_id = p.opportunity_id
      AND     t.source_application_cd = p.source_application_cd
      AND     t.dw_first_effective_ts = p.dw_first_effective_ts
      """,tgt_tbl,lr_tbl);

--FINAL INSERT TARGET TABLE
SET oms_opportunity_final_insert = FORMAT("""
      INSERT  INTO %s
      (
        opportunity_id
        ,dw_first_effective_ts
        ,dw_last_effective_ts
        ,deleted_ind
        ,account_id
        ,record_type_id
        ,opportunity_nm
        ,primary_commercial_amt
        ,opportunity_type_cd
        ,source_created_ts
        ,source_created_by_id
        ,source_last_modified_ts
        ,albertsons_divisions_nm
        ,annual_budget_amt
        ,planned_budget_amt
        ,campaign_start_dt
        ,campaign_end_dt
        ,client_sub_tier_nm
        ,client_tier_nm
        ,co_branded_ind
        ,hub_campaign_id
        ,parent_opportunity_id
        ,parent_ind
        ,total_line_item_budget_amt
        ,objectives_txt
        ,stage_nm
        ,brand_nm
        ,source_application_cd
        ,dw_create_ts
        ,dw_last_update_ts
        ,dw_logical_delete_ind
        ,dw_source_create_nm
        ,dw_source_update_nm
        ,dw_current_version_ind
      ) 
      SELECT  
        opportunity_id
        ,dw_first_effective_ts
        ,dw_last_effective_ts
        ,deleted_ind
        ,account_id
        ,record_type_id
        ,opportunity_nm
        ,primary_commercial_amt
        ,opportunity_type_cd
        ,source_created_ts
        ,source_created_by_id
        ,source_last_modified_ts
        ,albertsons_divisions_nm
        ,annual_budget_amt
        ,planned_budget_amt
        ,campaign_start_dt
        ,campaign_end_dt
        ,client_sub_tier_nm
        ,client_tier_nm
        ,co_branded_ind
        ,hub_campaign_id
        ,parent_opportunity_id
        ,parent_ind
        ,total_line_item_budget_amt
        ,objectives_txt
        ,stage_nm
        ,brand_nm
        ,source_application_cd
        ,CURRENT_TIMESTAMP() AS dw_create_ts
        ,CURRENT_TIMESTAMP() AS dw_last_update_ts
        ,FALSE AS dw_logical_delete_ind
        ,'OMS' AS dw_source_create_nm
        ,'OMS' AS dw_source_update_nm
        ,dw_current_version_ind
        FROM   %s
      """,tgt_tbl,tgt_wrk_tbl);

BEGIN
EXECUTE IMMEDIATE (sql_begin); 
EXECUTE IMMEDIATE (oms_opportunity_records_expire);
EXECUTE IMMEDIATE (oms_opportunity_final_update);
EXECUTE IMMEDIATE (oms_opportunity_final_insert);
SET record_count = @@row_count;

EXECUTE IMMEDIATE (sql_commit);
SET row_count = row_count + record_count;

EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET status  = "COMPLETED";
SET job_end = CURRENT_TIMESTAMP();
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('OMS','CONFIRMED',CURRENT_DATE(),"OMS_OPPORTUNITY");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;