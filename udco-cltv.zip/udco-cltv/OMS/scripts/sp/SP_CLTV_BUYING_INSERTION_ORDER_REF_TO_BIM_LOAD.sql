CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_BUYING_INSERTION_ORDER_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_lr_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE lr_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE buying_order_records_expire string;
DECLARE buying_order_final_update string;
DECLARE buying_order_final_insert string;



SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_BUYING_INSERTION_ORDER_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.BUYING_INSERTION_ORDER';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.BUYING_INSERTION_ORDER_WRK';        
SET src_tbl         = '<<EMFI_PROJECT_ID>>.<<EMFI_DATASET>>.advendio_buying_order_c';
SET lr_tbl          = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.BUYING_INSERTION_ORDER_LR_INSERT_UPDATE';

IF DATE(max_audit_ts) = '0001-01-01' THEN
  EXECUTE IMMEDIATE ('''TRUNCATE TABLE ''' || tgt_tbl);
END IF;

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = FORMAT("""
      INSERT INTO %s
			(
        buying_insertion_order_id  
        ,dw_first_effective_ts 
        ,dw_last_effective_ts    
        ,buying_campaign_id    
        ,buying_line_item_id      
        ,buying_insertion_order_campaign_id 
        ,buying_insertion_order_campaign_line_item_id   
        ,buying_insertion_order_nm 
        ,buying_insertion_order_advertiser_id        
        ,end_dt               
        ,goal_kpi_cd          
        ,goal_kpi_amt          
        ,start_dt              
        ,deleted_ind           
        ,source_last_modified_by_id   
        ,source_last_modified_ts      
        ,owner_id             
        ,system_mod_ts        
        ,currency_iso_cd      
        ,record_type_id       
        ,source_created_ts            
        ,source_created_by_id         
        ,last_activity_dt      
        ,last_viewed_dt       
        ,last_referenced_dt    
        ,user_record_access_id  
        ,budget_amt            
        ,budget_impressions_cnt  
        ,connection_id         
        ,ad_platform_campaign_id    
        ,status_cd             
        ,daily_budget_amt      
        ,budget_type_cd       
        ,order_bid_strategy_cd  
        ,order_goal_cd         
        ,order_level_budget_ind  
        ,selected_targeting_txt 
        ,daily_budget_impressions_cnt
        ,channel_cd           
        ,order_type_cd         
        ,media_cost_amt        
        ,additional_order_id  
        ,audience_id          
        ,country_cd            
        ,external_ref_nbr      
        ,inventory_media_placement_id
        ,landing_page_url_txt 
        ,language_cd  
        ,order_pacing_cd   
        ,priority_nbr    
        ,target_platform_cd  
        ,budget_nm           
        ,delivery_method_cd   
        ,campaign_po_nbr       
        ,inventory_type_cd    
        ,post_click_lookback_days 
        ,post_click_product_cd 
        ,post_view_lookback_days  
        ,post_view_product_cd 
        ,submitted_buying_item_id  
        ,monthly_budget_amt   
        ,comments_txt         
        ,insertion_order_type_txt 
        ,sales_rep_nm         
        ,trafficker_nm      
        ,unlimited_budget_ind 
        ,ad_platform_campaign_url_txt     
        ,ad_platform_insertion_order_url_txt  
        ,buying_order_ext_nm  
        ,freq_cap_rule_txt    
        ,pacing_value_amt    
        ,avg_goal_cpm_amt     
        ,goal_kpi_pct          
        ,media_campaign_id     
        ,optimization_at_order_level_ind 
        ,dv360_buying_order_formula_txt
        ,source_application_cd 
        ,dw_create_ts
        ,dw_last_update_ts
        ,dw_logical_delete_ind
        ,dw_source_create_nm
        ,dw_source_update_nm
        ,dw_current_version_ind
      )
        SELECT  t.*
        FROM    
      (
        SELECT 
        buying_insertion_order_id
        ,dw_first_effective_ts
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN '9999-12-31 00:00:00' ELSE TIMESTAMP_SUB(dw_last_effective_ts, INTERVAL 1 SECOND) END AS dw_last_effective_ts 
        ,buying_campaign_id    
        ,buying_line_item_id      
        ,buying_insertion_order_campaign_id 
        ,buying_insertion_order_campaign_line_item_id   
        ,buying_insertion_order_nm 
        ,buying_insertion_order_advertiser_id        
        ,end_dt               
        ,goal_kpi_cd          
        ,goal_kpi_amt          
        ,start_dt              
        ,deleted_ind           
        ,source_last_modified_by_id   
        ,source_last_modified_ts      
        ,owner_id             
        ,system_mod_ts        
        ,currency_iso_cd      
        ,record_type_id       
        ,source_created_ts            
        ,source_created_by_id         
        ,last_activity_dt      
        ,last_viewed_dt       
        ,last_referenced_dt    
        ,user_record_access_id  
        ,budget_amt            
        ,budget_impressions_cnt  
        ,connection_id         
        ,ad_platform_campaign_id    
        ,status_cd             
        ,daily_budget_amt      
        ,budget_type_cd       
        ,order_bid_strategy_cd  
        ,order_goal_cd         
        ,order_level_budget_ind  
        ,selected_targeting_txt 
        ,daily_budget_impressions_cnt
        ,channel_cd           
        ,order_type_cd         
        ,media_cost_amt        
        ,additional_order_id  
        ,audience_id          
        ,country_cd            
        ,external_ref_nbr      
        ,inventory_media_placement_id
        ,landing_page_url_txt 
        ,language_cd  
        ,order_pacing_cd   
        ,priority_nbr    
        ,target_platform_cd  
        ,budget_nm           
        ,delivery_method_cd   
        ,campaign_po_nbr       
        ,inventory_type_cd    
        ,post_click_lookback_days 
        ,post_click_product_cd 
        ,post_view_lookback_days  
        ,post_view_product_cd 
        ,submitted_buying_item_id  
        ,monthly_budget_amt   
        ,comments_txt         
        ,insertion_order_type_txt 
        ,sales_rep_nm         
        ,trafficker_nm      
        ,unlimited_budget_ind 
        ,ad_platform_campaign_url_txt     
        ,ad_platform_insertion_order_url_txt  
        ,buying_order_ext_nm  
        ,freq_cap_rule_txt    
        ,pacing_value_amt    
        ,avg_goal_cpm_amt     
        ,goal_kpi_pct          
        ,media_campaign_id     
        ,optimization_at_order_level_ind 
        ,dv360_buying_order_formula_txt
        ,source_application_cd 
        ,CURRENT_TIMESTAMP() AS dw_create_ts
        ,CURRENT_TIMESTAMP() AS dw_last_update_ts
        ,FALSE AS dw_logical_delete_ind
        ,'OMS' AS dw_source_create_nm
        ,'OMS' AS dw_source_update_nm
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN TRUE ELSE FALSE END AS dw_current_version_ind
        FROM 
        (
        SELECT 
        id  as buying_insertion_order_id
        ,advendio_buying_campaign_c  as buying_campaign_id
        ,campaign_item_c  as buying_line_item_id     
        ,advendio_campaign_id_c  as buying_insertion_order_campaign_id
        ,advendio_campaign_item_c as buying_insertion_order_campaign_line_item_id
        ,name  as buying_insertion_order_nm
        ,advendio_advertiser_c  as buying_insertion_order_advertiser_id
        ,advendio_end_date_c as end_dt
        ,advendio_goal_kpi_c  as goal_kpi_cd
        ,round(cast(advendio_goal_kpiamount_c as numeric),2) as goal_kpi_amt
        ,advendio_start_date_c  as start_dt
        ,is_deleted  as deleted_ind
        ,last_modified_by_id  as source_last_modified_by_id
        ,last_modified_date  as source_last_modified_ts
        ,owner_id  as owner_id
        ,system_modstamp  as system_mod_ts
        ,currency_iso_code  as currency_iso_cd
        ,record_type_id  as record_type_id
        ,created_date  as source_created_ts
        ,created_by_id  as source_created_by_id
        ,last_activity_date  as last_activity_dt
        ,last_viewed_date  as last_viewed_dt
        ,last_referenced_date  as last_referenced_dt
        ,cast(null as string) as user_record_access_id
        ,round(cast(advendio_budget_amount_c as numeric),2)  as budget_amt
        ,advendio_budget_impressions_c  as budget_impressions_cnt
        ,advendio_connection_c  as connection_id
        ,advendio_insertion_order_id_c  as ad_platform_campaign_id
        ,advendio_status_c  as status_cd
        ,round(cast(advendio_budget_amount_daily_c as numeric),2) as daily_budget_amt
        ,advendio_budget_type_c as budget_type_cd
        ,advendio_order_bid_strategy_c  as order_bid_strategy_cd
        ,advendio_order_goal_c  as order_goal_cd
        ,advendio_set_budget_order_level_c  as order_level_budget_ind
        ,advendio_selected_targeting_c  as selected_targeting_txt
        ,advendio_budget_impression_daily_c  as daily_budget_impressions_cnt
        ,advendio_channel_c  as channel_cd
        ,advendio_order_type_c  as order_type_cd
        ,round(cast(advendio_media_cost_c as numeric),2)  as media_cost_amt
        ,advendio_additional_order_ids_c  as additional_order_id
        ,advendio_audience_ids_c  as audience_id
        ,advendio_country_c  as country_cd
        ,advendio_external_reference_no_c  as external_ref_nbr
        ,advendio_inventory_media_placement_ids_c  as inventory_media_placement_id
        ,advendio_landing_page_url_c  as landing_page_url_txt
        ,advendio_language_c  as language_cd
        ,advendio_order_pacing_c  as order_pacing_cd
        ,advendio_priority_c  as priority_nbr
        ,advendio_target_platform_c  as target_platform_cd
        ,advendio_budget_name_c  as budget_nm
        ,advendio_delivery_method_c  as delivery_method_cd
        ,advendio_campaign_purchase_order_c  as campaign_po_nbr
        ,advendio_inventory_type_c  as inventory_type_cd
        ,advendio_post_click_lookback_c  as post_click_lookback_days
        ,advendio_post_click_product_c  as post_click_product_cd
        ,advendio_post_view_lookback_c  as post_view_lookback_days
        ,advendio_post_view_product_c  as post_view_product_cd
        ,advendio_submitted_buying_items_c  as submitted_buying_item_id
        ,round(cast(advendio_budget_amount_monthly_c as numeric),2) as monthly_budget_amt
        ,advendio_comments_c  as comments_txt
        ,advendio_insertion_order_type_text_c  as insertion_order_type_txt
        ,advendio_sales_rep_c  as sales_rep_nm
        ,advendio_trafficker_c  as trafficker_nm
        ,advendio_unlimited_budget_c  as unlimited_budget_ind
        ,campaign_id_c  as ad_platform_campaign_url_txt
        ,insertion_order_id_c  as ad_platform_insertion_order_url_txt
        ,advendio_buying_order_extended_name_c as buying_order_ext_nm
        ,advendio_frequency_capping_c  as freq_cap_rule_txt
        ,advendio_pacing_value_c  as pacing_value_amt
        ,round(cast(advendio_avg_goal_cpm_c as numeric),2)  as avg_goal_cpm_amt
        ,advendio_goal_kpi_percent_c  as goal_kpi_pct
        ,advendio_media_campaign_c  as media_campaign_id
        ,advendio_set_optimization_order_level_c  as optimization_at_order_level_ind
        ,dv_360_buying_order_formula_c as dv360_buying_order_formula_txt
        ,'OMS' AS source_application_cd 
        ,CAST(last_modified_date AS TIMESTAMP) AS dw_first_effective_ts
        ,LAST_VALUE(last_modified_date) OVER (record_window) AS dw_last_effective_ts
        FROM %s
        WHERE 1=1
        AND _fivetran_synced >= %T AND _fivetran_synced < %T
        AND is_deleted = FALSE
        AND last_modified_date IS NOT NULL
        WINDOW  record_window AS (PARTITION BY id ORDER BY last_modified_date ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        )  
      ) t
        --remove incoming records where the dw_first_effective_ts is earlier than the current version's dw_first_effective_ts in production
        LEFT JOIN %s p
        ON      p.buying_insertion_order_id = t.buying_insertion_order_id
        AND     p.source_application_cd = t.source_application_cd
        AND     p.dw_current_version_ind = TRUE
        WHERE   p.buying_insertion_order_id IS NULL
        OR      t.dw_first_effective_ts > p.dw_first_effective_ts
""",tgt_wrk_tbl,src_tbl,data_extract_start_ts,data_extract_end_ts,tgt_tbl);

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET sql_truncate_lr_tbl = '''TRUNCATE TABLE ''' || lr_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_lr_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of load read table "|| lr_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END; 

-- RECORDS TO EXPIRE
SET buying_order_records_expire = FORMAT("""
      INSERT INTO %s
      (
        buying_insertion_order_id,
        source_application_cd,
        dw_first_effective_ts,
        dw_last_effective_ts,
        dw_current_version_ind
      )
        SELECT  
        p.buying_insertion_order_id,
        p.source_application_cd,
        p.dw_first_effective_ts,
        TIMESTAMP_SUB(t.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts,
        FALSE AS dw_current_version_ind
        FROM    %s p
        INNER   JOIN (
        SELECT *
        FROM    %s
        QUALIFY ROW_NUMBER() OVER (PARTITION BY buying_insertion_order_id, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
        ) t
        ON     t.buying_insertion_order_id = p.buying_insertion_order_id
        AND    t.source_application_cd = p.source_application_cd
        WHERE  p.dw_current_version_ind = TRUE
         """,lr_tbl,tgt_tbl,tgt_wrk_tbl);

  
--FINAL UPDATE TARGET TABLE
SET buying_order_final_update = FORMAT("""
      UPDATE  %s p
      SET  dw_last_effective_ts = t.dw_last_effective_ts,
      dw_current_version_ind = FALSE,
      dw_last_update_ts = CURRENT_TIMESTAMP,
      dw_source_update_nm = 'OMS'
      FROM    %s t
      WHERE   t.buying_insertion_order_id = p.buying_insertion_order_id
      AND     t.source_application_cd = p.source_application_cd
      AND     t.dw_first_effective_ts = p.dw_first_effective_ts
      """,tgt_tbl,lr_tbl);

--FINAL INSERT TARGET TABLE
SET buying_order_final_insert = FORMAT("""
      INSERT  INTO %s
      (
        buying_insertion_order_id  
        ,dw_first_effective_ts 
        ,dw_last_effective_ts    
        ,buying_campaign_id    
        ,buying_line_item_id      
        ,buying_insertion_order_campaign_id 
        ,buying_insertion_order_campaign_line_item_id   
        ,buying_insertion_order_nm 
        ,buying_insertion_order_advertiser_id        
        ,end_dt               
        ,goal_kpi_cd          
        ,goal_kpi_amt          
        ,start_dt              
        ,deleted_ind           
        ,source_last_modified_by_id   
        ,source_last_modified_ts      
        ,owner_id             
        ,system_mod_ts        
        ,currency_iso_cd      
        ,record_type_id       
        ,source_created_ts            
        ,source_created_by_id         
        ,last_activity_dt      
        ,last_viewed_dt       
        ,last_referenced_dt    
        ,user_record_access_id  
        ,budget_amt            
        ,budget_impressions_cnt  
        ,connection_id         
        ,ad_platform_campaign_id    
        ,status_cd             
        ,daily_budget_amt      
        ,budget_type_cd       
        ,order_bid_strategy_cd  
        ,order_goal_cd         
        ,order_level_budget_ind  
        ,selected_targeting_txt 
        ,daily_budget_impressions_cnt
        ,channel_cd           
        ,order_type_cd         
        ,media_cost_amt        
        ,additional_order_id  
        ,audience_id          
        ,country_cd            
        ,external_ref_nbr      
        ,inventory_media_placement_id
        ,landing_page_url_txt 
        ,language_cd  
        ,order_pacing_cd   
        ,priority_nbr    
        ,target_platform_cd  
        ,budget_nm           
        ,delivery_method_cd   
        ,campaign_po_nbr       
        ,inventory_type_cd    
        ,post_click_lookback_days 
        ,post_click_product_cd 
        ,post_view_lookback_days  
        ,post_view_product_cd 
        ,submitted_buying_item_id  
        ,monthly_budget_amt   
        ,comments_txt         
        ,insertion_order_type_txt 
        ,sales_rep_nm         
        ,trafficker_nm      
        ,unlimited_budget_ind 
        ,ad_platform_campaign_url_txt     
        ,ad_platform_insertion_order_url_txt  
        ,buying_order_ext_nm  
        ,freq_cap_rule_txt    
        ,pacing_value_amt    
        ,avg_goal_cpm_amt     
        ,goal_kpi_pct          
        ,media_campaign_id     
        ,optimization_at_order_level_ind 
        ,dv360_buying_order_formula_txt
        ,source_application_cd 
        ,dw_create_ts
        ,dw_last_update_ts
        ,dw_logical_delete_ind
        ,dw_source_create_nm
        ,dw_source_update_nm
        ,dw_current_version_ind
      ) 
      SELECT  
        buying_insertion_order_id  
        ,dw_first_effective_ts 
        ,dw_last_effective_ts    
        ,buying_campaign_id    
        ,buying_line_item_id      
        ,buying_insertion_order_campaign_id 
        ,buying_insertion_order_campaign_line_item_id   
        ,buying_insertion_order_nm 
        ,buying_insertion_order_advertiser_id        
        ,end_dt               
        ,goal_kpi_cd          
        ,goal_kpi_amt          
        ,start_dt              
        ,deleted_ind           
        ,source_last_modified_by_id   
        ,source_last_modified_ts      
        ,owner_id             
        ,system_mod_ts        
        ,currency_iso_cd      
        ,record_type_id       
        ,source_created_ts            
        ,source_created_by_id         
        ,last_activity_dt      
        ,last_viewed_dt       
        ,last_referenced_dt    
        ,user_record_access_id  
        ,budget_amt            
        ,budget_impressions_cnt  
        ,connection_id         
        ,ad_platform_campaign_id    
        ,status_cd             
        ,daily_budget_amt      
        ,budget_type_cd       
        ,order_bid_strategy_cd  
        ,order_goal_cd         
        ,order_level_budget_ind  
        ,selected_targeting_txt 
        ,daily_budget_impressions_cnt
        ,channel_cd           
        ,order_type_cd         
        ,media_cost_amt        
        ,additional_order_id  
        ,audience_id          
        ,country_cd            
        ,external_ref_nbr      
        ,inventory_media_placement_id
        ,landing_page_url_txt 
        ,language_cd  
        ,order_pacing_cd   
        ,priority_nbr    
        ,target_platform_cd  
        ,budget_nm           
        ,delivery_method_cd   
        ,campaign_po_nbr       
        ,inventory_type_cd    
        ,post_click_lookback_days 
        ,post_click_product_cd 
        ,post_view_lookback_days  
        ,post_view_product_cd 
        ,submitted_buying_item_id  
        ,monthly_budget_amt   
        ,comments_txt         
        ,insertion_order_type_txt 
        ,sales_rep_nm         
        ,trafficker_nm      
        ,unlimited_budget_ind 
        ,ad_platform_campaign_url_txt     
        ,ad_platform_insertion_order_url_txt  
        ,buying_order_ext_nm  
        ,freq_cap_rule_txt    
        ,pacing_value_amt    
        ,avg_goal_cpm_amt     
        ,goal_kpi_pct          
        ,media_campaign_id     
        ,optimization_at_order_level_ind 
        ,dv360_buying_order_formula_txt
        ,source_application_cd
        ,CURRENT_TIMESTAMP() AS dw_create_ts
        ,CURRENT_TIMESTAMP() AS dw_last_update_ts
        ,FALSE AS dw_logical_delete_ind
        ,'OMS' AS dw_source_create_nm
        ,'OMS' AS dw_source_update_nm
        ,dw_current_version_ind
        FROM   %s
      """,tgt_tbl,tgt_wrk_tbl);

BEGIN
EXECUTE IMMEDIATE (sql_begin); 
EXECUTE IMMEDIATE (buying_order_records_expire);
EXECUTE IMMEDIATE (buying_order_final_update);
EXECUTE IMMEDIATE (buying_order_final_insert);
SET record_count = @@row_count;

EXECUTE IMMEDIATE (sql_commit);
SET row_count = row_count + record_count;

EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET status  = "COMPLETED";
SET job_end = CURRENT_TIMESTAMP();
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('OMS','CONFIRMED',CURRENT_DATE(),"BUYING_INSERTION_ORDER");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;