CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_BUYING_CAMPAIGN_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_lr_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE lr_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE buying_campaign_records_expire string;
DECLARE buying_campaign_final_update string;
DECLARE buying_campaign_final_insert string;



SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_BUYING_CAMPAIGN_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.BUYING_CAMPAIGN';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.BUYING_CAMPAIGN_WRK';        
SET src_tbl         = '<<EMFI_PROJECT_ID>>.<<EMFI_DATASET>>.advendio_buying_campaign_c';
SET lr_tbl          = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.BUYING_CAMPAIGN_LR_INSERT_UPDATE';

IF DATE(max_audit_ts) = '0001-01-01' THEN
  EXECUTE IMMEDIATE ('''TRUNCATE TABLE ''' || tgt_tbl);
END IF;

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = FORMAT("""
      INSERT INTO %s
			(
        buying_campaign_id
        ,dw_first_effective_ts
        ,dw_last_effective_ts
        ,owner_id
        ,buying_campaign_advertiser_id
        ,ad_platform_campaign_id  
        ,media_campaign_id  
        ,deleted_ind         
        ,buying_item_nm     
        ,currency_iso_cd      
        ,campaign_url_txt           
        ,source_created_ts    
        ,source_created_by_id  
        ,source_last_modified_ts   
        ,source_last_modified_by_id   
        ,system_mod_ts        
        ,last_viewed_dt       
        ,last_referenced_dt    
        ,user_record_access_id  
        ,start_dt             
        ,end_dt                
        ,goal_kpi_amt         
        ,goal_kpi_cd          
        ,status_cd         
        ,campaign_goal_cd     
        ,connection_type_cd  
        ,buying_campaign_ext_nm
        ,source_application_cd 
        ,dw_create_ts
        ,dw_last_update_ts
        ,dw_logical_delete_ind
        ,dw_source_create_nm
        ,dw_source_update_nm
        ,dw_current_version_ind
      )
        SELECT  t.*
        FROM    
      (
        SELECT 
        buying_campaign_id
        ,dw_first_effective_ts
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN '9999-12-31 00:00:00' ELSE TIMESTAMP_SUB(dw_last_effective_ts, INTERVAL 1 SECOND) END AS dw_last_effective_ts 
        ,owner_id
        ,buying_campaign_advertiser_id
        ,ad_platform_campaign_id  
        ,media_campaign_id  
        ,deleted_ind         
        ,buying_item_nm     
        ,currency_iso_cd      
        ,campaign_url_txt           
        ,source_created_ts    
        ,source_created_by_id  
        ,source_last_modified_ts   
        ,source_last_modified_by_id   
        ,system_mod_ts        
        ,last_viewed_dt       
        ,last_referenced_dt    
        ,user_record_access_id  
        ,start_dt             
        ,end_dt                
        ,goal_kpi_amt         
        ,goal_kpi_cd          
        ,status_cd         
        ,campaign_goal_cd     
        ,connection_type_cd  
        ,buying_campaign_ext_nm
        ,source_application_cd 
        ,CURRENT_TIMESTAMP() AS dw_create_ts
        ,CURRENT_TIMESTAMP() AS dw_last_update_ts
        ,FALSE AS dw_logical_delete_ind
        ,'OMS' AS dw_source_create_nm
        ,'OMS' AS dw_source_update_nm
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN TRUE ELSE FALSE END AS dw_current_version_ind
        FROM 
        (
        SELECT 
         id as buying_campaign_id
         ,owner_id as owner_id
         ,advendio_advertiser_c as buying_campaign_advertiser_id
         ,advendio_campaign_id_c as ad_platform_campaign_id
         ,media_campaign_c as media_campaign_id
         ,is_deleted as deleted_ind
         ,name as buying_item_nm
         ,currency_iso_code as currency_iso_cd
         ,campaign_id_c as campaign_url_txt
         ,created_date as source_created_ts
         ,created_by_id as source_created_by_id
         ,last_modified_date as source_last_modified_ts
         ,last_modified_by_id as source_last_modified_by_id
         ,system_modstamp as system_mod_ts
         ,last_viewed_date as last_viewed_dt
         ,last_referenced_date as last_referenced_dt
         ,CAST(NULL AS STRING) as user_record_access_id     
         ,advendio_start_date_c as start_dt
         ,advendio_end_date_c as end_dt
         ,ROUND(CAST(advendio_goal_kpiamount_c AS NUMERIC),2) as goal_kpi_amt
         ,advendio_goal_kpi_c as goal_kpi_cd
         ,advendio_status_c as status_cd
         ,advendio_goal_c as campaign_goal_cd
         ,connection_type_c as connection_type_cd
         ,advendio_buying_campaign_extended_name_c as buying_campaign_ext_nm 
         ,'OMS' AS source_application_cd 
         ,CAST(last_modified_date AS TIMESTAMP) AS dw_first_effective_ts
        ,LAST_VALUE(last_modified_date) OVER (record_window) AS dw_last_effective_ts
        FROM %s 
        WHERE 1=1
        AND _fivetran_synced >= %T AND _fivetran_synced < %T
        AND is_deleted = FALSE
        AND last_modified_date IS NOT NULL
        WINDOW  record_window AS (PARTITION BY id ORDER BY last_modified_date ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        )  
      ) t
        --remove incoming records where the dw_first_effective_ts is earlier than the current version's dw_first_effective_ts in production
        LEFT JOIN %s p
        ON      p.buying_campaign_id = t.buying_campaign_id
        AND     p.source_application_cd = t.source_application_cd
        AND     p.dw_current_version_ind = TRUE
        WHERE   p.buying_campaign_id IS NULL
        OR      t.dw_first_effective_ts > p.dw_first_effective_ts
""",tgt_wrk_tbl,src_tbl,data_extract_start_ts,data_extract_end_ts,tgt_tbl);

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET sql_truncate_lr_tbl = '''TRUNCATE TABLE ''' || lr_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_lr_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of load read table "|| lr_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END; 

-- RECORDS TO EXPIRE
SET buying_campaign_records_expire = FORMAT("""
      INSERT INTO %s
      (
        buying_campaign_id,
        source_application_cd,
        dw_first_effective_ts,
        dw_last_effective_ts,
        dw_current_version_ind
      )
        SELECT  
        p.buying_campaign_id,
        p.source_application_cd,
        p.dw_first_effective_ts,
        TIMESTAMP_SUB(t.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts,
        FALSE AS dw_current_version_ind
        FROM    %s p
        INNER   JOIN (
        SELECT *
        FROM    %s
        QUALIFY ROW_NUMBER() OVER (PARTITION BY buying_campaign_id, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
        ) t
        ON     t.buying_campaign_id = p.buying_campaign_id
        AND    t.source_application_cd = p.source_application_cd
        WHERE  p.dw_current_version_ind = TRUE
         """,lr_tbl,tgt_tbl,tgt_wrk_tbl);

  
--FINAL UPDATE TARGET TABLE
SET buying_campaign_final_update = FORMAT("""
      UPDATE  %s p
      SET  dw_last_effective_ts = t.dw_last_effective_ts,
      dw_current_version_ind = FALSE,
      dw_last_update_ts = CURRENT_TIMESTAMP,
      dw_source_update_nm = 'OMS'
      FROM    %s t
      WHERE   t.buying_campaign_id = p.buying_campaign_id
      AND     t.source_application_cd = p.source_application_cd
      AND     t.dw_first_effective_ts = p.dw_first_effective_ts
      """,tgt_tbl,lr_tbl);

--FINAL INSERT TARGET TABLE
SET buying_campaign_final_insert = FORMAT("""
      INSERT  INTO %s
      (
        buying_campaign_id
        ,dw_first_effective_ts
        ,dw_last_effective_ts
        ,owner_id
        ,buying_campaign_advertiser_id
        ,ad_platform_campaign_id  
        ,media_campaign_id  
        ,deleted_ind         
        ,buying_item_nm     
        ,currency_iso_cd      
        ,campaign_url_txt           
        ,source_created_ts    
        ,source_created_by_id  
        ,source_last_modified_ts   
        ,source_last_modified_by_id   
        ,system_mod_ts        
        ,last_viewed_dt       
        ,last_referenced_dt    
        ,user_record_access_id  
        ,start_dt             
        ,end_dt                
        ,goal_kpi_amt         
        ,goal_kpi_cd          
        ,status_cd         
        ,campaign_goal_cd     
        ,connection_type_cd  
        ,buying_campaign_ext_nm
        ,source_application_cd 
        ,dw_create_ts
        ,dw_last_update_ts
        ,dw_logical_delete_ind
        ,dw_source_create_nm
        ,dw_source_update_nm
        ,dw_current_version_ind
      ) 
      SELECT  
        buying_campaign_id
        ,dw_first_effective_ts
        ,dw_last_effective_ts
        ,owner_id
        ,buying_campaign_advertiser_id
        ,ad_platform_campaign_id  
        ,media_campaign_id  
        ,deleted_ind         
        ,buying_item_nm     
        ,currency_iso_cd      
        ,campaign_url_txt           
        ,source_created_ts    
        ,source_created_by_id  
        ,source_last_modified_ts   
        ,source_last_modified_by_id   
        ,system_mod_ts        
        ,last_viewed_dt       
        ,last_referenced_dt    
        ,user_record_access_id  
        ,start_dt             
        ,end_dt                
        ,goal_kpi_amt         
        ,goal_kpi_cd          
        ,status_cd         
        ,campaign_goal_cd     
        ,connection_type_cd  
        ,buying_campaign_ext_nm
        ,source_application_cd
        ,CURRENT_TIMESTAMP() AS dw_create_ts
        ,CURRENT_TIMESTAMP() AS dw_last_update_ts
        ,FALSE AS dw_logical_delete_ind
        ,'OMS' AS dw_source_create_nm
        ,'OMS' AS dw_source_update_nm
        ,dw_current_version_ind
        FROM   %s
      """,tgt_tbl,tgt_wrk_tbl);

BEGIN
EXECUTE IMMEDIATE (sql_begin); 
EXECUTE IMMEDIATE (buying_campaign_records_expire);
EXECUTE IMMEDIATE (buying_campaign_final_update);
EXECUTE IMMEDIATE (buying_campaign_final_insert);
SET record_count = @@row_count;

EXECUTE IMMEDIATE (sql_commit);
SET row_count = row_count + record_count;

EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET status  = "COMPLETED";
SET job_end = CURRENT_TIMESTAMP();
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('OMS','CONFIRMED',CURRENT_DATE(),"BUYING_CAMPAIGN");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;