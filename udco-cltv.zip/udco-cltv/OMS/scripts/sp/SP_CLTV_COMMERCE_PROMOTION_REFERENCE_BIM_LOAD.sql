CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_COMMERCE_PROMOTION_REFERENCE_BIM_LOAD`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_lr_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE lr_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE commerce_promotion_records_expire string;
DECLARE commerce_promotion_final_update string;
DECLARE commerce_promotion_final_insert string;



SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_COMMERCE_PROMOTION_REFERENCE_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.commerce_promotion_reference';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.commerce_promotion_reference_wrk';        
SET src_tbl         = '<<EMDG_PROJECT_ID>>.<<EMDG_DATASET>>.PromotedCommerceObject';
SET lr_tbl          = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.commerce_promotion_reference_lr';

IF DATE(max_audit_ts) = '0001-01-01' THEN
  EXECUTE IMMEDIATE ('''TRUNCATE TABLE ''' || tgt_tbl);
END IF;

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = FORMAT("""
      INSERT INTO %s
		(
        hub_campaign_id,
        brand_nm,
        dw_first_effective_ts,
        dw_last_effective_ts,
        vendor_nm,
        group_nm,
        category_nm,
        department_nm,
        class_nm,
        attribution_list_nm,
        attribution_type_nm,
        co_branded_advertiser_nm,
        co_branded_tier_nm,
        co_branded_ind,
        partner_id,
        partner_nm,
        source_created_ts,
        source_last_modified_ts,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind,
        dw_dml_type
      )
      SELECT SRC.MediaOrder AS  hub_campaign_id
			,SRC.BrandName AS brand_nm
			,CURRENT_TIMESTAMP() AS dw_first_effective_ts
			,CAST('9999-12-31 00:00:00' AS TIMESTAMP)  AS dw_last_effective_ts
			,SRC.Vendor AS vendor_nm
			,SRC.`Group` AS group_nm
			,SRC.Category AS category_nm
			,SRC.department AS department_nm
			,SRC.Class AS class_nm
			,SRC.AttributionListName AS  attribution_list_nm
			,SRC.AttributionType AS attribution_type_nm
			,SRC.CoBrandedAdvertiser AS  co_branded_advertiser_nm
			,SRC.CoBrandedTier AS co_branded_tier_nm
			,SRC.IsCobranded AS co_branded_ind
			,SRC.PartnerId AS partner_id
			,SRC.PartnerName AS partner_nm
			,CURRENT_TIMESTAMP AS source_created_ts
			,CURRENT_TIMESTAMP AS source_last_modified_ts
			,'OMS' AS source_application_cd
			,CURRENT_TIMESTAMP AS dw_create_ts
			,CURRENT_TIMESTAMP AS dw_last_update_ts
			,FALSE  AS dw_logical_delete_ind
			,'OMS' AS dw_source_create_nm
			,'OMS'  AS dw_source_update_nm
			,TRUE  AS dw_current_version_ind 
      ,CASE WHEN (TGT.hub_campaign_id IS NULL AND TGT.brand_nm IS NULL) THEN 'I' ELSE 'U' END AS dw_dml_type
      FROM %s SRC
      LEFT JOIN %s TGT
      ON SRC.MediaOrder = TGT.hub_campaign_id
      AND  SRC.BrandName = TGT.brand_nm
	  AND  IFNULL(SRC.Vendor,"1") = IFNULL(TGT.vendor_nm,"1")
      AND  IFNULL(SRC.`Group`,"1") = IFNULL(TGT.group_nm,"1")
      AND  IFNULL(SRC.category,"1")  = IFNULL(TGT.category_nm,"1") 
      AND  IFNULL(SRC.department,"1") = IFNULL(TGT.department_nm,"1") 
      AND  IFNULL(SRC.Class,"1") = IFNULL(TGT.class_nm,"1") 
      AND  IFNULL(SRC.PartnerId,"1") = IFNULL(TGT.partner_id,"1")
      AND  TGT.DW_CURRENT_VERSION_IND = TRUE
      WHERE SRC.MediaOrder IS NOT NULL 
      AND   SRC.BrandName IS NOT NULL
      AND ((TGT.hub_campaign_id IS NULL AND TGT.brand_nm IS NULL)  -- New records
         OR (
          IFNULL(SRC.AttributionListName, '') <> IFNULL(TGT.attribution_list_nm, '') OR
          IFNULL(SRC.AttributionType, '') <> IFNULL(TGT.attribution_type_nm, '') OR
          IFNULL(SRC.CoBrandedAdvertiser, '') <> IFNULL(TGT.co_branded_advertiser_nm, '') OR
          IFNULL(SRC.CoBrandedTier, '') <> IFNULL(TGT.co_branded_tier_nm, '') OR
          IFNULL(SRC.IsCobranded, FALSE) <> IFNULL(TGT.co_branded_ind, FALSE) OR
          IFNULL(SRC.PartnerName, '') <> IFNULL(TGT.partner_nm, '')
        ))
      QUALIFY ROW_NUMBER() OVER (PARTITION BY MediaOrder,BrandName,Vendor,`Group`,Category,department,class,partnerid ORDER BY RowUpdateTS DESC) = 1
""",tgt_wrk_tbl,src_tbl,tgt_tbl);

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET sql_truncate_lr_tbl = '''TRUNCATE TABLE ''' || lr_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_lr_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of load read table "|| lr_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END; 

-- RECORDS TO EXPIRE
SET commerce_promotion_records_expire = FORMAT("""
      INSERT INTO %s
      (
        hub_campaign_id,
        brand_nm,
		vendor_nm,
        dw_first_effective_ts,
        dw_last_effective_ts,
        group_nm,
        category_nm,
        department_nm,
        class_nm,
        partner_id,
        source_application_cd,
        dw_current_version_ind
      )
        SELECT  
        p.hub_campaign_id,
        p.brand_nm,
		p.vendor_nm,
        p.dw_first_effective_ts,
        TIMESTAMP_SUB(t.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts,
        p.group_nm,
        p.category_nm,
        p.department_nm,
        p.class_nm,
        p.partner_id,
        p.source_application_cd,
        FALSE AS dw_current_version_ind
        FROM    %s p
        INNER   JOIN (
        SELECT *
        FROM   %s
        WHERE dw_dml_type = 'U'
        QUALIFY ROW_NUMBER() OVER (PARTITION BY hub_campaign_id,brand_nm,vendor_nm,group_nm,category_nm,department_nm,class_nm,partner_id ORDER BY dw_first_effective_ts ASC) = 1
        ) t
        ON     t.hub_campaign_id = p.hub_campaign_id
        AND    t.brand_nm = p.brand_nm
		AND    t.vendor_nm = p.vendor_nm
        AND    t.group_nm = p.group_nm
        AND    t.category_nm = p.category_nm
        AND    t.department_nm = p.department_nm
        AND    t.class_nm = p.class_nm 
        AND    t.partner_id = p.partner_id
        AND   p.dw_current_version_ind = TRUE
         """,lr_tbl,tgt_tbl,tgt_wrk_tbl);

  
--FINAL UPDATE TARGET TABLE
SET commerce_promotion_final_update = FORMAT("""
      UPDATE  %s p
      SET  dw_last_effective_ts = t.dw_last_effective_ts,
      dw_current_version_ind = FALSE,
      dw_last_update_ts = CURRENT_TIMESTAMP,
      dw_source_update_nm = 'OMS'
      FROM   %s t
      WHERE  t.hub_campaign_id = p.hub_campaign_id
      AND    t.brand_nm = p.brand_nm
	  ANd    t.vendor_nm = p.vendor_nm
      AND    t.group_nm = p.group_nm
      AND    t.category_nm = p.category_nm
      AND    t.department_nm = p.department_nm
      AND    t.class_nm = p.class_nm 
      AND    t.partner_id = p.partner_id
      AND    t.dw_first_effective_ts = p.dw_first_effective_ts;
      """,tgt_tbl,lr_tbl);

--FINAL INSERT TARGET TABLE
SET commerce_promotion_final_insert = FORMAT("""
      INSERT  INTO %s
      (
        hub_campaign_id,
        brand_nm,
        dw_first_effective_ts,
        dw_last_effective_ts,
        vendor_nm,
        group_nm,
        category_nm,
        department_nm,
        class_nm,
        attribution_list_nm,
        attribution_type_nm,
        co_branded_advertiser_nm,
        co_branded_tier_nm,
        co_branded_ind,
        partner_id,
        partner_nm,
        source_created_ts,
        source_last_modified_ts,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind
      ) 
      SELECT  
        hub_campaign_id,
        brand_nm,
        dw_first_effective_ts,
        dw_last_effective_ts,
        vendor_nm,
        group_nm,
        category_nm,
        department_nm,
        class_nm,
        attribution_list_nm,
        attribution_type_nm,
        co_branded_advertiser_nm,
        co_branded_tier_nm,
        co_branded_ind,
        partner_id,
        partner_nm,
        source_created_ts,
        source_last_modified_ts,
        source_application_cd,
        CURRENT_TIMESTAMP() AS dw_create_ts,
        CURRENT_TIMESTAMP() AS dw_last_update_ts,
        FALSE AS dw_logical_delete_ind,
        'OMS' AS dw_source_create_nm,
        'OMS' AS dw_source_update_nm,
        dw_current_version_ind
        FROM   %s
      """,tgt_tbl,tgt_wrk_tbl);

BEGIN
EXECUTE IMMEDIATE (sql_begin); 
EXECUTE IMMEDIATE (commerce_promotion_records_expire);
EXECUTE IMMEDIATE (commerce_promotion_final_update);
EXECUTE IMMEDIATE (commerce_promotion_final_insert);
SET record_count = @@row_count;

EXECUTE IMMEDIATE (sql_commit);
SET row_count = row_count + record_count;

EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET status  = "COMPLETED";
SET job_end = CURRENT_TIMESTAMP();
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('OMS','CONFIRMED',CURRENT_DATE(),"commerce_promotion_reference");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;