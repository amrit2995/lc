CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_OMS_ACCOUNT_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_lr_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE lr_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE oms_account_records_expire string;
DECLARE oms_account_final_update string;
DECLARE oms_account_final_insert string;



SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_OMS_ACCOUNT_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.OMS_ACCOUNT';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_ACCOUNT_WRK';        
SET src_tbl         = '<<EMFI_PROJECT_ID>>.<<EMFI_DATASET>>.account';
SET lr_tbl          = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_ACCOUNT_LR_INSERT_UPDATE';

IF DATE(max_audit_ts) = '0001-01-01' THEN
  EXECUTE IMMEDIATE ('''TRUNCATE TABLE ''' || tgt_tbl);
END IF;

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = FORMAT("""
      INSERT INTO %s
			(
        account_id,
        dw_first_effective_ts,
        dw_last_effective_ts,
        advertiser_nm,
        invoice_email_txt,
        payment_processing_type_nm,
        terms_of_payment_txt,
        total_net_revenue_last_year_amt,
        total_net_revenue_next_year_amt,
        total_net_revenue_this_year_amt,
        total_revenue_last_year_amt,
        total_revenue_next_year_amt,
        total_revenue_this_year_amt,
        annual_revenue_amt,
        billing_shipping_address_txt,
        billing_city_nm,
        billing_country_cd,
        billing_geocode_accuracy_txt,
        billing_latitude_dgr,
        billing_longitude_dgr,
        billing_postal_cd,
        billing_state_nm,
        billing_street_address_txt,
        bill_to_agency_ind,
        category_nm,
        client_tier_nm,
        client_sub_tier_nm,
        client_type_nm,
        source_created_by_id,
        source_created_ts,
        currency_iso_cd,
        customer_id,
        account_dsc,
        industry_nm,
        invoice_email_2_txt,
        invoice_email_3_txt,
        invoice_email_4_txt,
        invoice_email_5_txt,
        invoice_email_6_txt,
        invoice_email_7_txt,
        invoice_email_8_txt,
        invoice_email_9_txt,
        invoice_email_10_txt,
        iri_id,
        deleted_ind,
        source_last_modified_by_id,
        source_last_modified_ts,
        account_nm,
        oracle_account_nbr,
        oracle_site_nbr,
        other_nm,
        owner_id,
        parent_account_id,
        phone_nbr,
        record_type_id,
        system_modstamp_ts,
        account_type_nm,
        website_url_txt,
        total_net_revenue_last_fiscal_year_amt,
        total_net_revenue_next_fiscal_year_amt,
        total_net_revenue_this_fiscal_year_amt,
        total_revenue_last_fiscal_year_amt,
        total_revenue_next_fiscal_year_amt,
        total_revenue_this_fiscal_year_amt,
        po_required_invoicing_ind,
        annual_retail_sales_revenue_prior_to_prior_fy_amt ,
        annual_retail_sales_revenue_prior_fy_amt,
        app_partner_id,
        app_partner_nm,
        business_venture_ind,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind
      )
        SELECT  t.*
        FROM    
      (
        SELECT 
        account_id
        , dw_first_effective_ts
        , CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN '9999-12-31 00:00:00' ELSE TIMESTAMP_SUB(dw_last_effective_ts, INTERVAL 1 SECOND) END AS dw_last_effective_ts 
        , advertiser_nm
        , invoice_email_txt
        , payment_processing_type_nm
        , terms_of_payment_txt
        , total_net_revenue_last_year_amt
        , total_net_revenue_next_year_amt
        , total_net_revenue_this_year_amt
        , total_revenue_last_year_amt
        , total_revenue_next_year_amt
        , total_revenue_this_year_amt
        , annual_revenue_amt
        , billing_shipping_address_txt
        , billing_city_nm
        , billing_country_cd
        , billing_geocode_accuracy_txt
        , billing_latitude_dgr
        , billing_longitude_dgr
        , billing_postal_cd
        , billing_state_nm
        , billing_street_address_txt
        , bill_to_agency_ind
        , category_nm
        , client_tier_nm
        , client_sub_tier_nm
        , client_type_nm
        , source_created_by_id
        , source_created_ts
        , currency_iso_cd
        , customer_id
        , account_dsc
        , industry_nm
        , invoice_email_2_txt
        , invoice_email_3_txt
        , invoice_email_4_txt
        , invoice_email_5_txt
        , invoice_email_6_txt
        , invoice_email_7_txt
        , invoice_email_8_txt
        , invoice_email_9_txt
        , invoice_email_10_txt
        , iri_id
        , deleted_ind
        , source_last_modified_by_id
        , source_last_modified_ts
        , account_nm
        , oracle_account_nbr
        , oracle_site_nbr
        , other_nm
        , owner_id
        , parent_account_id
        , phone_nbr
        , record_type_id
        , system_modstamp_ts
        , account_type_nm
        , website_url_txt
        , total_net_revenue_last_fiscal_year_amt
        , total_net_revenue_next_fiscal_year_amt
        , total_net_revenue_this_fiscal_year_amt
        , total_revenue_last_fiscal_year_amt
        , total_revenue_next_fiscal_year_amt
        , total_revenue_this_fiscal_year_amt
        , po_required_invoicing_ind
        , annual_retail_sales_revenue_prior_to_prior_fy_amt
        , annual_retail_sales_revenue_prior_fy_amt
        , app_partner_id
        , app_partner_nm
        , business_venture_ind
        , source_application_cd
        , CURRENT_TIMESTAMP() AS dw_create_ts
        , CURRENT_TIMESTAMP() AS dw_last_update_ts
        , FALSE AS dw_logical_delete_ind
        , 'OMS' AS dw_source_create_nm
        , 'OMS' AS dw_source_update_nm
        , CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN TRUE ELSE FALSE END AS dw_current_version_ind
        FROM 
        (
        SELECT 
        id AS ACCOUNT_ID      
        ,advendio_advertiser_name_c AS  ADVERTISER_NM
        ,advendio_invoice_email_c  AS INVOICE_EMAIL_TXT
        ,advendio_payment_processing_c  AS PAYMENT_PROCESSING_TYPE_NM 
        ,advendio_terms_of_payment_c  AS TERMS_OF_PAYMENT_TXT
        ,ROUND(CAST(advendio_total_net_revenue_last_year_c AS NUMERIC),2) AS TOTAL_NET_REVENUE_LAST_YEAR_AMT
        ,ROUND(CAST(advendio_total_net_revenue_next_year_c AS NUMERIC),2) AS TOTAL_NET_REVENUE_NEXT_YEAR_AMT
        ,ROUND(CAST(advendio_total_net_revenue_this_year_c AS NUMERIC),2) AS TOTAL_NET_REVENUE_THIS_YEAR_AMT
        ,ROUND(CAST(advendio_total_revenue_last_year_c AS NUMERIC),2) AS TOTAL_REVENUE_LAST_YEAR_AMT
        ,ROUND(CAST(advendio_total_revenue_next_year_c AS NUMERIC),2) AS TOTAL_REVENUE_NEXT_YEAR_AMT
        ,ROUND(CAST(advendio_total_revenue_this_year_c AS NUMERIC),2) AS TOTAL_REVENUE_THIS_YEAR_AMT
        ,ROUND(CAST(annual_revenue AS NUMERIC),2) AS ANNUAL_REVENUE_AMT 
        ,shipping_street AS BILLING_SHIPPING_ADDRESS_TXT
        ,billing_city  AS BILLING_CITY_NM
        ,billing_country  AS BILLING_COUNTRY_CD
        ,billing_geocode_accuracy  AS BILLING_GEOCODE_ACCURACY_TXT
        ,billing_latitude AS BILLING_LATITUDE_DGR
        ,billing_longitude  AS BILLING_LONGITUDE_DGR
        ,billing_postal_code  AS BILLING_POSTAL_CD
        ,billing_state  AS BILLING_STATE_NM
        ,billing_street  AS BILLING_STREET_ADDRESS_TXT
        ,bill_to_agency_c AS BILL_TO_AGENCY_IND
        ,category_c  AS CATEGORY_NM
        ,client_tier_c  AS CLIENT_TIER_NM
        ,client_sub_tier_c  AS CLIENT_SUB_TIER_NM
        ,client_type_c  AS CLIENT_TYPE_NM
        ,created_by_id  AS SOURCE_CREATED_BY_ID  
        ,created_date  AS SOURCE_CREATED_TS
        ,currency_iso_code  AS CURRENCY_ISO_CD 
        ,customer_id_c  AS CUSTOMER_ID
        ,description  AS ACCOUNT_DSC
        ,industry   AS INDUSTRY_NM
        ,invoice_email_2_c  AS INVOICE_EMAIL_2_TXT
        ,invoice_email_3_c  AS INVOICE_EMAIL_3_TXT
        ,invoice_email_4_c  AS INVOICE_EMAIL_4_TXT 
        ,invoice_email_5_c  AS  INVOICE_EMAIL_5_TXT
        ,invoice_email_6_c  AS INVOICE_EMAIL_6_TXT 
        ,invoice_email_7_c  AS  INVOICE_EMAIL_7_TXT
        ,invoice_email_8_c  AS INVOICE_EMAIL_8_TXT
        ,invoice_email_9_c  AS INVOICE_EMAIL_9_TXT 
        ,invoice_email_10_c  AS INVOICE_EMAIL_10_TXT
        ,iri_id_c  AS IRI_ID
        ,is_deleted  AS DELETED_IND
        ,last_modified_by_id  AS SOURCE_LAST_MODIFIED_BY_ID  
        ,last_modified_date  AS SOURCE_LAST_MODIFIED_TS
        ,name  AS ACCOUNT_NM
        ,oracle_account_no_c  AS ORACLE_ACCOUNT_NBR
        ,oracle_site_no_c  AS ORACLE_SITE_NBR
        ,other_name_c  AS OTHER_NM
        ,owner_id  AS OWNER_ID
        ,parent_id  AS PARENT_ACCOUNT_ID
        ,phone  AS PHONE_NBR
        ,record_type_id  AS RECORD_TYPE_ID 
        ,system_modstamp  AS  SYSTEM_MODSTAMP_TS 
        ,type  AS  ACCOUNT_TYPE_NM 
        ,website  AS  WEBSITE_URL_TXT 
        ,ROUND(CAST(advendio_total_net_revenue_last_fiscal_year_c AS NUMERIC),2) AS  TOTAL_NET_REVENUE_LAST_FISCAL_YEAR_AMT 
        ,ROUND(CAST(advendio_total_net_revenue_next_fiscal_year_c AS NUMERIC),2) AS  TOTAL_NET_REVENUE_NEXT_FISCAL_YEAR_AMT  
        ,ROUND(CAST(advendio_total_net_revenue_this_fiscal_year_c AS NUMERIC),2) AS  TOTAL_NET_REVENUE_THIS_FISCAL_YEAR_AMT 
        ,ROUND(CAST(advendio_total_revenue_last_fiscal_year_c AS NUMERIC),2) AS  TOTAL_REVENUE_LAST_FISCAL_YEAR_AMT
        ,ROUND(CAST(advendio_total_revenue_next_fiscal_year_c AS NUMERIC),2) AS TOTAL_REVENUE_NEXT_FISCAL_YEAR_AMT 
        ,ROUND(CAST(advendio_total_revenue_this_fiscal_year_c AS NUMERIC),2) AS  TOTAL_REVENUE_THIS_FISCAL_YEAR_AMT
        ,albcrm_po_number_required_for_invoicing_c  AS PO_REQUIRED_INVOICING_IND
        ,ROUND(CAST(annual_retail_sales_revenue_pr_to_pr_fy_c AS NUMERIC),2) AS ANNUAL_RETAIL_SALES_REVENUE_PRIOR_TO_PRIOR_FY_AMT
        ,ROUND(CAST(annual_retail_sales_revenue_prior_fy_c AS NUMERIC),2) AS ANNUAL_RETAIL_SALES_REVENUE_PRIOR_FY_AMT
        ,app_partner_id_c  AS APP_PARTNER_ID
        ,app_partner_name_c  AS APP_PARTNER_NM
        ,business_venture_c AS BUSINESS_VENTURE_IND
        ,CAST(last_modified_date AS TIMESTAMP) AS dw_first_effective_ts
        ,LAST_VALUE(last_modified_date) OVER (record_window) AS dw_last_effective_ts
        ,'OMS' AS SOURCE_APPLICATION_CD 
        FROM %s 
        WHERE _fivetran_synced >= %T AND _fivetran_synced < %T
        AND is_deleted = FALSE
        AND last_modified_date IS NOT NULL
        WINDOW  record_window AS (PARTITION BY id ORDER BY last_modified_date ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        )  
      ) t
        --remove incoming records where the dw_first_effective_ts is earlier than the current version's dw_first_effective_ts in production
        LEFT JOIN %s p
        ON      p.account_id = t.account_id
        AND     p.source_application_cd = t.source_application_cd
        AND     p.dw_current_version_ind = TRUE
        WHERE   p.account_id IS NULL
        OR      t.dw_first_effective_ts > p.dw_first_effective_ts
""",tgt_wrk_tbl,src_tbl,data_extract_start_ts,data_extract_end_ts,tgt_tbl);

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET sql_truncate_lr_tbl = '''TRUNCATE TABLE ''' || lr_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_lr_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of load read table "|| lr_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END; 

-- RECORDS TO EXPIRE
SET oms_account_records_expire = FORMAT("""
      INSERT INTO %s
      (
        account_id,
        source_application_cd,
        dw_first_effective_ts,
        dw_last_effective_ts,
        dw_current_version_ind
      )
        SELECT  
        p.account_id,
        p.source_application_cd,
        p.dw_first_effective_ts,
        TIMESTAMP_SUB(t.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts,
        FALSE AS dw_current_version_ind
        FROM    %s p
        INNER   JOIN (
        SELECT *
        FROM    %s
        QUALIFY ROW_NUMBER() OVER (PARTITION BY account_id, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
        ) t
        ON     t.account_id = p.account_id
        AND    t.source_application_cd = p.source_application_cd
        WHERE  p.dw_current_version_ind = TRUE
         """,lr_tbl,tgt_tbl,tgt_wrk_tbl);

  
--FINAL UPDATE TARGET TABLE
SET oms_account_final_update = FORMAT("""
      UPDATE  %s p
      SET  dw_last_effective_ts = t.dw_last_effective_ts,
      dw_current_version_ind = FALSE,
      dw_last_update_ts = CURRENT_TIMESTAMP,
      dw_source_update_nm = 'OMS'
      FROM    %s t
      WHERE   t.account_id = p.account_id
      AND     t.source_application_cd = p.source_application_cd
      AND     t.dw_first_effective_ts = p.dw_first_effective_ts
      """,tgt_tbl,lr_tbl);

--FINAL INSERT TARGET TABLE
SET oms_account_final_insert = FORMAT("""
      INSERT  INTO %s
      (
        account_id,
        dw_first_effective_ts,
        dw_last_effective_ts,
        advertiser_nm,
        invoice_email_txt,
        payment_processing_type_nm,
        terms_of_payment_txt,
        total_net_revenue_last_year_amt,
        total_net_revenue_next_year_amt,
        total_net_revenue_this_year_amt,
        total_revenue_last_year_amt,
        total_revenue_next_year_amt,
        total_revenue_this_year_amt,
        annual_revenue_amt,
        billing_shipping_address_txt,
        billing_city_nm,
        billing_country_cd,
        billing_geocode_accuracy_txt,
        billing_latitude_dgr,
        billing_longitude_dgr,
        billing_postal_cd,
        billing_state_nm,
        billing_street_address_txt,
        bill_to_agency_ind,
        category_nm,
        client_tier_nm,
        client_sub_tier_nm,
        client_type_nm,
        source_created_by_id,
        source_created_ts,
        currency_iso_cd,
        customer_id,
        account_dsc,
        industry_nm,
        invoice_email_2_txt,
        invoice_email_3_txt,
        invoice_email_4_txt,
        invoice_email_5_txt,
        invoice_email_6_txt,
        invoice_email_7_txt,
        invoice_email_8_txt,
        invoice_email_9_txt,
        invoice_email_10_txt,
        iri_id,
        deleted_ind,
        source_last_modified_by_id,
        source_last_modified_ts,
        account_nm,
        oracle_account_nbr,
        oracle_site_nbr,
        other_nm,
        owner_id,
        parent_account_id,
        phone_nbr,
        record_type_id,
        system_modstamp_ts,
        account_type_nm,
        website_url_txt,
        total_net_revenue_last_fiscal_year_amt,
        total_net_revenue_next_fiscal_year_amt,
        total_net_revenue_this_fiscal_year_amt,
        total_revenue_last_fiscal_year_amt,
        total_revenue_next_fiscal_year_amt,
        total_revenue_this_fiscal_year_amt,
        po_required_invoicing_ind,
        annual_retail_sales_revenue_prior_to_prior_fy_amt ,
        annual_retail_sales_revenue_prior_fy_amt,
        app_partner_id,
        app_partner_nm,
        business_venture_ind,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind
      ) 
      SELECT  
        account_id,
        dw_first_effective_ts,
        dw_last_effective_ts,
        advertiser_nm,
        invoice_email_txt,
        payment_processing_type_nm,
        terms_of_payment_txt,
        total_net_revenue_last_year_amt,
        total_net_revenue_next_year_amt,
        total_net_revenue_this_year_amt,
        total_revenue_last_year_amt,
        total_revenue_next_year_amt,
        total_revenue_this_year_amt,
        annual_revenue_amt,
        billing_shipping_address_txt,
        billing_city_nm,
        billing_country_cd,
        billing_geocode_accuracy_txt,
        billing_latitude_dgr,
        billing_longitude_dgr,
        billing_postal_cd,
        billing_state_nm,
        billing_street_address_txt,
        bill_to_agency_ind,
        category_nm,
        client_tier_nm,
        client_sub_tier_nm,
        client_type_nm,
        source_created_by_id,
        source_created_ts,
        currency_iso_cd,
        customer_id,
        account_dsc,
        industry_nm,
        invoice_email_2_txt,
        invoice_email_3_txt,
        invoice_email_4_txt,
        invoice_email_5_txt,
        invoice_email_6_txt,
        invoice_email_7_txt,
        invoice_email_8_txt,
        invoice_email_9_txt,
        invoice_email_10_txt,
        iri_id,
        deleted_ind,
        source_last_modified_by_id,
        source_last_modified_ts,
        account_nm,
        oracle_account_nbr,
        oracle_site_nbr,
        other_nm,
        owner_id,
        parent_account_id,
        phone_nbr,
        record_type_id,
        system_modstamp_ts,
        account_type_nm,
        website_url_txt,
        total_net_revenue_last_fiscal_year_amt,
        total_net_revenue_next_fiscal_year_amt,
        total_net_revenue_this_fiscal_year_amt,
        total_revenue_last_fiscal_year_amt,
        total_revenue_next_fiscal_year_amt,
        total_revenue_this_fiscal_year_amt,
        po_required_invoicing_ind,
        annual_retail_sales_revenue_prior_to_prior_fy_amt ,
        annual_retail_sales_revenue_prior_fy_amt,
        app_partner_id,
        app_partner_nm,
        business_venture_ind,
        source_application_cd,
        CURRENT_TIMESTAMP() AS dw_create_ts,
        CURRENT_TIMESTAMP() AS dw_last_update_ts,
        FALSE AS dw_logical_delete_ind,
        'OMS' AS dw_source_create_nm,
        'OMS' AS dw_source_update_nm,
        dw_current_version_ind
        FROM   %s
      """,tgt_tbl,tgt_wrk_tbl);

BEGIN
EXECUTE IMMEDIATE (sql_begin); 
EXECUTE IMMEDIATE (oms_account_records_expire);
EXECUTE IMMEDIATE (oms_account_final_update);
EXECUTE IMMEDIATE (oms_account_final_insert);
SET record_count = @@row_count;

EXECUTE IMMEDIATE (sql_commit);
SET row_count = row_count + record_count;

EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET status  = "COMPLETED";
SET job_end = CURRENT_TIMESTAMP();
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('OMS','CONFIRMED',CURRENT_DATE(),"OMS_ACCOUNT");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;