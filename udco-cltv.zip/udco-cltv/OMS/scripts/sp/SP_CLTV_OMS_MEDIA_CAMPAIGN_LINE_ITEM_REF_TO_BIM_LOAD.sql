CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_OMS_MEDIA_CAMPAIGN_LINE_ITEM_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_lr_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE lr_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE oms_media_campaign_line_item_records_expire string;
DECLARE oms_media_campaign_line_item_final_update string;
DECLARE oms_media_campaign_line_item_final_insert string;



SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_OMS_MEDIA_CAMPAIGN_LINE_ITEM_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.OMS_MEDIA_CAMPAIGN_LINE_ITEM';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_MEDIA_CAMPAIGN_LINE_ITEM_WRK';        
SET src_tbl         = '<<EMFI_PROJECT_ID>>.<<EMFI_DATASET>>.advendio_campaign_item_c';
SET lr_tbl          = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.OMS_MEDIA_CAMPAIGN_LINE_ITEM_LR_INSERT_UPDATE';

IF DATE(max_audit_ts) = '0001-01-01' THEN
  EXECUTE IMMEDIATE ('''TRUNCATE TABLE ''' || tgt_tbl);
END IF;

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = FORMAT("""
      INSERT INTO %s
			(
        media_campaign_line_item_id
        ,dw_first_effective_ts
        ,dw_last_effective_ts
        ,media_campaign_id
        ,ad_platform_campaign_id
        ,ad_platform_line_item_id
        ,source_application_cd
        ,is_deleted
        ,record_type_id
        ,source_created_by_id
        ,source_created_ts
        ,source_last_modified_by_id
        ,source_last_modified_ts
        ,system_modstamp
        ,ad_key_value_lst
        ,adserver_order_id
        ,adserver_line_item_id
        ,adserver_advertiser_id
        ,media_campaign_line_item_nm
        ,ad_server_proposal_id
        ,ad_server_proposal_line_item_id
        ,ad_server_targeting_lst
        ,ad_type_nm
        ,ad_price_amt
        ,ad_spec_txt
        ,additional_ad_lst
        ,adserver_status_nm
        ,custom_b_2_amt
        ,custom_b_3_amt
        ,total_gross_amt
        ,third_tier_net_amt
        ,net_amt
        ,net_net_amt
        ,availability_running_qty
        ,availability_qty
        ,bill_me_ind
        ,billing_status_nm
        ,billing_category_cd
        ,booking_qty
        ,budget_n_2_amt
        ,calendar_week_end_nbr
        ,calendar_week_start_nbr
        ,creative_rotation_type_nm
        ,current_ad_server_status_nm
        ,duration_days_nbr
        ,delivered_clicks_nbr
        ,delivered_impressions_nbr
        ,distribution_unit_cd
        ,effective_agency_commission_pct
        ,cpm_price_ind
        ,last_availability_forecast_ts
        ,last_delivery_status_update_ts
        ,line_dsc
        ,linear_distribution_ind
        ,list_price_amt
        ,matched_impressions_planned_nbr
        ,matched_impressions_running_nbr
        ,overbooking_factor_pct
        ,pay_factor_pct
        ,performance_indicator_nbr
        ,total_qty
        ,query_inventory_ind
        ,rate_discount_1_abs_amt
        ,rate_discount_2_abs_amt
        ,rate_discount_3_abs_amt
        ,rate_discount_4_abs_amt
        ,rate_discount_4_amt
        ,reserved_impressions_planned_qty
        ,reserved_impressions_running_qty
        ,share_of_voice_pct
        ,show_on_invoice_pdf_ind
        ,sort_order_num
        ,status_submitted_to_ad_server_txt
        ,submit_to_ad_server_ind
        ,surcharge_sales_price_amt
        ,targeting_criteria_txt
        ,targeting_abbreviation_txt
        ,taxable_amount_type_nm
        ,third_party_commission_amt
        ,time_zone_cd
        ,total_discount_amt
        ,vat_amt
        ,video_metric_nbr
        ,effective_cost_per_click_amt
        ,effective_cost_per_thousand_impressions_amt
        ,from_dt
        ,end_dt
        ,third_party_tagging_ind
        ,kpi_cd
        ,site_nm
        ,opportunity_product_id
        ,weighted_budget_pct
        ,weighted_cpg_budget_amt
        ,platform_nm
        ,opportunity_line_item_id
        ,media_campaign_opportunity_id
        ,rate_card_id
        ,creative_version_txt
        ,landing_page_url
        ,app_landing_page_url_txt
        ,web_landing_page_url_txt
        ,placeholder_tactic_id
        ,estimated_available_budget_amt
        ,estimated_available_inventory_qty
        ,creative_rotation_nm
        ,dw_create_ts
        ,dw_last_update_ts
        ,dw_logical_delete_ind
        ,dw_source_create_nm
        ,dw_source_update_nm
        ,dw_current_version_ind
      )
        SELECT  t.*
        FROM    
      (
        SELECT 
        media_campaign_line_item_id
        ,dw_first_effective_ts
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN '9999-12-31 00:00:00' ELSE TIMESTAMP_SUB(dw_last_effective_ts, INTERVAL 1 SECOND) END AS dw_last_effective_ts
        ,media_campaign_id
        ,ad_platform_campaign_id
        ,ad_platform_line_item_id
        ,source_application_cd
        ,is_deleted
        ,record_type_id
        ,source_created_by_id
        ,source_created_ts
        ,source_last_modified_by_id
        ,source_last_modified_ts
        ,system_modstamp
        ,ad_key_value_lst
        ,adserver_order_id
        ,adserver_line_item_id
        ,adserver_advertiser_id
        ,media_campaign_line_item_nm
        ,ad_server_proposal_id
        ,ad_server_proposal_line_item_id
        ,ad_server_targeting_lst
        ,ad_type_nm
        ,ad_price_amt
        ,ad_spec_txt
        ,additional_ad_lst
        ,adserver_status_nm
        ,custom_b_2_amt
        ,custom_b_3_amt
        ,total_gross_amt
        ,third_tier_net_amt
        ,net_amt
        ,net_net_amt
        ,availability_running_qty
        ,availability_qty
        ,bill_me_ind
        ,billing_status_nm
        ,billing_category_cd
        ,booking_qty
        ,budget_n_2_amt
        ,calendar_week_end_nbr
        ,calendar_week_start_nbr
        ,creative_rotation_type_nm
        ,current_ad_server_status_nm
        ,duration_days_nbr
        ,delivered_clicks_nbr
        ,delivered_impressions_nbr
        ,distribution_unit_cd
        ,effective_agency_commission_pct
        ,cpm_price_ind
        ,last_availability_forecast_ts
        ,last_delivery_status_update_ts
        ,line_dsc
        ,linear_distribution_ind
        ,list_price_amt
        ,matched_impressions_planned_nbr
        ,matched_impressions_running_nbr
        ,overbooking_factor_pct
        ,pay_factor_pct
        ,performance_indicator_nbr
        ,total_qty
        ,query_inventory_ind
        ,rate_discount_1_abs_amt
        ,rate_discount_2_abs_amt
        ,rate_discount_3_abs_amt
        ,rate_discount_4_abs_amt
        ,rate_discount_4_amt
        ,reserved_impressions_planned_qty
        ,reserved_impressions_running_qty
        ,share_of_voice_pct
        ,show_on_invoice_pdf_ind
        ,sort_order_num
        ,status_submitted_to_ad_server_txt
        ,submit_to_ad_server_ind
        ,surcharge_sales_price_amt
        ,targeting_criteria_txt
        ,targeting_abbreviation_txt
        ,taxable_amount_type_nm
        ,third_party_commission_amt
        ,time_zone_cd
        ,total_discount_amt
        ,vat_amt
        ,video_metric_nbr
        ,effective_cost_per_click_amt
        ,effective_cost_per_thousand_impressions_amt
        ,from_dt
        ,end_dt
        ,third_party_tagging_ind
        ,kpi_cd
        ,site_nm
        ,opportunity_product_id
        ,weighted_budget_pct
        ,weighted_cpg_budget_amt
        ,platform_nm
        ,opportunity_line_item_id
        ,media_campaign_opportunity_id
        ,rate_card_id
        ,creative_version_txt
        ,landing_page_url
        ,app_landing_page_url_txt
        ,web_landing_page_url_txt
        ,placeholder_tactic_id
        ,estimated_available_budget_amt
        ,estimated_available_inventory_qty
        ,creative_rotation_nm
        ,CURRENT_TIMESTAMP() AS dw_create_ts
        ,CURRENT_TIMESTAMP() AS dw_last_update_ts
        ,FALSE AS dw_logical_delete_ind
        ,'OMS' AS dw_source_create_nm
        ,'OMS' AS dw_source_update_nm
        ,CASE WHEN dw_first_effective_ts = dw_last_effective_ts THEN TRUE ELSE FALSE END AS dw_current_version_ind
        FROM
        (
          SELECT
          id AS media_campaign_line_item_id
          ,advendio_media_campaign_c  AS  MEDIA_CAMPAIGN_ID    
          ,advendio_adserver_id_order_id_c  AS  ad_platform_campaign_id    
          ,advendio_ad_id_c  AS  ad_platform_line_item_id                   
          ,'OMS' AS  SOURCE_APPLICATION_CD    
          ,is_deleted  AS  IS_DELETED              
          ,record_type_id  AS  RECORD_TYPE_ID          
          ,created_by_id  AS  SOURCE_CREATED_BY_ID           
          ,created_date  AS  SOURCE_CREATED_TS       
          ,last_modified_by_id  AS  SOURCE_LAST_MODIFIED_BY_ID
          ,last_modified_date  AS  SOURCE_LAST_MODIFIED_TS    
          ,system_modstamp AS  SYSTEM_MODSTAMP         
          ,advendio_ad_key_values_c  AS  AD_KEY_VALUE_LST        
          ,adserver_order_id_c AS  ADSERVER_ORDER_ID       
          ,adserver_line_item_id_c AS  ADSERVER_LINE_ITEM_ID    
          ,advendio_adserver_adv_advertiser_id_c AS  adserver_advertiser_id    
          ,name  AS  media_campaign_line_item_nm             
          ,advendio_ad_server_proposal_id_c  AS  AD_SERVER_PROPOSAL_ID    
          ,advendio_ad_server_proposal_line_item_id_c  AS  AD_SERVER_PROPOSAL_LINE_ITEM_ID    
          ,advendio_ad_server_targeting_c  AS  AD_SERVER_TARGETING_LST    
          ,advendio_ad_type_c  AS  AD_TYPE_NM              
          ,advendio_ad_price_c  AS  AD_PRICE_AMT            
          ,advendio_ad_spec_c AS  AD_SPEC_TXT             
          ,advendio_additional_ad_ids_c  AS  ADDITIONAL_AD_LST       
          ,advendio_adserver_status_c  AS  ADSERVER_STATUS_NM      
          ,round(cast(advendio_amount_b_2_apex_c as numeric),2) AS  CUSTOM_B_2_AMT          
          ,round(cast(advendio_amount_b_3_apex_c as numeric),2) AS  CUSTOM_B_3_AMT          
          ,round(cast(advendio_amount_apex_c as numeric),2) AS  TOTAL_GROSS_AMT         
          ,round(cast(advendio_amount_net_3_apex_c as numeric),2) AS THIRD_TIER_NET_AMT      
          ,round(cast(advendio_amount_net_apex_c as numeric),2) AS NET_AMT                 
          ,round(cast(advendio_amount_net_net_apex_c as numeric),2) AS NET_NET_AMT             
          ,advendio_availability_running_c  AS  AVAILABILITY_RUNNING_QTY    
          ,advendio_availability_c  AS  AVAILABILITY_QTY        
          ,advendio_bill_me_c  AS  BILL_ME_IND             
          ,advendio_billing_status_c  AS  BILLING_STATUS_NM       
          ,advendio_billing_category_c  AS  BILLING_CATEGORY_CD     
          ,advendio_booking_quantity_c AS  BOOKING_QTY             
          ,round(cast(advendio_budget_n_2_c as numeric),2)  AS  BUDGET_N_2_AMT          
          ,advendio_calendar_week_due_to_c  AS  CALENDAR_WEEK_END_NBR    
          ,advendio_calendar_week_from_c  AS  CALENDAR_WEEK_START_NBR    
          ,advendio_creative_rotation_type_c  AS  CREATIVE_ROTATION_TYPE_NM    
          ,advendio_current_ad_server_status_c  AS  CURRENT_AD_SERVER_STATUS_NM    
          ,advendio_days_c AS  DURATION_DAYS_NBR       
          ,advendio_delivered_clicks_c  AS  DELIVERED_CLICKS_NBR    
          ,advendio_delivered_impressions_c  AS  DELIVERED_IMPRESSIONS_NBR    
          ,advendio_distribution_unit_c  AS  DISTRIBUTION_UNIT_CD    
          ,advendio_effective_agency_commission_c  AS  EFFECTIVE_AGENCY_COMMISSION_PCT    
          ,advendio_is_cpmprice_c  AS  CPM_PRICE_IND           
          ,advendio_last_availability_forecast_c  AS  LAST_AVAILABILITY_FORECAST_TS    
          ,advendio_last_deliverystats_update_c  AS  LAST_DELIVERY_STATUS_UPDATE_TS    
          ,advendio_line_description_c  AS  LINE_DSC                
          ,advendio_linear_distribution_c  AS  LINEAR_DISTRIBUTION_IND    
          ,round(cast(advendio_list_price_c as numeric),2) AS  LIST_PRICE_AMT          
          ,advendio_matched_impressions_planned_c AS  MATCHED_IMPRESSIONS_PLANNED_NBR    
          ,advendio_matched_impressions_running_c AS  MATCHED_IMPRESSIONS_RUNNING_NBR    
          ,advendio_overbooking_factor_c  AS  OVERBOOKING_FACTOR_PCT    
          ,advendio_pay_factor_c AS  PAY_FACTOR_PCT          
          ,advendio_performance_indicator_c AS  PERFORMANCE_INDICATOR_NBR    
          ,advendio_quantity_c  AS  TOTAL_QTY               
          ,advendio_query_inventory_c  AS  QUERY_INVENTORY_IND     
          ,round(cast(advendio_rate_discount_1_abs_c as numeric),2)  AS  RATE_DISCOUNT_1_ABS_AMT     
          ,round(cast(advendio_rate_discount_2_abs_c as numeric),2) AS  RATE_DISCOUNT_2_ABS_AMT     
          ,round(cast(advendio_rate_discount_3_abs_c as numeric),2) AS  RATE_DISCOUNT_3_ABS_AMT     
          ,round(cast(advendio_rate_discount_4_abs_c as numeric),2) AS  RATE_DISCOUNT_4_ABS_AMT     
          ,advendio_rate_discount_4_c  AS  RATE_DISCOUNT_4_AMT
          ,advendio_reserved_impressions_planned_c  AS RESERVED_IMPRESSIONS_PLANNED_QTY    
          ,advendio_reserved_impressions_running_c  AS  RESERVED_IMPRESSIONS_RUNNING_QTY    
          ,advendio_share_of_voice_c  AS  SHARE_OF_VOICE_PCT      
          ,advendio_show_on_invoice_pdf_c  AS  SHOW_ON_INVOICE_PDF_IND    
          ,advendio_sort_order_c  AS  SORT_ORDER_NUM          
          ,advendio_status_submitted_to_ad_server_c  AS  STATUS_SUBMITTED_TO_AD_SERVER_TXT    
          ,advendio_submit_to_ad_server_c  AS  SUBMIT_TO_AD_SERVER_IND    
          ,round(cast(advendio_surcharge_sales_price_c as numeric),2)  AS  SURCHARGE_SALES_PRICE_AMT    
          ,advendio_targeting_c AS  TARGETING_CRITERIA_TXT    
          ,advendio_targetingabbrevation_c AS  TARGETING_ABBREVIATION_TXT    
          ,advendio_taxable_amount_type_c  AS  TAXABLE_AMOUNT_TYPE_NM    
          ,round(cast(advendio_third_party_commission_abs_c as numeric),2) AS  THIRD_PARTY_COMMISSION_AMT    
          ,advendio_time_zone_c  AS  TIME_ZONE_CD            
          ,round(cast(advendio_total_discount_abs_c as numeric),2) AS  TOTAL_DISCOUNT_AMT      
          ,round(cast(advendio_vat_amount_c as numeric),2) AS  VAT_AMT                 
          ,advendio_video_metric_c  AS  VIDEO_METRIC_NBR        
          ,round(cast(advendio_e_cpc_c as numeric),2) AS  EFFECTIVE_COST_PER_CLICK_AMT    
          ,round(cast(advendio_data_ecpm_c as numeric),2)  AS  EFFECTIVE_COST_PER_THOUSAND_IMPRESSIONS_AMT    
          ,advendio_from_date_c  AS  FROM_DT                 
          ,advendio_until_date_c  AS  END_DT                  
          ,x_3_rd_party_tagging_c  AS  THIRD_PARTY_TAGGING_IND    
          ,kpi_c  AS  KPI_CD                  
          ,site_c AS  SITE_NM                 
          ,opportunity_product_c  AS  OPPORTUNITY_PRODUCT_ID    
          ,weighted_budget_percent_c AS  WEIGHTED_BUDGET_PCT     
          ,round(cast(weighted_cpg_budget_c as numeric),2) AS  WEIGHTED_CPG_BUDGET_AMT    
          ,platform_c AS  PLATFORM_NM             
          ,opportunity_line_item_c  AS  OPPORTUNITY_LINE_ITEM_ID    
          ,opportunity_from_media_campaign_c  AS  MEDIA_CAMPAIGN_OPPORTUNITY_ID    
          ,rate_card_c  AS  RATE_CARD_ID            
          ,creative_version_c  AS  CREATIVE_VERSION_TXT    
          ,landing_page_destination_c  AS  LANDING_PAGE_URL        
          ,app_landing_page_c  AS  APP_LANDING_PAGE_URL_TXT    
          ,web_landing_page_c  AS  WEB_LANDING_PAGE_URL_TXT    
          ,placeholder_tactic_id_c  AS  PLACEHOLDER_TACTIC_ID    
          ,estimated_available_budget_c AS  ESTIMATED_AVAILABLE_BUDGET_AMT    
          ,estimated_available_inventory_c AS  ESTIMATED_AVAILABLE_INVENTORY_QTY    
          ,creative_rotation_c  AS  CREATIVE_ROTATION_NM
        ,CAST(last_modified_date AS TIMESTAMP) AS dw_first_effective_ts
        ,LAST_VALUE(last_modified_date) OVER (record_window) AS dw_last_effective_ts
        FROM %s
        WHERE 1=1
        AND _fivetran_synced >= %T AND _fivetran_synced < %T
        AND is_deleted = FALSE
        AND last_modified_date IS NOT NULL
        WINDOW  record_window AS (PARTITION BY id ORDER BY last_modified_date ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        ) 
      ) t
        --remove incoming records where the dw_first_effective_ts is earlier than the current version's dw_first_effective_ts in production
        LEFT JOIN %s p
        ON      p.media_campaign_line_item_id = t.media_campaign_line_item_id
        AND     p.source_application_cd = t.source_application_cd
        AND     p.dw_current_version_ind = TRUE
        WHERE   p.media_campaign_line_item_id IS NULL
        OR      t.dw_first_effective_ts > p.dw_first_effective_ts
""",tgt_wrk_tbl,src_tbl,data_extract_start_ts,data_extract_end_ts,tgt_tbl
  );

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET sql_truncate_lr_tbl = '''TRUNCATE TABLE ''' || lr_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_lr_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of load read table "|| lr_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END; 

-- RECORDS TO EXPIRE
SET oms_media_campaign_line_item_records_expire = FORMAT("""
      INSERT INTO %s
      (
        media_campaign_line_item_id,
        source_application_cd,
        dw_first_effective_ts,
        dw_last_effective_ts,
        dw_current_version_ind
      )
        SELECT  
        p.media_campaign_line_item_id,
        p.source_application_cd,
        p.dw_first_effective_ts,
        TIMESTAMP_SUB(t.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts,
        FALSE AS dw_current_version_ind
        FROM    %s p
        INNER   JOIN (
        SELECT *
        FROM    %s
        QUALIFY ROW_NUMBER() OVER (PARTITION BY media_campaign_line_item_id, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
        ) t
        ON     t.media_campaign_line_item_id = p.media_campaign_line_item_id
        AND    t.source_application_cd = p.source_application_cd
        WHERE  p.dw_current_version_ind = TRUE
         """,lr_tbl,tgt_tbl,tgt_wrk_tbl);

  
--FINAL UPDATE TARGET TABLE
SET oms_media_campaign_line_item_final_update = FORMAT("""
      UPDATE  %s p
      SET  dw_last_effective_ts = t.dw_last_effective_ts,
      dw_current_version_ind = FALSE,
      dw_last_update_ts = CURRENT_TIMESTAMP,
      dw_source_update_nm = 'OMS'
      FROM    %s t
      WHERE   t.media_campaign_line_item_id = p.media_campaign_line_item_id
      AND     t.source_application_cd = p.source_application_cd
      AND     t.dw_first_effective_ts = p.dw_first_effective_ts
      """,tgt_tbl,lr_tbl);

--FINAL INSERT TARGET TABLE
SET oms_media_campaign_line_item_final_insert = FORMAT("""
      INSERT  INTO %s
      (
        media_campaign_line_item_id
        ,dw_first_effective_ts
        ,dw_last_effective_ts
        ,media_campaign_id
        ,ad_platform_campaign_id
        ,ad_platform_line_item_id
        ,source_application_cd
        ,is_deleted
        ,record_type_id
        ,source_created_by_id
        ,source_created_ts
        ,source_last_modified_by_id
        ,source_last_modified_ts
        ,system_modstamp
        ,ad_key_value_lst
        ,adserver_order_id
        ,adserver_line_item_id
        ,adserver_advertiser_id
        ,media_campaign_line_item_nm
        ,ad_server_proposal_id
        ,ad_server_proposal_line_item_id
        ,ad_server_targeting_lst
        ,ad_type_nm
        ,ad_price_amt
        ,ad_spec_txt
        ,additional_ad_lst
        ,adserver_status_nm
        ,custom_b_2_amt
        ,custom_b_3_amt
        ,total_gross_amt
        ,third_tier_net_amt
        ,net_amt
        ,net_net_amt
        ,availability_running_qty
        ,availability_qty
        ,bill_me_ind
        ,billing_status_nm
        ,billing_category_cd
        ,booking_qty
        ,budget_n_2_amt
        ,calendar_week_end_nbr
        ,calendar_week_start_nbr
        ,creative_rotation_type_nm
        ,current_ad_server_status_nm
        ,duration_days_nbr
        ,delivered_clicks_nbr
        ,delivered_impressions_nbr
        ,distribution_unit_cd
        ,effective_agency_commission_pct
        ,cpm_price_ind
        ,last_availability_forecast_ts
        ,last_delivery_status_update_ts
        ,line_dsc
        ,linear_distribution_ind
        ,list_price_amt
        ,matched_impressions_planned_nbr
        ,matched_impressions_running_nbr
        ,overbooking_factor_pct
        ,pay_factor_pct
        ,performance_indicator_nbr
        ,total_qty
        ,query_inventory_ind
        ,rate_discount_1_abs_amt
        ,rate_discount_2_abs_amt
        ,rate_discount_3_abs_amt
        ,rate_discount_4_abs_amt
        ,rate_discount_4_amt
        ,reserved_impressions_planned_qty
        ,reserved_impressions_running_qty
        ,share_of_voice_pct
        ,show_on_invoice_pdf_ind
        ,sort_order_num
        ,status_submitted_to_ad_server_txt
        ,submit_to_ad_server_ind
        ,surcharge_sales_price_amt
        ,targeting_criteria_txt
        ,targeting_abbreviation_txt
        ,taxable_amount_type_nm
        ,third_party_commission_amt
        ,time_zone_cd
        ,total_discount_amt
        ,vat_amt
        ,video_metric_nbr
        ,effective_cost_per_click_amt
        ,effective_cost_per_thousand_impressions_amt
        ,from_dt
        ,end_dt
        ,third_party_tagging_ind
        ,kpi_cd
        ,site_nm
        ,opportunity_product_id
        ,weighted_budget_pct
        ,weighted_cpg_budget_amt
        ,platform_nm
        ,opportunity_line_item_id
        ,media_campaign_opportunity_id
        ,rate_card_id
        ,creative_version_txt
        ,landing_page_url
        ,app_landing_page_url_txt
        ,web_landing_page_url_txt
        ,placeholder_tactic_id
        ,estimated_available_budget_amt
        ,estimated_available_inventory_qty
        ,creative_rotation_nm
        ,dw_create_ts
        ,dw_last_update_ts
        ,dw_logical_delete_ind
        ,dw_source_create_nm
        ,dw_source_update_nm
        ,dw_current_version_ind
      ) 
      SELECT  
        media_campaign_line_item_id
        ,dw_first_effective_ts
        ,dw_last_effective_ts
        ,media_campaign_id
        ,ad_platform_campaign_id
        ,ad_platform_line_item_id
        ,source_application_cd
        ,is_deleted
        ,record_type_id
        ,source_created_by_id
        ,source_created_ts
        ,source_last_modified_by_id
        ,source_last_modified_ts
        ,system_modstamp
        ,ad_key_value_lst
        ,adserver_order_id
        ,adserver_line_item_id
        ,adserver_advertiser_id
        ,media_campaign_line_item_nm
        ,ad_server_proposal_id
        ,ad_server_proposal_line_item_id
        ,ad_server_targeting_lst
        ,ad_type_nm
        ,ad_price_amt
        ,ad_spec_txt
        ,additional_ad_lst
        ,adserver_status_nm
        ,custom_b_2_amt
        ,custom_b_3_amt
        ,total_gross_amt
        ,third_tier_net_amt
        ,net_amt
        ,net_net_amt
        ,availability_running_qty
        ,availability_qty
        ,bill_me_ind
        ,billing_status_nm
        ,billing_category_cd
        ,booking_qty
        ,budget_n_2_amt
        ,calendar_week_end_nbr
        ,calendar_week_start_nbr
        ,creative_rotation_type_nm
        ,current_ad_server_status_nm
        ,duration_days_nbr
        ,delivered_clicks_nbr
        ,delivered_impressions_nbr
        ,distribution_unit_cd
        ,effective_agency_commission_pct
        ,cpm_price_ind
        ,last_availability_forecast_ts
        ,last_delivery_status_update_ts
        ,line_dsc
        ,linear_distribution_ind
        ,list_price_amt
        ,matched_impressions_planned_nbr
        ,matched_impressions_running_nbr
        ,overbooking_factor_pct
        ,pay_factor_pct
        ,performance_indicator_nbr
        ,total_qty
        ,query_inventory_ind
        ,rate_discount_1_abs_amt
        ,rate_discount_2_abs_amt
        ,rate_discount_3_abs_amt
        ,rate_discount_4_abs_amt
        ,rate_discount_4_amt
        ,reserved_impressions_planned_qty
        ,reserved_impressions_running_qty
        ,share_of_voice_pct
        ,show_on_invoice_pdf_ind
        ,sort_order_num
        ,status_submitted_to_ad_server_txt
        ,submit_to_ad_server_ind
        ,surcharge_sales_price_amt
        ,targeting_criteria_txt
        ,targeting_abbreviation_txt
        ,taxable_amount_type_nm
        ,third_party_commission_amt
        ,time_zone_cd
        ,total_discount_amt
        ,vat_amt
        ,video_metric_nbr
        ,effective_cost_per_click_amt
        ,effective_cost_per_thousand_impressions_amt
        ,from_dt
        ,end_dt
        ,third_party_tagging_ind
        ,kpi_cd
        ,site_nm
        ,opportunity_product_id
        ,weighted_budget_pct
        ,weighted_cpg_budget_amt
        ,platform_nm
        ,opportunity_line_item_id
        ,media_campaign_opportunity_id
        ,rate_card_id
        ,creative_version_txt
        ,landing_page_url
        ,app_landing_page_url_txt
        ,web_landing_page_url_txt
        ,placeholder_tactic_id
        ,estimated_available_budget_amt
        ,estimated_available_inventory_qty
        ,creative_rotation_nm
        ,CURRENT_TIMESTAMP() AS dw_create_ts
        ,CURRENT_TIMESTAMP() AS dw_last_update_ts
        ,FALSE AS dw_logical_delete_ind
        ,'OMS' AS dw_source_create_nm
        ,'OMS' AS dw_source_update_nm
        ,dw_current_version_ind
        FROM   %s
      """,tgt_tbl,tgt_wrk_tbl);

BEGIN
EXECUTE IMMEDIATE (sql_begin); 
EXECUTE IMMEDIATE (oms_media_campaign_line_item_records_expire);
EXECUTE IMMEDIATE (oms_media_campaign_line_item_final_update);
EXECUTE IMMEDIATE (oms_media_campaign_line_item_final_insert);
SET record_count = @@row_count;

EXECUTE IMMEDIATE (sql_commit);
SET row_count = row_count + record_count;

EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET status  = "COMPLETED";
SET job_end = CURRENT_TIMESTAMP();
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('OMS','CONFIRMED',CURRENT_DATE(),"OMS_MEDIA_CAMPAIGN_LINE_ITEM");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;