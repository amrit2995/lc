CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CRITEO_UPC_PRODUCT_MAPPING`
(
    UPC STRING,
    PRODUCT_ID STRING,
    JOB_ID STRING,
    DW_CREATE_TS TIMESTAMP
)
CLUSTER BY UPC, PRODUCT_ID, JOB_ID, DW_CREATE_TS
OPTIONS (labels = [('appcode','emdg'),('bodname','mdm'),('domainname','collect'),('environment','<<ENV>>')]);
