CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.OFFER_PRODUCT_MAPPING`
(
    OFFER_ID INT64,
    BRAND_PRODUCT_NUMS STRING,
    JOB_ID STRING,
    DW_CREATE_TS TIMESTAMP
)
CLUSTER BY BRAND_PRODUCT_NUMS, OFFER_ID, JOB_ID
OPTIONS (labels = [('appcode','emdg'),('bodname','mdm'),('domainname','collect'),('environment','<<ENV>>')]);
