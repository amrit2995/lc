CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.SP_OFFER_PRODUCT_MAPPING`(job_id STRING)
BEGIN

    -- Start a transaction
  BEGIN TRANSACTION;

  -- Step 1: Delete existing data from the target table
    DELETE FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.OFFER_PRODUCT_MAPPING` WHERE 1=1;

    INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.OFFER_PRODUCT_MAPPING`
    WITH
      PGUPC AS(
      SELECT
        DISTINCT PGUPC.PRODUCT_GROUP_ID,
        LPAD(PGUPC.UPC_CD, 13, '0') AS UPC_NBR
      FROM
        `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_mrch.OMS_PRODUCT_GROUP_UPC` PGUPC WHERE DW_CURRENT_VERSION_IND=TRUE AND DW_LOGICAL_DELETE_IND=FALSE),
      PreAggregatedPGUPC AS (
      SELECT
        PGUPC.PRODUCT_GROUP_ID,
        ARRAY_AGG(PGUPC.UPC_NBR IGNORE NULLS) AS UPC_CDS,
      FROM
        PGUPC GROUP BY PGUPC.PRODUCT_GROUP_ID),
    OFFER_DATA AS (
    SELECT
      DISTINCT o.OMS_OFFER_ID,
      o.OFFER_NM,
      pgu.UPC_CDS AS PRODUCTS_UPC FROM `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_mrch.OMS_OFFER` o LEFT JOIN
      `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_mrch.OMS_OFFER_QUALIFICATION_PRODUCT_GROUP` pg
    ON
      o.OMS_OFFER_ID = pg.OMS_OFFER_ID LEFT JOIN
      PreAggregatedPGUPC pgu
    ON
      pg.PRODUCT_GROUP_ID = pgu.PRODUCT_GROUP_ID WHERE o.DW_CURRENT_VERSION_IND = TRUE
      AND o.DW_LOGICAL_DELETE_IND = FALSE
      AND pg.DW_CURRENT_VERSION_IND = TRUE
      AND pg.DW_LOGICAL_DELETE_IND = FALSE
      AND CURRENT_DATE() BETWEEN o.effective_start_dt and o.effective_end_dt
      --AND CURRENT_DATE() BETWEEN o.DISPLAY_EFFECTIVE_START_DT and o.DISPLAY_EFFECTIVE_END_DT
      AND REMOVED_UNCLIPPED_ON_TS_UTC IS NULL
      AND OFFER_STATUS_CD = 'PU'
      --AND PROVIDER_NM = 'OMS Digital'

    ) --select count(*) from OFFER_DATA
    , OFFER_DATA_UNNEST AS (
      SELECT OMS_OFFER_ID, OFFER_NM, UPC
      FROM OFFER_DATA, UNNEST(OFFER_DATA.PRODUCTS_UPC) UPC
    ), Last7DayProducts AS (
      SELECT
        UPC,
        PRODUCT_ID
      FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CRITEO_UPC_PRODUCT_MAPPING`
    )

    SELECT
      OD.OMS_OFFER_ID,
      STRING_AGG(PRDTS.PRODUCT_ID) AS Products,
      job_id,
      CURRENT_TIMESTAMP()
    FROM
    Last7DayProducts PRDTS INNER JOIN OFFER_DATA_UNNEST OD ON OD.UPC = PRDTS.UPC
    GROUP BY OD.OMS_OFFER_ID;

    -- Commit the transaction
  COMMIT TRANSACTION;
END