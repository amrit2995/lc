CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.SP_CRITEO_AD_REQUESTED_PRODUCT_UPC`(job_id STRING)
BEGIN

  DECLARE job_start Timestamp;
  DECLARE job_end Timestamp;
  DECLARE data_extract_start_ts Timestamp;
  DECLARE data_extract_end_ts Timestamp;
  DECLARE proc_name STRING;
  DECLARE row_count INT64;
  DECLARE status STRING;

  SET job_start= CURRENT_TIMESTAMP();
  SET row_count = 0;

  SET proc_name = 'SP_CRITEO_AD_REQUESTED_PRODUCT_UPC';

    -- Start a transaction
    BEGIN TRANSACTION;

    -- Step 1: Delete existing data from the target table
    DELETE FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CRITEO_UPC_PRODUCT_MAPPING` WHERE 1=1;

    INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CRITEO_UPC_PRODUCT_MAPPING`
    WITH UPC_PRODUCT AS (
      SELECT
        DISTINCT
            productInfo.content.upc as upc,
            productInfo.content.productId as productId,

      FROM   `<<DAPI_LOGS_PROJECT>>.emdg_onpdapilogs_<<ENV>>_ds_01.dapi_media_logs`
      WHERE   DATE(_PARTITIONTIME) >= DATE_ADD(CURRENT_DATE(), INTERVAL -8 DAY)
      AND productInfo.content.upc IS NOT NULL AND productInfo.content.productId IS NOT NULL
    )
    SELECT
        upc,
        productId,
        job_id,
        CURRENT_TIMESTAMP()
    FROM
    UPC_PRODUCT;

    SET data_extract_end_ts = CURRENT_TIMESTAMP();
    SET row_count = (SELECT COUNT(*) FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CRITEO_UPC_PRODUCT_MAPPING`);
    SET status = 'COMPLETED';

    CALL `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.SP_PROCESS_AUDIT_CONTROL` ('CLTV', job_id, proc_name, job_start, CURRENT_TIMESTAMP(), data_extract_start_ts, data_extract_end_ts, row_count, status, null);

    -- Commit the transaction
    COMMIT TRANSACTION;

  EXCEPTION


  WHEN error THEN SET job_end= CURRENT_TIMESTAMP();
    SET status= 'FAILED';
    SET err_desc= 'Error executing the Stored proedure ' || proc_name ||'. Failed with error: '|| @@error.message;
    CALL `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.SP_PROCESS_AUDIT_CONTROL` ('CLTV', job_id, proc_name, job_start, CURRENT_TIMESTAMP(), data_extract_start_ts, data_extract_end_ts, row_count, status, err_desc); RAISE USING message= err_desc;


END