# SPAOfferProduct (SPA Offer-Product Mapping)

Maps SPA offers to products and Criteo product UPCs. Includes a `perf/` variant for performance-environment schemas.

## Pipeline Flow

```
Source BQ Tables ──► [VToB SPs] ──► Mapping Tables
```

## Directory Layout

```
SPAOfferProduct/
├── README.md
├── params_dev.json / params_qa.json / params_prod.json
├── config/                         ← 3 Airflow workflow & step configs
│   └── perf/                       ← 3 performance-env configs
└── ddl/                            ← 4 table DDLs
    └── perf/                       ← 4 performance-env DDLs
```

## Key Entities

| Entity | DDL Location |
|--------|-------------|
| Offer-Product Mapping | `ddl/` |
| Criteo Product UPC Mapping | `ddl/` |
| Performance variants | `ddl/perf/` |
