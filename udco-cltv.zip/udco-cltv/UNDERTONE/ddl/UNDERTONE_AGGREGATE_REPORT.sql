CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT` (
  utc_date DATE,
  opportunity_id STRING,
  opportunity_line_id STRING,
  campaign_id STRING,
  campaign_name STRING,
  line_item_id STRING,
  line_item_name STRING,
  creative_id STRING,
  creative_name STRING,
  format_type STRING,
  format_name STRING,
  spend FLOAT64,
  impressions INT64,
  clicks INT64,
  dw_file_path STRING,
  dw_create_ts TIMESTAMP,
  `format` STRING,
  source_application_cd STRING,
  header_line STRING,
  footer_line STRING,
  job_id STRING
)
OPTIONS (labels = [('appcode','uddi'),('bodname','undertone'),('domainname','collect'),('environment','<<ENV>>')]);