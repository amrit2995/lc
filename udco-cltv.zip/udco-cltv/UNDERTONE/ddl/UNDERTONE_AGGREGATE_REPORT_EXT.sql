CREATE OR REPLACE EXTERNAL TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT_EXT`
(
  utc_date DATE,
  opportunity_id STRING,
  campaign_id STRING,
  campaign_name STRING,
  line_item_id STRING,
  line_item_name STRING,
  creative_id STRING,
  creative_name STRING,
  format_type STRING,
  format_name STRING,
  spend FLOAT64,
  impressions INT64,
  clicks INT64
)
OPTIONS (
  format = 'CSV',
  uris = ['gs://uddi-b2b-<<ENV>>-bkt-01/external/udco-cltv/inbound/undertone_old_format/Albertsons_AMC_*.csv'],
  skip_leading_rows = 1
);