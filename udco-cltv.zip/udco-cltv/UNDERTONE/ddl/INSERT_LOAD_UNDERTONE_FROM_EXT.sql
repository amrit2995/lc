INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT` (
    utc_date,
    opportunity_id,
    opportunity_line_id,
    campaign_id,
    campaign_name,
    line_item_id,
    line_item_name,
    creative_id,
    creative_name,
    format_type,
    format_name,
    spend,
    impressions,
    clicks,
    dw_file_path,
    dw_create_ts,
    `format`,
    source_application_cd,
    header_line,
    footer_line,
    job_id
    )
SELECT
    utc_date,
    opportunity_id,
    NULL AS opportunity_line_id,
    campaign_id,
    campaign_name,
    line_item_id,
    line_item_name,
    creative_id,
    creative_name,
    format_type,
    format_name,
    spend,
    impressions,
    clicks,
    NULL AS dw_file_path,
    CURRENT_TIMESTAMP() AS dw_create_ts,
    'csv' AS `format`,
    'CLTV' AS source_application_cd,
    '' AS header_line,
    '' AS footer_line,
    NULL AS job_id
FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT_EXT`;


UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT`
SET opportunity_id = 'MW36538169834997'
WHERE campaign_id = '733676';
 
UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT`
SET opportunity_line_id = 'MW36538169834997.012'
WHERE line_item_id = '3733875';

UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT`
SET opportunity_line_id = 'MW36538169834997.013'
WHERE line_item_id = '3733876';

UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT`
SET opportunity_line_id = 'MW36538169834997.014'
WHERE line_item_id = '3737785';

UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT`
SET opportunity_line_id = 'MW36538169834997.015'
WHERE line_item_id = '3737786';

UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT`
SET opportunity_line_id = 'HT51742995778038.010'
WHERE line_item_id = '3736548';
 
UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT`
SET opportunity_line_id = 'HT51742995778038.011'
WHERE line_item_id = '3736549';
 
UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT`
SET opportunity_line_id = 'XF91110836229999.001'
WHERE line_item_id = '3737056';