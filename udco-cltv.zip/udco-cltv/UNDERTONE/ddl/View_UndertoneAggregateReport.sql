CREATE OR REPLACE VIEW `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_cltv.vw_UndertoneAggregateReport`
OPTIONS (labels = [('appcode','uddi'),('bodname','undertone'),('domainname','collect'),('environment','<<ENV>>')])
AS (
    SELECT 
    *
    FROM 
    `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UNDERTONE_AGGREGATE_REPORT`
);