# UNDERTONE (Display Ad Reporting)

Ingests Undertone aggregate report CSVs from GCS into BigQuery via an external-table load pattern.

## Pipeline Flow

```
GCS CSVs ──► External Table (DDL) ──► INSERT INTO ... SELECT ──► Aggregate Report Table ──► View
```

### Data Flow Detail
1. External table DDL points at GCS CSV location
2. INSERT statement reads from external table into the main aggregate report table
3. View exposes the data for consumption

## Directory Layout

```
UNDERTONE/
├── README.md
├── params_dev.json / params_qa.json / params_prod.json
├── config/                         ← 1 SToV file-to-BQ config
│   └── SToV_UNDERTONE_FileToBQ.json  ← GCS source path, schema, sink table
└── ddl/                            ← 4 table DDLs
    ├── ddl_undertone_aggregate_report.sql       ← main table
    ├── ddl_undertone_aggregate_report_ext.sql   ← external table
    ├── ddl_undertone_aggregate_report_wrk.sql   ← work table
    └── ddl_undertone_insert_from_ext.sql        ← insert-from-external DML
```

## Deployment

| YAML | Scope |
|------|-------|
| `script_order_execution_undertone_dev.yaml` | Table + view creation |
| `script_order_execution_undertone_insert_update.yaml` | External table + data load |
