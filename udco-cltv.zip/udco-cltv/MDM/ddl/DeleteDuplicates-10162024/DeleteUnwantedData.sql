DELETE FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoDimensions`
where accountID = 'accountID' and accountName = 'accountName';