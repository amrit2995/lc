CREATE OR REPLACE VIEW `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_cltv.vw_CriteoDimensions`
OPTIONS (labels = [('appcode','emdg'),('bodname','mdm'),('domainname','collect'),('environment','<<ENV>>')])
AS (
    SELECT 
        accountID,
        accountName,
        productLine,
        campaignID,
        campaignName,
        sellingChannel,
        SAFE_CAST(campaignStartDate AS DATE) AS campaignStartDate,
        SAFE_CAST(campaignEndDate AS DATE) AS campaignEndDate,
        lineItemID,
        lineItemName,
        SAFE_CAST(lineItemStartDate AS DATE) AS lineItemStartDate,
        SAFE_CAST(lineItemEndDate AS DATE) AS lineItemEndDate,
        lineItemBudget,
        skuID,
        skuName,
        dw_file_path,
        dw_create_ts,
        `format`,
        source_application_cd,
        header_line,
        footer_line,
        job_id
    FROM 
    `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoDimensions`
);