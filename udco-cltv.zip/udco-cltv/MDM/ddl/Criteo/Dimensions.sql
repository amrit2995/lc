CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoDimensions`
(
    accountID STRING,
    accountName STRING,
    productLine  STRING,	
    campaignID STRING,
    campaignName STRING,	
    sellingChannel STRING,
    campaignStartDate STRING,
    campaignEndDate STRING,
    lineItemID STRING,
    lineItemName STRING,	
    lineItemStartDate STRING,
    lineItemEndDate STRING,
    lineItemBudget STRING,
    GTIN STRING,
    parentSkuID STRING,
    skuID STRING,
    skuName STRING,
    dw_file_path STRING,
    dw_create_ts TIMESTAMP,
    `format` STRING,
    source_application_cd STRING,
    header_line STRING,
    footer_line STRING,
    job_id STRING
)
CLUSTER BY campaignID, lineItemID, skuID, parentSkuID
OPTIONS (labels = [('appcode','emdg'),('bodname','mdm'),('domainname','collect'),('environment','<<ENV>>')]);
