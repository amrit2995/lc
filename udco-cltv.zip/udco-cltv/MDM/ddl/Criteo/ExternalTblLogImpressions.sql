CREATE EXTERNAL TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.ExtCriteoImpressionLogs`(
    impression_timestamp_EST DATETIME,
    impression_date	DATE,
    impression_id STRING,
    user_id	STRING,
    placement STRING,
    account_id STRING,
    campaign_id	STRING,
    campaign_type STRING,
    line_item_id STRING,
    keyword	STRING,
    platform STRING,
    page_type STRING,
    operating_system STRING,
    browser STRING,
    retailer_taxonomy STRING,
    sku_id STRING
)
OPTIONS (
  format='CSV',
  uris=['gs://udco-cltv-<<ENV>>-bkt-01/criteo/inbound/datalake/albertsons_impression_log_daily*.tsv'],
  field_delimiter='\t',
  skip_leading_rows = 1
);