CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoDailySnapshot`
(
    `Date` DATE,
    Platform STRING,
    pageType STRING,
    L1RetailerTaxonomy STRING,
    L2RetailerTaxonomy STRING,
    L3RetailerTaxonomy STRING,
    L4RetailerTaxonomy STRING,
    accountID STRING,
    campaignID STRING,
    lineItemID STRING,
    Keyword STRING,
    brandName STRING,
    GTIN STRING,
    parentSkuID STRING,
    skuId STRING,
    Impressions	FLOAT64,
    Clicks FLOAT64,
    Transactions FLOAT64,
    attributedSales	NUMERIC,
    attributedUnits	FLOAT64,
    workingMedia NUMERIC,
    netRevenue NUMERIC,
    dw_file_path STRING,
    dw_create_ts TIMESTAMP,
    `format` STRING,
    source_application_cd STRING,
    header_line STRING,
    footer_line STRING,
    job_id STRING
)
PARTITION BY Date
CLUSTER BY parentSkuID, pageType, campaignID, lineItemID
OPTIONS (labels = [('appcode','emdg'),('bodname','mdm'),('domainname','collect'),('environment','<<ENV>>')]);