CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.STG_CriteoImpressionLogs`
(
    impression_timestamp_EST STRING,
    impression_date	STRING,
    impression_id STRING,
    user_id	STRING,
    placement STRING,
    account_id STRING,
    campaign_id	STRING,
    campaign_type STRING,
    line_item_id STRING,
    keyword	STRING,
    platform STRING,
    page_type STRING,
    operating_system STRING,
    browser STRING,	
    retailer_taxonomy STRING,
    sku_id STRING,
    dw_file_path STRING,
    dw_create_ts TIMESTAMP,
    `format` STRING,
    source_application_cd STRING,
    header_line STRING,
    footer_line STRING,
    job_id STRING,
)
-- PARTITION BY impression_date
-- CLUSTER BY impression_timestamp_EST, placement, campaign_id, line_item_id
OPTIONS (labels = [('appcode','emdg'),('bodname','mdm'),('domainname','collect'),('environment','<<ENV>>')]);