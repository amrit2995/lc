CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_CRITEO_CLICKS`(job_id STRING)
BEGIN
    INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoClickLogs`
    SELECT 
        SAFE_CAST(click_timestamp_EST AS DATETIME) AS click_timestamp_EST,
        SAFE_CAST(click_date AS DATE) AS click_date,
        click_id,
        user_id,
        placement,
        account_id,
        campaign_id,
        campaign_type,
        line_item_id,
        keyword,
        platform,
        page_type,
        operating_system,
        browser,
        REPLACE(retailer_taxonomy, '"', '') AS retailer_taxonomy,
        sku_id,
        SAFE_CAST(cpc AS NUMERIC) AS cpc,
        dw_file_path,
        dw_create_ts,
        `format`,
        source_application_cd,
        header_line,
        footer_line,
        job_id
    FROM 
    `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.STG_CriteoClickLogs`;
END