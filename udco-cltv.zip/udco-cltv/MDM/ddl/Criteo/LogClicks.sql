CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoClickLogs`
(
    click_timestamp_EST DATETIME,
    click_date	DATE,
    click_id STRING,
    user_id	STRING,
    placement_id STRING,
    placement STRING,
    account_id STRING,
    campaign_id	STRING,
    campaign_type STRING,
    line_item_id STRING,
    keyword	STRING,
    platform STRING,
    page_type STRING,
    operating_system STRING,
    browser STRING,	
    retailer_taxonomy STRING,
    sku_id STRING,
    cpc NUMERIC,
    dw_file_path STRING,
    dw_create_ts TIMESTAMP,
    `format` STRING,
    source_application_cd STRING,
    header_line STRING,
    footer_line STRING,
    job_id STRING
)
PARTITION BY click_date
CLUSTER BY sku_id, placement_id, campaign_id, line_item_id
OPTIONS (labels = [('appcode','emdg'),('bodname','mdm'),('domainname','collect'),('environment','<<ENV>>')]);