CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_CRITEO_IMPRESSIONS`(job_id STRING)
BEGIN
    INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoImpressionLogs`
    SELECT 
        SAFE_CAST(impression_timestamp_EST AS DATETIME) AS impression_timestamp_EST,
        SAFE_CAST(impression_date AS DATE) AS impression_date,
        impression_id,
        user_id,
        placement,
        account_id,
        campaign_id,
        campaign_type,
        line_item_id,
        keyword,
        platform,
        page_type,
        operating_system,
        browser,
        retailer_taxonomy,
        sku_id,
        dw_file_path,
        dw_create_ts,
        `format`,
        source_application_cd,
        header_line,
        footer_line,
        job_id
    FROM 
    `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.STG_CriteoImpressionLogs`;
END