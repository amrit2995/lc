CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_CRITEO_DELETE_DUPLICATE_IMPRESSIONS`(job_id STRING)
BEGIN
    DELETE FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoImpressionLogs` cil
    WHERE EXISTS (
        With DuplicateImpressions AS (
              select * from (
              select *,
                LEAD(cnt) OVER (PARTITION BY impression_date order by impression_date, dw_create_ts, rownum) as next_row
                from (
                select impression_date, dw_create_ts, count(*) as cnt,
                ROW_NUMBER() OVER (PARTITION BY impression_date order by dw_create_ts desc) as rownum
                FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoImpressionLogs`
                where impression_date is not null
                group by 1,2
                )
                order by 1,2
              ) where cnt = next_row
        ) select * from DuplicateImpressions dis
        WHERE cil.impression_date = dis.impression_date and dis.dw_create_ts = cil.dw_create_ts
    );
END