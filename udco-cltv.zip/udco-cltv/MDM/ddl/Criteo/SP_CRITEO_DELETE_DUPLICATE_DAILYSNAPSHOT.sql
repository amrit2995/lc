CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_CRITEO_DELETE_DUPLICATE_DAILYSNAPSHOT`(job_id STRING)
BEGIN
    DELETE FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoDailySnapshot` cds
    WHERE EXISTS (
        With DuplicateDailySnapshot AS (
          select * from (
              select *,
                LEAD(cnt) OVER (PARTITION BY date order by date, dw_create_ts, rownum) as next_row
                from (
                    select date, dw_create_ts, count(*) as cnt,
                    ROW_NUMBER() OVER (PARTITION BY date order by dw_create_ts desc) as rownum
                    FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoDailySnapshot`
                    where date is not null
                    group by 1,2
                )
                order by 1,2
          ) where cnt = next_row
      ) SELECT * FROM DuplicateDailySnapshot dds
        WHERE cds.date = dds.date and dds.dw_create_ts = cds.dw_create_ts
    );
END