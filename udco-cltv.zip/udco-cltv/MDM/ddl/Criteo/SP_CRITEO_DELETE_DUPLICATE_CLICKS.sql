CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_CRITEO_DELETE_DUPLICATE_CLICKS`(job_id STRING)
BEGIN
    DELETE FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoClickLogs` ccl
    WHERE EXISTS (
        With DuplicateClicks AS (
              select * from (
              select *,
                LEAD(cnt) OVER (PARTITION BY click_date order by click_date, dw_create_ts, rownum) as next_row
                from (
                select click_date, dw_create_ts, count(*) as cnt,
                ROW_NUMBER() OVER (PARTITION BY click_date order by dw_create_ts desc) as rownum
                FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoClickLogs`
                where click_date is not null
                group by 1,2
                )
                order by 1,2
              ) where cnt = next_row
        ) select * from DuplicateClicks dcs
        WHERE ccl.click_date = dcs.click_date and dcs.dw_create_ts = ccl.dw_create_ts
    );
END