CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoDailyFillRate`
(
	Date								DATE,
	Platform							STRING,
	PageType							STRING,
	KeywordStemmed						STRING,
	PlacementName						STRING,
	PlacementType						STRING,
	PageTaxonomyBreadcrumb				STRING,
	WorkingMedia						NUMERIC,
	NetRevenue							NUMERIC,
	Impressions							FLOAT64,
	Clicks								FLOAT64,
	PlacementImpressions				FLOAT64,
	DeliverablePlacements				FLOAT64,
	CoveredAvailablePlacements			FLOAT64,
	UnfilledNotEnoughDemand				FLOAT64,
	UnfilledTotalAuctionSettings		FLOAT64,
	UnfilledReturnedNotPainted			FLOAT64,
    dw_file_path STRING,
    dw_create_ts TIMESTAMP,
    `format` STRING,
    source_application_cd STRING,
    header_line STRING,
    footer_line STRING,
    job_id STRING
)
PARTITION BY Date
CLUSTER BY Platform, PageType, KeywordStemmed, PlacementType
OPTIONS (
  labels = [('appcode','emdg'),('bodname','mdm'),('domainname','collect'),('environment','<<ENV>>')]);
  
  