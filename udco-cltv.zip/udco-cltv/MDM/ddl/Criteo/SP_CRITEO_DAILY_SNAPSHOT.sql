CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_CRITEO_DAILY_SNAPSHOT`(job_id STRING)
BEGIN
    INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CriteoDailySnapshot`
    SELECT 
        SAFE_CAST(`Date` AS DATE) AS `Date`,
        Platform,
        pageType,
        L1RetailerTaxonomy,
        L2RetailerTaxonomy,
        L3RetailerTaxonomy,
        L4RetailerTaxonomy,
        accountID,
        campaignID,
        lineItemID,
        Keyword,
        brandName,
        SAFE_CAST(Impressions AS INT64) AS Impressions,
        SAFE_CAST(Clicks AS INT64) AS Clicks,
        SAFE_CAST(Transactions AS INT64) AS Transactions,
        SAFE_CAST(attributedSales AS NUMERIC) AS attributedSales,
        SAFE_CAST(attributedUnits AS INT64) AS attributedUnits,
        SAFE_CAST(workingMedia AS NUMERIC) AS workingMedia,
        SAFE_CAST(netRevenue AS NUMERIC) AS netRevenue,
        dw_file_path,
        dw_create_ts,
        `format`,
        source_application_cd,
        header_line,
        footer_line,
        job_id
    FROM 
    `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.STG_CriteoDailySnapshot`;
END