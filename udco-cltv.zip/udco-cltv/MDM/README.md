# MDM (Master Data Management — Criteo)

Manages Criteo ad-platform data: billing, click logs, daily snapshots, dimension tables, impression logs, and fill rates. Includes deduplication SPs and file-splitting utilities.

## Pipeline Flow

```
GCS Files ──► [SToV] ──► Raw Tables ──► [VToB / Dedup SPs] ──► Confirmed Tables
```

### File Splitting
Large source files are split before ingestion using `SplitLargeFiles.sh` and Python helper scripts in `config/`.

## Directory Layout

```
MDM/
├── README.md
├── params_dev.json / params_qa.json / params_prod.json
├── config/                         ← 14 JSONs + Shell/Python utilities
│   ├── MDM_*_WF.json               ← DAG definitions
│   ├── SToV_MDM_*_FileToBQ.json    ← file-to-BQ ingestion configs
│   ├── SplitLargeFiles.sh          ← file-splitting shell script
│   └── *.py                        ← Python helpers
├── ddl/                            ← 3 core DDLs
│   ├── Criteo/                     ← 22 Criteo-specific DDLs
│   └── DeleteDuplicates-*/         ← deduplication SPs
└── OldConfig/                      ← 11 deprecated configs (historical reference)
```

## Key Entities

| Entity | DDL Location |
|--------|-------------|
| Criteo Billing | `ddl/Criteo/` |
| Click Logs | `ddl/Criteo/` |
| Daily Snapshots | `ddl/Criteo/` |
| Dimensions | `ddl/Criteo/` |
| Impression Logs | `ddl/Criteo/` |
| Fill Rates | `ddl/Criteo/` |
