#!/bin/bash

# Input gz compressed CSV file
input_file="$1"

# Temporary files
temp_file="temp.tsv"
first_half="first_half.tsv"
second_half="second_half.tsv"
second_half_with_header="second_half_with_header.tsv"

# Unzip the input file
gunzip -c "$input_file" > "$temp_file"
echo "Unzipped the input file"

# Get the total number of lines in the file
total_lines=$(wc -l < "$temp_file")
echo "Total lines in the file: $total_lines"

# Calculate the middle line number
middle_line=$((total_lines / 2))
echo "Middle line number: $middle_line"

# Extract the header
header=$(head -n 1 "$temp_file")

# Split the file into two halves
head -n "$middle_line" "$temp_file" > "$first_half"
tail -n +$((middle_line + 1)) "$temp_file" > "$second_half"

# Add the header to the second half
echo "$header" > "$second_half_with_header"
cat "$second_half" >> "$second_half_with_header"

# Compress the output files
gzip "$first_half"
echo "Compressed the first half"

gzip "$second_half_with_header"
echo "Compressed the second half"

# Clean up temporary files
rm "$temp_file" "$second_half"
echo "Cleaned up temporary files"

filename=$(basename "$input_file")
filename_without_extension="${filename%.*.*}"
echo "Filename without extension: $filename_without_extension"

mv "$first_half.gz" "${filename_without_extension}_1.tsv.gz"
echo "Renamed the first half file to ${filename_without_extension}_1.tsv.gz"

mv "$second_half_with_header.gz" "${filename_without_extension}_2.tsv.gz"
echo "Renamed the second half file to ${filename_without_extension}_2.tsv.gz"

echo "Files have been split and compressed: ${filename_without_extension}_1.tsv.gz and ${filename_without_extension}_2.tsv.gz"
