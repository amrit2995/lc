from airflow.models import DAG
from airflow.operators.python_operator import PythonOperator
from google.cloud import storage
import os
import pandas as pd
from datetime import datetime

bucket_name = "udco-cltv-<<ENV>>-bkt-01"
source_blob_prefix = "criteo/inbound/"
large_files_blob_prefix = "criteo/inbound/largefiles/"
file_filter = "albertsons_impression_log_daily_"
chunk_size = 1000000
size_limit = 4294967296 # 4 GB
temp_files = []


def chunk_files_and_upload_to_gcs(**context):
    try:
        client = storage.Client()
        bucket = client.bucket(bucket_name)
        print(f"Bucket name - {bucket_name}")

        for blob in client.list_blobs(bucket, prefix=source_blob_prefix, delimiter='/'):
            if f'{source_blob_prefix}{file_filter}' not in blob.name:
                print(f"Skipping {blob.name} as it does not match the filter {file_filter}")
                continue

            print(f"Processing {blob.name}. Size Limit is {size_limit}. Size - {blob.size} bytes")
            if blob.size < size_limit:
                print(f"Skipping {blob} as it is smaller than {size_limit} bytes")
                continue

            source_blob_file_name = (blob.name.split('/')[-1]).split('.')[0]

            chunk_iter = pd.read_csv(f"gs://{bucket_name}/{blob.name}", sep='\t',
                                     chunksize=chunk_size, compression="gzip")
            for chunk_number, chunk in enumerate(chunk_iter):
                print(f"Chunk {chunk_number} shape - {chunk.shape}")

                # Upload the gzipped chunk to GCS
                chunk_filename = f"gs://{bucket_name}/{source_blob_prefix}{source_blob_file_name}_chunk{chunk_number}.tsv.gz"
                print(f"Writing Chunk # {chunk_number}. filename - {chunk_filename}")
                chunk.to_csv(chunk_filename, sep='\t', index=False, compression="gzip")

            # Move the original file to largefiles folder
            bucket.rename_blob(blob, f'{large_files_blob_prefix}{blob.name.split("/")[-1]}.tsv.gz')
    except Exception as e:
        raise Exception(f"Error while chunking files: {str(e)}")
    finally:
        for temp_file in temp_files:
            if os.path.exists(temp_file):
                os.remove(temp_file)
                print(f"Deleted {temp_file}")
            else:
                print(f"File {temp_file} already deleted")



with DAG('mdm_impressions_chunk_large_files', schedule_interval='30 5 * * *',
         max_active_runs=1,
         start_date=datetime(2024, 11, 17, 12, 0, 0),
         catchup=False) as dag:

    chunk_files = PythonOperator(
        task_id='chunk_files_and_upload_to_gcs',
        python_callable=chunk_files_and_upload_to_gcs,
        provide_context=True,
        dag=dag
    )

    chunk_files