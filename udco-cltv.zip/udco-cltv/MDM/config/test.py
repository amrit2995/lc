import pandas as pd
import tempfile

temp_files = []
chunk_iter = pd.read_csv('/Users/gsrid02/Documents/Criteo/Shellscripts/albertsons_impression_log_daily_2024-11-27_2.tsv.gz',
                         sep='\t', chunksize=5000000, compression="gzip")

for chunk_number, chunk in enumerate(chunk_iter):
    print(f"Chunk shape - {chunk.shape}")
    with open(f'/Users/gsrid02/Documents/Criteo/Shellscripts/imp_{chunk_number}.tsv', 'wb') as tmp_file:
        #with gzip.GzipFile(fileobj=tmp_file, mode='wb') as f_out:
        chunk.to_csv(tmp_file, sep='\t', index=False, compression="gzip")
        print(f"Chunk written to - {tmp_file.name}")
        temp_files.append(tmp_file.name)