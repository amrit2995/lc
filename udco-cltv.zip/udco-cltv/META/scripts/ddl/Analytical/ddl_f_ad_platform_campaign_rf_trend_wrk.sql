CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.F_AD_PLATFORM_CAMPAIGN_RF_TREND_WRK`
(
	PERFORMANCE_DAY_ID NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101" ),
	PLATFORM_ADVERTISER_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
	AD_MEDIA_PLATFORM_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
	AD_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system." ),
	PLATFORM_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for platform media campaign – uniquely identifies each campaign per platform." ),
	AD_MEDIA_OPPORTUNITY_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for opportunity – uniquely identifies each advertising opportunity record in the system." ),
	AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for promotional channel – uniquely identifies each promotional channel record in the system." ),
	CUMULATIVE_AD_CAMPAIGN_REACH_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Cumulative Count of audience exposed to campaign" ),
	CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Cumulative value on Number of audience exposed to the campaign" ),
	CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Cumulative Count of  clicks received from the audience reached" ),
	CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT NUMERIC(14,2) NOT NULL OPTIONS(DESCRIPTION = "Cumulative Frequency of the campaign" ),
	CUMULATIVE_CLICK_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Count of clicks on the ad"  ),
	CUMULATIVE_IMPRESSION_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Impression count for Social Performance" ),
	CUMULATIVE_MEASUREMENT_REVENUE_AMT NUMERIC(14,2) NOT NULL OPTIONS(DESCRIPTION = "For DV360/GAM: Aggregation of online, offline, and mobile revenue For Meta/Pinterest: No available attributable sales" ),
	CUMULATIVE_CPG_MEDIA_SPEND_AMT NUMERIC(14,2) NOT NULL OPTIONS(DESCRIPTION = "This reflects the amount charged by Albertsons to the CPG. platform_impressions * hub_l2_cpg_cpm / 1000" ),
	DW_CREATE_TS TIMESTAMP NOT NULL,
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL
)
OPTIONS(
	DESCRIPTION = "Fact Table F_AD_PLATFORM_CAMPAIGN_RF_TREND_WRK holds the cumulative count of Reach and Impressions for a Campaign .It maintains Cumulative data at campaign level with daily loads, Important to note as these counts are cumulative per date , Any aggregation to have data at higer or lower granularity level will output inaccurate  numbers."
	,labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);