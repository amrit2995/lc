CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_PLATFORM_MEDIA_CAMPAIGN_WRK`
(
  PLATFORM_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = 'Surrogate key for platform media campaign – uniquely identifies each campaign per platform.'),
	PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Name"),
	PLATFORM_CAMPAIGN_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Campaign ID"),
	PLATFORM_CAMPAIGN_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Platform campaign name"),
	PLATFORM_CAMPAIGN_START_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Platform Campaign START Date"),
	PLATFORM_CAMPAIGN_END_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Platform Campaign End Date"),
	PLATFORM_BUYING_TYPE_CD STRING NOT NULL OPTIONS(DESCRIPTION = 'its the type of sale, if it was a direct sale from albertson or Indirect , thru partner'),
	PLATFORM_ACTIVATION_SPECIALIST_TXT STRING NOT NULL OPTIONS(DESCRIPTION = "Platform activation specialist"),
	IS_ALBERTSONS_MANAGED_SOLD_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Albertsons Managed sold indicator"),
	IS_SELF_SERVE_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Self serve indicator"),
	IS_COBRANDED_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Co-branded indicator")
)
OPTIONS(
	DESCRIPTION = "D1_PLATFORM_MEDIA_CAMAPIGN staging table to handle delta.",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);
	