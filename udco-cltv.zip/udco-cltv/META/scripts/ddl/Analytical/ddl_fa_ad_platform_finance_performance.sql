-- Fact Table: FA_AD_PLATFORM_FINANCE_PERFORMANCE
-- Purpose: Stores finance performance metrics at the most granular level

DROP TABLE IF EXISTS `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.FA_AD_PLATFORM_FINANCE_PERFORMANCE`;

CREATE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.FA_AD_PLATFORM_FINANCE_PERFORMANCE`
(
    PERFORMANCE_DAY_ID                  NUMERIC         NOT NULL    OPTIONS(description="Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101"),
    AD_MEDIA_PLATFORM_D1_SK             NUMERIC         NOT NULL    OPTIONS(description="Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."),
    AD_MEDIA_CAMPAIGN_D1_SK             NUMERIC         NOT NULL    OPTIONS(description="Surrogate key for campaign – uniquely identifies each advertising campaign record in the system."),
    AD_MEDIA_CAMPAIGN_LINE_D1_SK        NUMERIC         NOT NULL    OPTIONS(description="Surrogate key for campaign line item – uniquely identifies each line item record."),
    AD_MEDIA_OPPORTUNITY_D1_SK          NUMERIC         NOT NULL    OPTIONS(description="Surrogate key for campaign – uniquely identifies each advertising campaign record in the system."),
    PLATFORM_ADVERTISER_D1_SK           NUMERIC         NOT NULL    OPTIONS(description="Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."),
    PLATFORM_MEDIA_CAMPAIGN_D1_SK       NUMERIC         NOT NULL    OPTIONS(description="Surrogate key for platform media campaign – uniquely identifies each campaign per platform."),
    PLATFORM_MEDIA_LINE_D1_SK           NUMERIC         NOT NULL    OPTIONS(description="Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns."),
    AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK NUMERIC         NOT NULL    OPTIONS(description="Surrogate key for promotional channel – identifies the advertising channel type (Social, Display, CTV, etc.)"),
    TOTAL_CLICK_CNT                     NUMERIC         NOT NULL    OPTIONS(description="Count of clicks on the ad"),
    TOTAL_IMPRESSION_CNT                NUMERIC         NOT NULL    OPTIONS(description="Impression count for Social Performance"),
    TOTAL_MEDIA_SPEND_AMT               NUMERIC(14,2)   NOT NULL    OPTIONS(description="This reflects the amount charged by Albertsons to the CPG."),
    VIDEO_TRUEVIEW_CNT                  NUMERIC         NOT NULL    OPTIONS(description="Number of people who saw at least the start of the video."),
    CPG_MEDIA_SPEND_AMT                 NUMERIC(14,2)   NOT NULL    OPTIONS(description="This reflects the amount charged by Albertsons to the CPG."),
    BILLABLE_IMPRESSION_CNT             NUMERIC         NOT NULL    OPTIONS(description="Impression count for Social Performance"),
    BILLABLE_CPG_MEDIA_SPEND_AMT        NUMERIC(14,2)   NOT NULL    OPTIONS(description="This reflects the amount charged by Albertsons to the CPG."),
    DW_CREATE_TS                        TIMESTAMP       NOT NULL    OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS                   TIMESTAMP       NOT NULL    OPTIONS(description="When a record is updated, this would be the current timestamp")
)
OPTIONS(
    description="Fact table storing finance performance metrics at granular level with billable impressions and CPG media spend calculations",
    labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);