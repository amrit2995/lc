CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.FA_AD_PLATFORM_FINANCE_PERFORMANCE`
(
	PERFORMANCE_DAY_ID OPTIONS(DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101" ),
	AD_MEDIA_PLATFORM_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
	AD_MEDIA_CAMPAIGN_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system." ),
	AD_MEDIA_CAMPAIGN_LINE_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for campaign line item – uniquely identifies each line item record." ),
	AD_MEDIA_OPPORTUNITY_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system." ),
	PLATFORM_ADVERTISER_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
	PLATFORM_MEDIA_CAMPAIGN_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for platform media campaign – uniquely identifies each campaign per platform." ),
	PLATFORM_MEDIA_LINE_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns." ),
	AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for promotional channel – identifies the advertising channel type (Social, Display, CTV, etc.)" ),
	TOTAL_CLICK_CNT OPTIONS(DESCRIPTION = "Count of clicks on the ad" ),
	TOTAL_IMPRESSION_CNT OPTIONS(DESCRIPTION = "Impression count for Social Performance" ),
	TOTAL_MEDIA_SPEND_AMT OPTIONS(DESCRIPTION = "This reflects the amount charged by Albertsons to the CPG." ),
	VIDEO_TRUEVIEW_CNT OPTIONS(DESCRIPTION = "Number of people who saw at least the start of the video." ),
	CPG_MEDIA_SPEND_AMT OPTIONS(DESCRIPTION = "This reflects the amount charged by Albertsons to the CPG." ),
	BILLABLE_IMPRESSION_CNT OPTIONS(DESCRIPTION = "Impression count for Social Performance" ),
	BILLABLE_CPG_MEDIA_SPEND_AMT OPTIONS(DESCRIPTION = "This reflects the amount charged by Albertsons to the CPG." ),
	DW_CREATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
    PERFORMANCE_DAY_ID,
	AD_MEDIA_PLATFORM_D1_SK,
	AD_MEDIA_CAMPAIGN_D1_SK,
	AD_MEDIA_CAMPAIGN_LINE_D1_SK,
	AD_MEDIA_OPPORTUNITY_D1_SK,
	PLATFORM_ADVERTISER_D1_SK,
	PLATFORM_MEDIA_CAMPAIGN_D1_SK,
	PLATFORM_MEDIA_LINE_D1_SK,
	AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK,
	TOTAL_CLICK_CNT,
	TOTAL_IMPRESSION_CNT,
	TOTAL_MEDIA_SPEND_AMT,
	VIDEO_TRUEVIEW_CNT,
	CPG_MEDIA_SPEND_AMT,
	BILLABLE_IMPRESSION_CNT,
	BILLABLE_CPG_MEDIA_SPEND_AMT,
	DW_CREATE_TS,
	DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.FA_AD_PLATFORM_FINANCE_PERFORMANCE`
