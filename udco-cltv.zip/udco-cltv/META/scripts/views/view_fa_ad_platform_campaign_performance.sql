CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE`
(
		PERFORMANCE_DAY_ID OPTIONS(DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101" ),
		PLATFORM_MEDIA_AD_UNIT_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for creative unit – uniquely identifies each creative ad placement." ),
		PLATFORM_ADVERTISER_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
		AD_MEDIA_PLATFORM_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
		AD_MEDIA_CAMPAIGN_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system." ),
		AD_MEDIA_CAMPAIGN_LINE_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for campaign line item – uniquely identifies each line item record." ),
		PLATFORM_MEDIA_CAMPAIGN_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for platform media campaign – uniquely identifies each campaign per platform." ),
		PLATFORM_MEDIA_LINE_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns." ),
		PLATFORM_MEDIA_CREATIVE_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns." ),
		PLATFORM_MEDIA_PLACEMENT_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for creative unit Placement  – uniquely identifies each creative ad placement." ),
		AD_MEDIA_OPPORTUNITY_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system." ),
		PLATFORM_MEDIA_ADVERTISEMENT_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for creative unit – uniquely identifies each creative ad placement." ),
		TOTAL_CLICK_CNT  OPTIONS(DESCRIPTION = "Count of clicks on the ad"  ),
		TOTAL_IMPRESSION_CNT  OPTIONS(DESCRIPTION = "Impression count for Social Performance" ),
		TOTAL_MEDIA_SPEND_AMT  OPTIONS(DESCRIPTION = "This reflects the amount charged by Albertsons to the CPG." ),
		VIDEO_START_CNT  OPTIONS(DESCRIPTION = "Number of people who saw at least the start of the video." ),
		VIDEO_25P_CNT  OPTIONS(DESCRIPTION = "Number of people who saw at least 25% of the video." ),
		VIDEO_50P_CNT  OPTIONS(DESCRIPTION = "Number of people who saw at least 50% of the video." ),
		VIDEO_75P_CNT  OPTIONS(DESCRIPTION = "Number of people who saw at least 75% of the video." ),
		VIDEO_COMPLETE_CNT  OPTIONS(DESCRIPTION = "Number of people who saw at least 100% of the video." ),
		POST_REACTION_ANGRY_CNT  OPTIONS(DESCRIPTION = "Count of 'Angry' reactions on Facebook. Not present on Instagram." ),
		POST_REACTION_WOW_CNT  OPTIONS(DESCRIPTION = "Count of 'Wow' reactions on Facebook. Not present on Instagram." ),
		POST_REACTION_LOVE_CNT  OPTIONS(DESCRIPTION = "Count of 'Love' reactions on Facebook. Not present on Instagram." ),
		POST_REACTION_CARE_CNT  OPTIONS(DESCRIPTION = "Count of 'Care' reactions on Facebook. Not present on Instagram." ),
		POST_REACTION_HAHA_CNT  OPTIONS(DESCRIPTION = "Count of 'Haha'(Laugh) reactions on Facebook. Not present on Instagram." ),
		POST_REACTION_LIKE_CNT  OPTIONS(DESCRIPTION = "Count of likes across Meta properties. This metric is cumulative across Facebook & Instagram." ),
		POST_REACTION_SAD_CNT  OPTIONS(DESCRIPTION = "Count of 'Sad' reactions across Meta properties. This metric is cumulative across Facebook & Instagram." ),
		TOTAL_POST_ENGAGEMENT_CNT  OPTIONS(DESCRIPTION = "Count of engagements across Meta properties. Includes reactions, likes, comments, shares." ),
		TOTAL_POST_COMMENT_CNT  OPTIONS(DESCRIPTION = "Count of comments across Meta properties. This metric is cumulative across Facebook & Instagram." ),
		TOTAL_POST_REACTION_CNT  OPTIONS(DESCRIPTION = "Count of Reactions across Meta properties. This metric is cumulative across Facebook & Instagram." ),
		TOTAL_PINTEREST_ENGAGEMENT_CNT  OPTIONS(DESCRIPTION = "Count of total engagements on Pinterest. This includes people clicking on or saving a pin." ),
		TOTAL_PINTEREST_REPIN_CNT  OPTIONS(DESCRIPTION = "Count or “Re-Pins” on Pinterest." ),
		CPG_MEDIA_SPEND_AMT  OPTIONS(DESCRIPTION = "This reflects the amount charged by Albertsons to the CPG." ),
		MEASUREMENT_ONLINE_TRANSACTIONS_CNT OPTIONS(DESCRIPTION = "Number of Orders completed for given set of dimensions purchased online For DV360/GAM: Sum of online transactions\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		MEASUREMENT_ONLINE_REVENUE_AMT OPTIONS(DESCRIPTION = "Attributed Revenue for given set of dimensions purchased online For DV360/GAM: Sum of online revenue\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		MEASUREMENT_OFFLINE_TRANSACTIONS_CNT OPTIONS(DESCRIPTION = "Number of Orders completed for given set of dimensions purchased instore For DV360/GAM: Sum of offline transactions\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		MEASUREMENT_OFFLINE_REVENUE_AMT OPTIONS(DESCRIPTION = "Attributed Revenue for given set of dimensions purchased online For DV360/GAM: Sum of offline revenue\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		MEASUREMENT_MOBILE_TRANSACTIONS_CNT OPTIONS(DESCRIPTION = "For DV360/GAM: Sum of mobile transactions\nFor Meta: No available attributable sales\nFor Pinterest: Pinterest does not provide attributable sales by sales channel\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		MEASUREMENT_MOBILE_REVENUE_AMT OPTIONS(DESCRIPTION = "For DV360/GAM: Sum of mobile revenue\nFor Meta: No available attributable sales\nFor Pinterest: Pinterest does not provide attributable sales by sales channel\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		MEASUREMENT_TOTAL_TRANSACTIONS_CNT OPTIONS(DESCRIPTION = "For DV360/GAM: Aggregation of online, offline, and mobile transactions\nFor Meta/Pinterest: No available attributable sales" ),
		MEASUREMENT_TOTAL_REVENUE_AMT OPTIONS(DESCRIPTION = "For DV360/GAM: Aggregation of online, offline, and mobile revenue\nFor Meta/Pinterest: No available attributable sales" ),
		MEASUREMENT_ONLINE_UNITS_CNT OPTIONS(DESCRIPTION = "For DV360/GAM: Sum of online units\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		MEASUREMENT_OFFLINE_UNITS_CNT OPTIONS(DESCRIPTION = "For DV360/GAM: Sum of offline units\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		MEASUREMENT_MOBILE_UNITS_CNT OPTIONS(DESCRIPTION = "For DV360/GAM: Sum of mobile units\nFor Meta: No available attributable sales\nFor Pinterest: Pinterest does not provide attributable sales by sales channel\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		MEASUREMENT_TOTAL_UNITS_CNT OPTIONS(DESCRIPTION = "For DV360/GAM: Aggregation of online, offline, and mobile units\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension." ),
		DW_CREATE_TS  OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
		DW_LAST_UPDATE_TS  OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
		T.PERFORMANCE_DAY_ID,
		T.PLATFORM_MEDIA_AD_UNIT_D1_SK,
		T.PLATFORM_ADVERTISER_D1_SK,
		T.AD_MEDIA_PLATFORM_D1_SK,
		T.AD_MEDIA_CAMPAIGN_D1_SK,
		T.AD_MEDIA_CAMPAIGN_LINE_D1_SK,
		T.PLATFORM_MEDIA_CAMPAIGN_D1_SK,
		T.PLATFORM_MEDIA_LINE_D1_SK,
		T.PLATFORM_MEDIA_CREATIVE_D1_SK,
		T.PLATFORM_MEDIA_PLACEMENT_D1_SK,
		T.AD_MEDIA_OPPORTUNITY_D1_SK,
		T.PLATFORM_MEDIA_ADVERTISEMENT_D1_SK,
		COALESCE(P.TOTAL_CLICK_CNT, T.TOTAL_CLICK_CNT) AS TOTAL_CLICK_CNT,
		COALESCE(P.TOTAL_IMPRESSION_CNT, T.TOTAL_IMPRESSION_CNT) AS TOTAL_IMPRESSION_CNT,
		COALESCE(P.TOTAL_MEDIA_SPEND_AMT, T.TOTAL_MEDIA_SPEND_AMT) AS TOTAL_MEDIA_SPEND_AMT,
		COALESCE(P.VIDEO_START_CNT, T.VIDEO_START_CNT) AS VIDEO_START_CNT,
		COALESCE(P.VIDEO_25P_CNT, T.VIDEO_25P_CNT) AS VIDEO_25P_CNT,
		COALESCE(P.VIDEO_50P_CNT, T.VIDEO_50P_CNT) AS VIDEO_50P_CNT,
		COALESCE(P.VIDEO_75P_CNT, T.VIDEO_75P_CNT) AS VIDEO_75P_CNT,
		COALESCE(P.VIDEO_COMPLETE_CNT, T.VIDEO_COMPLETE_CNT) AS VIDEO_COMPLETE_CNT,
		COALESCE(P.POST_REACTION_ANGRY_CNT, T.POST_REACTION_ANGRY_CNT) AS POST_REACTION_ANGRY_CNT,
		COALESCE(P.POST_REACTION_WOW_CNT, T.POST_REACTION_WOW_CNT) AS POST_REACTION_WOW_CNT,
		COALESCE(P.POST_REACTION_LOVE_CNT, T.POST_REACTION_LOVE_CNT) AS POST_REACTION_LOVE_CNT,
		COALESCE(P.POST_REACTION_CARE_CNT, T.POST_REACTION_CARE_CNT) AS POST_REACTION_CARE_CNT,
		COALESCE(P.POST_REACTION_HAHA_CNT, T.POST_REACTION_HAHA_CNT) AS POST_REACTION_HAHA_CNT,
		COALESCE(P.POST_REACTION_LIKE_CNT, T.POST_REACTION_LIKE_CNT) AS POST_REACTION_LIKE_CNT,
		COALESCE(P.POST_REACTION_SAD_CNT, T.POST_REACTION_SAD_CNT) AS POST_REACTION_SAD_CNT,
		COALESCE(P.TOTAL_POST_ENGAGEMENT_CNT, T.TOTAL_POST_ENGAGEMENT_CNT) AS TOTAL_POST_ENGAGEMENT_CNT,
		COALESCE(P.TOTAL_POST_COMMENT_CNT, T.TOTAL_POST_COMMENT_CNT) AS TOTAL_POST_COMMENT_CNT,
		COALESCE(P.TOTAL_POST_REACTION_CNT, T.TOTAL_POST_REACTION_CNT) AS TOTAL_POST_REACTION_CNT,
		COALESCE(P.TOTAL_PINTEREST_ENGAGEMENT_CNT, T.TOTAL_PINTEREST_ENGAGEMENT_CNT) AS TOTAL_PINTEREST_ENGAGEMENT_CNT,
		COALESCE(P.TOTAL_PINTEREST_REPIN_CNT, T.TOTAL_PINTEREST_REPINS_CNT) AS TOTAL_PINTEREST_REPIN_CNT,
		COALESCE(P.CPG_MEDIA_SPEND_AMT, T.CPG_MEDIA_SPEND_AMT) AS CPG_MEDIA_SPEND_AMT,
		COALESCE(P.MEASUREMENT_ONLINE_TRANSACTIONS_CNT, NULL) AS MEASUREMENT_ONLINE_TRANSACTIONS_CNT,
		COALESCE(P.MEASUREMENT_ONLINE_REVENUE_AMT, NULL) AS MEASUREMENT_ONLINE_REVENUE_AMT,
		COALESCE(P.MEASUREMENT_OFFLINE_TRANSACTIONS_CNT, NULL) AS MEASUREMENT_OFFLINE_TRANSACTIONS_CNT,
		COALESCE(P.MEASUREMENT_OFFLINE_REVENUE_AMT, NULL) AS MEASUREMENT_OFFLINE_REVENUE_AMT,
		COALESCE(P.MEASUREMENT_MOBILE_TRANSACTIONS_CNT, NULL) AS MEASUREMENT_MOBILE_TRANSACTIONS_CNT,
		COALESCE(P.MEASUREMENT_MOBILE_REVENUE_AMT, NULL) AS MEASUREMENT_MOBILE_REVENUE_AMT,
		COALESCE(P.MEASUREMENT_TOTAL_TRANSACTIONS_CNT, NULL) AS MEASUREMENT_TOTAL_TRANSACTIONS_CNT,
		COALESCE(P.MEASUREMENT_TOTAL_REVENUE_AMT, NULL) AS MEASUREMENT_TOTAL_REVENUE_AMT,
		COALESCE(P.MEASUREMENT_ONLINE_UNITS_CNT, NULL) AS MEASUREMENT_ONLINE_UNITS_CNT,
		COALESCE(P.MEASUREMENT_OFFLINE_UNITS_CNT, NULL) AS MEASUREMENT_OFFLINE_UNITS_CNT,
		COALESCE(P.MEASUREMENT_MOBILE_UNITS_CNT, NULL) AS MEASUREMENT_MOBILE_UNITS_CNT,
		COALESCE(P.MEASUREMENT_TOTAL_UNITS_CNT, NULL) AS MEASUREMENT_TOTAL_UNITS_CNT,
		COALESCE(P.DW_CREATE_TS, T.DW_CREATE_TS) AS DW_CREATE_TS,
		COALESCE(P.DW_LAST_UPDATE_TS, T.DW_LAST_UPDATE_TS) AS DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_CAMPAIGN_TREND` T
LEFT JOIN `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE` P
	ON T.PERFORMANCE_DAY_ID = P.PERFORMANCE_DAY_ID
	AND T.AD_MEDIA_PLATFORM_D1_SK = P.AD_MEDIA_PLATFORM_D1_SK
	AND T.AD_MEDIA_CAMPAIGN_D1_SK = P.AD_MEDIA_CAMPAIGN_D1_SK
	AND T.AD_MEDIA_CAMPAIGN_LINE_D1_SK = P.AD_MEDIA_CAMPAIGN_LINE_D1_SK
	AND T.PLATFORM_MEDIA_CAMPAIGN_D1_SK = P.PLATFORM_MEDIA_CAMPAIGN_D1_SK
	AND T.PLATFORM_MEDIA_LINE_D1_SK = P.PLATFORM_MEDIA_LINE_D1_SK
	AND T.PLATFORM_MEDIA_CREATIVE_D1_SK = P.PLATFORM_MEDIA_CREATIVE_D1_SK
	AND T.PLATFORM_MEDIA_PLACEMENT_D1_SK = P.PLATFORM_MEDIA_PLACEMENT_D1_SK
	AND T.PLATFORM_MEDIA_ADVERTISEMENT_D1_SK = P.PLATFORM_MEDIA_ADVERTISEMENT_D1_SK
	AND T.PLATFORM_MEDIA_AD_UNIT_D1_SK = P.PLATFORM_MEDIA_AD_UNIT_D1_SK
	AND T.PLATFORM_ADVERTISER_D1_SK = P.PLATFORM_ADVERTISER_D1_SK
	AND T.AD_MEDIA_OPPORTUNITY_D1_SK = P.AD_MEDIA_OPPORTUNITY_D1_SK