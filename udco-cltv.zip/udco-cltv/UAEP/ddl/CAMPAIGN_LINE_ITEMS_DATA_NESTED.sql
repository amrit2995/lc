CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CAMPAIGN_LINE_ITEMS_DATA_NESTED` (
  action_type STRING,
  action_id STRING,
  action_at STRING,
  source STRING,
  version STRING,
  data STRUCT<
    id STRING,
    name STRING,
    external_associations ARRAY<STRUCT<
      system STRING,
      identifier STRING
    >>,
    state STRING,
    is_created BOOLEAN,
    is_modified BOOLEAN,
    is_deleted BOOLEAN,
    advertiser STRUCT<
      id STRING,
      name STRING
    >,
    brands ARRAY<STRING>,
    budget STRUCT<
      amount NUMERIC,
      currency STRING
    >,
    start_at STRING,
    end_at STRING,
    objective STRING,
    kpi STRUCT<
      primary STRING,
      secondary STRING
    >,
    banners ARRAY<STRING>,
    line_items ARRAY<STRUCT<
      id STRING,
      name STRING,
      external_associations ARRAY<STRUCT<
        system STRING,
        identifier STRING
      >>,
      state STRING,
      is_created BOOLEAN,
      is_modified BOOLEAN,
      is_deleted BOOLEAN,
      type STRING,
      budget STRUCT<
        amount NUMERIC,
        currency STRING
      >,
      start_at STRING,
      end_at STRING,
      ad_server_name STRING,
      bid_type STRING,
      bid_rate STRUCT<
        amount NUMERIC,
        currency STRING
      >,
      planned_impressions STRING,
      tactic STRUCT<
        id STRING,
        name STRING
      >,
      targeting STRUCT<
        type STRING,
        category STRING,
        included_keywords ARRAY<STRING>,
        excluded_keywords ARRAY<STRING>,
        divisions ARRAY<STRING>,
        states ARRAY<STRING>,
        cities ARRAY<STRING>
      >
    >>
  >,
  event_ts TIMESTAMP,
  `partition` INT64,
  committed_offset INT64,
  latest_offset INT64,
  RowCreateTS TIMESTAMP
)
OPTIONS (labels = [('appcode','uddi'),('bodname','uaep'),('domainname','collect'),('environment','<<ENV>>')]);