CREATE OR REPLACE VIEW `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_cltv.vw_UAEP_CampaignLineItemData`
OPTIONS (labels = [('appcode','uddi'),('bodname','uaep'),('domainname','collect'),('environment','<<ENV>>')])
AS (
    SELECT
    *
    FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CAMPAIGN_LINE_ITEMS_DATA_NESTED`
);