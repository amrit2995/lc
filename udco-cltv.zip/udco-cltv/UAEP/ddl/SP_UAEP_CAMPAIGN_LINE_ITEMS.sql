CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_UAEP_CAMPAIGN_LINE_ITEMS`(job_id STRING)
BEGIN
DECLARE src_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_insert STRING;
DECLARE sql_row_count STRING; 
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = '';
SET status    = 'RUNNING';
SET proc_name = 'SP_UAEP_CAMPAIGN_LINE_ITEMS'; 
SET prcs_audit_tbl = 'gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.cltv_process_audit_control'; 

-- Audit entry for RUNNING
CALL `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.SP_PROCESS_AUDIT_CONTROL`('cltv',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl = 'gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.CAMPAIGN_LINE_ITEMS_DATA_NESTED';
SET src_tbl = 'gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UAEP_CAMPAIGN_LINE_ITEM_METADATA';

-- insert with incremental logic
SET sql_insert = '''INSERT INTO ''' || tgt_tbl || '''
SELECT
  JSON_VALUE(raw_message_val, '$.action_type') AS action_type,
  JSON_VALUE(raw_message_val, '$.action_id') AS action_id,
  JSON_VALUE(raw_message_val, '$.action_at') AS action_at,
  JSON_VALUE(raw_message_val, '$.source') AS source,
  JSON_VALUE(raw_message_val, '$.version') AS version,
  STRUCT(
    JSON_VALUE(raw_message_val, '$.data.id') AS id,
    JSON_VALUE(raw_message_val, '$.data.name') AS name,
    (
      SELECT ARRAY_AGG(STRUCT(
        JSON_VALUE(ea, '$.system') AS system,
        JSON_VALUE(ea, '$.identifier') AS identifier
      ))
      FROM UNNEST(JSON_QUERY_ARRAY(raw_message_val, '$.data.external_associations')) AS ea
    ) AS external_associations,
    JSON_VALUE(raw_message_val, '$.data.state') AS state,
    SAFE_CAST(JSON_VALUE(raw_message_val, '$.data.is_created') AS BOOL) AS is_created,
    SAFE_CAST(JSON_VALUE(raw_message_val, '$.data.is_modified') AS BOOL) AS is_modified,
    SAFE_CAST(JSON_VALUE(raw_message_val, '$.data.is_deleted') AS BOOL) AS is_deleted,
    STRUCT(
      JSON_VALUE(raw_message_val, '$.data.advertiser.id') AS id,
      JSON_VALUE(raw_message_val, '$.data.advertiser.name') AS name
    ) AS advertiser,
    JSON_QUERY_ARRAY(raw_message_val, '$.data.brands') AS brands,
    STRUCT(
      SAFE_CAST(JSON_VALUE(raw_message_val, '$.data.budget.amount') AS NUMERIC) as amount,
      JSON_VALUE(raw_message_val, '$.data.budget.currency') as currency
    ) AS budget,
    JSON_VALUE(raw_message_val, '$.data.start_at') AS start_at,
    JSON_VALUE(raw_message_val, '$.data.end_at') AS end_at,
    JSON_VALUE(raw_message_val, '$.data.objective') AS objective,
    STRUCT(
      JSON_VALUE(raw_message_val, '$.data.kpi.primary') AS primary,
      JSON_VALUE(raw_message_val, '$.data.kpi.secondary') AS secondary
    ) AS kpi,
    JSON_QUERY_ARRAY(raw_message_val, '$.data.banners') AS banners,
    (
      SELECT ARRAY_AGG(STRUCT(
        JSON_VALUE(li, '$.id') AS id,
        JSON_VALUE(li, '$.name') AS name,
        (
          SELECT ARRAY_AGG(STRUCT(
            JSON_VALUE(l_ea, '$.system') AS system,
            JSON_VALUE(l_ea, '$.identifier') AS identifier
          ))
          FROM UNNEST(JSON_QUERY_ARRAY(li, '$.external_associations')) AS l_ea
        ) AS external_associations,
        JSON_VALUE(li, '$.state') AS state,
        SAFE_CAST(JSON_VALUE(li, '$.is_created') AS BOOL) as is_created,
        SAFE_CAST(JSON_VALUE(li, '$.is_modified') AS BOOL) as is_modified,
        SAFE_CAST(JSON_VALUE(li, '$.is_deleted') AS BOOL) as is_deleted,
        JSON_VALUE(li, '$.type') AS type,
        STRUCT(
          SAFE_CAST(JSON_VALUE(li, '$.budget.amount') AS NUMERIC) as amount,
          JSON_VALUE(li, '$.budget.currency') as currency
        ) AS budget,
        JSON_VALUE(li, '$.start_at') AS start_at,
        JSON_VALUE(li, '$.end_at') AS end_at,
        JSON_VALUE(li, '$.ad_server_name') AS ad_server_name,
        JSON_VALUE(li, '$.bid_type') AS bid_type,
        STRUCT(
          SAFE_CAST(JSON_VALUE(li, '$.bid_rate.amount') AS NUMERIC) as amount,
          JSON_VALUE(li, '$.bid_rate.currency') as currency
        ) AS bid_rate,
        JSON_VALUE(li, '$.planned_impressions') AS planned_impressions,
        STRUCT(
          JSON_VALUE(li, '$.tactic.id') AS id,
          JSON_VALUE(li, '$.tactic.name') AS name
        ) AS tactic,
        STRUCT(
          JSON_VALUE(li, '$.targeting.type') AS type,
          JSON_VALUE(li, '$.targeting.category') AS category,
          JSON_QUERY_ARRAY(li, '$.targeting.included_keywords') AS included_keywords,
          JSON_QUERY_ARRAY(li, '$.targeting.excluded_keywords') AS excluded_keywords,
          JSON_QUERY_ARRAY(li, '$.targeting.divisions') AS divisions,
          JSON_QUERY_ARRAY(li, '$.targeting.states') AS states,
          JSON_QUERY_ARRAY(li, '$.targeting.cities') AS cities
        ) AS targeting
      ))
      FROM UNNEST(JSON_QUERY_ARRAY(raw_message_val, '$.data.line_items')) AS li
    ) AS line_items
  ) AS data,
  src.event_ts,
  src.`partition`,
  src.committed_offset,
  src.latest_offset,
  CURRENT_TIMESTAMP() AS RowCreateTS
FROM ''' || src_tbl || ''' src
LEFT JOIN ''' || tgt_tbl || ''' tgt
  ON src.`partition` = tgt.`partition`
  AND src.committed_offset = tgt.committed_offset
WHERE tgt.`partition` IS NULL
  AND tgt.committed_offset IS NULL
  AND src.`partition` IS NOT NULL
  AND src.committed_offset IS NOT NULL''';

-- Query to get row count after insert
SET sql_row_count = '''SELECT COUNT(*) FROM ''' || tgt_tbl || ''' WHERE DATE(RowCreateTS) = CURRENT_DATE()''';

-- Execute the insert
BEGIN
EXECUTE IMMEDIATE (sql_insert);
EXECUTE IMMEDIATE (sql_row_count) INTO row_count;
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Insert into table " || tgt_tbl || " Failed with error: " || @@error.message;
CALL `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.SP_PROCESS_AUDIT_CONTROL`('cltv',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

-- Success audit entry
SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
CALL `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.SP_PROCESS_AUDIT_CONTROL`('cltv',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;