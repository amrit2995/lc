CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UAEP_CAMPAIGN_LINE_ITEM_METADATA`(
  src_app_cd STRING,
  raw_message_key STRING,
  raw_message_val STRING,
  event_ts TIMESTAMP,
  processing_ts TIMESTAMP,
  `partition` INT64,
  committed_offset INT64,
  latest_offset INT64,
  audit_ts TIMESTAMP
)
OPTIONS (labels = [('appcode','uddi'),('bodname','uaep'),('domainname','collect'),('environment','<<ENV>>')]);