# UAEP (Unified Ad Experience Platform)

Handles campaign line-item data plus the **PCO** (Promoted Commerce Object) sub-module. Ingests from Kafka and BQ sources.

## Pipeline Flow

```
Kafka / BQ Sources ──► [SToV / VToB] ──► Tables ──► Views
```

## Directory Layout

```
UAEP/
├── README.md
├── params_dev.json / params_qa.json / params_prod.json
├── config/                         ← 3 Airflow workflow & step configs
├── ddl/                            ← 4 table DDLs
└── PCO/                            ← Promoted Commerce Object sub-module
    ├── params_dev.json / params_qa.json / params_prod.json
    ├── config/                     ← 3 PCO-specific workflow & step configs
    └── ddl/                        ← 4 PCO table DDLs
```

## Key Entities

| Entity | Location |
|--------|----------|
| Campaign Line Items | `ddl/` |
| Promoted Commerce Objects | `PCO/ddl/` |

## Deployment

Ordered via `script_order_execution_uaep_pco_dev.yaml` at the repo root.
