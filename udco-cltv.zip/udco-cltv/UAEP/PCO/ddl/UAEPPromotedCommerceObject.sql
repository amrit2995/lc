CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UAEPPromotedCommerceObject`(
    action_type STRING,
    action_id STRING,
    action_at STRING,
    source STRING,
    version STRING,
    data STRUCT<
        id STRING,
        CampaignType STRING,
        MediaOrderName STRING,
        MediaOrder STRING,
        state STRING,
        is_created BOOL,
        is_modified BOOL,
        is_deleted BOOL,
        start_at STRING,
        end_at STRING,
        IsCobranded BOOL,
        AttributionType STRING,
        AttributionListName STRING,
        filename STRING,
        CoBrandedAdvertiser STRING,
        CoBrandedTier STRING,
        brands_upcs ARRAY<STRUCT<
            iri_brand_id STRING,
            iri_partner_id STRING,
            advertiser ARRAY<STRUCT<
                id STRING,
                PartnerName STRING,
                PartnerId STRING
            >>,
            upcs STRING
        >>
    >,
    event_ts TIMESTAMP,
    `partition` INT64,
    committed_offset INT64,
    latest_offset INT64,
    RowCreateTS TIMESTAMP
)
OPTIONS (labels = [('appcode','uddi'),('bodname','uaep'),('domainname','collect'),('environment','<<ENV>>')]);