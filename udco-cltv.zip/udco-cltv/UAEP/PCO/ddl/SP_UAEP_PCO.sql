CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_UAEP_PCO`(job_id STRING)
BEGIN
DECLARE src_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_insert STRING;
DECLARE sql_row_count STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = '';
SET status = 'RUNNING';
SET proc_name = 'SP_UAEP_PCO';
SET prcs_audit_tbl = 'gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.cltv_process_audit_control'; 

-- Audit entry for RUNNING
CALL `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.SP_PROCESS_AUDIT_CONTROL`('cltv',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl = 'gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UAEPPromotedCommerceObject';
SET src_tbl = 'gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UAEP_PCO_Metadata';

-- insert with incremental logic
SET sql_insert = '''INSERT INTO ''' || tgt_tbl || '''
SELECT
    JSON_VALUE(raw_message_val, '$.action_type') AS action_type,
    JSON_VALUE(raw_message_val, '$.action_id') AS action_id,
    JSON_VALUE(raw_message_val, '$.action_at') AS action_at,
    JSON_VALUE(raw_message_val, '$.source') AS source,
    JSON_VALUE(raw_message_val, '$.version') AS version,
    STRUCT(
      JSON_VALUE(raw_message_val, '$.data.id') AS id,
      JSON_VALUE(raw_message_val, '$.data.campaign_type') AS CampaignType,
      JSON_VALUE(raw_message_val, '$.data.media_order_name') AS MediaOrderName,
      JSON_VALUE(raw_message_val, '$.data.media_order') AS MediaOrder,
      JSON_VALUE(raw_message_val, '$.data.state') AS state,
      SAFE_CAST(JSON_VALUE(raw_message_val, '$.data.is_created') AS BOOL) AS is_created,
      SAFE_CAST(JSON_VALUE(raw_message_val, '$.data.is_modified') AS BOOL) AS is_modified,
      SAFE_CAST(JSON_VALUE(raw_message_val, '$.data.is_deleted') AS BOOL) AS is_deleted,
      JSON_VALUE(raw_message_val, '$.data.start_at') AS start_at,
      JSON_VALUE(raw_message_val, '$.data.end_at') AS end_at,
      SAFE_CAST(JSON_VALUE(raw_message_val, '$.data.is_cobranded') AS BOOL) AS IsCobranded,
      JSON_VALUE(raw_message_val, '$.data.attribution_type') AS AttributionType,
      JSON_VALUE(raw_message_val, '$.data.attribution_file') AS AttributionListName,
      JSON_VALUE(raw_message_val, '$.data.file_name') AS filename,
      JSON_VALUE(raw_message_val, '$.data.cobranded_advertiser') AS CoBrandedAdvertiser,
      JSON_VALUE(raw_message_val, '$.data.cobranded_tier') AS CoBrandedTier,
      (
        SELECT ARRAY_AGG(STRUCT(
          JSON_VALUE(brands_upcs, '$.iri_brand_id') AS iri_brand_id,
          JSON_VALUE(brands_upcs, '$.iri_partner_id') AS iri_partner_id,
          (
            SELECT ARRAY_AGG(STRUCT(
            JSON_VALUE(advertiser, '$.id') AS id,
            JSON_VALUE(advertiser, '$.name') AS PartnerName,
            JSON_VALUE(advertiser, '$.partner_id') AS PartnerId
            ))
            FROM UNNEST([JSON_QUERY(brands_upcs, '$.advertiser')]) AS advertiser
          ) AS advertiser,
          JSON_VALUE(brands_upcs, '$.upcs') AS upcs
        ))
        FROM UNNEST(JSON_QUERY_ARRAY(raw_message_val, '$.data.brands_upcs')) AS brands_upcs
      ) AS brands_upcs
    ) AS data,
    src.event_ts,
    src.`partition`,
    src.committed_offset,
    src.latest_offset,
    CURRENT_TIMESTAMP() AS RowCreateTS
FROM ''' || src_tbl || ''' src
LEFT JOIN ''' || tgt_tbl || ''' tgt
  ON src.`partition` = tgt.`partition`
  AND src.committed_offset = tgt.committed_offset
  WHERE tgt.`partition` IS NULL
  AND tgt.committed_offset IS NULL
  AND src.`partition` IS NOT NULL
  AND src.committed_offset IS NOT NULL''';
  
-- Query to get row count after insert
SET sql_row_count = '''SELECT COUNT(*) FROM ''' || tgt_tbl || ''' WHERE DATE(RowCreateTS) = CURRENT_DATE()''';

-- Excute the insert
BEGIN
EXECUTE IMMEDIATE (sql_insert);
EXECUTE IMMEDIATE (sql_row_count) INTO row_count;
EXCEPTION WHEN ERROR THEN
SET job_end = CURRENT_TIMESTAMP();
SET status = 'FAILED';
SET err_desc = "Insert into table " || tgt_tbl || " Failed with error: " || @@error.message;
CALL `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.SP_PROCESS_AUDIT_CONTROL`('cltv',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

-- Success audit entry
SET job_end = CURRENT_TIMESTAMP();
SET status = "COMPLETED";
CALL `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_audit.SP_PROCESS_AUDIT_CONTROL`('cltv',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;