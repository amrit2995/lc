CREATE OR REPLACE VIEW `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_cltv.vw_UAEP_PCO`
OPTIONS (labels = [('appcode','uddi'),('bodname','uaep'),('domainname','collect'),('environment','<<ENV>>')])
AS (
    SELECT
    *
    FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.UAEPPromotedCommerceObject`
    Qualify(ROW_NUMBER() OVER (PARTITION BY data.id ORDER BY action_at DESC) = 1)
);