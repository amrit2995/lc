# UDCO-CLTV

BigQuery data pipelines for the **CLTV** (Customer Lifetime Value) pillar under the **UDCO** (Unified Data & Commerce Operations) app code. Ingests, transforms, and models advertising data from multiple platforms into a shared analytical warehouse.

## Architecture

```
Source (GCS / Kafka / BQ)
  │
  ├─ [SToV]  Source → Vault        (file / stream ingestion)
  ├─ [VToB]  Vault → BIM           (stored-procedure transforms, SCD2)
  └─ [BToA]  BIM   → Analytics     (dimension / fact modelling)

Orchestration: Airflow DAGs defined by *_WF.json configs
Environments:  dev / qa / prod  (params_*.json with <<ENV>> substitution)
Deployment:    script_order_execution*.yaml
```

## Domain Modules

| Module | Description | README |
|--------|-------------|--------|
| **META** | Facebook / Instagram Ads — confirmed + analytical layers | [META/README.md](META/README.md) |
| **PINTEREST** | Pinterest Ads — mirrors META structure | [PINTEREST/README.md](PINTEREST/README.md) |
| **OMS** | Order Management — accounts, campaigns, insertion orders | [OMS/README.md](OMS/README.md) |
| **INSTORE** | In-Store Retail Media — Stratacache campaigns, sensors, proof-of-play | [INSTORE/README.md](INSTORE/README.md) |
| **UAEP** | Unified Ad Experience Platform + PCO sub-module | [UAEP/README.md](UAEP/README.md) |
| **UNDERTONE** | Undertone display ad aggregate reporting | [UNDERTONE/README.md](UNDERTONE/README.md) |
| **MDM** | Master Data Management — Criteo ad data | [MDM/README.md](MDM/README.md) |
| **SPAOfferProduct** | SPA Offer-Product & Criteo UPC mappings | [SPAOfferProduct/README.md](SPAOfferProduct/README.md) |

## Repository Structure

```
udco-cltv/
├── README.md                              ← you are here
├── CODEOWNERS                             ← repo ownership
├── script_order_execution*.yaml           ← deployment ordering per domain
├── pillar/                                ← global infra config
│   ├── pillar-config.json                 ← Dataflow, audit, OAuth, Teams webhook
│   └── params_*.json                      ← pillar-level env parameters
│
├── <MODULE>/                              ← one per domain (META, OMS, etc.)
│   ├── README.md                          ← module-specific docs
│   ├── params_dev.json                    ← env parameters (dev / qa / prod)
│   ├── params_qa.json
│   ├── params_prod.json
│   ├── config/                            ← Airflow workflow & step configs
│   │   ├── <BOD>_CONF_WF.json             ← confirmed-layer DAG
│   │   ├── <BOD>_ANALYTICAL_WF.json       ← analytical-layer DAG
│   │   ├── SToV_*_FileToBQ.json           ← source-to-vault step configs
│   │   ├── VToB_*_BQToBQ.json             ← vault-to-BIM step configs
│   │   └── BToA_*_BQToBQ.json             ← BIM-to-analytics step configs
│   └── scripts/                           ← SQL assets
│       ├── ddl/                           ← table DDLs (main + _WRK + _LR_UPDATE)
│       ├── sql/ or sp/                    ← stored procedures & DMLs
│       └── views/ or view/               ← view definitions
```

## Where to Put New Files

| Asset Type | Location | Naming Pattern |
|------------|----------|----------------|
| **Table DDL** | `<MODULE>/scripts/ddl/` (or `ddl/Analytical/` for analytical-layer) | `ddl_<entity>.sql` |
| **Work Table DDL** | Same as above | `ddl_<entity>_wrk.sql` |
| **LR Update DDL** | Same as above | `ddl_<entity>_lr_update.sql` |
| **Stored Procedure** | `<MODULE>/scripts/sql/` or `scripts/sp/` | `SP_CLTV_*.sql` |
| **View** | `<MODULE>/scripts/views/` or `scripts/view/` | `view_<entity>.sql` |
| **Step Config** | `<MODULE>/config/` | `SToV_*_FileToBQ.json` / `VToB_*_BQToBQ.json` / `BToA_*_BQToBQ.json` |
| **Workflow DAG** | `<MODULE>/config/` | `<BOD>_<LAYER>_WF.json` |
| **Deployment order** | repo root | `script_order_execution_<domain>.yaml` |
| **Env parameters** | `<MODULE>/` | `params_dev.json` / `params_qa.json` / `params_prod.json` |

## Config File Formats

### How Names Connect (The Naming Chain)

Every entity flows through a strict naming chain. The **step config filename**, the **`job_name` inside it**, and the **workflow DAG reference** must all match exactly:

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│  1. STORED PROCEDURE (SQL file)                                                │
│     SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN.sql                          │
│     └─ contains: CREATE PROCEDURE ... SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN │
│                                                                                 │
│  2. STEP CONFIG (JSON file — filename = job_name + ".json")                     │
│     BToA_META_D1_AD_MEDIA_CAMPAIGN_BQToBQ.json                                  │
│     └─ "job_name": "BToA_META_D1_AD_MEDIA_CAMPAIGN_BQToBQ"    ← must match filename │
│     └─ "sp": "SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN"  ← must match SP name  │
│                                                                                 │
│  3. WORKFLOW DAG (WF JSON)                                                      │
│     META_ANALYTICAL_WF.json                                                     │
│     └─ job_level_2.noOptask: ["BToA_META_D1_AD_MEDIA_CAMPAIGN_BQToBQ", ...]     │
│                                  ↑ must match step config job_name exactly      │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Naming formula:**

| Component | Pattern | Example |
|-----------|---------|--------|
| Step config filename | `<Layer>_<BOD>_<ENTITY>_BQToBQ.json` | `BToA_META_D1_AD_MEDIA_CAMPAIGN_BQToBQ.json` |
| `job_name` (inside JSON) | Same as filename minus `.json` | `BToA_META_D1_AD_MEDIA_CAMPAIGN_BQToBQ` |
| SP name (inside JSON `sp` field) | `SP_CLTV_<SOURCE>_TO_<TARGET>_<ENTITY>` | `SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN` |
| SP SQL filename | `<SP_NAME>.sql` | `SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN.sql` |

Layer prefixes: `SToV` = Source→Vault, `VToB` = Vault→BIM, `BToA` = BIM→Analytics.

### Workflow DAG (`*_WF.json`)

Defines an Airflow DAG with scheduling and multi-level task dependencies:

```json
{
  "pillar_name": "CLTV",
  "bq_conn_id": "cltv_conn_id",
  "bod_name": "META",
  "job_name": "META_ANALYTICAL_WF",
  "schedule": "0 11 * * *",
  "retries": 0,
  "job_level_1": "noOptask",
  "job_level_2": { "noOptask": ["BToA_META_D1_..._BQToBQ", "..."] },
  "job_level_3": { "BToA_META_D1_..._BQToBQ": ["BToA_META_F_..._BQToBQ"] },
  "job_level_4": { "BToA_META_F_..._BQToBQ": ["BToA_META_FA_..._BQToBQ"] }
}
```

**How job levels work:**

| Field | Meaning |
|-------|--------|
| `job_level_1` | Root anchor task — always `"noOptask"` (a dummy task that enables fan-out) |
| `job_level_2` | `{ "<parent>": ["<child1>", "<child2>", ...] }` — tasks that run after Level 1 |
| `job_level_3` | `{ "<parent>": ["<child>"] }` — tasks that run after their Level 2 parent completes |
| `job_level_N` | Same pattern — each key is a Level N-1 task, value is array of tasks to trigger |

**Dependency resolution:** A Level N+1 task runs only after **all** Level N parents that list it have completed. If multiple Level 2 tasks list the same Level 3 task, it waits for all of them.

**`noOptask` explained:** A dummy anchor defined in `noOptask.json` that simply echoes a message. It exists solely to enable fan-out parallelism — all Level 2 tasks depend on it, so they start simultaneously.

### Step Config (`SToV_*` / `VToB_*` / `BToA_*`)

Each step config tells Airflow which SP to call and on which dataset:
```json
{
  "bod_name": "META",
  "job_name": "BToA_META_D1_AD_MEDIA_CAMPAIGN_BQToBQ",
  "run_on": "bq",
  "BQToBQ": {
    "dataset": "<<ANALYTIC_DATASET>>",
    "sp": "SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN"
  }
}
```

| Field | Purpose |
|-------|--------|
| `bod_name` | Business Object Domain — must match the parent module (META, OMS, etc.) |
| `job_name` | **Must exactly match the filename** (minus `.json`) — Airflow uses this to find the config |
| `run_on` | Execution engine — `"bq"` for BigQuery |
| `BQToBQ.dataset` | Target dataset placeholder — resolved from `params_*.json` at runtime |
| `BQToBQ.sp` | Stored procedure name — **must exactly match** the SP name in the SQL file |

For **VToB** (confirmed layer), `dataset` points to `<<CONF_DATASET>>` instead of `<<ANALYTIC_DATASET>>`.

For **SToV** (file ingestion) configs, the structure differs — includes `source_path`, `file_format`, `schema`, and `sink_table` instead of `BQToBQ`.

### Environment Parameters (`params_*.json`)
```json
{
  "ENV": "dev",
  "CLTV_PROJECT_ID": "gcp-abs-udco-bq-dev-prj-01",
  "ANALYTIC_DATASET": "udco_ds_cltv_analytics",
  "CONF_DATASET": "udco_ds_cltv_confirmed",
  "AUDIT_DATASET": "udco_ds_audit",
  "VIEW_DATASET": "udco_ds_cltv",
  "SP_LABEL": "appcode:uddi, bodname:meta, domainname:cltv, environment:dev"
}
```
Placeholders like `<<CLTV_PROJECT_ID>>`, `<<ANALYTIC_DATASET>>`, `<<ENV>>` in SQL and config files are substituted from these at deploy time.

### Pillar Config (`pillar/pillar-config.json`)
Global infra: Dataflow (project, region, workers), audit log table, OAuth secrets, Teams notification webhook.

## Adding a New Entity (End-to-End Checklist)

When adding a new table/SP to the pipeline:

1. **Create SQL files** in the module's `scripts/` directory:
   - `ddl/ddl_<entity>.sql` — main table
   - `ddl/ddl_<entity>_wrk.sql` — work/staging table
   - `ddl/ddl_<entity>_lr_update.sql` — SCD2 tracking table (if needed)
   - `sql/SP_CLTV_<SOURCE>_TO_<TARGET>_<ENTITY>.sql` — stored procedure
   - `views/view_<entity>.sql` — view

2. **Create step config** in `<MODULE>/config/`:
   - Filename: `<Layer>_<BOD>_<ENTITY>_BQToBQ.json`
   - `job_name` inside must match the filename (minus `.json`)
   - `sp` must match the SP name exactly

3. **Register in workflow DAG** (`<BOD>_<LAYER>_WF.json`):
   - Add the `job_name` to the appropriate `job_level_N` based on dependencies
   - If independent (no upstream dependencies beyond the anchor), add to `job_level_2`
   - If it depends on a dimension loading first, add to `job_level_3` under that dimension's key

4. **Add to deployment YAML** (root-level `script_order_execution_*.yaml`):
   - Add DDL, view, and SP file paths to the `files:` list in the correct job block

## Deployment YAML Files

Each YAML defines ordered BigQuery deployment jobs with tagged file lists:

| YAML | Domain | Scope |
|------|--------|-------|
| `script_order_execution_meta.yaml` | META | Analytical DDLs, views, SPs |
| `script_order_execution_meta_dq.yaml` | META | Data-quality layer |
| `script_order_execution_meta_id_an.yaml` | META | Analytical SP execution |
| `script_order_execution_meta_id_cn.yaml` | META | Confirmed-layer full pipeline |
| `script_order_execution_oms.yaml` | OMS | Full OMS pipeline |
| `script_order_execution_pinterest.yaml` | PINTEREST | SP updates |
| `script_order_execution_sveep00.yaml` | PINTEREST | SP subset variant |
| `script_order_execution_uaep_pco_dev.yaml` | UAEP | PCO sub-module pipeline |
| `script_order_execution_undertone_dev.yaml` | UNDERTONE | Table + view creation |
| `script_order_execution_undertone_insert_update.yaml` | UNDERTONE | External table load |
| `in_store_script_order_execution.yaml` | INSTORE | Campaign SPs, BLE mappings |

YAML structure:
```yaml
type: BigQuery
order:
  - deploy:
      jobs:
        - name: "<job description>"
          tags: { appcode: uddi, bodname: <bod>, domainname: cltv, environment: dev }
          files:
            - <MODULE>/scripts/ddl/<file>.sql
            - <MODULE>/scripts/sql/<SP>.sql
```

## Conventions

- **Table naming**: `D1_` = dimension, `F_` = fact, `FA_` = aggregate fact, `_WRK` = staging, `_LR_UPDATE` = SCD2 tracking
- **Config naming**: `SToV_*` = source-to-vault, `VToB_*` = vault-to-BIM, `BToA_*` = BIM-to-analytics, `*_WF.json` = workflow DAG
- **Params placeholders**: `<<CLTV_PROJECT_ID>>`, `<<ANALYTIC_DATASET>>`, `<<ENV>>` — substituted per environment
- **SPs**: Prefixed `SP_CLTV_*`, include audit logging and DQ observability calls
- **Tags**: All resources tagged with `appcode:uddi`, `bodname:<module>`, `domainname:cltv`, `environment:<<ENV>>`

## Release Managers

> data-management-release-managers
