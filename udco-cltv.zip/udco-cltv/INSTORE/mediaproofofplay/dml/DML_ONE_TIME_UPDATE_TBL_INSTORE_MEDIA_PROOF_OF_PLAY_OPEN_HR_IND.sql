UPDATE
  `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_PROOF_OF_PLAY` AS T
SET
  AD_PLAY_STORE_OPEN_HR_IND = (

    -- 24x7 store shortcut (true 24x7 OR 00:00 → 23:59)
    (
      S.MONDAY_OPEN_HR = S.MONDAY_CLOSE_HR
      OR (
          S.MONDAY_OPEN_HR = TIME '00:00:00'
          AND S.MONDAY_CLOSE_HR >= TIME '23:59:00'
        )
    )


    OR

    -- 1) Ad fully contained inside the interval that starts on the same calendar date as the ad start
    (
      DATETIME(DATE(S.LOCAL_AD_PLAY_START_DT), S.MONDAY_OPEN_HR) <= S.LOCAL_AD_PLAY_START_DT
      AND
      S.LOCAL_AD_PLAY_END_DT <= CASE
                                  WHEN S.MONDAY_CLOSE_HR < S.MONDAY_OPEN_HR
                                    THEN DATETIME(DATE_ADD(DATE(S.LOCAL_AD_PLAY_START_DT), INTERVAL 1 DAY), S.MONDAY_CLOSE_HR)
                                  ELSE DATETIME(DATE(S.LOCAL_AD_PLAY_START_DT), S.MONDAY_CLOSE_HR)
                                END
    )

    OR

    -- 2) Ad fully contained inside the interval that started yesterday (only possible for overnight schedules)
    (
      S.MONDAY_CLOSE_HR < S.MONDAY_OPEN_HR
      AND DATETIME(DATE_SUB(DATE(S.LOCAL_AD_PLAY_START_DT), INTERVAL 1 DAY), S.MONDAY_OPEN_HR) <= S.LOCAL_AD_PLAY_START_DT
      AND S.LOCAL_AD_PLAY_END_DT <= DATETIME(DATE(S.LOCAL_AD_PLAY_START_DT), S.MONDAY_CLOSE_HR)
    )
  )

FROM (
  -- compute local datetimes once here; bring necessary store hours
  SELECT
    S.FACILITY_INTEGRATION_ID,
    S.MONDAY_OPEN_HR,
    S.MONDAY_CLOSE_HR,
    -- compute local datetimes for start & end
    DATETIME(T.AD_PLAY_START_TS,
      CASE S.STATE_CD
        WHEN 'CA' THEN 'America/Los_Angeles' WHEN 'OR' THEN 'America/Los_Angeles'
        WHEN 'WA' THEN 'America/Los_Angeles' WHEN 'NV' THEN 'America/Los_Angeles'
        WHEN 'CO' THEN 'America/Denver' WHEN 'ID' THEN 'America/Denver'
        WHEN 'MT' THEN 'America/Denver' WHEN 'NM' THEN 'America/Denver'
        WHEN 'UT' THEN 'America/Denver' WHEN 'WY' THEN 'America/Denver'
        WHEN 'AZ' THEN 'America/Phoenix'
        WHEN 'IL' THEN 'America/Chicago' WHEN 'TX' THEN 'America/Chicago'
        WHEN 'LA' THEN 'America/Chicago' WHEN 'AR' THEN 'America/Chicago'
        WHEN 'OK' THEN 'America/Chicago' WHEN 'IA' THEN 'America/Chicago'
        WHEN 'SD' THEN 'America/Chicago' WHEN 'NE' THEN 'America/Chicago'
        WHEN 'ND' THEN 'America/Chicago'
        WHEN 'VA' THEN 'America/New_York' WHEN 'DC' THEN 'America/New_York'
        WHEN 'NJ' THEN 'America/New_York' WHEN 'MD' THEN 'America/New_York'
        WHEN 'DE' THEN 'America/New_York' WHEN 'MA' THEN 'America/New_York'
        WHEN 'NH' THEN 'America/New_York' WHEN 'PA' THEN 'America/New_York'
        WHEN 'MI' THEN 'America/New_York' WHEN 'NY' THEN 'America/New_York'
        WHEN 'IN' THEN 'America/New_York' WHEN 'VT' THEN 'America/New_York'
        WHEN 'ME' THEN 'America/New_York' WHEN 'RI' THEN 'America/New_York'
        WHEN 'CT' THEN 'America/New_York' WHEN 'FL' THEN 'America/New_York'
        WHEN 'GA' THEN 'America/New_York'
        WHEN 'AK' THEN 'America/Anchorage'
        WHEN 'HI' THEN 'Pacific/Honolulu'
        ELSE 'UTC'
      END) AS LOCAL_AD_PLAY_START_DT,

    DATETIME(T.AD_PLAY_END_TS,
      CASE S.STATE_CD
        WHEN 'CA' THEN 'America/Los_Angeles' WHEN 'OR' THEN 'America/Los_Angeles'
        WHEN 'WA' THEN 'America/Los_Angeles' WHEN 'NV' THEN 'America/Los_Angeles'
        WHEN 'CO' THEN 'America/Denver' WHEN 'ID' THEN 'America/Denver'
        WHEN 'MT' THEN 'America/Denver' WHEN 'NM' THEN 'America/Denver'
        WHEN 'UT' THEN 'America/Denver' WHEN 'WY' THEN 'America/Denver'
        WHEN 'AZ' THEN 'America/Phoenix'
        WHEN 'IL' THEN 'America/Chicago' WHEN 'TX' THEN 'America/Chicago'
        WHEN 'LA' THEN 'America/Chicago' WHEN 'AR' THEN 'America/Chicago'
        WHEN 'OK' THEN 'America/Chicago' WHEN 'IA' THEN 'America/Chicago'
        WHEN 'SD' THEN 'America/Chicago' WHEN 'NE' THEN 'America/Chicago'
        WHEN 'ND' THEN 'America/Chicago'
        WHEN 'VA' THEN 'America/New_York' WHEN 'DC' THEN 'America/New_York'
        WHEN 'NJ' THEN 'America/New_York' WHEN 'MD' THEN 'America/New_York'
        WHEN 'DE' THEN 'America/New_York' WHEN 'MA' THEN 'America/New_York'
        WHEN 'NH' THEN 'America/New_York' WHEN 'PA' THEN 'America/New_York'
        WHEN 'MI' THEN 'America/New_York' WHEN 'NY' THEN 'America/New_York'
        WHEN 'IN' THEN 'America/New_York' WHEN 'VT' THEN 'America/New_York'
        WHEN 'ME' THEN 'America/New_York' WHEN 'RI' THEN 'America/New_York'
        WHEN 'CT' THEN 'America/New_York' WHEN 'FL' THEN 'America/New_York'
        WHEN 'GA' THEN 'America/New_York'
        WHEN 'AK' THEN 'America/Anchorage'
        WHEN 'HI' THEN 'Pacific/Honolulu'
        ELSE 'UTC'
      END) AS LOCAL_AD_PLAY_END_DT,

    T.PLAYER_ID,
    T.AD_PLAY_START_TS,
    T.AD_PLAY_END_TS
  FROM `<<RETAILSTORE_DATASET>>.D1_RETAIL_STORE` AS S
  JOIN `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_PROOF_OF_PLAY` AS T
    ON S.FACILITY_INTEGRATION_ID = T.FACILITY_INTEGRATION_ID
) AS S
WHERE
  T.FACILITY_INTEGRATION_ID = S.FACILITY_INTEGRATION_ID
  AND T.PLAYER_ID = S.PLAYER_ID
  AND T.AD_PLAY_START_TS = S.AD_PLAY_START_TS
  AND T.AD_PLAY_END_TS = S.AD_PLAY_END_TS;
