-- Create table for valid proof of play data
CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_PROOF_OF_PLAY` (
    MEDIA_CREATIVE_ID STRING NOT NULL OPTIONS(description="Unique identifier for each creative. One campaign can have multiple Line items and each Line item can have multiple Creatives. A campaign may or may not have line item. In second case when campaign doesnt have Line item then a Creative Id will be associated with Campaign Id , else with Line item id and then campaign Id in Hierarchy."),
    FACILITY_INTEGRATION_ID NUMERIC NOT NULL OPTIONS(description="Facility Integration ID for the corresponding Store ID"),
    MEDIA_ZONE_CD STRING NOT NULL OPTIONS(description="Zone ID where the media player is installed.Place where the media was played Example Deli, Pharmacy, Entry"),
    PLAYER_ID NUMERIC NOT NULL OPTIONS(description="Unique Player ID /device Id of the media player"),
    AD_PLAY_START_TS TIMESTAMP NOT NULL OPTIONS(description="Time when the ad started playing on the media player"),
    MEDIA_CAMPAIGN_ID STRING NOT NULL OPTIONS(description="Unique identifier for the campaign."),
    CAMPAIGN_LINE_ITEM_ID STRING NOT NULL OPTIONS(description="Unique line item id under a campaign. A camapign may or may not have Line item. Also a camapign can have multiple line items. Line items can have multiple creatives associated to it."),
    AD_PLAY_END_TS TIMESTAMP NOT NULL OPTIONS(description="Time when the ad ended playing on the media player"),
    AD_PLAY_CNT NUMERIC OPTIONS(description="Number of times the Ad was played"),
    PLATFORM_ID STRING NOT NULL OPTIONS(description="Platform to run Campaign example Instore"),
    MEDIA_PARTNER_ID STRING NOT NULL OPTIONS(description="Partners who are engaged to run Campaign in stores"),
    SOURCE_APPLICATION_CD STRING NOT NULL OPTIONS(description="Unique Player ID of the media player"),
    DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    JOB_ID STRING NOT NULL  OPTIONS(description="Unique Player ID of the media player")
)
PARTITION BY DATE(AD_PLAY_END_TS)
CLUSTER BY FACILITY_INTEGRATION_ID,MEDIA_ZONE_CD
OPTIONS (
    description="This entity  provides concrete evidence that advertisements actually played as scheduled and contracted. It records precise timestamps for when each ad started and stopped playing, how many times it played, and exactly which screen in which store displayed it. This data is essential for billing advertisers accurately and proving campaign delivery.",
    labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
)