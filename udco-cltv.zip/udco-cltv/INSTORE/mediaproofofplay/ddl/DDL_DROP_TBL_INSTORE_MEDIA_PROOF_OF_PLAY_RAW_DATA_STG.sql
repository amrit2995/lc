DECLARE column_exists BOOL;

-- Step 1: Check if column exists
SET column_exists = (
  SELECT COUNT(*) > 0
  FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INFORMATION_SCHEMA.COLUMNS`
  WHERE table_name = 'RETAIL_STORE_MEDIA_PROOF_OF_PLAY_RAW_DATA_STG'
    AND column_name = 'AD_PLAY_STORE_OPEN_HR_IND'
);

-- Step 2: Conditionally add column
IF NOT column_exists THEN
  EXECUTE IMMEDIATE """
    DROP TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.RETAIL_STORE_MEDIA_PROOF_OF_PLAY_RAW_DATA_STG`
    --OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')])
  """;
END IF;