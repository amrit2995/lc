CREATE EXTERNAL TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.EXT_INSTORE_MEDIA_PROOF_OF_PLAYER_CONNECTIVITY_RAW_DATA` (
    RETAIL_STORE_FACILITY_NBR                      STRING OPTIONS(description="Store number where the players have been installed"),
    RETAIL_STORE_PLAYER_ID                         STRING OPTIONS(description="Unique Player ID of the media player"),
    RETAIL_STORE_PLAYER_CONNECTION_STATUS          STRING OPTIONS(description="This represents the health status of the player (Ex, Connected/Disconnected)"),
    RETAIL_STORE_PLAYER_LAST_CONNECTED             STRING OPTIONS(description="Last time when the player was connected in UTC"),
    RETAIL_STORE_PLAYER_FAILURE_REASON             STRING OPTIONS(description="This field should only have data when the player was disconnected (Optional)")
)
OPTIONS(
  --labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')],
  skip_leading_rows=1,
  format="CSV",
  uris=["gs://<<GCSBUCKET>>/external/udco-cltv/inbound/stratacache/player_connectivity_log/player_connectivity_log*.csv"]
);
