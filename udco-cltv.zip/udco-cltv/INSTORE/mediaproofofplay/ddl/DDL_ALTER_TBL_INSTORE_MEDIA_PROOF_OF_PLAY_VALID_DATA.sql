DECLARE column_exists BOOL;

-- Step 1: Check if column exists
SET column_exists = (
  SELECT COUNT(*) > 0
  FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.INFORMATION_SCHEMA.COLUMNS`
  WHERE table_name = 'RETAIL_STORE_MEDIA_PROOF_OF_PLAY'
    AND column_name = 'AD_PLAY_STORE_OPEN_HR_IND'
);

-- Step 2: Conditionally add column
IF NOT column_exists THEN
  EXECUTE IMMEDIATE """
    ALTER TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_PROOF_OF_PLAY`
    ADD COLUMN AD_PLAY_STORE_OPEN_HR_IND BOOLEAN OPTIONS(description="This feature indicates whether the ad was played during store Open hour or close hour, ad plays logs coming from the vendor. To perform reporting on ad plays captured during store opening/closing hours.")
    --OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')])
  """;
END IF;


SET column_exists = (
  SELECT COUNT(*) > 0
  FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.INFORMATION_SCHEMA.COLUMNS`
  WHERE table_name = 'RETAIL_STORE_MEDIA_PROOF_OF_PLAY'
    AND column_name = 'TRANSACTION_ID'
);

-- Step 2: Conditionally add column
IF NOT column_exists THEN
  EXECUTE IMMEDIATE """
    ALTER TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_PROOF_OF_PLAY`
    ADD COLUMN TRANSACTION_ID NUMERIC OPTIONS(description="Unique Transaction Id associated to  Point of sale transaction in the store, To calculate impression and perform attribution for Assisted and Self Checkout Terminals")
    --OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')])
  """;
END IF;