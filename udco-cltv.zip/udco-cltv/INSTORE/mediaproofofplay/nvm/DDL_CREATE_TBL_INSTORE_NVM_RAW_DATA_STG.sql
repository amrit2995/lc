CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PROOF_OF_PLAY_NVM_RAW_DATA_STG` (
    RETAIL_STORE_FACILITY_NBR                STRING OPTIONS(description="Store ID where the media player is installed"),
    RETAIL_STORE_PLAYER_NM                   STRING OPTIONS(description="Name of the player along with the zone"),
    RETAIL_STORE_PLAYER_SERIAL_NBR           STRING OPTIONS(description="Unique Serial number of the player"),
    RETAIL_STORE_PLAYER_ID                   STRING OPTIONS(description="Unique Player ID of the media player"),
    MEDIA_CREATIVE_NM                        STRING OPTIONS(description="It should be the media file name"),
    MEDIA_CAMPAIGN_ID                        STRING OPTIONS(description="campaign"),
    MEDIA_CREATIVE_ID                        STRING OPTIONS(description="Unique ID of the creative"),
    AD_EXPOSURE_DATE                         STRING OPTIONS(description="Date when the media ad played"),
    AD_EXPOSURE_START_TS                     STRING OPTIONS(description="Time when the media ad starts playing"),
    AD_EXPOSURE_END_TS                       STRING OPTIONS(description="Time when the media ad ends playing"),
    BANNER_NM                                STRING OPTIONS(description="Banner in which the media was played Safeway, Albertsons"),
    MEDIA_TYPE_CD                            STRING OPTIONS(description="Type of media file if it is video or image"),
    AD_EXPOSURE_CNT                          STRING OPTIONS(description="This is the ad exposure, how many times the campaign has been played"),
    -- Required metadata fields
    DW_FILE_PATH                             STRING OPTIONS(description="Google storage path for input file"),
    DW_CREATE_TS                             TIMESTAMP OPTIONS(description="Timestamp when the record is created in BigQuery"),
    `format`                                 STRING OPTIONS(description="File format of input file like csv, fwf, json,xml or parquet"),
    SOURCE_APPLICATION_CD                    STRING OPTIONS(description="Name of the process creating the record"),
    HEADER_LINE                              STRING OPTIONS(description="If header is present "),
    FOOTER_LINE                              STRING OPTIONS(description="If Footer is present"),
    JOB_ID                                   STRING OPTIONS(description="JOB_ID of the current DAG run")
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
