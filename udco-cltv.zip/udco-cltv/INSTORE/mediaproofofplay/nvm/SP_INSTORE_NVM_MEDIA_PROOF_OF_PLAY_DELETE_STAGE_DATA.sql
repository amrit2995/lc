CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_INSTORE_MEDIA_PROOF_OF_PLAY_NVM_DELETE_STAGE_DATA`(job_id STRING)
BEGIN

    -- Declare a variable to store the record count
    DECLARE record_count INT64;

    DECLARE CURRENT_JOB_ID STRING;
    SET CURRENT_JOB_ID = job_id;

    DELETE FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PROOF_OF_PLAY_NVM_RAW_DATA_STG`
    WHERE JOB_ID = CURRENT_JOB_ID;
END;