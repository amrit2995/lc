CREATE EXTERNAL TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.EXT_INSTORE_MEDIA_PROOF_OF_PLAY_NVM_PLAYER_CONNECTIVITY_RAW_DATA` (
    RETAIL_STORE_FACILITY_NBR                    STRING OPTIONS(description="Store ID where the media player is installed"),
    RETAIL_STORE_PLAYER_ID                       STRING OPTIONS(description="Unique Player ID of the media player"),
    RETAIL_STORE_PLAYER_SERIAL_NBR               STRING OPTIONS(description="Unique Serial Number of the media player"),
    RETAIL_STORE_PLAYER_CONNECTION_STATUS        STRING OPTIONS(description="Connectivity Status (Disconnected)"),
    RETAIL_STORE_PLAYER_LAST_CONNECTED           STRING OPTIONS(description="Last Connected Date of the Player"),
    RETAIL_STORE_PLAYER_FAILURE_REASON           STRING OPTIONS(description="Optional Failure Reason of the Player")
)
OPTIONS (
    -- labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
  skip_leading_rows=1,
  format="CSV",
  uris=["gs://<<GCSBUCKET>>/external/udco-cltv/inbound/new_visual_media/player_connectivity_log/player_connectivity_log*.csv"]
);
