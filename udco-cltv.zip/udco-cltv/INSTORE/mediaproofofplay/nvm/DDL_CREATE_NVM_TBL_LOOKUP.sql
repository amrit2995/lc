CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_NVM_MEDIA_STORE_ZONE_LOOKUP` (
    RETAIL_STORE_FACILITY_NBR STRING NOT NULL,
    RETAIL_STORE_PLAYER_ID NUMERIC NOT NULL,
    RETAIL_STORE_ZONE_NM STRING NOT NULL,
    -- Required metadata fields
    DW_FILE_PATH STRING,
    DW_CREATE_TS TIMESTAMP,
    format STRING,
    SOURCE_APPLICATION_CD STRING,
    HEADER_LINE STRING,
    FOOTER_LINE STRING,
    JOB_ID STRING
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
