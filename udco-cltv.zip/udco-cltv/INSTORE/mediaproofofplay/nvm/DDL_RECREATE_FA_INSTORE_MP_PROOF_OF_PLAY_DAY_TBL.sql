-- Drop backup table if it exists
DROP TABLE IF EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY_BACKUP`;

-- Create new table with desired partitioning
CREATE TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY_BACKUP`
PARTITION BY DATE(AD_EXPOSURE_END_TS) 
OPTIONS(
  labels = [('appcode', 'maid'), ('bodname', 'instore'), ('domainname', 'collect'), ('environment', '<<ENV>>')]
) 
AS SELECT * FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY`
;

-- Drop old table and rename new one
DROP TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY`;

-- Create table for instore mp proof of play day
CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY` (
    RETAIL_STORE_D1_SK                     NUMERIC NOT NULL OPTIONS(description="Store ID where the media player is installed"),
    AD_EXPOSURE_DAY_ID                     NUMERIC(8) NOT NULL OPTIONS(description="Date when the media ad played"),
    RETAIL_STORE_PLAYER_ID                 NUMERIC NOT NULL OPTIONS(description="Unique Player ID of the media player"),
    MEDIA_CAMPAIGN_ID                      STRING NOT NULL OPTIONS(description="campaign"),
    MEDIA_CREATIVE_ID                      STRING NOT NULL OPTIONS(description="Unique ID of the creative"),
    BANNER_D1_SK                           NUMERIC NOT NULL OPTIONS(description="Banner in which the media was played Safeway, Albertsons"),
    RETAIL_STORE_ZONE_NM                   STRING OPTIONS(description="Store Zone where the player is installed"),
    MEDIA_TYPE_CD                          STRING NOT NULL OPTIONS(description="Type of media file if it is video or image"),
    MEDIA_CREATIVE_NM                      STRING NOT NULL OPTIONS(description="It should be the media file name"),
    RETAIL_STORE_PLAYER_NM                 STRING NOT NULL OPTIONS(description="Name of the player along with the zone"),
    RETAIL_STORE_PLAYER_SERIAL_NBR         STRING OPTIONS(description="Unique Serial number of the player"),
    AD_EXPOSURE_CNT                        NUMERIC NOT NULL OPTIONS(description="Count of media ad playing"),
    AD_EXPOSURE_START_TS                   TIMESTAMP OPTIONS(description="Time when the media ad starts playing"),
    AD_EXPOSURE_END_TS                     TIMESTAMP OPTIONS(description="Time when the media ad ends playing"),
    SOURCE_APP_CD                          STRING OPTIONS(description="Name of the process creating the record"),
    JOB_ID                                 STRING OPTIONS(description="JOB_ID of the current DAG run"),
    DW_CREATE_TS                           TIMESTAMP NOT NULL OPTIONS(description="Timestamp when the record is created in BigQuery"),
    DW_LAST_UPDATE_TS                      TIMESTAMP NOT NULL OPTIONS(description="Timestamp when the record is updated in BigQuery") 
)
PARTITION BY DATE(AD_EXPOSURE_END_TS) 
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);


-- Load the new table with data from the backup table
INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY`
SELECT * FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY_BACKUP`;