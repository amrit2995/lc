-- Create view for instore mp proof of play day
CREATE OR REPLACE VIEW `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY_VW`
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]) 
as  
SELECT 
    RETAIL_STORE_FACILITY_NBR,
    CALENDAR_DT AS AD_EXPOSURE_DATE                  ,
    RETAIL_STORE_PLAYER_ID                           ,
    MEDIA_CAMPAIGN_ID                                ,
    MEDIA_CREATIVE_ID                                ,
    INITCAP(D1_BANNER.BANNER_NM) AS BANNER_NM        ,
    RETAIL_STORE_ZONE_NM                             ,
    MEDIA_TYPE_CD                                    ,
    MEDIA_CREATIVE_NM                                ,
    RETAIL_STORE_PLAYER_NM                           ,
    RETAIL_STORE_PLAYER_SERIAL_NBR                   ,
    SUM(AD_EXPOSURE_CNT) AS AD_EXPOSURE_CNT          ,
    MIN(AD_EXPOSURE_START_TS) AS AD_EXPOSURE_START_TS,
    MAX(AD_EXPOSURE_END_TS) AS AD_EXPOSURE_END_TS    ,
    MAX(SOURCE.DW_CREATE_TS) AS DW_CREATE_TS         ,
    MAX(SOURCE.DW_LAST_UPDATE_TS) AS DW_LAST_UPDATE_TS             
    FROM  `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY` SOURCE
    INNER JOIN 
    `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_locn.D1_BANNER` D1_BANNER
           ON SOURCE.BANNER_D1_SK=D1_BANNER.BANNER_D1_SK
    INNER JOIN 
    `<<RETAILSTORE_DATASET>>.D1_RETAIL_STORE`  D1_RETAIL_STORE
            ON SOURCE.RETAIL_STORE_D1_SK = D1_RETAIL_STORE.RETAIL_STORE_D1_SK
    INNER JOIN 
     `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_acct.D0_CALENDAR_DAY`  CALENDAR_DAY
            ON SOURCE.AD_EXPOSURE_DAY_ID = CALENDAR_DAY.DAY_ID 
            WHERE D1_BANNER.DW_LOGICAL_DELETE_IND = FALSE 
            and D1_RETAIL_STORE.DW_LOGICAL_DELETE_IND = FALSE 
            and CALENDAR_DAY.DW_LOGICAL_DELETE_IND = FALSE
     GROUP BY
       RETAIL_STORE_FACILITY_NBR                        ,    
       CALENDAR_DT                                      ,
       RETAIL_STORE_PLAYER_ID                           ,
       MEDIA_CAMPAIGN_ID                                ,
       MEDIA_CREATIVE_ID                                ,
       INITCAP(D1_BANNER.BANNER_NM)                     ,
       RETAIL_STORE_ZONE_NM                             ,
       MEDIA_TYPE_CD                                    ,
       MEDIA_CREATIVE_NM                                ,
       RETAIL_STORE_PLAYER_NM                           ,
       RETAIL_STORE_PLAYER_SERIAL_NBR;                