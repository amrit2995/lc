CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_INSTORE_MEDIA_PROOF_OF_PLAY_NVM_VALIDATE_AND_INSERT_DATA`(job_id STRING)
BEGIN

    -- Declare a variable to store the record count
    DECLARE record_count INT64;

    DECLARE CURRENT_JOB_ID STRING;
    SET CURRENT_JOB_ID = job_id;



    -- Below query is responsible for doing the validations
    -- Null check on below fields. StoreID, Player Type, Player Id, MediaFileName, CampaignId(HubID), 
    -- CreativeId, AdExposureDate, NetworkName, Division, MediaType, AdPlayStartTime, AdPlayEndTime, AdExposures
    -- validate against the lookup table (Store Id and Player ID Mapping).
    -- validate if every player is sending the data (Log the missing player info) - Look up based on the player
    -- AdPlayStartTime can't be grater than AdPlayEndTime.
    -- AdPlayStartTime and AdPlayEndTime should not be future

    -- Do Validations and insert data into TEMP table  
    CREATE TEMP TABLE TEMP_MEDIA_PROOF_OF_PLAY_RECORD_WITH_VALIDATION_STATUS AS
        WITH VALIDATION_RESULTS AS (
            SELECT
                SOURCE_DATA.RETAIL_STORE_PLAYER_ID,
                LOOKUP_DATA.RETAIL_STORE_ZONE_NM,
                SOURCE_DATA.RETAIL_STORE_PLAYER_NM,
                SOURCE_DATA.RETAIL_STORE_PLAYER_SERIAL_NBR,
                SOURCE_DATA.RETAIL_STORE_FACILITY_NBR,
                RETAIL_STORE.RETAIL_STORE_D1_SK,
                SOURCE_DATA.BANNER_NM,
                BANNER.BANNER_D1_SK,
                SOURCE_DATA.MEDIA_CREATIVE_NM,
                SOURCE_DATA.MEDIA_TYPE_CD,
                SOURCE_DATA.MEDIA_CAMPAIGN_ID,
                SOURCE_DATA.MEDIA_CREATIVE_ID,
                SOURCE_DATA.AD_EXPOSURE_DATE,
                CALENDAR_DAY.DAY_ID,
                SOURCE_DATA.AD_EXPOSURE_START_TS,
                SOURCE_DATA.AD_EXPOSURE_END_TS,
                SOURCE_DATA.AD_EXPOSURE_CNT,
                SOURCE_DATA.DW_FILE_PATH,
                SOURCE_DATA.DW_CREATE_TS,
                SOURCE_DATA.format,
                SOURCE_DATA.SOURCE_APPLICATION_CD,
                SOURCE_DATA.HEADER_LINE,
                SOURCE_DATA.FOOTER_LINE,
                job_id,
                CONCAT(
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.RETAIL_STORE_PLAYER_ID), '') = '' THEN 'PlayerID is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.RETAIL_STORE_PLAYER_NM), '') = '' THEN 'PlayerName is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.RETAIL_STORE_PLAYER_SERIAL_NBR), '') = '' THEN 'Serial is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.RETAIL_STORE_FACILITY_NBR), '') = '' THEN 'StoreID is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.BANNER_NM), '') = '' THEN 'NetworkName is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.MEDIA_CREATIVE_NM), '') = '' THEN 'MediaFileName is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.MEDIA_TYPE_CD), '') = '' THEN 'MediaType is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.MEDIA_CAMPAIGN_ID), '') = '' THEN 'CampaignID is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.MEDIA_CREATIVE_ID), '') = '' THEN 'CreativeID is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.AD_EXPOSURE_DATE), '') = '' THEN 'AdExposureDate is null/empty;' ELSE '' END,
                CASE WHEN SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_DATE AS DATE) IS NULL THEN 'AdExposureDate format is incorrect;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.AD_EXPOSURE_START_TS), '') = '' THEN 'FirstExposureStart is null/empty;' ELSE '' END,
                CASE WHEN IFNULL(TRIM(SOURCE_DATA.AD_EXPOSURE_END_TS), '') = '' THEN 'LastExposureEnd is null/empty;' ELSE '' END,
                CASE WHEN SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_START_TS AS TIMESTAMP) IS NULL THEN 'FirstExposureStart format is incorrect;' ELSE '' END,
                CASE WHEN SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_END_TS AS TIMESTAMP) IS NULL THEN 'LastExposureEnd format is incorrect;' ELSE '' END,
                CASE 
                    WHEN SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_DATE AS DATE) IS NOT NULL
                        AND SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_DATE AS DATE) > CURRENT_DATE()
                    THEN 'AdExposureDate is in future;'
                    ELSE ''
                END,
                CASE 
                    WHEN SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_START_TS AS TIMESTAMP) IS NOT NULL 
                        AND SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_END_TS AS TIMESTAMP) IS NOT NULL 
                        AND SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_START_TS AS TIMESTAMP) > SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_END_TS AS TIMESTAMP) 
                    THEN 'AdPlayStartTime is greater than AdPlayEndTime;' 
                    ELSE '' 
                END,
                CASE 
                    WHEN SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_START_TS AS TIMESTAMP) IS NOT NULL 
                        AND SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_START_TS AS TIMESTAMP) > CURRENT_TIMESTAMP() 
                    THEN 'AdPlayStartTime is in future;'  
                    ELSE '' 
                END,
                CASE 
                    WHEN SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_END_TS AS TIMESTAMP) IS NOT NULL 
                        AND SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_END_TS AS TIMESTAMP) > CURRENT_TIMESTAMP() 
                    THEN 'AdPlayEndTime is in future;'  
                    ELSE '' 
                END,       
                CASE WHEN SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_CNT AS INT64) IS NULL THEN 'AdExposures is null;'  ELSE '' END,
                CASE WHEN SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_CNT AS INT64) < 0 THEN 'AdExposures is negative;' ELSE '' END,
                CASE WHEN SAFE_CAST(RETAIL_STORE.RETAIL_STORE_D1_SK AS INT64) IS NULL THEN 'StoreID is not available;' ELSE '' END,
                CASE WHEN SAFE_CAST(CALENDAR_DAY.DAY_ID AS INT64) IS NULL THEN 'Calendar Date is not available;' ELSE '' END,
                CASE WHEN LOOKUP_DATA.RETAIL_STORE_FACILITY_NBR is NULL THEN 'Lookup missing for StoreID and PlayerID;'  ELSE '' END,
                CASE WHEN BANNER.BANNER_D1_SK IS NULL THEN 'Invalid NetworkName;'  ELSE '' END
                    ) AS ERR_DESC,
                ROW_NUMBER() OVER(PARTITION BY 
                SOURCE_DATA.RETAIL_STORE_PLAYER_ID,
                SOURCE_DATA.RETAIL_STORE_PLAYER_NM,
                SOURCE_DATA.RETAIL_STORE_PLAYER_SERIAL_NBR,
                SOURCE_DATA.RETAIL_STORE_FACILITY_NBR,
                SOURCE_DATA.BANNER_NM,
                SOURCE_DATA.MEDIA_CREATIVE_NM,
                SOURCE_DATA.MEDIA_TYPE_CD,
                SOURCE_DATA.MEDIA_CAMPAIGN_ID,
                SOURCE_DATA.MEDIA_CREATIVE_ID,
                SOURCE_DATA.AD_EXPOSURE_DATE,
                SOURCE_DATA.AD_EXPOSURE_START_TS,
                SOURCE_DATA.AD_EXPOSURE_END_TS
                ORDER BY SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_START_TS AS TIMESTAMP) DESC) as RN
            FROM
            `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PROOF_OF_PLAY_NVM_RAW_DATA_STG` SOURCE_DATA
            LEFT JOIN (SELECT DAY_ID, CALENDAR_DT FROM `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_acct.D0_CALENDAR_DAY`
            WHERE DW_LOGICAL_DELETE_IND = FALSE) CALENDAR_DAY
            ON SAFE_CAST(SOURCE_DATA.AD_EXPOSURE_DATE AS DATE) = CALENDAR_DAY.CALENDAR_DT
            LEFT JOIN (SELECT RETAIL_STORE_D1_SK, RETAIL_STORE_FACILITY_NBR FROM `<<RETAILSTORE_DATASET>>.D1_RETAIL_STORE` 
            WHERE DW_LOGICAL_DELETE_IND = FALSE) RETAIL_STORE
            ON SOURCE_DATA.RETAIL_STORE_FACILITY_NBR = RETAIL_STORE.RETAIL_STORE_FACILITY_NBR
            LEFT JOIN 
            (SELECT BANNER_D1_SK,BANNER_NM FROM `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_locn.D1_BANNER`
            WHERE DW_LOGICAL_DELETE_IND = FALSE) BANNER
            ON TRIM(LOWER(SOURCE_DATA.BANNER_NM)) = TRIM(LOWER(BANNER.BANNER_NM))
            LEFT JOIN (
                SELECT DISTINCT
                    RETAIL_STORE_FACILITY_NBR, RETAIL_STORE_ZONE_NM, RETAIL_STORE_PLAYER_ID
                FROM
                    `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_NVM_MEDIA_STORE_ZONE_LOOKUP`
                ) AS LOOKUP_DATA
            ON
                TRIM(SOURCE_DATA.RETAIL_STORE_FACILITY_NBR) = TRIM(LOOKUP_DATA.RETAIL_STORE_FACILITY_NBR)
                AND SAFE_CAST(SOURCE_DATA.RETAIL_STORE_PLAYER_ID AS NUMERIC) = LOOKUP_DATA.RETAIL_STORE_PLAYER_ID 
            WHERE 
            JOB_ID = CURRENT_JOB_ID
        )
        SELECT
            RETAIL_STORE_PLAYER_ID,
            RETAIL_STORE_ZONE_NM,
            RETAIL_STORE_PLAYER_NM,
            RETAIL_STORE_PLAYER_SERIAL_NBR,
            RETAIL_STORE_FACILITY_NBR,
            RETAIL_STORE_D1_SK,
            BANNER_NM,
            BANNER_D1_SK,
            MEDIA_CREATIVE_NM,
            MEDIA_TYPE_CD,
            MEDIA_CAMPAIGN_ID,
            MEDIA_CREATIVE_ID,
            AD_EXPOSURE_DATE,
            DAY_ID,
            AD_EXPOSURE_START_TS,
            AD_EXPOSURE_END_TS,
            AD_EXPOSURE_CNT,
            CASE 
                WHEN RN > 1 THEN CONCAT(ERR_DESC, 'Duplicate record - More than one record for the same PLAYER_ID;')
                ELSE ERR_DESC 
            END AS ERROR_MESSAGE,
            DW_FILE_PATH,
            DW_CREATE_TS,
            format,
            SOURCE_APPLICATION_CD,
            HEADER_LINE,
            FOOTER_LINE,
            JOB_ID
        FROM
            VALIDATION_RESULTS;
        
        -- Check against existing records in target table to detect duplicates
        CREATE TEMP TABLE TEMP_PROOF_OF_PLAY_DEDUPED AS
        SELECT 
            TEMP.RETAIL_STORE_PLAYER_ID,
            TEMP.RETAIL_STORE_ZONE_NM,
            TEMP.RETAIL_STORE_PLAYER_NM,
            TEMP.RETAIL_STORE_PLAYER_SERIAL_NBR,
            TEMP.RETAIL_STORE_FACILITY_NBR,
            TEMP.RETAIL_STORE_D1_SK,
            TEMP.BANNER_NM,
            TEMP.BANNER_D1_SK,
            TEMP.MEDIA_CREATIVE_NM,
            TEMP.MEDIA_TYPE_CD,
            TEMP.MEDIA_CAMPAIGN_ID,
            TEMP.MEDIA_CREATIVE_ID,
            TEMP.AD_EXPOSURE_DATE,
            TEMP.DAY_ID,
            TEMP.AD_EXPOSURE_START_TS,
            TEMP.AD_EXPOSURE_END_TS,
            TEMP.AD_EXPOSURE_CNT,
            CASE 
                WHEN TARGET.RETAIL_STORE_PLAYER_ID IS NOT NULL AND TEMP.ERROR_MESSAGE = ''
                    THEN 'Record already exists in target table;'
                ELSE TEMP.ERROR_MESSAGE
            END AS ERROR_MESSAGE,
            TEMP.DW_FILE_PATH,
            TEMP.DW_CREATE_TS,
            TEMP.format,
            TEMP.SOURCE_APPLICATION_CD,
            TEMP.HEADER_LINE,
            TEMP.FOOTER_LINE,
            TEMP.JOB_ID
        FROM TEMP_MEDIA_PROOF_OF_PLAY_RECORD_WITH_VALIDATION_STATUS AS TEMP
        LEFT JOIN `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY` AS TARGET
            ON TARGET.RETAIL_STORE_PLAYER_ID = SAFE_CAST(TEMP.RETAIL_STORE_PLAYER_ID AS NUMERIC)
            AND TARGET.AD_EXPOSURE_END_TS = SAFE_CAST(TEMP.AD_EXPOSURE_END_TS AS TIMESTAMP)
            AND TARGET.MEDIA_CAMPAIGN_ID = TEMP.MEDIA_CAMPAIGN_ID
            AND TARGET.MEDIA_CREATIVE_ID = TEMP.MEDIA_CREATIVE_ID
            AND TARGET.AD_EXPOSURE_START_TS = SAFE_CAST(TEMP.AD_EXPOSURE_START_TS AS TIMESTAMP)
            AND TARGET.MEDIA_CREATIVE_NM = TEMP.MEDIA_CREATIVE_NM
            AND TARGET.MEDIA_TYPE_CD = TEMP.MEDIA_TYPE_CD;



        -- Insert valid records into table
        INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.FA_INSTORE_MP_PROOF_OF_PLAY_DAY`
        (
            RETAIL_STORE_PLAYER_ID,
            RETAIL_STORE_ZONE_NM,
            RETAIL_STORE_PLAYER_NM,
            RETAIL_STORE_PLAYER_SERIAL_NBR,
            RETAIL_STORE_D1_SK,
            BANNER_D1_SK,
            MEDIA_CREATIVE_NM,
            MEDIA_TYPE_CD,
            MEDIA_CAMPAIGN_ID,
            MEDIA_CREATIVE_ID,
            AD_EXPOSURE_DAY_ID,
            AD_EXPOSURE_START_TS,
            AD_EXPOSURE_END_TS,
            AD_EXPOSURE_CNT,
            SOURCE_APP_CD,
            JOB_ID,
            DW_CREATE_TS,
            DW_LAST_UPDATE_TS
        )
        SELECT
            SAFE_CAST(RETAIL_STORE_PLAYER_ID AS NUMERIC) AS RETAIL_STORE_PLAYER_ID,
            RETAIL_STORE_ZONE_NM,
            RETAIL_STORE_PLAYER_NM,
            RETAIL_STORE_PLAYER_SERIAL_NBR,
            RETAIL_STORE_D1_SK,
            BANNER_D1_SK,
            MEDIA_CREATIVE_NM,
            MEDIA_TYPE_CD,
            MEDIA_CAMPAIGN_ID,
            MEDIA_CREATIVE_ID,
            DAY_ID,
            SAFE_CAST(AD_EXPOSURE_START_TS AS TIMESTAMP) AS AD_EXPOSURE_START_TS,
            SAFE_CAST(AD_EXPOSURE_END_TS AS TIMESTAMP) AS AD_EXPOSURE_END_TS,
            SAFE_CAST(AD_EXPOSURE_CNT AS NUMERIC) AS AD_EXPOSURE_CNT,
            SOURCE_APPLICATION_CD,
            JOB_ID,
            CURRENT_TIMESTAMP(),
            CURRENT_TIMESTAMP() 
        FROM
            TEMP_PROOF_OF_PLAY_DEDUPED
        WHERE
            ERROR_MESSAGE = '';

        -- Assign the result of the query to the variable
        SET record_count = (
            SELECT COUNT(1)
            FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PROOF_OF_PLAY_NVM_INVALID_DATA`
            WHERE JOB_ID = CURRENT_JOB_ID
        );

        -- If no records exist for the job_id, proceed with the insert
        IF record_count = 0 THEN
            INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PROOF_OF_PLAY_NVM_INVALID_DATA` 
            (
                RETAIL_STORE_PLAYER_ID,
                RETAIL_STORE_PLAYER_NM,
                RETAIL_STORE_PLAYER_SERIAL_NBR,
                RETAIL_STORE_FACILITY_NBR,
                BANNER_NM,
                MEDIA_CREATIVE_NM,
                MEDIA_TYPE_CD,
                MEDIA_CAMPAIGN_ID,
                MEDIA_CREATIVE_ID,
                AD_EXPOSURE_DATE,
                AD_EXPOSURE_START_TS,
                AD_EXPOSURE_END_TS,
                AD_EXPOSURE_CNT,
                ERROR_MESSAGE,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            )
            SELECT
                SOURCE_DATA.RETAIL_STORE_PLAYER_ID,
                SOURCE_DATA.RETAIL_STORE_PLAYER_NM,
                SOURCE_DATA.RETAIL_STORE_PLAYER_SERIAL_NBR,
                SOURCE_DATA.RETAIL_STORE_FACILITY_NBR,
                SOURCE_DATA.BANNER_NM,
                SOURCE_DATA.MEDIA_CREATIVE_NM,
                SOURCE_DATA.MEDIA_TYPE_CD,
                SOURCE_DATA.MEDIA_CAMPAIGN_ID,
                SOURCE_DATA.MEDIA_CREATIVE_ID,
                SOURCE_DATA.AD_EXPOSURE_DATE,
                SOURCE_DATA.AD_EXPOSURE_START_TS,
                SOURCE_DATA.AD_EXPOSURE_END_TS,
                SOURCE_DATA.AD_EXPOSURE_CNT,
                SOURCE_DATA.ERROR_MESSAGE,
                SOURCE_DATA.DW_FILE_PATH,
                CURRENT_TIMESTAMP(),
                SOURCE_DATA.SOURCE_APPLICATION_CD,
                SOURCE_DATA.JOB_ID
            FROM TEMP_PROOF_OF_PLAY_DEDUPED AS SOURCE_DATA
            WHERE SOURCE_DATA.ERROR_MESSAGE != '';
        END IF;

END;
