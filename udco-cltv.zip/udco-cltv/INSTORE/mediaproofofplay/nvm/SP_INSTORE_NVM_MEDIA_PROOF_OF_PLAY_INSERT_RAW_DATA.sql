CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_INSTORE_MEDIA_PROOF_OF_PLAY_NVM_INSERT_RAW_DATA`(job_id STRING)
BEGIN

    -- Declare a variable to store the record count
    DECLARE record_count INT64;

    DECLARE CURRENT_JOB_ID STRING;
    SET CURRENT_JOB_ID = job_id;

    -- Assign the result of the query to the variable
    SET record_count = (
        SELECT COUNT(1)
        FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PROOF_OF_PLAY_NVM_RAW_DATA`
        WHERE JOB_ID = CURRENT_JOB_ID
    );

    -- If no records exist for the job_id, proceed with the insert
    IF record_count = 0 THEN
        INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PROOF_OF_PLAY_NVM_RAW_DATA`
        (
            RETAIL_STORE_PLAYER_ID,
            RETAIL_STORE_PLAYER_NM,
            RETAIL_STORE_PLAYER_SERIAL_NBR,
            RETAIL_STORE_FACILITY_NBR,
            BANNER_NM,
            MEDIA_CREATIVE_NM,
            MEDIA_TYPE_CD,
            MEDIA_CAMPAIGN_ID,
            MEDIA_CREATIVE_ID,
            AD_EXPOSURE_DATE,
            AD_EXPOSURE_START_TS,
            AD_EXPOSURE_END_TS,
            AD_EXPOSURE_CNT,
            DW_FILE_PATH,
            DW_CREATE_TS,
            format,
            SOURCE_APPLICATION_CD,
            HEADER_LINE,
            FOOTER_LINE,
            JOB_ID
        )
        SELECT
            SOURCE_DATA.RETAIL_STORE_PLAYER_ID,
            SOURCE_DATA.RETAIL_STORE_PLAYER_NM,
            SOURCE_DATA.RETAIL_STORE_PLAYER_SERIAL_NBR,
            SOURCE_DATA.RETAIL_STORE_FACILITY_NBR,
            SOURCE_DATA.BANNER_NM,
            SOURCE_DATA.MEDIA_CREATIVE_NM,
            SOURCE_DATA.MEDIA_TYPE_CD,
            SOURCE_DATA.MEDIA_CAMPAIGN_ID,
            SOURCE_DATA.MEDIA_CREATIVE_ID,
            SOURCE_DATA.AD_EXPOSURE_DATE,
            SOURCE_DATA.AD_EXPOSURE_START_TS,
            SOURCE_DATA.AD_EXPOSURE_END_TS,
            SOURCE_DATA.AD_EXPOSURE_CNT,
            SOURCE_DATA.DW_FILE_PATH,
            CURRENT_TIMESTAMP(),
            SOURCE_DATA.format,
            SOURCE_DATA.SOURCE_APPLICATION_CD,
            SOURCE_DATA.HEADER_LINE,
            SOURCE_DATA.FOOTER_LINE,
            CURRENT_JOB_ID
        FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PROOF_OF_PLAY_NVM_RAW_DATA_STG` SOURCE_DATA
        WHERE SOURCE_DATA.JOB_ID = CURRENT_JOB_ID;
    END IF;
END;