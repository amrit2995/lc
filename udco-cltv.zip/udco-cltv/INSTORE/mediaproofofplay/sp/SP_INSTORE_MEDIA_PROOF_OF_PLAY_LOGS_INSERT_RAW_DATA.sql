CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_INSTORE_MEDIA_PROOF_OF_PLAY_LOGS_INSERT_RAW_DATA`(job_id STRING)
BEGIN
  DECLARE record_count INT64;

  DECLARE CURRENT_JOB_ID STRING;
  SET CURRENT_JOB_ID = job_id;
  
  -- Step 1: Check if records for this job_id already exist
  SET record_count = (
    SELECT COUNT(1)
    FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.RETAIL_STORE_MEDIA_PROOF_OF_PLAY_RAW_DATA`
    WHERE JOB_ID = CURRENT_JOB_ID
  );

  -- Step 2: If no records, insert from staging
  IF record_count = 0 THEN
    INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.RETAIL_STORE_MEDIA_PROOF_OF_PLAY_RAW_DATA`
    (
      PLAYER_ID,
      MEDIA_CREATIVE_ID,
      CAMPAIGN_LINE_ITEM_ID,
      RETAIL_STORE_FACILITY_NBR,
      AD_PLAY_START_TS,
      AD_PLAY_END_TS,
      -- Required metadata fields
      DW_FILE_PATH,
      DW_CREATE_TS,
      format,
      SOURCE_APPLICATION_CD,
      HEADER_LINE,
      FOOTER_LINE,
      JOB_ID,
      AD_PLAY_STORE_OPEN_HR_IND
    )
    SELECT
      PLAYER_ID,
      MEDIA_CREATIVE_ID,
      CAMPAIGN_LINE_ITEM_ID,
      RETAIL_STORE_FACILITY_NBR,
      AD_PLAY_START_TS,
      AD_PLAY_END_TS,
      -- Required metadata fields
      DW_FILE_PATH,
      CURRENT_TIMESTAMP(),
      format,
      SOURCE_APPLICATION_CD,
      HEADER_LINE,
      FOOTER_LINE,
      JOB_ID,
      AD_PLAY_STORE_OPEN_HR_IND
    FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.RETAIL_STORE_MEDIA_PROOF_OF_PLAY_RAW_DATA_STG`
    WHERE JOB_ID = CURRENT_JOB_ID;
  END IF;
END;