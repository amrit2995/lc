# INSTORE (In-Store Retail Media)

Manages Stratacache in-store media data — campaigns, creatives, proof-of-play logs, sensors (BLE + MMWave), out-of-stock tracking, and POS media.

## Pipeline Flow

```
SFTP / GCS Files ──► [SToV] ──► Raw Tables ──► [VToB SPs] ──► Confirmed Tables ──► Views
```

### Data Flow Detail
1. **SToV**: CSV/JSON files land in GCS → ingested into raw BigQuery tables
2. **VToB SPs**: Stored procedures validate, deduplicate, and SCD2-merge into confirmed tables
3. **Views**: Expose confirmed data for downstream consumption

## Directory Layout

```
INSTORE/
├── README.md
├── params_dev.json / params_qa.json / params_prod.json
├── config/                         ← 51 Airflow workflow & step configs
│   ├── INSTORE*_WF.json            ← domain-specific DAGs
│   ├── SToV_INSTORE_*_FileToBQ.json   ← file-to-BQ ingestion configs
│   └── VToB_INSTORE_*_BQToBQ.json     ← BQ-to-BQ transform configs
│
├── campaign/                       ← Campaign entity
│   ├── ddl/  (7)   ├── sp/  (2)   └── view/  (5)
├── creative/                       ← Creative entity
│   ├── ddl/  (4)   ├── sp/  (2)   └── view/  (1)
├── mediaproofofplay/               ← Proof-of-play (standard + NVM + POS)
│   ├── ddl/ (12)   ├── sp/  (6)   ├── view/ (1)   ├── dml/ (1)
│   └── nvm/ (11)                   ← NVM proof-of-play sub-module
├── sensor/                         ← BLE & MMWave sensors
│   ├── ddl/ (14)   ├── sp/  (8)   └── view/ (6)
├── lookup/                         ← Zone / Player / Partner lookups
│   ├── ddl/ (12)   ├── sp/  (2)   └── view/ (7)
├── outofstock/                     ← OOS status tracking
│   ├── ddl/  (2)   ├── sp/  (1)   └── views/ (2)
├── pos/                            ← POS media
│   ├── dml/  (4)   └── Lookup-Files/ (CSVs)
│
├── dml/                            ← Data-fix / BLE mapping DMLs
│   └── 26.01.01/                   ← BLE exposure register mappings (15)
├── Lookup-Files/                   ← Monthly lookup CSVs (Aug – Nov)
│   ├── Aug/ → Sep/ → Oct/ → Nov/
├── thoughtspot/                    ← ThoughtSpot exports
│   ├── liveboard/ (dev + qa)       ← TML liveboards
│   └── model/ (dev + qa)           ← TML models
└── release-BE-*/                   ← Versioned release artifacts
```

## Key Entities

| Entity | DDL | SP | View |
|--------|-----|-----|------|
| Campaign Details | `campaign/ddl/` | `campaign/sp/` | `campaign/view/` |
| Creative Details | `creative/ddl/` | `creative/sp/` | `creative/view/` |
| Media Proof-of-Play | `mediaproofofplay/ddl/` | `mediaproofofplay/sp/` | `mediaproofofplay/view/` |
| NVM Proof-of-Play | `mediaproofofplay/nvm/` | — | — |
| Sensor (BLE + MMWave) | `sensor/ddl/` | `sensor/sp/` | `sensor/view/` |
| Lookups (Zone/Player) | `lookup/ddl/` | `lookup/sp/` | `lookup/view/` |
| Out-of-Stock | `outofstock/ddl/` | `outofstock/sp/` | `outofstock/views/` |
| POS Media | — | — | `pos/dml/` |

## Deployment

Ordered via `in_store_script_order_execution.yaml` at the repo root.
