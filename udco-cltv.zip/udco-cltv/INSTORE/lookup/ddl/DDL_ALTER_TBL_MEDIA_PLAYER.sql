DECLARE column_exists BOOL;

-- Step 1: Check if column exists
SET column_exists = (
  SELECT COUNT(*) > 0
  FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.INFORMATION_SCHEMA.COLUMNS`
  WHERE table_name = 'MEDIA_PLAYER'
    AND column_name = 'PLAYER_SERIAL_NBR'
);

-- Step 2: Conditionally drop column
IF column_exists THEN
  EXECUTE IMMEDIATE """
    ALTER TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PLAYER`
    DROP COLUMN PLAYER_SERIAL_NBR
    --OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')])
  """;
END IF;


-- Step 3: Check if column exists
SET column_exists = (
  SELECT COUNT(*) > 0
  FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.INFORMATION_SCHEMA.COLUMNS`
  WHERE table_name = 'MEDIA_PLAYER'
    AND column_name = 'PLAYER_SERIAL_NBR'
);

-- Step 4: Conditionally add column
IF not column_exists THEN
  EXECUTE IMMEDIATE """
    ALTER TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PLAYER`
    ADD COLUMN PLAYER_SERIAL_NBR STRING 
  OPTIONS(description="Unique Serial number of the player");
  """;
END IF;

