CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CAMPAIGN_ADVERTISER` (
    CAMPAIGN_ADVERTISER_ID STRING NOT NULL,
    CAMPAIGN_ADVERTISER_NM STRING NOT NULL,
    DW_CREATE_TS TIMESTAMP NOT NULL,
    DW_LAST_UPDATE_TS TIMESTAMP NOT NULL,
    SOURCE_APPLICATION_CD STRING NOT NULL,
    JOB_ID STRING NOT NULL
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);