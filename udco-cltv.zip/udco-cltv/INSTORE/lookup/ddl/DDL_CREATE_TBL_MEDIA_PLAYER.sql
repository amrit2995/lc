CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PLAYER` (
    PLAYER_ID                        NUMERIC NOT NULL OPTIONS(description="Unique Player ID /device Id of the media player"),
    PLAYER_NM                        STRING OPTIONS(description="Name of the player along with the zone where it is placed Example Deli, Pharmacy, Entry"),
    PLAYER_SERIAL_NBR                NUMERIC OPTIONS(description="Unique Serial number of the player"),
    SCREEN_SIZE_DSC                 NUMERIC OPTIONS(description="The value could be null if it''s a checkout zone"),
    ASPECT_RATIO_DSC                 STRING OPTIONS(description="Aspect ratio of the installed screens"),
    -- Required metadata fields
    SOURCE_APPLICATION_CD            STRING NOT NULL OPTIONS(description="Name of the process creating the record"),
    DW_CREATE_TS                     TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS                TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
    JOB_ID                           STRING NOT NULL OPTIONS(description="JOB_ID of the current DAG run"),
    PRIMARY KEY (PLAYER_ID) NOT ENFORCED
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
