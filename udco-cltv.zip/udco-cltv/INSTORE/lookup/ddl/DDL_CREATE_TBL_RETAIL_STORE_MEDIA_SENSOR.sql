CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_SENSOR` (
    FACILITY_INTEGRATION_ID          NUMERIC NOT NULL OPTIONS(description="Entity to store different media zones in a store. A store may have multiple zones under each department. exmaple Deli"),
    MEDIA_ZONE_CD                    STRING NOT NULL OPTIONS(description="Zone ID where the media player is installed.Place where the media was played Example Deli, Pharmacy, Entry"),
    MEDIA_SENSOR_ID                  STRING NOT NULL OPTIONS(description="Unique ID of the media sensor."),
    SOURCE_APPLICATION_CD            STRING OPTIONS(description="Name of the process creating the record"),
    DW_CREATE_TS                     TIMESTAMP OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS                TIMESTAMP OPTIONS(description="When a record is updated  this would be the current timestamp"),
    JOB_ID                           STRING NOT NULL OPTIONS(description="JOB_ID of the current DAG run"),
    PRIMARY KEY (FACILITY_INTEGRATION_ID, MEDIA_ZONE_CD) NOT ENFORCED
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
