CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_ZONE_PLAYER` (
    FACILITY_INTEGRATION_ID          NUMERIC NOT NULL OPTIONS(description="Entity to store different media zones in a store. A store may have multiple zones under each department. exmaple Deli"),
    MEDIA_ZONE_CD                    STRING NOT NULL OPTIONS(description="Zone ID where the media player is installed.Place where the media was played Example Deli, Pharmacy, Entry"),
    PLAYER_ID                        NUMERIC NOT NULL OPTIONS(description="Unique Player ID /device Id of the media player"),
    PLAYER_MOUNTING_DSC              STRING OPTIONS(description="Mounting type of the player. Sample values: wall, ceiling, floor etc"),
    PLAYER_POSITION_DSC              STRING OPTIONS(description="Position of the player/screens(Sample values: FRONT, BACK)"),
    PLAYER_TYPE_DSC                  STRING NOT NULL OPTIONS(description="Player is used as selfcheckout or display screen..Sample values: display, fuel etc"),
    DEVICE_TZ                        STRING OPTIONS(description="Local timezone of the device/players."),
    SOURCE_APPLICATION_CD            STRING NOT NULL OPTIONS(description="Name of the process creating the record"),
    DW_CREATE_TS                     TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS                TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
    JOB_ID                           STRING NOT NULL OPTIONS(description="JOB_ID of the current DAG run"),
    PRIMARY KEY (FACILITY_INTEGRATION_ID, MEDIA_ZONE_CD,PLAYER_ID) NOT ENFORCED
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
