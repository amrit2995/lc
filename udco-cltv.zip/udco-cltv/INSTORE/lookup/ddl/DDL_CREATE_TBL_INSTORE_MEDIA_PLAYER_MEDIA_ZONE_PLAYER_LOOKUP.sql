CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PLAYER_MEDIA_ZONE_PLAYER_LOOKUP` (
    RETAIL_STORE_FACILITY_NBR                STRING OPTIONS(description="Store ID where the media player is installed"),
    ZONE_ID                                  STRING OPTIONS(description="Zone ID where the media player is installed.Place where the media was played Example Deli, Pharmacy, Entry'"),
    PLAYER_ID                                STRING OPTIONS(description="Unique Player ID /device Id of the media player"),
    PLAYER_NM                                STRING OPTIONS(description="Name of the player along with the zone where it is placed Example Deli, Pharmacy, Entry"),
    PLAYER_SERIAL_NBR                        STRING OPTIONS(description="Unique Serial number of the player"),
    SCREEN_SIZE_DESC                         STRING OPTIONS(description="The value could be null if it''s a checkout zone"),
    ASPECT_RATIO                             STRING OPTIONS(description="Aspect ratio of the installed screens"),
    MOUNTING                                 STRING OPTIONS(description="Mounting type of the player. Sample values: wall, ceiling, floor etc"),
    POSITION                                 STRING OPTIONS(description="Position of the player/screens(Sample values: FRONT, BACK)"),
    PLAYER_TYPE                              STRING OPTIONS(description="Player is used as selfcheckout or display screen..Sample values: display, fuel etc"),
    DEVICE_TZ                                STRING OPTIONS(description="Local timezone of the device/players."),
    -- Required metadata fields
    DW_FILE_PATH                             STRING OPTIONS(description="Google storage path for input file"),
    DW_CREATE_TS                             TIMESTAMP OPTIONS(description="Timestamp when the record is created in BigQuery"),
    `format`                                 STRING OPTIONS(description="File format of input file like csv, fwf, json,xml or parquet"),
    SOURCE_APPLICATION_CD                    STRING OPTIONS(description="Name of the process creating the record"),
    HEADER_LINE                              STRING OPTIONS(description="Indicates whether the input file contains a header line (true/false)"),
    FOOTER_LINE                              STRING OPTIONS(description="Indicates whether the input file contains a footer line (true/false)"),
    JOB_ID                                   STRING OPTIONS(description="JOB_ID of the current DAG run")
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);