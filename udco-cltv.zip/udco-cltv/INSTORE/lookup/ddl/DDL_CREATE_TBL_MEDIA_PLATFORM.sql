CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PLATFORM` (
 PLATFORM_ID           STRING  NOT NULL OPTIONS(description="Platform ID to run Campaign example Instore"),
 PLATFORM_NM           STRING OPTIONS(description="Platform to run Campaign example Instore"),
 DW_CREATE_TS          TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
 DW_LAST_UPDATE_TS     TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
 SOURCE_APPLICATION_CD  STRING NOT NULL OPTIONS(description="Source Application Code which created this record."),
 JOB_ID                STRING  NOT NULL OPTIONS(description="Job ID which is used to identify the job that created this record.")
)
OPTIONS (
    description="The retail media system often works with multiple technology platforms and partners. This table tracks all the different platforms that can deliver advertisements - whether they''re in-house systems, third-party networks, or specialized display technologies. Each platform has its own capabilities and characteristics.",    
    labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
);
