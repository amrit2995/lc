CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_STORE_ZONE_LOOKUP` (
    RETAIL_STORE_FACILITY_NBR                STRING OPTIONS(description="Store ID where the media player is installed"),
    MEDIA_ZONE_CD                            STRING OPTIONS(description="Associated zone info(Ex. Sidecap, Endcap etc)"),
    REGISTER_NBR                             STRING OPTIONS(description="Register ID"),
    -- Required metadata fields
    DW_FILE_PATH                             STRING OPTIONS(description="Google storage path for input file"),
    DW_CREATE_TS                             TIMESTAMP OPTIONS(description="Timestamp when the record is created in BigQuery"),
    `format`                                 STRING OPTIONS(description="File format of input file like csv, fwf, json,xml or parquet"),
    SOURCE_APPLICATION_CD                    STRING OPTIONS(description="Name of the process creating the record"),
    HEADER_LINE                              STRING OPTIONS(description="If header is present "),
    FOOTER_LINE                              STRING OPTIONS(description="If Footer is present"),
    JOB_ID                                   STRING OPTIONS(description="JOB_ID of the current DAG run")
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);