CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_ZONE` (
    MEDIA_ZONE_CD           STRING NOT NULL OPTIONS(description="Zone ID where the media player is installed.Place where the media was played Example Deli, Pharmacy, Entry"),
    MEDIA_ZONE_NM           STRING OPTIONS(description="Zone Name where the media player is installed."),
    CHECKOUT_IND            SMALLINT NOT NULL  OPTIONS(description="its a flag to check , Is the zone is a checkout Zone"),
    MEDIA_ZONE_TYPE_CD      STRING OPTIONS(description="ssociated zone info(Ex. Sidecap, Endcap etc)"),
    SOURCE_APPLICATION_CD   STRING NOT NULL OPTIONS(description="Name of the process creating the record"),
    DW_CREATE_TS            TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS       TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
    JOB_ID                  STRING NOT NULL OPTIONS(description="JOB_ID of the current DAG run"),
    PRIMARY KEY (MEDIA_ZONE_CD) NOT ENFORCED
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
