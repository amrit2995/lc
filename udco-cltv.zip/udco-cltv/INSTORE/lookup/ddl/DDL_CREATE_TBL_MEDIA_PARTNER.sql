CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PARTNER` (
 MEDIA_PARTNER_ID      STRING  NOT NULL OPTIONS(description="Partner IDs who are engaged to run Campaign in stores"),
 MEDIA_PARTNER_NM      STRING   OPTIONS(description="Partners who are engaged to run Campaign in stores"),
 DW_CREATE_TS          TIMESTAMP NOT NULL   OPTIONS(description="The timestamp the record was inserted."),
 DW_LAST_UPDATE_TS     TIMESTAMP NOT NULL   OPTIONS(description="When a record is updated  this would be the current timestamp"),
 SOURCE_APPLICATION_CD  STRING NOT NULL   OPTIONS(description="Source Application Code which created this record."),
 JOB_ID                STRING NOT NULL  OPTIONS(description="Job ID which is used to identify the job that created this record.")
)
OPTIONS (
    description="This is a comprehensive database of all business partners involved in delivering advertising campaigns. This includes technology vendors, display hardware providers, sensor companies, and other service providers that support the advertising ecosystem.",    
    labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
);
