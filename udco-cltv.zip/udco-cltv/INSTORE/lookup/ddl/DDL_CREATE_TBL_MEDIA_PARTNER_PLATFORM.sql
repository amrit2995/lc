CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PARTNER_PLATFORM` (
 PLATFORM_ID           STRING  NOT NULL OPTIONS(description="Platform ID to run Campaign example Instore"),
 MEDIA_PARTNER_ID      STRING  NOT NULL OPTIONS(description="Partner IDs who are engaged to run Campaign in stores"),
 DW_CREATE_TS          TIMESTAMP OPTIONS(description="The timestamp the record was inserted."),
 DW_LAST_UPDATE_TS     TIMESTAMP OPTIONS(description="When a record is updated  this would be the current timestamp"),
 SOURCE_APPLICATION_CD  STRING OPTIONS(description="Source Application Code which created this record."),
 JOB_ID                STRING  NOT NULL OPTIONS(description="Job ID which is used to identify the job that created this record.")
)
OPTIONS (
    description="This table connects media partners (companies that help deliver advertising) with the specific platforms they use.",    
    labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
);
