CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.SP_RETAIL_STORE_MEDIA_ZONE_PLAYER_INSERT_DATA`(job_id STRING)
BEGIN
        DECLARE CURRENT_JOB_ID STRING;
        DECLARE transaction_started BOOL;
        SET CURRENT_JOB_ID = job_id;
        SET transaction_started = FALSE;

        -- This query loads the data to MEDIA_PLAYER table from INSTORE_MEDIA_PLAYER_MEDIA_ZONE_PLAYER_LOOKUP 
BEGIN
    -- BEGIN TRANSACTION BEFORE INSERTING/MERGING TO TARGET TABLES
    BEGIN TRANSACTION;

    -- Set transaction_started to TRUE to indicate that the transaction has started
    SET transaction_started = TRUE;
       
               CREATE TEMP TABLE MEDIA_PLAYER_RETAIL_STORE_ZONE_PLAYER_TEMP AS 
               WITH SourceData AS 
               (
               SELECT 
                   CAST(RETAIL_STORE.FACILITY_INTEGRATION_ID AS NUMERIC) AS FACILITY_INTEGRATION_ID,
                   ZONE_ID AS MEDIA_ZONE_CD,
                   SAFE_CAST(PLAYER_ID AS NUMERIC) AS PLAYER_ID,
                   SOURCE_DATA.PLAYER_NM AS PLAYER_NM,
                   SOURCE_DATA.PLAYER_SERIAL_NBR AS PLAYER_SERIAL_NBR,
                   SAFE_CAST(REPLACE(SOURCE_DATA.SCREEN_SIZE_DESC, '"', '') AS NUMERIC) AS SCREEN_SIZE_DSC,
                   SOURCE_DATA.ASPECT_RATIO AS ASPECT_RATIO_DSC,
                   MOUNTING AS PLAYER_MOUNTING_DSC,
                   POSITION AS PLAYER_POSITION_DSC,
                   IFNULL(PLAYER_TYPE,'NA') AS PLAYER_TYPE_DSC,
                   DEVICE_TZ,
                   SOURCE_APPLICATION_CD,
                   IFNULL(RETAIL_STORE_MEDIA_ZONE_PLAYER.DW_CREATE_TS,SOURCE_DATA.DW_CREATE_TS) DW_CREATE_TS,
                   IFNULL(RETAIL_STORE_MEDIA_ZONE_PLAYER.DW_CREATE_TS,CURRENT_TIMESTAMP()) DW_CREATE_TS_INSERT,
                   -- Removed DW_LAST_UPDATE_TS to avoid redundancy
                   SOURCE_DATA.JOB_ID AS JOB_ID
                FROM 
                   `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.INSTORE_MEDIA_PLAYER_MEDIA_ZONE_PLAYER_LOOKUP` AS SOURCE_DATA 
                   -- Join with retail store data to get facility integration IDs
                JOIN (
            SELECT DISTINCT
                RETAIL_STORE_FACILITY_NBR,
                FACILITY_INTEGRATION_ID
            FROM 
                `<<RETAILSTORE_DATASET>>.D1_RETAIL_STORE` 
            WHERE 
                DW_LOGICAL_DELETE_IND = FALSE 
                AND RETAIL_STORE_FACILITY_NBR IS NOT NULL
                AND FACILITY_INTEGRATION_ID IS NOT NULL
        ) RETAIL_STORE 
        ON 
            SOURCE_DATA.RETAIL_STORE_FACILITY_NBR = RETAIL_STORE.RETAIL_STORE_FACILITY_NBR 
            LEFT JOIN (
              SELECT  FACILITY_INTEGRATION_ID, 
              MAX(DW_CREATE_TS) AS DW_CREATE_TS
              FROM 
              `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_ZONE_PLAYER`
              GROUP BY 
              FACILITY_INTEGRATION_ID
            ) RETAIL_STORE_MEDIA_ZONE_PLAYER
            ON 
            RETAIL_STORE.FACILITY_INTEGRATION_ID = RETAIL_STORE_MEDIA_ZONE_PLAYER.FACILITY_INTEGRATION_ID
         WHERE 
                   SOURCE_DATA.JOB_ID = CURRENT_JOB_ID
                   AND SAFE_CAST(SOURCE_DATA.PLAYER_ID AS NUMERIC) IS NOT NULL
                   AND SOURCE_DATA.ZONE_ID IS NOT NULL 
               )
               SELECT * FROM (
                 SELECT *,
                   ROW_NUMBER() OVER (
                     PARTITION BY PLAYER_ID, MEDIA_ZONE_CD, FACILITY_INTEGRATION_ID
                     ORDER BY DW_CREATE_TS DESC
                   ) AS rn
                 FROM SourceData
               )
               WHERE rn = 1;


    -- Delete data from MEDIA_PLAYER table

    DELETE FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PLAYER` WHERE PLAYER_ID IN
    (SELECT DISTINCT A.PLAYER_ID FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_ZONE_PLAYER` A INNER JOIN 
    MEDIA_PLAYER_RETAIL_STORE_ZONE_PLAYER_TEMP B ON A.FACILITY_INTEGRATION_ID = B.FACILITY_INTEGRATION_ID)  AND
    JOB_ID <> CURRENT_JOB_ID;

    -- Insert data into MEDIA_PLAYER table

    INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PLAYER`
    (       PLAYER_ID, 
            PLAYER_NM, 
            PLAYER_SERIAL_NBR,
            SCREEN_SIZE_DSC, 
            ASPECT_RATIO_DSC, 
            SOURCE_APPLICATION_CD, 
            DW_CREATE_TS, 
            DW_LAST_UPDATE_TS, 
            JOB_ID
    )
    SELECT 
            SOURCE.PLAYER_ID, 
            SOURCE.PLAYER_NM, 
            SOURCE.PLAYER_SERIAL_NBR, 
            SOURCE.SCREEN_SIZE_DSC, 
            SOURCE.ASPECT_RATIO_DSC, 
            SOURCE.SOURCE_APPLICATION_CD, 
            SOURCE.DW_CREATE_TS_INSERT, 
            CURRENT_TIMESTAMP(), 
            SOURCE.JOB_ID
    FROM MEDIA_PLAYER_RETAIL_STORE_ZONE_PLAYER_TEMP SOURCE;


    -- DELETE data from RETAIL_STORE_MEDIA_ZONE_PLAYER table

    DELETE FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_ZONE_PLAYER` WHERE 
    FACILITY_INTEGRATION_ID IN (SELECT DISTINCT FACILITY_INTEGRATION_ID FROM MEDIA_PLAYER_RETAIL_STORE_ZONE_PLAYER_TEMP) AND
    JOB_ID <> CURRENT_JOB_ID;

    -- INSERT data into RETAIL_STORE_MEDIA_ZONE_PLAYER table
    INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_ZONE_PLAYER`
    (
            FACILITY_INTEGRATION_ID, 
            MEDIA_ZONE_CD, 
            PLAYER_ID, 
            PLAYER_MOUNTING_DSC, 
            PLAYER_POSITION_DSC,
            PLAYER_TYPE_DSC,
            DEVICE_TZ, 
            SOURCE_APPLICATION_CD, 
            DW_CREATE_TS, 
            DW_LAST_UPDATE_TS, 
            JOB_ID
        )
        SELECT 
            SOURCE.FACILITY_INTEGRATION_ID,
            SOURCE.MEDIA_ZONE_CD,
            SOURCE.PLAYER_ID,
            SOURCE.PLAYER_MOUNTING_DSC,
            SOURCE.PLAYER_POSITION_DSC,
            SOURCE.PLAYER_TYPE_DSC,
            SOURCE.DEVICE_TZ,
            SOURCE.SOURCE_APPLICATION_CD,
            SOURCE.DW_CREATE_TS_INSERT,
            CURRENT_TIMESTAMP(),
            SOURCE.JOB_ID
         FROM MEDIA_PLAYER_RETAIL_STORE_ZONE_PLAYER_TEMP SOURCE;

    -- COMMITTING THE TRANSACTION AFTER ALL INSERTS/MERGE IS DONE
    COMMIT TRANSACTION;
    EXCEPTION WHEN ERROR THEN
    -- ROLLBACK THE TRANSACTION INSIDE THE EXCEPTION HANDLER.
    SELECT @@error.message;
    -- Check if the transaction was started before rolling back
    IF transaction_started THEN
        ROLLBACK TRANSACTION;
    END IF;
    RAISE USING message = FORMAT("Error while processing media zone player data: %s.", @@error.message);
END;
END;
