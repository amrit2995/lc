UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_MEDIA_ZONE_PLAYER`
SET DEVICE_TZ = "America/Chicago"
WHERE FACILITY_INTEGRATION_ID = 1806;