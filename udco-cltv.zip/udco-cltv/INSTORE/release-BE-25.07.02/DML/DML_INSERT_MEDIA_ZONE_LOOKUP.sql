INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_ZONE` (
    MEDIA_ZONE_CD,
    MEDIA_ZONE_NM,
    CHECKOUT_IND,
    MEDIA_ZONE_TYPE_CD,
    SOURCE_APPLICATION_CD,
    DW_CREATE_TS,
    DW_LAST_UPDATE_TS,
    JOB_ID
)
VALUES
    ('42', 'Checkout - cashier - register 009', 1, NULL, 'MAID', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), 'DML_SCRIPT_INSERT'),
    ('43', 'Checkout - cashier - register 010', 1, NULL, 'MAID', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), 'DML_SCRIPT_INSERT'),
    ('44', 'Checkout - cashier - register 011', 1, NULL, 'MAID', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), 'DML_SCRIPT_INSERT'),
    ('45', 'Checkout - cashier - register 012', 1, NULL, 'MAID', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), 'DML_SCRIPT_INSERT');