CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CREATIVE` (
    MEDIA_CREATIVE_ID STRING NOT NULL OPTIONS(description="Unique identifier for the creative."),
    MEDIA_CREATIVE_NM STRING NOT NULL OPTIONS(description="It should be the media file name for the advertisement , that is played on the Tv screens/Player Ids, in the zones , in the store"),
    MEDIA_TYPE_CD STRING NOT NULL OPTIONS(description="Type of media file for advertisement to be played in different Zones of store,Example video or image, HTML page etc."),
    MEDIA_CREATIVE_DURATION_TM NUMERIC OPTIONS(description="Duration of the media file in seconds. it represents the length of Advertisement played on Tv Screens in each Zone of a store."),
    MEDIA_FILE_DIMENSION_CD STRING OPTIONS(description="Dimension of the media files(Related to the aspect ratio of the screen)"),
    UPC_NBR ARRAY<STRING> OPTIONS(description="UPC code of each product for the ad was played, should be tied with creative."),
    CREATIVE_LAST_MODIFIED_TS TIMESTAMP NOT NULL OPTIONS(description="Last modified time stamp of the creative object in vendor application."),
    DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
    SOURCE_APPLICATION_CD STRING NOT NULL OPTIONS(description="Source Application Code for the Campaign Target"),
    JOB_ID STRING NOT NULL OPTIONS(description="Job ID which is used to identify the job that created this record.")
)
OPTIONS (
    description="This table manages all the advertising content - videos, images, interactive displays, and other media that customers will see. It stores technical details like file names, media types, duration, dimensions, file size, and creation dates. Each creative asset is linked to specific campaigns. But it May not be linked with Line item. as a capaign may not have line item associated but have direct relation ship to Creative Id",    
    labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
);