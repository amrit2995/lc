CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_INSTORE_MEDIA_CREATIVE_DETAILS_INSERT_RAW_DATA`(job_id STRING)
BEGIN
    DECLARE project_id STRING;
    DECLARE refined_dataset STRING;
    DECLARE creative_raw_data_stg_table STRING;
    DECLARE creative_raw_data_table STRING;
    DECLARE sql_string STRING;
    DECLARE record_count INT64;
    DECLARE current_job_id STRING;

    -- Set variable values
    SET project_id = 'gcp-abs-udco-bq-<<ENV>>-prj-01';
    SET refined_dataset = 'udco_ds_cltv_refined';
    SET creative_raw_data_stg_table = 'MEDIA_CREATIVE_DETAILS_STG';
    SET creative_raw_data_table = 'MEDIA_CREATIVE_DETAILS';
    SET current_job_id = job_id;

    -- Check if the table has records for the given job_id
    EXECUTE IMMEDIATE FORMAT("""
        SELECT COUNT(1)
        FROM `%s.%s.%s`
        WHERE JOB_ID = '%s'
    """, project_id, refined_dataset, creative_raw_data_table, current_job_id)
    INTO record_count;
    -- If no records exist for the job_id, proceed with the insert
    IF record_count = 0 THEN
        SET sql_string = """
            INSERT INTO `""" || project_id || "." || refined_dataset || "." || creative_raw_data_table || """` (
                MEDIA_CREATIVE_ID,
                MEDIA_CREATIVE_NM,
                MEDIA_TYPE_CD,
                MEDIA_CREATIVE_DURATION_TM,
                UPC_NBR,
                CREATIVE_LAST_MODIFIED_TS,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
               )
            SELECT
                CREATIVE_ID,
                CREATIVE,
                MEDIA_TYPE,
                DURATION,
                UPC,
                LAST_MODIFIED_TIMESTAMP,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                `""" || project_id || "." || refined_dataset || "." || creative_raw_data_stg_table || """`
        """;
        EXECUTE IMMEDIATE sql_string;
    END IF;
END;