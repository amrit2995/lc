CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_INSTORE_MEDIA_CREATIVE_DETAILS_VALIDATE_AND_INSERT_DATA`(job_id STRING)
BEGIN

--  Steps:
    --  a.  Do the validation on the records in staging table.
    --      (this staging table will only contain delta records)
    --  b.  Insert valid data into valid data table.
    --  c.  Insert invalid data into invalid data table
    DECLARE current_job_id STRING;
    DECLARE record_count INT64;
    -- Set variable values
    SET current_job_id = job_id;


    ---------------------------Start of validation-------------------------------------------
    -- Below query is responsible for doing the below validations
    -- 1. null/empty check for the required columns
    -- 2. Duplicate check based on CAMPAIGN_ID
    -- 3. UPC validation
    -- 4. Last modified timestamp validation    
 
        
     CREATE TEMP TABLE CREATIVE_METADATA_WITH_VALIDATION_STATUS AS
        WITH
        -- CTE 1: Extract the raw data 
        SOURCE_DATA AS (
            SELECT
                CREATIVE_ID,
                CREATIVE,
                MEDIA_TYPE,
                DURATION,
                UPC,
                LAST_MODIFIED_TIMESTAMP,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID 
            FROM 
                `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.MEDIA_CREATIVE_DETAILS_STG`
        ),
        -- CTE 2: Perform null/empty validations and UPC check
        NULL_CHECK_VALIDATION AS (
            SELECT
                *,
                CASE
                    WHEN CREATIVE_ID IS NULL OR TRIM(CREATIVE_ID) = '' THEN 'CREATIVE_ID is null/empty;'
                    ELSE ''
                END AS CreativeIdValidationError,
                CASE
                    WHEN CREATIVE IS NULL OR TRIM(CREATIVE) = '' THEN ' CREATIVE is null/empty;'
                    ELSE ''
                END AS CreativeValidationError,
                CASE
                    WHEN MEDIA_TYPE IS NULL OR TRIM(MEDIA_TYPE) = '' THEN ' MEDIA_TYPE is null/empty;'
                    ELSE ''
                END AS MediaTypeValidationError,
                CASE
                    WHEN DURATION IS NOT NULL AND TRIM(DURATION) != '' AND SAFE_CAST(TRIM(DURATION) AS NUMERIC) IS NULL THEN ' DURATION is not a number;'
                    ELSE ''
                END AS DurationValidationError,
                -- CASE
                --     WHEN UPC IS NULL OR TRIM(UPC) = '' THEN ' UPC is null/empty;'
                --     ELSE ''
                -- END AS UpcNullValidationError,
                CASE
                    WHEN SAFE_CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) IS NULL THEN ' LAST_MODIFIED_TIMESTAMP is in incorrect format or null/empty;'
                    ELSE ''
                END AS LastModifiedTimestampInvalidError
            FROM 
                SOURCE_DATA
        ),

        -- CTE 3: Validate timestamp fields
        TIMESTAMP_VALIDATION AS (
            SELECT
                *,
                CASE
                    WHEN SAFE_CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) > CURRENT_TIMESTAMP() THEN ' LAST_MODIFIED_TIMESTAMP is a future timestamp;'
                    ELSE ''
                END AS LastModifiedTimestampFutureError
            FROM 
                NULL_CHECK_VALIDATION
        ),
    -- CTE 4: Perform date/timestamp fields' validations
    LOOKUP_VALIDATION AS (
        SELECT *  FROM (
            SELECT
                NCV.CREATIVE_ID,
                NCV.CREATIVE,
                NCV.MEDIA_TYPE,
                NCV.DURATION,
                NCV.UPC,
                NCV.LAST_MODIFIED_TIMESTAMP,
                NCV.DW_FILE_PATH,
                NCV.DW_CREATE_TS,
                NCV.SOURCE_APPLICATION_CD,
                NCV.JOB_ID,
                NCV.CreativeIdValidationError,
                NCV.CreativeValidationError,
                NCV.MediaTypeValidationError,
                NCV.DurationValidationError,
                -- NCV.UpcNullValidationError,
                NCV.LastModifiedTimestampInvalidError,
                NCV.LastModifiedTimestampFutureError,
                CASE
                    WHEN MC.CREATIVE_LAST_MODIFIED_TS IS NOT NULL AND SAFE_CAST(MC.CREATIVE_LAST_MODIFIED_TS AS TIMESTAMP) > SAFE_CAST(TRIM(NCV.LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) THEN 'Creative Last Modified timestamp is less than existing data;'
                    ELSE ''
                END AS MediaCreativeLastModifiedTimestampError
            FROM
                TIMESTAMP_VALIDATION NCV
                LEFT JOIN `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CREATIVE` MC
                    ON MC.MEDIA_CREATIVE_ID = NCV.CREATIVE_ID
        )        
    ),
        -- CTE 5: Combine all validation errors into a single column and duplicate check
        COMBINED_VALIDATION AS (
            SELECT  
                CREATIVE_ID,
                CREATIVE,
                MEDIA_TYPE,
                DURATION,
                UPC,
                LAST_MODIFIED_TIMESTAMP,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID,
                CONCAT(
                    CreativeIdValidationError,
                    CreativeValidationError,
                    MediaTypeValidationError,
                    DurationValidationError,
                    -- UpcNullValidationError,
                    LastModifiedTimestampInvalidError,
                    LastModifiedTimestampFutureError,
                    MediaCreativeLastModifiedTimestampError
                     ) AS ERR_DESC,
                ROW_NUMBER() OVER (
                    PARTITION BY
                        TRIM(CREATIVE_ID)
                    ORDER BY
                        SAFE_CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) DESC
                ) AS RN
            FROM 
                LOOKUP_VALIDATION
        )
        SELECT 
             CREATIVE_ID AS MEDIA_CREATIVE_ID,
             CREATIVE AS MEDIA_CREATIVE_NM,
             MEDIA_TYPE AS MEDIA_TYPE_CD,
             DURATION AS MEDIA_CREATIVE_DURATION_TM,
             UPC,
             LAST_MODIFIED_TIMESTAMP AS CREATIVE_LAST_MODIFIED_TS,
             DW_FILE_PATH,
             DW_CREATE_TS,
             SOURCE_APPLICATION_CD,
             JOB_ID,
             IF(RN > 1, CONCAT(ERR_DESC, ' Duplicate record for same CREATIVE_ID;'), ERR_DESC) AS ERR_DESC
        FROM
            COMBINED_VALIDATION;

    
    ---------------------------------------End of validation--------------------------
    -- Upsert valid data into target table
        MERGE
            `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CREATIVE` T
        USING(
            SELECT
                FVS.MEDIA_CREATIVE_ID,
                FVS.MEDIA_CREATIVE_NM,
                FVS.MEDIA_TYPE_CD,
                FVS.MEDIA_CREATIVE_DURATION_TM,
                FVS.UPC,
                FVS.CREATIVE_LAST_MODIFIED_TS,
                FVS.DW_CREATE_TS,
                FVS.SOURCE_APPLICATION_CD,
                FVS.JOB_ID
            FROM
                CREATIVE_METADATA_WITH_VALIDATION_STATUS FVS
            WHERE
                TRIM(FVS.ERR_DESC) = ''
        ) S 
        ON
            T.MEDIA_CREATIVE_ID = TRIM(S.MEDIA_CREATIVE_ID)
        WHEN MATCHED THEN
            UPDATE SET
                T.MEDIA_CREATIVE_NM = TRIM(S.MEDIA_CREATIVE_NM),
                T.MEDIA_TYPE_CD = TRIM(S.MEDIA_TYPE_CD),
                T.MEDIA_CREATIVE_DURATION_TM = CAST(TRIM(S.MEDIA_CREATIVE_DURATION_TM) as NUMERIC),
                T.UPC_NBR = SPLIT(S.UPC, ';'),
                T.CREATIVE_LAST_MODIFIED_TS = CAST(TRIM(S.CREATIVE_LAST_MODIFIED_TS) AS TIMESTAMP),
                -- DW_CREATE_TS is not updated (This should be the TIMESTAMP when it is first inserted/created)
                T.DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP(),
                T.SOURCE_APPLICATION_CD = S.SOURCE_APPLICATION_CD,
                T.JOB_ID = S.JOB_ID
        WHEN NOT MATCHED THEN
            INSERT (
                MEDIA_CREATIVE_ID,
                MEDIA_CREATIVE_NM,
                MEDIA_TYPE_CD,
                MEDIA_CREATIVE_DURATION_TM,
                MEDIA_FILE_DIMENSION_CD,
                UPC_NBR,
                CREATIVE_LAST_MODIFIED_TS,
                DW_CREATE_TS,
                DW_LAST_UPDATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            )
            VALUES (
                TRIM(S.MEDIA_CREATIVE_ID),
                TRIM(S.MEDIA_CREATIVE_NM),
                TRIM(S.MEDIA_TYPE_CD),
                CAST(TRIM(S.MEDIA_CREATIVE_DURATION_TM) as NUMERIC),
                NULL,
                SPLIT(S.UPC, ';'),
                CAST(TRIM(S.CREATIVE_LAST_MODIFIED_TS) AS TIMESTAMP),
                S.DW_CREATE_TS,
                CURRENT_TIMESTAMP(),
                S.SOURCE_APPLICATION_CD,
                S.JOB_ID
        );

    -- Insert invalid records into table
    -- Check if the table has records for the given job_id
    SET record_count = (
        SELECT COUNT(1)
        FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.MEDIA_CREATIVE_DETAILS_INVALID`
        WHERE JOB_ID = current_job_id);

    -- If no records exist for the job_id, proceed with the insert
    IF record_count = 0 THEN
            INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.MEDIA_CREATIVE_DETAILS_INVALID` (
                MEDIA_CREATIVE_ID,
                MEDIA_CREATIVE_NM,
                MEDIA_TYPE_CD,
                MEDIA_CREATIVE_DURATION_TM,
                UPC_NBR,
                CREATIVE_LAST_MODIFIED_TS,
                ERR_MSG,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            )
            SELECT  
                FVS.MEDIA_CREATIVE_ID,
                FVS.MEDIA_CREATIVE_NM,
                FVS.MEDIA_TYPE_CD,
                FVS.MEDIA_CREATIVE_DURATION_TM,
                FVS.UPC AS UPC_NBR,
                FVS.CREATIVE_LAST_MODIFIED_TS,
                FVS.ERR_DESC,
                FVS.DW_FILE_PATH,
                FVS.DW_CREATE_TS,
                FVS.SOURCE_APPLICATION_CD,
                FVS.JOB_ID 
            FROM
                CREATIVE_METADATA_WITH_VALIDATION_STATUS FVS
            WHERE
                TRIM(FVS.ERR_DESC) != '';
    END IF;
END;