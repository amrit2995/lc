CREATE OR REPLACE VIEW `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_cltv.CAMPAIGN_ADVERTISER`
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]) 
as  
SELECT * FROM  `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CAMPAIGN_ADVERTISER`;