CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CAMPAIGN_LINE_ITEM` (
    CAMPAIGN_LINE_ITEM_ID STRING NOT NULL OPTIONS(description="Unique line item id under a campaign. A camapign may or may not have Line item. Also a camapign can have multiple line items. Line items can have multiple creatives associated to it."),
    MEDIA_CAMPAIGN_ID STRING NOT NULL OPTIONS(description="Unique line item id under a campaign"),
    CAMPAIGN_LINE_ITEM_NM STRING NOT NULL OPTIONS(description="Line item name under a campaign"),
    CAMPAIGN_LINE_ITEM_START_DT DATE NOT NULL OPTIONS(description="Start date of the line item"),
    CAMPAIGN_LINE_ITEM_END_DT DATE NOT NULL OPTIONS(description="End date of the line item"),
    CAMPAIGN_LINE_ITEM_CPM_AMT NUMERIC NOT NULL OPTIONS(description="CPM (Cost Per Mile) at line item level."),
    CAMPAIGN_LINE_ITEM_BUDGET_AMT NUMERIC NOT NULL OPTIONS(description="Budget at line item level."),
    LINE_ITEM_BUDGET_GOAL_TYPE STRING NOT NULL OPTIONS(description="Budget goal type for the line item."),
    MEDIA_HUB_TACTIC_ID STRING NOT NULL OPTIONS(description="If a campaign is tied to have a line item then a Hub Tectic Id is created in media Briefs.Hub tactic id is an L2 level id from OMS.(Note: For each line item the Ad OPs team will manually enter  the key value pair to into Description/Notes data field in SC/AMP)"),
    LINE_ITEM_CREATED_TS TIMESTAMP NOT NULL OPTIONS(description="Created timestamp of the campaign object in vendor application."),
    LINE_ITEM_LAST_MODIFIED_BY STRING NOT NULL OPTIONS(description="username of the last modified"),
    LINE_ITEM_LAST_MODIFIED_TS TIMESTAMP NOT NULL OPTIONS(description="Last modified timestamp of the campaign object in vendor application."),
    DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
    SOURCE_APPLICATION_CD STRING NOT NULL OPTIONS(description="Source Application Code for the Campaign Target"),
    JOB_ID STRING NOT NULL OPTIONS(description="Job ID which is used to identify the job that created this record.")
)
OPTIONS (
    description="Large advertising campaigns are typically broken down into smaller, more manageable pieces called line items. For example, a holiday campaign might have separate line items for different product categories, store locations, or time periods. Each line item has its own budget, start and end dates, cost-per-thousand-impressions (CPM) pricing, and performance targets.",
    labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
);