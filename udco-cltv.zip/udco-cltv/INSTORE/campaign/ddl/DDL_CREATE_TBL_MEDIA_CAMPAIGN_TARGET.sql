CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CAMPAIGN_TARGET` (
    CAMPAIGN_TARGET_ID STRING NOT NULL OPTIONS(description="Unique key for Campaign Id + Campaign Target"),
    MEDIA_CAMPAIGN_ID STRING NOT NULL OPTIONS(description="Unique identifier for the campaign."),
    CAMPAIGN_TARGET ARRAY<STRING> OPTIONS(description="List of Campaign Targets for the Campaign"),
    CAMPAIGN_TARGET_CD STRING OPTIONS(description="List of Campaign Target Codes for the Campaign"),
    CAMPAIGN_TARGET_REF_ID STRING OPTIONS(description="List of Campaign Target Reference Ids for the Campaign"),
    DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
    SOURCE_APPLICATION_CD STRING NOT NULL OPTIONS(description="Source Application Code for the Campaign Target"),
    JOB_ID STRING NOT NULL OPTIONS(description="Job ID which is used to identify the job that created this record."),
)
OPTIONS (
    description="This connection table links specific campaigns to their targeting criteria. A single campaign might target multiple customer segments simultaneously, and this table manages those relationships. It ensures ads are shown to the right audiences at the right times.",
    labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
);