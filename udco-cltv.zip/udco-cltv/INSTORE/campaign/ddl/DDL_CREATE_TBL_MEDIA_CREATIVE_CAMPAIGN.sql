CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CREATIVE_CAMPAIGN` (
    MEDIA_CAMPAIGN_ID STRING NOT NULL OPTIONS(description="Unique identifier for the campaign."),
    CAMPAIGN_LINE_ITEM_ID STRING NOT NULL OPTIONS(description="Unique line item id under a campaign. A camapign may or may not have Line item. Also a camapign can have multiple line items. Line items can have multiple creatives associated to it."),
    MEDIA_CREATIVE_ID STRING NOT NULL OPTIONS(description="Unique identifier for the creative."),
    PLATFORM_ID STRING NOT NULL OPTIONS(description="Platform where the creative is played."),
    MEDIA_PARTNER_ID STRING NOT NULL OPTIONS(description="Partner system where the creative was created."),
    DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
    SOURCE_APPLICATION_CD STRING NOT NULL OPTIONS(description="Source Application Code for the Campaign Target"),
    JOB_ID STRING NOT NULL OPTIONS(description="Job ID which is used to identify the job that created this record.")
)
OPTIONS (
    description="This connection table links specific campaigns to their line items and creatives",
    labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
);