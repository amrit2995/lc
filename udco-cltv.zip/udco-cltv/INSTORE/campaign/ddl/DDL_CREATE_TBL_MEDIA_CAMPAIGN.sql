CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CAMPAIGN` (
    MEDIA_CAMPAIGN_ID STRING NOT NULL OPTIONS(description="Unique identifier for the campaign."),
    CAMPAIGN_ADVERTISER_ID STRING NOT NULL OPTIONS(description="Advertiser name, same as CPG in vendor CMS"),
    CAMPAIGN_OPPORTUNITY_ID STRING NOT NULL OPTIONS(description="Opportunity same as CRM"),
    MEDIA_CAMPAIGN_NM STRING NOT NULL OPTIONS(description="Name of a campaign played in the store."),
    MEDIA_CAMPAIGN_TYPE_CD STRING NOT NULL OPTIONS(description="Type of the campaign(this is a constant value and should be 'In Store Digital')"),
    MEDIA_CAMPAIGN_STATUS_CD STRING NOT NULL OPTIONS(description="Status of a campaign"),
    MEDIA_CAMPAIGN_START_DT DATE NOT NULL OPTIONS(description="Date in which campaign started in the CMS"),
    MEDIA_CAMPAIGN_END_DT DATE NOT NULL OPTIONS(description="Date in which campaign ended in the CMS"),
    MEDIA_HUB_ID STRING NOT NULL OPTIONS(description="Hub ID created in OMS."),
    CAMPAIGN_CREATED_TS TIMESTAMP NOT NULL OPTIONS(description="Created timestamp of the campaign object in vendor application."),
    CAMPAIGN_LAST_MODIFIED_BY STRING NOT NULL OPTIONS(description="username of the last modified"),
    CAMPAIGN_LAST_MODIFIED_TS TIMESTAMP NOT NULL OPTIONS(description="Created timestamp of the campaign object in vendor application."),
    DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
    SOURCE_APPLICATION_CD STRING NOT NULL OPTIONS(description="Source Application Code for the Campaign Target"),
    JOB_ID STRING NOT NULL OPTIONS(description="Job ID which is used to identify the job that created this record.")
)
OPTIONS (
    description="This is the central table for all advertising campaigns. Once an opportunity converts to actual business, a full campaign is created here. It includes comprehensive details like the campaign name, type (video, display, interactive), current status (planning, active, paused, completed), start and end dates, creation timestamps, and modification history. Each campaign is linked back to a specific advertiser and opportunity..",    
    labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]
);