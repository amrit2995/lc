CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_INSTORE_MEDIA_CAMPAIGN_DETAILS_VALIDATE_AND_INSERT_DATA`(job_id STRING)
BEGIN
  -- Below variable is used to track if the transaction has started or not.   
  DECLARE transaction_started BOOL;


--  Steps:
    --  a.  Do the validation on the records in staging table.
    --      (this staging table will only contain delta records)
    --  b.  Insert valid data into valid data table.
    --  c.  Insert invalid data into invalid data table
    DECLARE current_job_id STRING;
    DECLARE record_count INT64;
    DECLARE PARTNER_ID STRING;
    DECLARE PLATFORM_ID STRING;

    -- Set variable values
    SET current_job_id = job_id;
    -- Set transaction_started to FALSE initially

    SET transaction_started = FALSE;
    -- Assign PARTNER_ID
    SET PARTNER_ID = (
        SELECT MEDIA_PARTNER_ID
        FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PARTNER`
        WHERE MEDIA_PARTNER_NM = 'STRATACACHE'
        LIMIT 1
    );

    -- Assign PLATFORM_ID
    SET PLATFORM_ID = (
        SELECT PLATFORM_ID
        FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_PLATFORM`
        WHERE PLATFORM_NM = 'Display'
        LIMIT 1
    );
    ---------------------------Start of validation-------------------------------------------
    -- Below query is responsible for doing the below validations
    -- 1. null/empty check for the required columns
    -- 2. Duplicate check based on CAMPAIGN_ID

    --TODO: TEMPORARILY COMMENTED OUT CHANGES RELATED TO CAMPAIGN TARGET VALIDATIONS AND RELATED FUNCTIONALITIES. IT WILL BE 
    --UPDATE ONCE WE GET ACCESS TO PMP AND UNDERSTAND MORE ABOUT THE REQUIREMENT

    CREATE TEMP TABLE CAMPAIGN_DETAILS_WITH_VALIDATION_STATUS AS
    WITH
    -- CTE 1: Extract the raw data
    SOURCE_DATA AS (
        SELECT
            CAMPAIGN_ID,
            CREATIVE_ID,
            -- CAMPAIGN_NAME,
	    NAME AS CAMPAIGN_NAME,
            CAMPAIGN_START_DATE,
            CAMPAIGN_END_DATE,
            -- CAMPAIGN_TARGET,
            CAMPAIGN_STATUS,
            CAMPAIGN_DESCRIPTION,
            LINE_ITEM_ID,
            LINE_ITEM_NAME,
            LINE_ITEM_START_DATE,
            LINE_ITEM_END_DATE,
            LINE_ITEM_DESCRIPTION,
            LINE_ITEM_CPM,
            LINE_ITEM_BUDGET,
            LINE_ITEM_BUDGET_GOAL_TYPE,
            ADVERTISER,
            CREATED_TIMESTAMP,
            LAST_MODIFIED_BY,
            LAST_MODIFIED_TIMESTAMP,
            DW_FILE_PATH,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID,
            PARTNER_ID,
            PLATFORM_ID
        FROM
            `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.MEDIA_CAMPAIGN_DETAILS_STG` STG
	    LEFT OUTER JOIN 
            (select 
             Opportunity__c as OMS_Opportunity_ID,
             Name from 
             `<<EMDG_PROJECT>>.<<MOM_DATASET>>.MediaCampaign`
            where IsDeleted = False
	    QUALIFY ROW_NUMBER() OVER (PARTITION BY Opportunity__c ORDER BY  _insertRowUtcTs DESC, Id DESC) = 1
            ) OMS_CAMPAIGN
            ON UPPER(OMS_CAMPAIGN.OMS_Opportunity_ID) = UPPER(SPLIT( SPLIT(CAMPAIGN_DESCRIPTION, '|')[SAFE_OFFSET(1)],'=')[SAFE_OFFSET(1)])
        ),
    -- CTE 2: Perform null/empty validations
    NULL_CHECK_VALIDATION AS (
        SELECT
            *,
            CASE
                WHEN SAFE_CAST(TRIM(CAMPAIGN_ID) AS STRING) IS NULL THEN 'CAMPAIGN_ID is null/empty or not a String;'
                ELSE ''
            END AS CampaignIdValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(CREATIVE_ID) AS STRING) IS NULL THEN ' CREATIVE_ID is null/empty or not a Integer number;'
                ELSE ''
            END AS CreativeIdValidationError,
            CASE
                WHEN CAMPAIGN_NAME IS NULL OR TRIM(CAMPAIGN_NAME) = '' THEN ' CAMPAIGN_NAME is null/empty or Opportunity_Id missing in OMS;'
                ELSE ''
            END AS CampaignNameValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(CAMPAIGN_START_DATE) AS DATE) IS NULL THEN ' CAMPAIGN_START_DATE is in incorrect format or null/empty;'
                ELSE ''
            END AS CampaignStartDateValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(CAMPAIGN_END_DATE) AS DATE) IS NULL THEN ' CAMPAIGN_END_DATE is in incorrect format or null/empty;'
                ELSE ''
            END AS CampaignEndDateValidationError,
            -- CASE
            --     WHEN CAMPAIGN_TARGET IS NULL OR TRIM(CAMPAIGN_TARGET) = '' THEN ' CAMPAIGN_TARGET is null/empty;'
            --     ELSE ''
            -- END AS CampaignTargetValidationError,
            CASE
                WHEN CAMPAIGN_STATUS IS NULL OR TRIM(CAMPAIGN_STATUS) = '' THEN ' CAMPAIGN_STATUS is null/empty;'
                ELSE ''
            END AS CampaignStatusValidationError,
            CASE
                WHEN CAMPAIGN_DESCRIPTION IS NULL OR TRIM(CAMPAIGN_DESCRIPTION) = '' THEN ' CAMPAIGN_DESCRIPTION is null/empty;'
                ELSE ''
            END AS CampaignDescriptionValidationError,
            CASE 
                WHEN NOT REGEXP_CONTAINS(CAMPAIGN_DESCRIPTION, r'(?i)HUB_CAMPAIGN_ID=[^|]+\|.*OPPORTUNITY_ID=[^|]+|OPPORTUNITY_ID=[^|]+\|.*HUB_CAMPAIGN_ID=[^|]+')
                      OR REGEXP_CONTAINS(CAMPAIGN_DESCRIPTION, r'(?i)HUB_CAMPAIGN_ID=[^|]*(HUB_CAMPAIGN_ID|OPPORTUNITY_ID)|OPPORTUNITY_ID=[^|]*(HUB_CAMPAIGN_ID|OPPORTUNITY_ID)') 
                      THEN 'Invalid CAMPAIGN_DESCRIPTION format;'
                ELSE ''
            END AS CampaignDescriptionFormatValidationError,
            CASE
                WHEN LENGTH(TRIM(REGEXP_EXTRACT(CAMPAIGN_DESCRIPTION, r'(?i)OPPORTUNITY_ID=([^|]+)'))) != 18 
                    AND REGEXP_EXTRACT(CAMPAIGN_DESCRIPTION, r'(?i)OPPORTUNITY_ID=([^|]+)') IS NOT NULL
                    THEN ' CAMPAIGN_OPPORTUNITY_ID must be 18 characters;'
                ELSE ''
            END AS CampaignOpportunityIdLengthValidationError,
            CASE
                WHEN LINE_ITEM_ID IS NULL OR TRIM(LINE_ITEM_ID) = '' THEN ' LINE_ITEM_ID is null/empty;'
                ELSE ''
            END AS LineItemIdValidationError,
            CASE
                WHEN LINE_ITEM_NAME IS NULL OR TRIM(LINE_ITEM_NAME) = '' THEN ' LINE_ITEM_NAME is null/empty;'
                ELSE ''
            END AS LineItemNameValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(LINE_ITEM_START_DATE) AS DATE) IS NULL THEN ' LINE_ITEM_START_DATE is in incorrect format or null/empty;'
                ELSE ''
            END AS LineItemStartDateValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(LINE_ITEM_END_DATE) AS DATE) IS NULL THEN ' LINE_ITEM_END_DATE is in incorrect format or null/empty;'
                ELSE ''
            END AS LineItemEndDateValidationError,
            CASE
                WHEN LINE_ITEM_DESCRIPTION IS NULL OR TRIM(LINE_ITEM_DESCRIPTION) = '' THEN ' LINE_ITEM_DESCRIPTION is null/empty;'
                ELSE ''
            END AS LineItemDescriptionValidationError,
            CASE
                WHEN NOT REGEXP_CONTAINS(LINE_ITEM_DESCRIPTION, r'(?i)HUB_TACTIC_ID=([^|]+)') OR
                         REGEXP_CONTAINS(LINE_ITEM_DESCRIPTION, r'(?i)HUB_TACTIC_ID=[^|]*HUB_TACTIC_ID') 
                        THEN 'Invalid LINE_ITEM_DESCRIPTION format;'
                ELSE ''
            END AS LineItemDescriptionFormatValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(LINE_ITEM_CPM) AS NUMERIC) IS NULL THEN ' LINE_ITEM_CPM is null/empty or not a number;'
                ELSE ''
            END AS LineItemCpmValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(LINE_ITEM_BUDGET) AS NUMERIC) IS NULL THEN ' LINE_ITEM_BUDGET is null/empty or not a number;'
                ELSE ''
            END AS LineItemBudgetValidationError,
            CASE
                WHEN LINE_ITEM_BUDGET_GOAL_TYPE IS NULL OR TRIM(LINE_ITEM_BUDGET_GOAL_TYPE) = '' THEN ' LINE_ITEM_BUDGET_GOAL_TYPE is null/empty;'
                ELSE ''
            END AS LineItemBudgetTypeValidationError,
            CASE
                WHEN ADVERTISER IS NULL OR TRIM(ADVERTISER) = '' THEN ' ADVERTISER is null/empty;'
                ELSE ''
            END AS AdvertiserValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(CREATED_TIMESTAMP) AS TIMESTAMP) IS NULL THEN ' CREATED_TIMESTAMP is in incorrect format or null/empty;'
                ELSE ''
            END AS  CreatedTimestampValidationError,
            CASE
                WHEN LAST_MODIFIED_BY IS NULL OR TRIM(LAST_MODIFIED_BY) = '' THEN ' LAST_MODIFIED_BY is null/empty;'
                ELSE ''
            END AS LastModifiedByValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) IS NULL THEN ' LAST_MODIFIED_TIMESTAMP is in incorrect format or null/empty;'
                ELSE ''
            END AS LastModifiedTimestampValidationError
        FROM
            SOURCE_DATA
    ),
    -- CTE 3: Perform date/timestamp fields' validations
    -- Campaign Start Date cannot be greater than Campaign End Date
    -- Line Item Start Date cannot be greater than Line Item End Date
    -- Created Timestamp and Last Modified Timestamp cannot be in the future
    -- Line Item Start Date cannot be before Campaign Start Date
    -- Line Item End Date cannot be after Campaign End Date
    TIMESTAMP_VALIDATION AS (
        SELECT
            *,
            CASE
                WHEN SAFE_CAST(TRIM(CAMPAIGN_START_DATE) AS DATE) > SAFE_CAST(TRIM(CAMPAIGN_END_DATE) AS DATE) THEN ' CAMPAIGN_START_DATE is after CAMPAIGN_END_DATE;'
                ELSE ''
            END AS CampaignDateRangeValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(LINE_ITEM_START_DATE) AS DATE) > SAFE_CAST(TRIM(LINE_ITEM_END_DATE) AS DATE) THEN ' LINE_ITEM_START_DATE is after LINE_ITEM_END_DATE;'
                ELSE ''
            END AS LineItemDateRangeValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(CREATED_TIMESTAMP) AS TIMESTAMP) > CURRENT_TIMESTAMP() THEN ' CREATED_TIMESTAMP is future timestamp;'
                ELSE ''
            END AS CreatedTimestampFutureValidationError,
            CASE
                WHEN SAFE_CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) > CURRENT_TIMESTAMP() THEN ' LAST_MODIFIED_TIMESTAMP is future timestamp;'
                ELSE ''
            END AS LastModifiedTimestampFutureValidationError,
            CASE 
                WHEN (CampaignStartDateValidationError = '' AND LineItemStartDateValidationError = '' 
                    AND SAFE_CAST(TRIM(CAMPAIGN_START_DATE) AS DATE) > SAFE_CAST(TRIM(LINE_ITEM_START_DATE) AS DATE)) THEN ' LINE_ITEM_START_DATE is before CAMPAIGN_START_DATE;'
            ELSE ''
            END AS LineItemStartDateBeforeCampaignStartDateError,
            CASE 
                WHEN (CampaignEndDateValidationError = '' AND LineItemEndDateValidationError = '' 
                    AND SAFE_CAST(TRIM(CAMPAIGN_END_DATE) AS DATE) < SAFE_CAST(TRIM(LINE_ITEM_END_DATE) AS DATE)) THEN ' LINE_ITEM_END_DATE is after CAMPAIGN_END_DATE;'
            ELSE ''
            END AS LineItemEndDateAfterCampaignEndDateError
        FROM
            NULL_CHECK_VALIDATION S
    ),
    -- CTE 3: Perform date/timestamp fields' validations
    LOOKUP_VALIDATION AS (
        SELECT
        NCV.CAMPAIGN_ID,
        NCV.CREATIVE_ID,
        NCV.CAMPAIGN_NAME,
        NCV.CAMPAIGN_START_DATE,
        NCV.CAMPAIGN_END_DATE,
       -- NCV.CAMPAIGN_TARGET,
        NCV.CAMPAIGN_STATUS,
        NCV.CAMPAIGN_DESCRIPTION,
        NCV.LINE_ITEM_ID,
        NCV.LINE_ITEM_NAME,
        NCV.LINE_ITEM_START_DATE,
        NCV.LINE_ITEM_END_DATE,
        NCV.LINE_ITEM_DESCRIPTION,
        NCV.LINE_ITEM_CPM,
        NCV.LINE_ITEM_BUDGET,
        NCV.LINE_ITEM_BUDGET_GOAL_TYPE,
        NCV.ADVERTISER,
        NCV.CREATED_TIMESTAMP,
        NCV.LAST_MODIFIED_BY,
        NCV.LAST_MODIFIED_TIMESTAMP,
        NCV.DW_FILE_PATH,
        NCV.DW_CREATE_TS,
        NCV.SOURCE_APPLICATION_CD,
        NCV.JOB_ID,
        NCV.PARTNER_ID,
        NCV.PLATFORM_ID,
        CampaignIdValidationError,
        CreativeIdValidationError,
        CampaignNameValidationError,
        CampaignStartDateValidationError,
        CampaignEndDateValidationError,
        -- CampaignTargetValidationError,
        CampaignStatusValidationError,
        CampaignDescriptionValidationError,
        CampaignDescriptionFormatValidationError,
        CampaignOpportunityIdLengthValidationError,
        LineItemIdValidationError,
        LineItemNameValidationError,
        LineItemStartDateValidationError,
        LineItemEndDateValidationError,
        LineItemStartDateBeforeCampaignStartDateError,
        LineItemEndDateAfterCampaignEndDateError,
        LineItemDescriptionValidationError,
        LineItemDescriptionFormatValidationError,
        LineItemCpmValidationError,
        LineItemBudgetValidationError,
        LineItemBudgetTypeValidationError,
        AdvertiserValidationError,
        CreatedTimestampValidationError,
        LastModifiedByValidationError,
        LastModifiedTimestampValidationError,
        CampaignDateRangeValidationError,
        LineItemDateRangeValidationError,
        CreatedTimestampFutureValidationError,
        LastModifiedTimestampFutureValidationError,
        -- Check if the Media Campaign Last Modified Timestamp from source file is greater than the existing data in UDP
        CASE
            WHEN MC.CAMPAIGN_LAST_MODIFIED_TS IS NOT NULL AND SAFE_CAST(MC.CAMPAIGN_LAST_MODIFIED_TS AS TIMESTAMP) > SAFE_CAST(TRIM(NCV.LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) THEN 'Campaign Last Modified timestamp is less than existing data;'
            ELSE ''
        END AS MediaCampaignLastModifiedTimestampError
        FROM
            TIMESTAMP_VALIDATION NCV 
            LEFT JOIN `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CAMPAIGN` MC
            ON MC.MEDIA_CAMPAIGN_ID = NCV.CAMPAIGN_ID
    ),
    -- CTE 4: Combine all validation errors into a single column and perform duplicate record check
    COMBINED_VALIDATION AS (
        SELECT
            CAMPAIGN_ID,
            CREATIVE_ID,
            CAMPAIGN_NAME,
            CAMPAIGN_START_DATE,
            CAMPAIGN_END_DATE,
            -- CAMPAIGN_TARGET,
            CAMPAIGN_STATUS,
            CAMPAIGN_DESCRIPTION,
            LINE_ITEM_ID,
            LINE_ITEM_NAME,
            LINE_ITEM_START_DATE,
            LINE_ITEM_END_DATE,
            LINE_ITEM_DESCRIPTION,
            LINE_ITEM_CPM,
            LINE_ITEM_BUDGET,
            LINE_ITEM_BUDGET_GOAL_TYPE,
            ADVERTISER,
            CREATED_TIMESTAMP,
            LAST_MODIFIED_BY,
            LAST_MODIFIED_TIMESTAMP,
            DW_FILE_PATH,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID,
            PARTNER_ID,
            PLATFORM_ID,
            CONCAT(
                CampaignIdValidationError,
                CreativeIdValidationError,
                CampaignNameValidationError,
                CampaignStartDateValidationError,
                CampaignEndDateValidationError,
                -- CampaignTargetValidationError,
                CampaignStatusValidationError,
                CampaignDescriptionValidationError,
                CampaignDescriptionFormatValidationError,
                CampaignOpportunityIdLengthValidationError,
                LineItemIdValidationError,
                LineItemNameValidationError,
                LineItemStartDateValidationError,
                LineItemEndDateValidationError,
                LineItemStartDateBeforeCampaignStartDateError,
                LineItemEndDateAfterCampaignEndDateError,
                LineItemDescriptionValidationError,
                LineItemDescriptionFormatValidationError,
                LineItemCpmValidationError,
                LineItemBudgetValidationError,
                LineItemBudgetTypeValidationError,
                AdvertiserValidationError,
                CreatedTimestampValidationError,
                LastModifiedByValidationError,
                LastModifiedTimestampValidationError,
                CampaignDateRangeValidationError,
                LineItemDateRangeValidationError,
                CreatedTimestampFutureValidationError,
                LastModifiedTimestampFutureValidationError,
                MediaCampaignLastModifiedTimestampError
            ) AS ERR_DESC,
            ROW_NUMBER() OVER (
                PARTITION BY
                    TRIM(CAMPAIGN_ID),TRIM(LINE_ITEM_ID),TRIM(CREATIVE_ID)
                ORDER BY
                    SAFE_CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) DESC
            ) AS RN
        FROM
            LOOKUP_VALIDATION
    )
    SELECT
        CAMPAIGN_ID,
        CREATIVE_ID,
        CAMPAIGN_NAME,
        CAMPAIGN_START_DATE,
        CAMPAIGN_END_DATE,
        -- CAMPAIGN_TARGET,
        CAMPAIGN_STATUS,
        CAMPAIGN_DESCRIPTION,
        LINE_ITEM_ID,
        LINE_ITEM_NAME,
        LINE_ITEM_START_DATE,
        LINE_ITEM_END_DATE,
        LINE_ITEM_DESCRIPTION,
        LINE_ITEM_CPM,
        LINE_ITEM_BUDGET,
        LINE_ITEM_BUDGET_GOAL_TYPE,
        ADVERTISER,
        CREATED_TIMESTAMP,
        LAST_MODIFIED_BY,
        LAST_MODIFIED_TIMESTAMP,
        IF(RN > 1, CONCAT(ERR_DESC, 'Duplicate record - More than one record for same CAMPAIGN_ID, CREATIVE_ID, LINE_ITEM_ID;'), ERR_DESC) AS ERR_MSG,
        DW_FILE_PATH,
        DW_CREATE_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID,
        PARTNER_ID,
        PLATFORM_ID
    FROM
        COMBINED_VALIDATION;
    ---------------------------------------End of validation--------------------------

    ---------------------------Temp Table Creations before Transaction----------------
    -- This temp table is primarily used to identify the duplicate records for a specific CAMPAIGN_ID in the source file
    -- Assume if 2 records have same CAMPAIGN_ID but different CAMPAIGN_NAME or DESCRIPTION etc., then the record with
    -- latest LAST_MODIFIED_TIMESTAMP will be considered as valid record.
    -- subsequently this temp table will be used to insert valid data into the MEDIA_CAMPAIGN and CAMPAIGN_ADVERTISER table
    CREATE TEMP TABLE TEMP_TABLE_DUPLICATE_CAMPAIGN_IDENTIFIED AS
        WITH DISTINCT_CAMPAIGN_RECORDS AS (
        SELECT DISTINCT
            CAMPAIGN_ID,
            CAMPAIGN_NAME,
            CAMPAIGN_STATUS,
            CAMPAIGN_DESCRIPTION,
            CAMPAIGN_START_DATE,
            CAMPAIGN_END_DATE,
            ADVERTISER,
            CREATED_TIMESTAMP,
            LAST_MODIFIED_TIMESTAMP,
            LAST_MODIFIED_BY,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID
        FROM
            CAMPAIGN_DETAILS_WITH_VALIDATION_STATUS
        WHERE
            ERR_MSG = ''
        ),
        -- Step 2: Add row numbers for full row duplicates
        DUPLICATE_CAMPAIGN_RECORDS AS (
        SELECT
            T.*,
            ROW_NUMBER() OVER (
            PARTITION BY TRIM(CAMPAIGN_ID)
            ORDER BY SAFE_CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) DESC
            ) AS RN_CAMPAIGN
        FROM DISTINCT_CAMPAIGN_RECORDS T
        )
        -- Step 3: Join and flag
        SELECT
            CAMPAIGN_ID,
            CAMPAIGN_NAME,
            CAMPAIGN_STATUS,
            CAMPAIGN_DESCRIPTION,
            CAMPAIGN_START_DATE,
            CAMPAIGN_END_DATE,
            ADVERTISER,
            CREATED_TIMESTAMP,
            LAST_MODIFIED_TIMESTAMP,
            LAST_MODIFIED_BY,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID,
            IF(RN_CAMPAIGN > 1, 'Duplicate record - More than one record for same CAMPAIGN_ID;', '') AS ERR_MSG
        FROM DUPLICATE_CAMPAIGN_RECORDS;  

    -- This temp table is primarily used to identify the duplicate records for a specific CAMPAIGN_ID and LINE_ITEM_ID in the source file
    -- Assume if 2 records have same CAMPAIGN_ID and LINE_ITEM_ID but different Budget or CPM etc., then the record with
    -- latest LAST_MODIFIED_TIMESTAMP will be considered as valid record.
    -- subsequently this temp table will be used to insert valid data into the MEDIA_CAMPAIGN_LINE_ITEM table
    CREATE TEMP TABLE TEMP_TABLE_DUPLICATE_LINEITEM_IDENTIFIED AS
        WITH DISTINCT_LINEITEM_RECORDS AS (
        SELECT DISTINCT
            LINE_ITEM_ID,
            CAMPAIGN_ID,
            LINE_ITEM_NAME,
            LINE_ITEM_START_DATE,
            LINE_ITEM_END_DATE,
            LINE_ITEM_DESCRIPTION,
            LINE_ITEM_CPM,
            LINE_ITEM_BUDGET,
            LINE_ITEM_BUDGET_GOAL_TYPE,
            CREATED_TIMESTAMP,
            LAST_MODIFIED_BY,
            LAST_MODIFIED_TIMESTAMP,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID
        FROM
            CAMPAIGN_DETAILS_WITH_VALIDATION_STATUS
        WHERE
            ERR_MSG = ''
        ),
        -- Step 2: Add row numbers for full row duplicates
        DUPLICATE_LINEITEM_RECORDS AS (
        SELECT
            T.*,
            ROW_NUMBER() OVER (
            PARTITION BY TRIM(CAMPAIGN_ID),TRIM(LINE_ITEM_ID)
            ORDER BY SAFE_CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) DESC
            ) AS RN_LINEITEM
        FROM DISTINCT_LINEITEM_RECORDS T
        ) 
        -- Step 3: Join and flag
        SELECT
            LINE_ITEM_ID,
            CAMPAIGN_ID,
            LINE_ITEM_NAME,
            LINE_ITEM_START_DATE,
            LINE_ITEM_END_DATE,
            LINE_ITEM_DESCRIPTION,
            LINE_ITEM_CPM,
            LINE_ITEM_BUDGET,
            LINE_ITEM_BUDGET_GOAL_TYPE,
            CREATED_TIMESTAMP,
            LAST_MODIFIED_BY,
            LAST_MODIFIED_TIMESTAMP,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID,
            IF(RN_LINEITEM > 1, 'Duplicate record - More than one record for same CAMPAIGN_ID, LINE_ITEM_ID;', '') AS ERR_MSG
        FROM DUPLICATE_LINEITEM_RECORDS;  

    CREATE TEMP TABLE TEMP_CAMPAIGN_ADVERTISER AS
    -- Step 1: Extract data from target table - CAMPAIGN_ADVERTISER
    WITH BASE_ADVERTISERS AS (
        SELECT DISTINCT
            CAMPAIGN_ADVERTISER_NM,
            CAST(SUBSTR(CAMPAIGN_ADVERTISER_ID, 4) AS INT64) AS SUFFIX
        FROM
            `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CAMPAIGN_ADVERTISER`
    ),
    -- Step 2: Extract only new CAMPAIGN_ADVERTISER_NM from source
    NEW_ADVERTISERS AS (
        SELECT
            *
        FROM (
            SELECT DISTINCT
                TRIM(ADVERTISER) AS CAMPAIGN_ADVERTISER_NM_4M_SOURCE,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                TEMP_TABLE_DUPLICATE_CAMPAIGN_IDENTIFIED
            WHERE
            	ERR_MSG = ''
            ) STG
        LEFT JOIN
            BASE_ADVERTISERS ADV
        ON
            LOWER(TRIM(STG.CAMPAIGN_ADVERTISER_NM_4M_SOURCE)) = LOWER(TRIM(ADV.CAMPAIGN_ADVERTISER_NM))
        WHERE
            ADV.CAMPAIGN_ADVERTISER_NM IS NULL
    ),
    -- Step 3: Extract the number part of the Max existing CAMPAIGN_ADVERTISER_ID from the target table
    MAX_ID AS (
        SELECT
            IFNULL(MAX(SUFFIX), 0) AS MAX_SUFFIX
        FROM
            BASE_ADVERTISERS
    ),
    -- Step 4: Generate new CAMPAIGN_ADVERTISER_IDs for new CAMPAIGN_ADVERTISER_NMs
    NEW_ADVERTISERS_WITH_GENERATED_IDS AS (
        SELECT
            *,
            FORMAT('ADV%d', MAX_ID.MAX_SUFFIX + ROW_NUMBER() OVER ()) AS CAMPAIGN_ADVERTISER_ID
        FROM
            NEW_ADVERTISERS, MAX_ID
    )
    -- Step 5: Insert new CAMPAIGN_ADVERTISER_NMs into target table
    SELECT
        CAMPAIGN_ADVERTISER_ID,
        CAMPAIGN_ADVERTISER_NM_4M_SOURCE,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
        CURRENT_TIMESTAMP() AS DW_LAST_UPDATED_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID
    FROM
        NEW_ADVERTISERS_WITH_GENERATED_IDS;


    CREATE TEMP TABLE TEMP_CAMPAIGN_ADVERTISER_FOR_CAMPAIGN AS
    SELECT
        CAMPAIGN_ADVERTISER_ID,
        CAMPAIGN_ADVERTISER_NM_4M_SOURCE,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
        CURRENT_TIMESTAMP() AS DW_LAST_UPDATED_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID
    FROM TEMP_CAMPAIGN_ADVERTISER
    UNION ALL
    SELECT 
        CAMPAIGN_ADVERTISER_ID,
        CAMPAIGN_ADVERTISER_NM AS CAMPAIGN_ADVERTISER_NM_4M_SOURCE,
        DW_CREATE_TS,
        DW_LAST_UPDATE_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID
    FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CAMPAIGN_ADVERTISER`;
    
   

    CREATE TEMP TABLE TEMP_MEDIA_CAMPAIGN AS
        -- Step 1: Extract valid campaign data
        WITH CAMPAIGN_DATA AS (
            SELECT DISTINCT
                TRIM(CAMPAIGN_ID) AS MEDIA_CAMPAIGN_ID,
                TRIM(CAMPAIGN_NAME) AS MEDIA_CAMPAIGN_NM,
                TRIM(CAMPAIGN_STATUS) AS MEDIA_CAMPAIGN_STATUS_CD,
                TRIM(CAMPAIGN_DESCRIPTION) AS CAMPAIGN_DESCRIPTION,
                CAST(TRIM(CAMPAIGN_START_DATE) AS DATE) AS MEDIA_CAMPAIGN_START_DT,
                CAST(TRIM(CAMPAIGN_END_DATE) AS DATE) AS MEDIA_CAMPAIGN_END_DT,
                TRIM(ADVERTISER) AS CAMPAIGN_ADVERTISER_NM,
                CAST(TRIM(CREATED_TIMESTAMP) AS TIMESTAMP) AS CAMPAIGN_CREATED_TS,
                CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) AS CAMPAIGN_LAST_MODIFIED_TS,
                TRIM(LAST_MODIFIED_BY) AS CAMPAIGN_LAST_MODIFIED_BY,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                TEMP_TABLE_DUPLICATE_CAMPAIGN_IDENTIFIED
            WHERE
                ERR_MSG = ''
        ),
        -- Step 2: Parse the CAMPAIGN_DESCRIPTION to extract key-value pairs
        PARSED_CAMPAIGN_DATA AS (
            SELECT
                MEDIA_CAMPAIGN_ID,
                REGEXP_EXTRACT(CAMPAIGN_DESCRIPTION, r'(?i)OPPORTUNITY_ID=([^|]+)') AS CAMPAIGN_OPPORTUNITY_ID,
                MEDIA_CAMPAIGN_NM,
                MEDIA_CAMPAIGN_STATUS_CD,
                MEDIA_CAMPAIGN_START_DT,
                MEDIA_CAMPAIGN_END_DT,
                CAMPAIGN_ADVERTISER_NM,
                REGEXP_EXTRACT(CAMPAIGN_DESCRIPTION, r'(?i)HUB_CAMPAIGN_ID=([^|]+)') AS MEDIA_HUB_ID,
                CAMPAIGN_CREATED_TS,
                CAMPAIGN_LAST_MODIFIED_TS,
                CAMPAIGN_LAST_MODIFIED_BY,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                CAMPAIGN_DATA
        ),
        -- Step 3: Join with the campaign advertiser table to get the advertiser ID
            -- (CAMPAIGN_ADVERTISER table is already updated in the previous step so doing simple inner join)
        CAMPAIGN_DATA_WITH_ADVERTISER_ID AS (
            SELECT
                STG.*,
                ADV.CAMPAIGN_ADVERTISER_ID
            FROM
                PARSED_CAMPAIGN_DATA STG
            INNER JOIN
                TEMP_CAMPAIGN_ADVERTISER_FOR_CAMPAIGN ADV
            ON
                LOWER(TRIM(STG.CAMPAIGN_ADVERTISER_NM)) = LOWER(TRIM(ADV.CAMPAIGN_ADVERTISER_NM_4M_SOURCE))
        )
        SELECT
            MEDIA_CAMPAIGN_ID,
            CAMPAIGN_ADVERTISER_ID,
            CAMPAIGN_OPPORTUNITY_ID,
            MEDIA_CAMPAIGN_NM,
            MEDIA_CAMPAIGN_STATUS_CD,
            MEDIA_CAMPAIGN_START_DT,
            MEDIA_CAMPAIGN_END_DT,
            MEDIA_HUB_ID,
            CAMPAIGN_CREATED_TS,
            CAMPAIGN_LAST_MODIFIED_BY,
            CAMPAIGN_LAST_MODIFIED_TS,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID
        FROM
            CAMPAIGN_DATA_WITH_ADVERTISER_ID;

    
     CREATE TEMP TABLE TEMP_CAMPAIGN_LINE_ITEM AS
        -- Step 1: Extract valid line item data
        WITH CAMPAIGN_LINE_ITEM_DATA AS (
            SELECT
                TRIM(LINE_ITEM_ID) AS CAMPAIGN_LINE_ITEM_ID,
                TRIM(CAMPAIGN_ID) AS MEDIA_CAMPAIGN_ID,
                TRIM(LINE_ITEM_NAME) AS CAMPAIGN_LINE_ITEM_NM,
                CAST(TRIM(LINE_ITEM_START_DATE) AS DATE) AS CAMPAIGN_LINE_ITEM_START_DT,
                CAST(TRIM(LINE_ITEM_END_DATE) AS DATE) AS CAMPAIGN_LINE_ITEM_END_DT,
                TRIM(LINE_ITEM_DESCRIPTION) AS LINE_ITEM_DESCRIPTION,
                CAST(TRIM(LINE_ITEM_CPM) AS NUMERIC) AS CAMPAIGN_LINE_ITEM_CPM_AMT,
                CAST(TRIM(LINE_ITEM_BUDGET) AS NUMERIC) AS CAMPAIGN_LINE_ITEM_BUDGET_AMT,
                TRIM(LINE_ITEM_BUDGET_GOAL_TYPE) AS CAMPAIGN_LINE_ITEM_BUDGET_GOAL_TYPE,
                CAST(TRIM(CREATED_TIMESTAMP) AS TIMESTAMP) AS LINE_ITEM_CREATED_TS,
                TRIM(LAST_MODIFIED_BY) AS LINE_ITEM_LAST_MODIFIED_BY,
                CAST(TRIM(LAST_MODIFIED_TIMESTAMP) AS TIMESTAMP) AS LINE_ITEM_LAST_MODIFIED_TS,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                TEMP_TABLE_DUPLICATE_LINEITEM_IDENTIFIED
            WHERE
                ERR_MSG = ''
        ),
        -- Step 2: Parse the LINE_ITEM_DESCRIPTION description to extract key-value pairs
        PARSED_CAMPAIGN_LINE_ITEM_DATA AS (
            SELECT
                CAMPAIGN_LINE_ITEM_ID,
                MEDIA_CAMPAIGN_ID,
                CAMPAIGN_LINE_ITEM_NM,
                CAMPAIGN_LINE_ITEM_START_DT,
                CAMPAIGN_LINE_ITEM_END_DT,
                CAMPAIGN_LINE_ITEM_CPM_AMT,
                CAMPAIGN_LINE_ITEM_BUDGET_AMT,
                CAMPAIGN_LINE_ITEM_BUDGET_GOAL_TYPE,
                REGEXP_EXTRACT(LINE_ITEM_DESCRIPTION, r'(?i)HUB_TACTIC_ID=([^|]+)') AS MEDIA_HUB_TACTIC_ID,
                LINE_ITEM_CREATED_TS,
                LINE_ITEM_LAST_MODIFIED_BY,
                LINE_ITEM_LAST_MODIFIED_TS,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                CAMPAIGN_LINE_ITEM_DATA
        )
        SELECT
            CAMPAIGN_LINE_ITEM_ID,
            MEDIA_CAMPAIGN_ID,
            CAMPAIGN_LINE_ITEM_NM,
            CAMPAIGN_LINE_ITEM_START_DT,
            CAMPAIGN_LINE_ITEM_END_DT,
            CAMPAIGN_LINE_ITEM_CPM_AMT,
            CAMPAIGN_LINE_ITEM_BUDGET_AMT,
            CAMPAIGN_LINE_ITEM_BUDGET_GOAL_TYPE,
            MEDIA_HUB_TACTIC_ID,
            LINE_ITEM_CREATED_TS,
            LINE_ITEM_LAST_MODIFIED_BY,
            LINE_ITEM_LAST_MODIFIED_TS,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID
        FROM
            PARSED_CAMPAIGN_LINE_ITEM_DATA;

    CREATE TEMP TABLE TEMP_MEDIA_CREATIVE_CAMPAIGN AS
    -- Extract valid campaign creative mapping
    SELECT
        TRIM(CAMPAIGN_ID) AS MEDIA_CAMPAIGN_ID,
        TRIM(LINE_ITEM_ID) AS CAMPAIGN_LINE_ITEM_ID,
        TRIM(CREATIVE_ID) AS MEDIA_CREATIVE_ID,
        DW_CREATE_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID,
        PARTNER_ID,
        PLATFORM_ID
    FROM
        CAMPAIGN_DETAILS_WITH_VALIDATION_STATUS
    WHERE
        ERR_MSG = '';

    -----------------------------------------End of Temp Table Creations-------------------------------------

    --------------------START OF INSERTION/UPDATE OF TARGET TABLES -------------------
    -- 1. START processing CAMPAIGN_ADVERTISER(This table has the CAMPAIGN_ADVERTISER_IDs in the format:: ADV<monotonically increasing number>)
        -- Logic if CAMPAIGN_ADVERTISER_NM is not present in the target table then insert those into the target table
        -- Step 1: Extract data from target table - CAMPAIGN_ADVERTISER
        -- Step 2: Extract only new CAMPAIGN_ADVERTISER_NM from source
        -- Step 3: Extract the number part of the Max existing CAMPAIGN_ADVERTISER_ID from the target table
        -- Step 4: Generate new CAMPAIGN_ADVERTISER_IDs for new CAMPAIGN_ADVERTISER_NMs
        -- Step 5: Insert new CAMPAIGN_ADVERTISER_NMs into target table
BEGIN
    -- BEGIN TRANSACTION BEFORE INSERTING/MERGING TO TARGET TABLES
    BEGIN TRANSACTION;

    -- Set transaction_started to TRUE to indicate that the transaction has started
    SET transaction_started = TRUE;
    INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.CAMPAIGN_ADVERTISER` (
        CAMPAIGN_ADVERTISER_ID,
        CAMPAIGN_ADVERTISER_NM,
        DW_CREATE_TS,
        DW_LAST_UPDATE_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID
    )
    SELECT
        CAMPAIGN_ADVERTISER_ID,
        CAMPAIGN_ADVERTISER_NM_4M_SOURCE,
        DW_CREATE_TS,
        DW_LAST_UPDATED_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID
    FROM TEMP_CAMPAIGN_ADVERTISER;

    -- END processing for CAMPAIGN_ADVERTISER----------------


    -- 2. START Processing for MEDIA_CAMPAIGN table
        MERGE
             `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CAMPAIGN` TARGET
        USING TEMP_MEDIA_CAMPAIGN AS SOURCE
        ON
            TARGET.MEDIA_CAMPAIGN_ID = SOURCE.MEDIA_CAMPAIGN_ID            
        WHEN MATCHED THEN
            UPDATE SET
                TARGET.CAMPAIGN_ADVERTISER_ID = SOURCE.CAMPAIGN_ADVERTISER_ID,
                TARGET.CAMPAIGN_OPPORTUNITY_ID = SOURCE.CAMPAIGN_OPPORTUNITY_ID,
                TARGET.MEDIA_CAMPAIGN_NM = SOURCE.MEDIA_CAMPAIGN_NM,
                TARGET.MEDIA_CAMPAIGN_STATUS_CD = SOURCE.MEDIA_CAMPAIGN_STATUS_CD,
                TARGET.MEDIA_CAMPAIGN_START_DT = SOURCE.MEDIA_CAMPAIGN_START_DT,
                TARGET.MEDIA_CAMPAIGN_END_DT = SOURCE.MEDIA_CAMPAIGN_END_DT,
                TARGET.MEDIA_HUB_ID = SOURCE.MEDIA_HUB_ID,
                TARGET.CAMPAIGN_CREATED_TS = SOURCE.CAMPAIGN_CREATED_TS,
                TARGET.CAMPAIGN_LAST_MODIFIED_BY = SOURCE.CAMPAIGN_LAST_MODIFIED_BY,
                TARGET.CAMPAIGN_LAST_MODIFIED_TS = SOURCE.CAMPAIGN_LAST_MODIFIED_TS,
                -- DW_CREATE_TS we should not update (This should be the TIMESTAMP when it is first inserted/created)
                TARGET.DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP(),
                TARGET.SOURCE_APPLICATION_CD = SOURCE.SOURCE_APPLICATION_CD,
                TARGET.JOB_ID = SOURCE.JOB_ID
        WHEN NOT MATCHED THEN
            INSERT (
                MEDIA_CAMPAIGN_ID,
                CAMPAIGN_ADVERTISER_ID,
                CAMPAIGN_OPPORTUNITY_ID,
                MEDIA_CAMPAIGN_NM,
                MEDIA_CAMPAIGN_TYPE_CD,
                MEDIA_CAMPAIGN_STATUS_CD,
                MEDIA_CAMPAIGN_START_DT,
                MEDIA_CAMPAIGN_END_DT,
                MEDIA_HUB_ID,
                CAMPAIGN_CREATED_TS,
                CAMPAIGN_LAST_MODIFIED_BY,
                CAMPAIGN_LAST_MODIFIED_TS,
                DW_CREATE_TS,
                DW_LAST_UPDATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            )
            VALUES (
                SOURCE.MEDIA_CAMPAIGN_ID,
                SOURCE.CAMPAIGN_ADVERTISER_ID,
                SOURCE.CAMPAIGN_OPPORTUNITY_ID,
                SOURCE.MEDIA_CAMPAIGN_NM,
                'In Store Digital',  -- Default value for MEDIA_CAMPAIGN_TYPE_CD
                SOURCE.MEDIA_CAMPAIGN_STATUS_CD,
                SOURCE.MEDIA_CAMPAIGN_START_DT,
                SOURCE.MEDIA_CAMPAIGN_END_DT,
                SOURCE.MEDIA_HUB_ID,
                SOURCE.CAMPAIGN_CREATED_TS,
                SOURCE.CAMPAIGN_LAST_MODIFIED_BY,
                SOURCE.CAMPAIGN_LAST_MODIFIED_TS,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                SOURCE.SOURCE_APPLICATION_CD,
                SOURCE.JOB_ID
            );

    -- END processing for MEDIA_CAMPAIGN----------------

        MERGE
             `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CAMPAIGN_LINE_ITEM` TARGET
        USING TEMP_CAMPAIGN_LINE_ITEM AS SOURCE
        ON
            TARGET.CAMPAIGN_LINE_ITEM_ID = SOURCE.CAMPAIGN_LINE_ITEM_ID
            AND TARGET.MEDIA_CAMPAIGN_ID = SOURCE.MEDIA_CAMPAIGN_ID
        WHEN MATCHED THEN
            UPDATE SET
                TARGET.CAMPAIGN_LINE_ITEM_NM = SOURCE.CAMPAIGN_LINE_ITEM_NM,
                TARGET.CAMPAIGN_LINE_ITEM_START_DT = SOURCE.CAMPAIGN_LINE_ITEM_START_DT,
                TARGET.CAMPAIGN_LINE_ITEM_END_DT = SOURCE.CAMPAIGN_LINE_ITEM_END_DT,
                TARGET.CAMPAIGN_LINE_ITEM_CPM_AMT = SOURCE.CAMPAIGN_LINE_ITEM_CPM_AMT,
                TARGET.CAMPAIGN_LINE_ITEM_BUDGET_AMT = SOURCE.CAMPAIGN_LINE_ITEM_BUDGET_AMT,
                TARGET.LINE_ITEM_BUDGET_GOAL_TYPE = SOURCE.CAMPAIGN_LINE_ITEM_BUDGET_GOAL_TYPE,
                TARGET.MEDIA_HUB_TACTIC_ID = SOURCE.MEDIA_HUB_TACTIC_ID,
                TARGET.LINE_ITEM_CREATED_TS = SOURCE.LINE_ITEM_CREATED_TS,
                TARGET.LINE_ITEM_LAST_MODIFIED_BY = SOURCE.LINE_ITEM_LAST_MODIFIED_BY,
                TARGET.LINE_ITEM_LAST_MODIFIED_TS = SOURCE.LINE_ITEM_LAST_MODIFIED_TS,
                -- DW_CREATE_TS we should not update (This should be the TIMESTAMP when it is first inserted/created)
                TARGET.DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP(),
                TARGET.SOURCE_APPLICATION_CD = SOURCE.SOURCE_APPLICATION_CD,
                TARGET.JOB_ID = SOURCE.JOB_ID
        WHEN NOT MATCHED THEN
            INSERT (
                CAMPAIGN_LINE_ITEM_ID,
                MEDIA_CAMPAIGN_ID,
                CAMPAIGN_LINE_ITEM_NM,
                CAMPAIGN_LINE_ITEM_START_DT,
                CAMPAIGN_LINE_ITEM_END_DT,
                CAMPAIGN_LINE_ITEM_CPM_AMT,
                CAMPAIGN_LINE_ITEM_BUDGET_AMT,
                LINE_ITEM_BUDGET_GOAL_TYPE,
                MEDIA_HUB_TACTIC_ID,
                LINE_ITEM_CREATED_TS,
                LINE_ITEM_LAST_MODIFIED_BY,
                LINE_ITEM_LAST_MODIFIED_TS,
                DW_CREATE_TS,
                DW_LAST_UPDATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            )
            VALUES (
                SOURCE.CAMPAIGN_LINE_ITEM_ID,
                SOURCE.MEDIA_CAMPAIGN_ID,
                SOURCE.CAMPAIGN_LINE_ITEM_NM,
                SOURCE.CAMPAIGN_LINE_ITEM_START_DT,
                SOURCE.CAMPAIGN_LINE_ITEM_END_DT,
                SOURCE.CAMPAIGN_LINE_ITEM_CPM_AMT,
                SOURCE.CAMPAIGN_LINE_ITEM_BUDGET_AMT,
                SOURCE.CAMPAIGN_LINE_ITEM_BUDGET_GOAL_TYPE,
                SOURCE.MEDIA_HUB_TACTIC_ID,
                SOURCE.LINE_ITEM_CREATED_TS,
                SOURCE.LINE_ITEM_LAST_MODIFIED_BY,
                SOURCE.LINE_ITEM_LAST_MODIFIED_TS,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                SOURCE.SOURCE_APPLICATION_CD,
                SOURCE.JOB_ID
            );
    
    -- END processing for MEDIA_CAMPAIGN_LINE_ITEM----------------

    -- 4. START Processing for MEDIA_CREATIVE_CAMPAIGN table
        MERGE
            `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CREATIVE_CAMPAIGN` TARGET
        USING TEMP_MEDIA_CREATIVE_CAMPAIGN AS SOURCE
        ON
            TARGET.MEDIA_CAMPAIGN_ID = SOURCE.MEDIA_CAMPAIGN_ID
            AND TARGET.CAMPAIGN_LINE_ITEM_ID = SOURCE.CAMPAIGN_LINE_ITEM_ID
            AND TARGET.MEDIA_CREATIVE_ID = SOURCE.MEDIA_CREATIVE_ID
        WHEN NOT MATCHED THEN
            INSERT (
                MEDIA_CAMPAIGN_ID,
                CAMPAIGN_LINE_ITEM_ID,
                MEDIA_CREATIVE_ID,
                DW_CREATE_TS,
                DW_LAST_UPDATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID,
                PLATFORM_ID,
                MEDIA_PARTNER_ID
            )
            VALUES (
                SOURCE.MEDIA_CAMPAIGN_ID,
                SOURCE.CAMPAIGN_LINE_ITEM_ID,
                SOURCE.MEDIA_CREATIVE_ID,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                SOURCE.SOURCE_APPLICATION_CD,
                SOURCE.JOB_ID,
                SOURCE.PARTNER_ID,
                SOURCE.PLATFORM_ID
            );

    -- END processing for MEDIA_CREATIVE_CAMPAIGN----------------

    -- COMMENTED OUT THE BELOW MEDIA_CAMPAIGN_TARGET UPDATE AND INSERT BECAUSE CURRENTLY ACCESS TO PMP IS NOT AVAILABLE AND 
    -- THE FORMAT IN WHICH THE TARGET DATA WOULD BE SENT IS NOT SURE. ONCE WE HAVE THE CLARITY THEN BASED ON THE REQUIREMENT 
    -- BELOW CODE CAN BE CHANGED AND TESTED

    -- -- 5. START Processing for MEDIA_CAMPAIGN_TARGET table (<This table has the CAMPAIGN_TARGET_IDs in the format:: TGT<monotonically increasing number>)
    --     -- Assuming MEDIA_CAMPAIGN_ID has 1:1 relationship with MEDIA_CAMPAIGN_TARGET
    --     -- Logic below
    --     -- A. if MEDIA_CAMPAIGN_ID is  present in the target table then update target table
    --     -- B. Else insert those into the target table

    -- -- 5A. If MEDIA_CAMPAIGN_ID is present in the target table then update the CAMPAIGN_TARGET info
    --     UPDATE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CAMPAIGN_TARGET` TARGET
    --     SET
    --         TARGET.CAMPAIGN_TARGET = SPLIT(SOURCE.CAMPAIGN_TARGET, ','),
    --         -- DW_CREATE_TS we should not update (This should be the TIMESTAMP when it is first inserted/created)
    --         TARGET.DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP(),
    --         TARGET.SOURCE_APPLICATION_CD = SOURCE.SOURCE_APPLICATION_CD,
    --         TARGET.JOB_ID = SOURCE.JOB_ID
    --     FROM (
    --         SELECT DISTINCT
    --             CAMPAIGN_ID AS MEDIA_CAMPAIGN_ID,
    --             CAMPAIGN_TARGET,
    --             SOURCE_APPLICATION_CD,
    --             JOB_ID
    --         FROM
    --             CAMPAIGN_DETAILS_WITH_VALIDATION_STATUS
    --         WHERE
    --             ERR_MSG = ''
    --     ) SOURCE
    --     WHERE
    --         TARGET.MEDIA_CAMPAIGN_ID = SOURCE.MEDIA_CAMPAIGN_ID;

    -- -- 5B. If MEDIA_CAMPAIGN_ID is not present in the target table then insert those into the target table
    --     -- Step 1: Extract data from target table - MEDIA_CAMPAIGN_TARGET
    --     -- Step 2: Extract only new MEDIA_CAMPAIGN_IDs info from source
    --     -- Step 3: Extract the number part of the Max existing CAMPAIGN_TARGET_ID from the target table
    --     -- Step 4: Generate new CAMPAIGN_TARGET_IDs for new MEDIA_CAMPAIGN_IDs
    --     -- Step 5: Insert new MEDIA_CAMPAIGN_IDs, CAMPAIGN_TARGET info into target table

    -- INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CAMPAIGN_TARGET` (
    --     CAMPAIGN_TARGET_ID,
    --     MEDIA_CAMPAIGN_ID,
    --     CAMPAIGN_TARGET,
    --     DW_CREATE_TS,
    --     DW_LAST_UPDATE_TS,
    --     SOURCE_APPLICATION_CD,
    --     JOB_ID
    -- )
    -- -- Step 1: Extract data from target table - MEDIA_CAMPAIGN_TARGET
    -- WITH BASE_CAMPAIGN_TARGETS AS (
    --     SELECT DISTINCT
    --         MEDIA_CAMPAIGN_ID,
    --         CAST(SUBSTR(CAMPAIGN_TARGET_ID, 4) AS INT64) AS SUFFIX
    --     FROM
    --         `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_CAMPAIGN_TARGET`
    -- ),
    -- -- Step 2: Extract only new MEDIA_CAMPAIGN_IDs info from source
    -- NEW_CAMPAIGN_TARGETS AS (
    --     SELECT
    --         *
    --     FROM (
    --         SELECT DISTINCT
    --             CAMPAIGN_ID as MEDIA_CAMPAIGN_ID_4M_SOURCE,
    --             CAMPAIGN_TARGET,
    --             DW_CREATE_TS,
    --             SOURCE_APPLICATION_CD,
    --             JOB_ID
    --         FROM
    --             CAMPAIGN_DETAILS_WITH_VALIDATION_STATUS
    --         WHERE
    --         	ERR_MSG = ''
    --         ) STG
    --     LEFT JOIN
    --         BASE_CAMPAIGN_TARGETS CAMP_TGT
    --     ON
    --         STG.MEDIA_CAMPAIGN_ID_4M_SOURCE = CAMP_TGT.MEDIA_CAMPAIGN_ID
    --     WHERE
    --         CAMP_TGT.MEDIA_CAMPAIGN_ID IS NULL
    -- ),
    -- -- Step 3: Extract the number part of the Max existing CAMPAIGN_TARGET_ID from the target table
    -- MAX_ID AS (
    --     SELECT
    --         IFNULL(MAX(SUFFIX), 0) AS MAX_SUFFIX
    --     FROM
    --         BASE_CAMPAIGN_TARGETS
    -- ),
    -- -- Step 4: Generate new CAMPAIGN_TARGET_IDs for new MEDIA_CAMPAIGN_IDs
    -- NEW_CAMPAIGN_TARGETS_WITH_GENERATED_IDS AS (
    --     SELECT
    --         *,
    --         FORMAT('TGT%d', MAX_ID.MAX_SUFFIX + ROW_NUMBER() OVER ()) AS CAMPAIGN_TARGET_ID
    --     FROM
    --         NEW_CAMPAIGN_TARGETS, MAX_ID
    -- )
    -- -- Step 5: Insert new MEDIA_CAMPAIGN_IDs, CAMPAIGN_TARGET info into target table
    -- SELECT
    --     CAMPAIGN_TARGET_ID,
    --     MEDIA_CAMPAIGN_ID_4M_SOURCE,
    --     SPLIT(CAMPAIGN_TARGET, ','),
    --     CAST(NULL AS STRING),
    --     CAST(NULL AS STRING),
    --     DW_CREATE_TS,
    --     CURRENT_TIMESTAMP(),
    --     SOURCE_APPLICATION_CD,
    --     JOB_ID
    -- FROM
    --     NEW_CAMPAIGN_TARGETS_WITH_GENERATED_IDS;

    -- END processing for MEDIA_CAMPAIGN_TARGET----------------

    --6. START Processing for MEDIA_CAMPAIGN_DETAILS_INVALID table
    -- Check if the table has records for the given job_id
    SET record_count = (SELECT COUNT(1)
    FROM `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.MEDIA_CAMPAIGN_DETAILS_INVALID`
    WHERE JOB_ID = current_job_id);

    -- If no records exist for the job_id, proceed with the insert
    IF record_count = 0 THEN
            INSERT INTO `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.MEDIA_CAMPAIGN_DETAILS_INVALID` (
                MEDIA_CAMPAIGN_ID,
                MEDIA_CREATIVE_ID,
                MEDIA_CAMPAIGN_NM,
                MEDIA_CAMPAIGN_START_DT,
                MEDIA_CAMPAIGN_END_DT,
              --  CAMPAIGN_TARGET,
                MEDIA_CAMPAIGN_STATUS_CD,
                CAMPAIGN_DESCRIPTION,
                CAMPAIGN_LINE_ITEM_ID,
                CAMPAIGN_LINE_ITEM_NM,
                CAMPAIGN_LINE_ITEM_START_DT,
                CAMPAIGN_LINE_ITEM_END_DT,
                CAMPAIGN_LINE_ITEM_DESCRIPTION,
                CAMPAIGN_LINE_ITEM_CPM_AMT,
                CAMPAIGN_LINE_ITEM_BUDGET_AMT,
                CAMPAIGN_LINE_ITEM_BUDGET_GOAL_TYPE,
                CAMPAIGN_ADVERTISER_NM,
                CAMPAIGN_CREATED_TS,
                CAMPAIGN_LAST_MODIFIED_BY,
                CAMPAIGN_LAST_MODIFIED_TS,
                PLATFORM_ID,
                MEDIA_PARTNER_ID,
                ERR_MSG,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            )
            SELECT
                CAMPAIGN_ID,
                CREATIVE_ID,
                CAMPAIGN_NAME,
                CAMPAIGN_START_DATE,
                CAMPAIGN_END_DATE,
              --  CAMPAIGN_TARGET,
                CAMPAIGN_STATUS,
                CAMPAIGN_DESCRIPTION,
                LINE_ITEM_ID,
                LINE_ITEM_NAME,
                LINE_ITEM_START_DATE,
                LINE_ITEM_END_DATE,
                LINE_ITEM_DESCRIPTION,
                LINE_ITEM_CPM,
                LINE_ITEM_BUDGET,
                LINE_ITEM_BUDGET_GOAL_TYPE,
                ADVERTISER,
                CREATED_TIMESTAMP,
                LAST_MODIFIED_BY,
                LAST_MODIFIED_TIMESTAMP,
                PLATFORM_ID,
                PARTNER_ID,
                ERR_MSG,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                CAMPAIGN_DETAILS_WITH_VALIDATION_STATUS
            WHERE
                ERR_MSG != ''
            UNION ALL
            SELECT
                CAMPAIGN_ID,
                '' AS CREATIVE_ID,
                CAMPAIGN_NAME,
                CAMPAIGN_START_DATE,
                CAMPAIGN_END_DATE,
              --  CAMPAIGN_TARGET,
                CAMPAIGN_STATUS,
                CAMPAIGN_DESCRIPTION,
                '' AS LINE_ITEM_ID,
                '' AS LINE_ITEM_NAME,
                '' AS LINE_ITEM_START_DATE,
                '' AS LINE_ITEM_END_DATE,
                '' AS LINE_ITEM_DESCRIPTION,
                '' AS LINE_ITEM_CPM,
                '' AS LINE_ITEM_BUDGET,
                '' AS LINE_ITEM_BUDGET_GOAL_TYPE,
                ADVERTISER,
                CREATED_TIMESTAMP,
                LAST_MODIFIED_BY,
                LAST_MODIFIED_TIMESTAMP,
                PLATFORM_ID,
                PARTNER_ID,
                ERR_MSG,
                RAW.DW_FILE_PATH,
                DW_CREATE_TS,
                RAW.SOURCE_APPLICATION_CD,
                RAW.JOB_ID
            FROM
                TEMP_TABLE_DUPLICATE_CAMPAIGN_IDENTIFIED A 
                CROSS JOIN
                (SELECT DISTINCT
                    DW_FILE_PATH,
                    SOURCE_APPLICATION_CD,
                    JOB_ID  
                FROM
                    CAMPAIGN_DETAILS_WITH_VALIDATION_STATUS
                ) RAW
            WHERE
                ERR_MSG != ''
            UNION ALL
            SELECT
                CAMPAIGN_ID,
                '' AS CREATIVE_ID,
                '' AS CAMPAIGN_NAME,
                '' AS CAMPAIGN_START_DATE,
                '' AS CAMPAIGN_END_DATE,
                --  '' AS CAMPAIGN_TARGET,
                '' AS CAMPAIGN_STATUS,
                '' AS CAMPAIGN_DESCRIPTION,
                LINE_ITEM_ID,
                LINE_ITEM_NAME,
                LINE_ITEM_START_DATE,
                LINE_ITEM_END_DATE,
                LINE_ITEM_DESCRIPTION,
                LINE_ITEM_CPM,
                LINE_ITEM_BUDGET,
                LINE_ITEM_BUDGET_GOAL_TYPE,
                '' AS ADVERTISER,
                CREATED_TIMESTAMP,
                LAST_MODIFIED_BY,
                LAST_MODIFIED_TIMESTAMP,
                PLATFORM_ID,
                PARTNER_ID,
                ERR_MSG,
                RAW.DW_FILE_PATH,
                DW_CREATE_TS,
                RAW.SOURCE_APPLICATION_CD,
                RAW.JOB_ID
            FROM
                TEMP_TABLE_DUPLICATE_LINEITEM_IDENTIFIED A 
                CROSS JOIN
                (SELECT DISTINCT
                    DW_FILE_PATH,
                    SOURCE_APPLICATION_CD,
                    JOB_ID  
                FROM
                    CAMPAIGN_DETAILS_WITH_VALIDATION_STATUS
                ) RAW
            WHERE
                ERR_MSG != '';
    END IF;
    -- COMMITTING THE TRANSACTION AFTER ALL INSERTS/MERGE IS DONE
    COMMIT TRANSACTION;
    EXCEPTION WHEN ERROR THEN
    -- ROLLBACK THE TRANSACTION INSIDE THE EXCEPTION HANDLER.
    SELECT @@error.message;
    -- Check if the transaction was started before rolling back
    IF transaction_started THEN
        ROLLBACK TRANSACTION;
    END IF;
    RAISE USING message = FORMAT("Error while processing Campaign data: %s.", @@error.message);
END;
END;
