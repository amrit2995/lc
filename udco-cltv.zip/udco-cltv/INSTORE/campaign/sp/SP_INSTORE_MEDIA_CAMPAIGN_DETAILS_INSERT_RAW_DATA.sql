CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_INSTORE_MEDIA_CAMPAIGN_DETAILS_INSERT_RAW_DATA`(job_id STRING)
BEGIN
    DECLARE project_id STRING;
    DECLARE refined_dataset STRING;
    DECLARE campaign_raw_data_stg_table STRING;
    DECLARE campaign_raw_data_table STRING;
    DECLARE sql_string STRING;
    DECLARE record_count INT64;
    DECLARE current_job_id STRING;

    -- Set variable values
    SET project_id = 'gcp-abs-udco-bq-<<ENV>>-prj-01';
    SET refined_dataset = 'udco_ds_cltv_refined';
    SET campaign_raw_data_stg_table = 'MEDIA_CAMPAIGN_DETAILS_STG';
    SET campaign_raw_data_table = 'MEDIA_CAMPAIGN_DETAILS';
    SET current_job_id = job_id;

    -- Check if the table has records for the given job_id
    EXECUTE IMMEDIATE FORMAT("""
        SELECT COUNT(1)
        FROM `%s.%s.%s`
        WHERE JOB_ID = '%s'
    """, project_id, refined_dataset, campaign_raw_data_table, current_job_id)
    INTO record_count;
    -- If no records exist for the job_id, proceed with the insert
    IF record_count = 0 THEN
        SET sql_string = """
            INSERT INTO `""" || project_id || "." || refined_dataset || "." || campaign_raw_data_table || """` (
                MEDIA_CAMPAIGN_ID,
                MEDIA_CREATIVE_ID,
                MEDIA_CAMPAIGN_NM,
                MEDIA_CAMPAIGN_START_DT,
                MEDIA_CAMPAIGN_END_DT,
                CAMPAIGN_TARGET,
                MEDIA_CAMPAIGN_STATUS_CD,
                CAMPAIGN_DESCRIPTION,
                CAMPAIGN_LINE_ITEM_ID,
                CAMPAIGN_LINE_ITEM_NM,
                CAMPAIGN_LINE_ITEM_START_DT,
                CAMPAIGN_LINE_ITEM_END_DT,
                CAMPAIGN_LINE_ITEM_DESCRIPTION,
                CAMPAIGN_LINE_ITEM_CPM_AMT,
                CAMPAIGN_LINE_ITEM_BUDGET_AMT,
                CAMPAIGN_LINE_ITEM_BUDGET_GOAL_TYPE,
                CAMPAIGN_ADVERTISER_NM,
                CAMPAIGN_CREATED_TS,
                CAMPAIGN_LAST_MODIFIED_BY,
                CAMPAIGN_LAST_MODIFIED_TS,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            )
            SELECT
                CAMPAIGN_ID,
                CREATIVE_ID,
                CAMPAIGN_NAME,
                CAMPAIGN_START_DATE,
                CAMPAIGN_END_DATE,
                CAMPAIGN_TARGET,
                CAMPAIGN_STATUS,
                CAMPAIGN_DESCRIPTION,
                LINE_ITEM_ID,
                LINE_ITEM_NAME,
                LINE_ITEM_START_DATE,
                LINE_ITEM_END_DATE,
                LINE_ITEM_DESCRIPTION,
                LINE_ITEM_CPM,
                LINE_ITEM_BUDGET,
                LINE_ITEM_BUDGET_GOAL_TYPE,
                ADVERTISER,
                CREATED_TIMESTAMP,
                LAST_MODIFIED_BY,
                LAST_MODIFIED_TIMESTAMP,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                `""" || project_id || "." || refined_dataset || "." || campaign_raw_data_stg_table || """`
        """;
        EXECUTE IMMEDIATE sql_string;
    END IF;
END;