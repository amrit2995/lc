CREATE OR REPLACE VIEW `gcp-abs-udco-bqvw-<<ENV>>-prj-01.udco_ds_cltv.F_INSTORE_OUT_OF_STOCK_PRODUCT_DETAIL`
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]) 
as  
SELECT * FROM  `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.F_INSTORE_OUT_OF_STOCK_PRODUCT_DETAIL`;
