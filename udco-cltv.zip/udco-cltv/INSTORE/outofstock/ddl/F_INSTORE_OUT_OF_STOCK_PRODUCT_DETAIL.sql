CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.F_INSTORE_OUT_OF_STOCK_PRODUCT_DETAIL`
 ( 
   DAY_ID	INT64 NOT NULL OPTIONS(description = "Day Identifier YYYYMMDD "),
   INSTORE_MEDIA_CAMPAIGN_D1_SK	INT64 NOT NULL OPTIONS(description="A Surrogate Key - system-generated unique identifier that is used instead of the natural key."),
   RETAIL_STORE_D1_SK	INT64 NOT NULL OPTIONS(description="A Surrogate Key - system-generated unique identifier that is used instead of the natural key."),
   CAMPAIGN_LINE_ITEM_ID STRING OPTIONS(description="Unique line item id under a campaign. A camapign may or may not have Line item. Also a camapign can have multiple line items. Line items can have multiple creatives associated to it."),
   -- CAMPAIGN_LINE_ITEM_ID STRING NOT NULL OPTIONS(description="Unique line item id under a campaign. A camapign may or may not have Line item. Also a camapign can have multiple line items. Line items can have multiple creatives associated to it."),
   UPC_NBR	INT64 NOT NULL OPTIONS(description = "A Surrogate Key - system-generated unique identifier that is used instead of the natural key."),
  -- MEDIA_HUB_TACTIC_ID	STRING NOT NULL OPTIONS(description="If a campaign is tied to have a line item then a Hub Tectic Id is created in media Briefs.Hub tactic id is an L2 level id from OMS.(Note: For each line item the Ad OPs team will manually enter  the key value pair to into Description/Notes data field in SC/AMP)"),
   MEDIA_HUB_TACTIC_ID	STRING OPTIONS(description="If a campaign is tied to have a line item then a Hub Tectic Id is created in media Briefs.Hub tactic id is an L2 level id from OMS.(Note: For each line item the Ad OPs team will manually enter  the key value pair to into Description/Notes data field in SC/AMP)"),
   -- CAMPAIGN_LINE_ITEM_START_DT DATE NOT NULL OPTIONS(description="Start date of the line item"),
   -- CAMPAIGN_LINE_ITEM_END_DT DATE NOT NULL OPTIONS(description="End date of the line item"),
    CAMPAIGN_LINE_ITEM_START_DT DATE  OPTIONS(description="Start date of the line item"),
    CAMPAIGN_LINE_ITEM_END_DT DATE OPTIONS(description="End date of the line item"),
   OUT_OF_STOCK_UPC_IND BOOLEAN NOT NULL OPTIONS(description="This Boolean attribute holds true or false value based on campaigned Product's  availabily instore."),
   DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp"),
   DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted.")
   )  PARTITION BY DATE_TRUNC(DW_CREATE_TS, MONTH)
 OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
