CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_analytics.D1_INSTORE_MEDIA_CAMPAIGN`
 ( 
 INSTORE_MEDIA_CAMPAIGN_D1_SK	INT64 NOT NULL OPTIONS(description="A Surrogate Key - system-generated unique identifier that is used instead of the natural key."),
 MEDIA_CAMPAIGN_ID	STRING NOT NULL OPTIONS(description="Unique identifier for the campaign."),
 MEDIA_CAMPAIGN_NM	STRING NOT NULL OPTIONS(description="Name of a campaign played in the store."),
 MEDIA_CAMPAIGN_TYPE_CD	STRING NOT NULL OPTIONS(description="Type of the campaign(this is a constant value and should be 'In Store Digital')"),
 MEDIA_CAMPAIGN_STATUS_CD	STRING NOT NULL OPTIONS(description="Status of a campaign"),
 MEDIA_CAMPAIGN_START_DT	DATE NOT NULL OPTIONS(description="Date in which campaign started in the CMS"),
 MEDIA_CAMPAIGN_END_DT	DATE NOT NULL OPTIONS(description="Date in which campaign ended in the CMS"),
 MEDIA_HUB_ID	STRING NOT NULL OPTIONS(description="Hub ID created in OMS."),
 CAMPAIGN_OPPORTUNITY_ID	STRING NOT NULL OPTIONS(description="Opportunity same as CRM"),
 CAMPAIGN_ADVERTISER_ID	STRING NOT NULL OPTIONS(description="Advertiser name, same as CPG in vendor CMS"),
 CAMPAIGN_LAST_MODIFIED_TS	TIMESTAMP NOT NULL OPTIONS(description="Created timestamp of the campaign object in vendor application."),
 CAMPAIGN_CREATED_TS	TIMESTAMP NOT NULL OPTIONS(description="Created timestamp of the campaign object in vendor application."),
 CAMPAIGN_LAST_MODIFIED_BY	STRING NOT NULL OPTIONS(description="username of the last modified"),
 SOURCE_APPLICATION_CD	STRING NOT NULL OPTIONS(description="Source Application Code for the Campaign Target"),
 DW_CREATE_TS	TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
 DW_LAST_UPDATE_TS	TIMESTAMP NOT NULL OPTIONS(description="When a record is updated  this would be the current timestamp")
 )
 OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
