-- Create table for valid sensor mmwave data
CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_ZONE_MMWAVE_EXPOSURE` (
    FACILITY_INTEGRATION_ID NUMERIC NOT NULL OPTIONS(description="Facility Integration ID for the retail store number where the sensor is installed."),
    MEDIA_ZONE_CD STRING NOT NULL OPTIONS(description="Zone where customer movement is captured by the sensor"),
    MEDIA_SENSOR_ID STRING NOT NULL OPTIONS(description="Sensor ID which captures the shopper count"),
    INTERVAL_START_TS TIMESTAMP NOT NULL OPTIONS(description="Start time of the interval"),
    INTERVAL_END_TS TIMESTAMP NOT NULL OPTIONS(description="End time of the interval"),
    SHOPPER_CNT INT64 NOT NULL OPTIONS(description="Number of shoppers identified during this interval"),
    DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    SOURCE_APPLICATION_CD STRING NOT NULL OPTIONS(description="Name of the process creating the record"),
    JOB_ID STRING NOT NULL OPTIONS(description="JOB_ID of the current DAG run")
)
PARTITION BY DATE(INTERVAL_START_TS)
CLUSTER BY FACILITY_INTEGRATION_ID
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);