-- Create table for valid sensor data

CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_ZONE_BLE_EXPOSURE` (
    SESSION_ID STRING NOT NULL OPTIONS(description="Unique session id which gets created every time when the cart is being used in the store. this session Id is unique combination of  Beacon Id (Cart Id) and its arrival time in store"),
    ZONE_ARRIVAL_TS TIMESTAMP NOT NULL OPTIONS(description="Cart having beacon arriving in the zone in UTC"),
    BEACON_ID STRING NOT NULL OPTIONS(description="Beacon id (MAC Address tied to the carts).Its Unique Cart Id for each cart in store, in a given banner and Division"),
    ZONE_DEPARTURE_TS TIMESTAMP NOT NULL OPTIONS(description="Cart having beacon leaving the zone in UTC"),
    REGISTER_NBR INT64 OPTIONS(description="Associated to Carts movement in checkout Zone ,. Register ID where the checkout/transaction happened"),
    FACILITY_INTEGRATION_ID NUMERIC NOT NULL OPTIONS(description="Facility Integration ID for the retail store number where the sensor is installed."),
    MEDIA_ZONE_CD STRING NOT NULL OPTIONS(description="Zone where customer movement is captured by the sensor"),
    DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
    SOURCE_APPLICATION_CD STRING NOT NULL OPTIONS(description="Name of the process creating the record"),
    JOB_ID STRING NOT NULL OPTIONS(description="JOB_ID of the current DAG run")
)
PARTITION BY DATE(ZONE_DEPARTURE_TS)
CLUSTER BY FACILITY_INTEGRATION_ID,MEDIA_ZONE_CD
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);

ALTER TABLE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.RETAIL_STORE_ZONE_BLE_EXPOSURE` 
ADD COLUMN IF NOT EXISTS DW_CHECKSUM_VALUE_TXT STRING OPTIONS(description="CheckSum is row unique identifier");
