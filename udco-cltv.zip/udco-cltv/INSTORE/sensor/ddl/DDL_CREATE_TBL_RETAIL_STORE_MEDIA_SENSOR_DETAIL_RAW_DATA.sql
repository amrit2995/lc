CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.RETAIL_STORE_MEDIA_SENSOR_DETAIL_RAW_DATA` (
    RETAIL_STORE_FACILITY_NBR STRING,
    MEDIA_ZONE_CD STRING,
    MEDIA_SENSOR_ID STRING,
    MEDIA_SENSOR_TYPE_CD STRING,
    DW_FILE_PATH STRING,
    DW_CREATE_TS TIMESTAMP,
    SOURCE_APPLICATION_CD STRING,
    JOB_ID STRING
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
