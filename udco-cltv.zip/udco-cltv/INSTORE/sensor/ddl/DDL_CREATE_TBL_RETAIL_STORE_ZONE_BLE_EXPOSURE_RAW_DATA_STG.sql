-- Create staging table for sensor raw data
CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.RETAIL_STORE_ZONE_BLE_EXPOSURE_RAW_DATA_STG` (
    BEACON_ID STRING,
    RETAIL_STORE_FACILITY_NBR STRING,
    MEDIA_ZONE_CD STRING,
    REGISTER_NBR STRING,    
    ZONE_ARRIVAL_TS STRING,
    ZONE_DEPARTURE_TS STRING,
    SESSION_ID STRING,
    DW_FILE_PATH STRING,
    DW_CREATE_TS TIMESTAMP,
    FORMAT STRING,
    SOURCE_APPLICATION_CD STRING,
    HEADER_LINE STRING,
    FOOTER_LINE STRING,
    JOB_ID STRING
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
