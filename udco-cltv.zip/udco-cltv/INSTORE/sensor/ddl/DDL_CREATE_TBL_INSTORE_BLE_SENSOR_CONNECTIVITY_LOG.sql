-- Create table for mmwave sensor connectivity log
CREATE EXTERNAL TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.EXT_INSTORE_BLE_SENSOR_CONNECTIVITY_LOG` 
(
  STORE_ID STRING,
  SENSOR_ID STRING,
  CONNECTION_STATUS STRING,
  LAST_CONNECTED STRING,
  FAILURE_REASON STRING
)
OPTIONS(
  --labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')],
  skip_leading_rows=1,
  format="CSV", 
  uris=["gs://<<GCSBUCKET>>/external/udco-cltv/inbound/stratacache/ble_sensor_connectivity_log/ble_sensor_connectivity_log*.csv"]
);
