CREATE TABLE IF NOT EXISTS `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_SENSOR_DETAIL` (
    MEDIA_SENSOR_ID STRING NOT NULL,
    MEDIA_SENSOR_TYPE_CD STRING NOT NULL,
    DW_CREATE_TS TIMESTAMP NOT NULL,
    DW_LAST_UPDATE_TS TIMESTAMP NOT NULL,
    SOURCE_APPLICATION_CD STRING,
    JOB_ID STRING
)
OPTIONS (labels = [('appcode','maid'),('bodname','instore'),('domainname','collect'),('environment','<<ENV>>')]);
