CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_RETAIL_STORE_MEDIA_SENSOR_DETAIL_VALIDATE_AND_INSERT_DATA`(job_id STRING)
BEGIN

--  Steps:
    --  a.  Do the validation on the records in staging table.
    --      (this staging table will only contain delta records)
    --  b.  Insert valid data into valid data table.
    --  c.  Insert invalid data into invalid data table

    DECLARE project_id STRING;
    DECLARE project_id_lookup_store STRING;
    DECLARE lookup_dataset STRING;
    DECLARE lookup_table STRING;
    DECLARE refined_dataset STRING;
    DECLARE confirmed_dataset STRING;
    DECLARE raw_data_stg_table STRING;
    DECLARE media_sensor_detail_valid_data_table STRING;
    DECLARE retail_store_media_sensor_valid_data_table STRING;
    DECLARE invalid_data_table STRING;
    DECLARE sql_string STRING;
    DECLARE record_count INT64;
    DECLARE current_job_id STRING;
    DECLARE transaction_started BOOL;

    -- Set variable values
    SET project_id = 'gcp-abs-udco-bq-<<ENV>>-prj-01';
	SET project_id_lookup_store = 'gcp-abs-udco-bqvw-<<ENV>>-prj-01';
    SET lookup_dataset = '<<RETAILSTORE_DATASET>>';
    SET lookup_table = 'D1_RETAIL_STORE';
    SET refined_dataset = 'udco_ds_cltv_refined';
    SET confirmed_dataset = 'udco_ds_cltv_confirmed';
    SET raw_data_stg_table = 'RETAIL_STORE_MEDIA_SENSOR_DETAIL_RAW_DATA_STG';
    SET media_sensor_detail_valid_data_table = 'MEDIA_SENSOR_DETAIL';
	SET retail_store_media_sensor_valid_data_table = 'RETAIL_STORE_MEDIA_SENSOR';
    SET invalid_data_table = 'RETAIL_STORE_MEDIA_SENSOR_DETAIL_INVALID_DATA';
    SET current_job_id = job_id;
    SET transaction_started = FALSE;


BEGIN
    -- BEGIN TRANSACTION BEFORE INSERTING/MERGING TO TARGET TABLES
    BEGIN TRANSACTION;

    -- Set transaction_started to TRUE to indicate that the transaction has started
    SET transaction_started = TRUE;

    ---------------------------Start of validation-------------------------------------------
    -- Below query is responsible for doing the below validations
    -- 1. null check for the columns
    -- 2. if DETECTION_TIME is future TIMESTAMP
    -- 3. if store_id and zone_id mapping is valid (from lookup table)
    -- 4. Duplicate record check based on RETAIL_STORE_FACILITY_NBR, MEDIA_ZONE_CD, MEDIA_SENSOR_ID combination

    SET sql_string = """
		CREATE TEMP TABLE RETAIL_STORE_MEDIA_SENSOR_DETAIL_WITH_VALIDATION_STATUS AS
		WITH
		 
		-- CTE 1: Source Data
		SOURCEDATA AS (
			SELECT
				S.RETAIL_STORE_FACILITY_NBR,
				S.MEDIA_ZONE_CD,
				S.MEDIA_SENSOR_ID,
				S.MEDIA_SENSOR_TYPE_CD,
				S.DW_FILE_PATH,
				S.DW_CREATE_TS,
                IFNULL(M.DW_CREATE_TS,S.DW_CREATE_TS) MEDIA_SENSOR_DW_CREATE_TS,
                IFNULL(R.DW_CREATE_TS,S.DW_CREATE_TS) RETAIL_STORE_MEDIA_SENSOR_DW_CREATE_TS,
				S.SOURCE_APPLICATION_CD,
				S.JOB_ID,
				L.FACILITY_INTEGRATION_ID
			FROM
				`""" || project_id || "." || refined_dataset || "." || raw_data_stg_table || """` AS S
			LEFT JOIN (
				SELECT DISTINCT
					FACILITY_INTEGRATION_ID,
					RETAIL_STORE_FACILITY_NBR
				FROM
					`""" || lookup_dataset || "." || lookup_table || """`
            WHERE DW_LOGICAL_DELETE_IND = FALSE
			) AS L
			ON TRIM(IFNULL(S.RETAIL_STORE_FACILITY_NBR,'')) = TRIM(IFNULL(L.RETAIL_STORE_FACILITY_NBR,''))
            LEFT JOIN (
                SELECT 
                    MEDIA_SENSOR_ID,
                    MAX(DW_CREATE_TS) DW_CREATE_TS
                FROM
                    `""" || project_id || "." || confirmed_dataset || "." || media_sensor_detail_valid_data_table || """`
                GROUP BY 
                MEDIA_SENSOR_ID) AS M
            ON S.MEDIA_SENSOR_ID = M.MEDIA_SENSOR_ID
            LEFT JOIN (
                SELECT 
                    FACILITY_INTEGRATION_ID,
                    MAX(DW_CREATE_TS) DW_CREATE_TS
                FROM
                    `""" || project_id || "." || confirmed_dataset || "." || retail_store_media_sensor_valid_data_table || """`
                GROUP BY 
                FACILITY_INTEGRATION_ID) AS R
            ON CAST((L.FACILITY_INTEGRATION_ID) AS INT64) = R.FACILITY_INTEGRATION_ID
		),
		 
		-- CTE 2: Null and Format Validation
		NULLFORMATVALIDATION AS (
			SELECT
				*,
				CASE WHEN RETAIL_STORE_FACILITY_NBR IS NULL OR TRIM(RETAIL_STORE_FACILITY_NBR) = '' THEN 'RETAIL_STORE_FACILITY_NBR is null/empty; ' ELSE '' END AS RETAIL_STORE_FACILITY_NBRError,
				CASE WHEN SAFE_CAST(TRIM(MEDIA_ZONE_CD) AS INT64) IS NULL THEN 'MEDIA_ZONE_CD is null/empty or not a number; ' ELSE '' END AS ZoneIdError,
				CASE WHEN MEDIA_SENSOR_ID IS NULL OR TRIM(MEDIA_SENSOR_ID) = '' THEN 'MEDIA_SENSOR_ID is null/empty; ' ELSE '' END AS SensorIdError,				
				CASE WHEN MEDIA_SENSOR_TYPE_CD IS NULL OR TRIM(MEDIA_SENSOR_TYPE_CD) = '' THEN 'MEDIA_SENSOR_TYPE_CD is null/empty; ' ELSE '' END AS MEDIA_SENSOR_TYPE_CDError
			FROM SOURCEDATA
		),
		 
		-- CTE 3: Lookup Validation
		LOOKUPVALIDATION AS (
			SELECT
				*,
				CASE WHEN SAFE_CAST(FACILITY_INTEGRATION_ID AS INT64) IS NULL THEN 'Invalid store_id; ' ELSE '' END AS LookupError
			FROM NULLFORMATVALIDATION
		),
		 
		-- CTE 5: Combine All Errors
		COMBINEDVALIDATION AS (
			SELECT
				RETAIL_STORE_FACILITY_NBR,
				FACILITY_INTEGRATION_ID,
				MEDIA_ZONE_CD,
				MEDIA_SENSOR_ID,
				MEDIA_SENSOR_TYPE_CD,
				DW_FILE_PATH,
				DW_CREATE_TS,
                MEDIA_SENSOR_DW_CREATE_TS,
                RETAIL_STORE_MEDIA_SENSOR_DW_CREATE_TS,
				SOURCE_APPLICATION_CD,
				JOB_ID,
				CONCAT(
					RETAIL_STORE_FACILITY_NBRError,
					ZoneIdError,
					SensorIdError,
					MEDIA_SENSOR_TYPE_CDError,
					LookupError
				) AS ERR_MSG
			FROM LOOKUPVALIDATION
		),
		 
		-- CTE 6: Deduplication
		DEDUPLICATED AS (
			SELECT
				*,
				ROW_NUMBER() OVER (
					PARTITION BY
						TRIM(RETAIL_STORE_FACILITY_NBR),
						TRIM(MEDIA_ZONE_CD),
						TRIM(MEDIA_SENSOR_ID)
					ORDER BY
						TRIM(ERR_MSG) = '' DESC,SAFE_CAST(DW_CREATE_TS AS TIMESTAMP) DESC
				) AS RN
			FROM COMBINEDVALIDATION
		)
		 
		-- Final SELECT
		SELECT
			RETAIL_STORE_FACILITY_NBR,
			FACILITY_INTEGRATION_ID,
			MEDIA_ZONE_CD,
			MEDIA_SENSOR_ID,
			MEDIA_SENSOR_TYPE_CD,
			IF(RN > 1, 'Duplicate record for same RETAIL_STORE_FACILITY_NBR,MEDIA_SENSOR_ID,MEDIA_ZONE_CD; ', '') || ERR_MSG AS ERR_MSG,
			DW_FILE_PATH,
			DW_CREATE_TS,
            MEDIA_SENSOR_DW_CREATE_TS,
            RETAIL_STORE_MEDIA_SENSOR_DW_CREATE_TS,
			SOURCE_APPLICATION_CD,
			JOB_ID
		FROM DEDUPLICATED;
    """;
    EXECUTE IMMEDIATE sql_string;
    ---------------------------------------End of validation--------------------------

    -- Delete data from MEDIA_SENSOR_DETAIL
    SET sql_string = """
    DELETE FROM `""" || project_id || "." || confirmed_dataset || "." || media_sensor_detail_valid_data_table || """` WHERE
    MEDIA_SENSOR_ID IN (SELECT DISTINCT B.MEDIA_SENSOR_ID FROM RETAIL_STORE_MEDIA_SENSOR_DETAIL_WITH_VALIDATION_STATUS A INNER JOIN
    `""" || project_id || "." || confirmed_dataset || "." || retail_store_media_sensor_valid_data_table || """` B ON 
    A.FACILITY_INTEGRATION_ID = B.FACILITY_INTEGRATION_ID) AND 
    JOB_ID <> '""" || current_job_id || """';
    """;
    EXECUTE IMMEDIATE sql_string;


    -- Merge valid data into table MEDIA_SENSOR_DETAIL
    SET sql_string = """
        MERGE
            `""" || project_id || "." || confirmed_dataset || "." || media_sensor_detail_valid_data_table || """` T
        USING(
            SELECT DISTINCT
                MEDIA_SENSOR_ID,
                MEDIA_SENSOR_TYPE_CD,
                MEDIA_SENSOR_DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                RETAIL_STORE_MEDIA_SENSOR_DETAIL_WITH_VALIDATION_STATUS
            WHERE
                TRIM(ERR_MSG) = ''
        ) S
        ON
            T.MEDIA_SENSOR_ID = TRIM(S.MEDIA_SENSOR_ID)
        WHEN NOT MATCHED THEN
            INSERT (MEDIA_SENSOR_ID, MEDIA_SENSOR_TYPE_CD, DW_CREATE_TS,DW_LAST_UPDATE_TS, SOURCE_APPLICATION_CD, JOB_ID)
            VALUES(TRIM(S.MEDIA_SENSOR_ID), TRIM(S.MEDIA_SENSOR_TYPE_CD), S.MEDIA_SENSOR_DW_CREATE_TS,CURRENT_TIMESTAMP(), S.SOURCE_APPLICATION_CD, S.JOB_ID);
    """;
    EXECUTE IMMEDIATE sql_string;
	

    -- Delete data from RETAIL_STORE_MEDIA_SENSOR
    SET sql_string = """
    DELETE FROM `""" || project_id || "." || confirmed_dataset || "." || retail_store_media_sensor_valid_data_table || """` WHERE
    FACILITY_INTEGRATION_ID IN (SELECT DISTINCT FACILITY_INTEGRATION_ID FROM RETAIL_STORE_MEDIA_SENSOR_DETAIL_WITH_VALIDATION_STATUS) AND 
    JOB_ID <> '""" || current_job_id || """';
    """;
    EXECUTE IMMEDIATE sql_string;
	
	-- Merge valid data into table RETAIL_STORE_MEDIA_SENSOR
    SET sql_string = """
        MERGE
            `""" || project_id || "." || confirmed_dataset || "." || retail_store_media_sensor_valid_data_table || """` T
        USING(
            SELECT
                FACILITY_INTEGRATION_ID,
                MEDIA_ZONE_CD,
                MEDIA_SENSOR_ID,
                RETAIL_STORE_MEDIA_SENSOR_DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                RETAIL_STORE_MEDIA_SENSOR_DETAIL_WITH_VALIDATION_STATUS
            WHERE
                TRIM(ERR_MSG) = ''
        ) S
        ON
            T.FACILITY_INTEGRATION_ID = CAST((S.FACILITY_INTEGRATION_ID) AS INT64) AND
            T.MEDIA_ZONE_CD = TRIM(S.MEDIA_ZONE_CD) AND
            T.MEDIA_SENSOR_ID = TRIM(S.MEDIA_SENSOR_ID)
        WHEN NOT MATCHED THEN
            INSERT (FACILITY_INTEGRATION_ID, MEDIA_ZONE_CD, MEDIA_SENSOR_ID, DW_CREATE_TS,DW_LAST_UPDATE_TS , SOURCE_APPLICATION_CD, JOB_ID)
            VALUES(CAST(S.FACILITY_INTEGRATION_ID AS INT64), TRIM(S.MEDIA_ZONE_CD), TRIM(S.MEDIA_SENSOR_ID), S.RETAIL_STORE_MEDIA_SENSOR_DW_CREATE_TS, CURRENT_TIMESTAMP(), S.SOURCE_APPLICATION_CD, S.JOB_ID);
    """;
    EXECUTE IMMEDIATE sql_string;

    -- Insert invalid records into table
    -- Check if the table has records for the given job_id
    EXECUTE IMMEDIATE FORMAT("""
        SELECT COUNT(1)
        FROM `%s.%s.%s`
        WHERE JOB_ID = '%s'
    """, project_id, refined_dataset, invalid_data_table, current_job_id)
    INTO record_count;
    -- If no records exist for the job_id, proceed with the insert
    IF record_count = 0 THEN
        SET sql_string = """
            INSERT INTO `""" || project_id || "." || refined_dataset || "." || invalid_data_table || """`
            SELECT
                RETAIL_STORE_FACILITY_NBR,
                MEDIA_ZONE_CD,
                MEDIA_SENSOR_ID,
                MEDIA_SENSOR_TYPE_CD,
                ERR_MSG,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
                RETAIL_STORE_MEDIA_SENSOR_DETAIL_WITH_VALIDATION_STATUS
            WHERE
                TRIM(ERR_MSG) <> ''
        """;
        EXECUTE IMMEDIATE sql_string;
    END IF;

    -- COMMITTING THE TRANSACTION AFTER ALL INSERTS/MERGE IS DONE
    COMMIT TRANSACTION;
    EXCEPTION WHEN ERROR THEN
    -- ROLLBACK THE TRANSACTION INSIDE THE EXCEPTION HANDLER.
    SELECT @@error.message;
    -- Check if the transaction was started before rolling back
    IF transaction_started THEN
        ROLLBACK TRANSACTION;
    END IF;
    RAISE USING message = FORMAT("Error while processing sensor data: %s.", @@error.message);
END;
END;