CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_RETAIL_STORE_ZONE_MMWAVE_EXPOSURE_VALIDATE_AND_INSERT_DATA`(
  job_id STRING
)
BEGIN



  -- Variable declarations
  DECLARE project_id STRING;
  DECLARE project_id_lookup_store STRING;
  DECLARE lookup_dataset STRING;
  DECLARE lookup_table STRING;
  DECLARE lookup_dataset_store STRING;
  DECLARE lookup_table_store STRING;
  DECLARE refined_dataset STRING;
  DECLARE confirmed_dataset STRING;
  DECLARE mmwave_raw_data_stg_table STRING;
  DECLARE mmwave_valid_data_table STRING;
  DECLARE mmwave_invalid_data_table STRING;
  DECLARE sql_string STRING;
  DECLARE record_count INT64;
  DECLARE current_job_id STRING;
  DECLARE mmwave_mmwave_sensor_connectivity_log_table STRING;
  DECLARE lookup_table_sensor_detail STRING;



  -- Set variable values
  SET project_id = 'gcp-abs-udco-bq-<<ENV>>-prj-01';
  SET project_id_lookup_store = 'gcp-abs-udco-bqvw-<<ENV>>-prj-01';
  SET lookup_dataset = 'udco_ds_cltv_confirmed';
  SET lookup_table = 'RETAIL_STORE_MEDIA_SENSOR';
  SET lookup_table_sensor_detail = 'MEDIA_SENSOR_DETAIL';
  SET lookup_dataset_store = '<<RETAILSTORE_DATASET>>';
  SET lookup_table_store = 'D1_RETAIL_STORE';
  SET refined_dataset = 'udco_ds_cltv_refined';
  SET confirmed_dataset = 'udco_ds_cltv_confirmed';
  SET mmwave_raw_data_stg_table = 'RETAIL_STORE_ZONE_MMWAVE_EXPOSURE_RAW_DATA_STG';
  SET mmwave_valid_data_table = 'RETAIL_STORE_ZONE_MMWAVE_EXPOSURE';
  SET mmwave_invalid_data_table = 'RETAIL_STORE_ZONE_MMWAVE_EXPOSURE_INVALID_DATA';
  SET mmwave_mmwave_sensor_connectivity_log_table = 'EXT_INSTORE_MMWAVE_SENSOR_CONNECTIVITY_LOG';
  SET current_job_id = job_id;



  -- Step 1: Validation using temporary table
  SET sql_string = """
    CREATE TEMP TABLE MMWAVE_DATA_WITH_VALIDATION_STATUS AS
    WITH



    SOURCEDATA AS (
      SELECT
        S.RETAIL_STORE_FACILITY_NBR,
        S.MEDIA_ZONE_CD,
        S.MEDIA_SENSOR_ID,
        S.INTERVAL_START_TS,
        S.INTERVAL_END_TS,
        S.SHOPPER_CNT,
        S.DW_FILE_PATH,
        S.DW_CREATE_TS,
        S.SOURCE_APPLICATION_CD,
        S.JOB_ID,
        LS.FACILITY_INTEGRATION_ID,
        L.FACILITY_INTEGRATION_ID AS MEDIA_SENSOR_FACILITY_INTEGRATION_ID
      FROM
        `""" || project_id || "." || refined_dataset || "." || mmwave_raw_data_stg_table || """` AS S
      LEFT JOIN (
        SELECT 
		DISTINCT 
		FACILITY_INTEGRATION_ID, 
		RETAIL_STORE_FACILITY_NBR
        FROM `""" || lookup_dataset_store || "." || lookup_table_store || """`
        WHERE DW_LOGICAL_DELETE_IND = FALSE
      ) AS LS
      ON SAFE_CAST(S.RETAIL_STORE_FACILITY_NBR AS INT64) = SAFE_CAST(LS.RETAIL_STORE_FACILITY_NBR AS INT64)
      LEFT JOIN (
        SELECT 
		DISTINCT 
		FACILITY_INTEGRATION_ID, 
		MEDIA_ZONE_CD, 
		MEDIA_SENSOR_ID
        FROM `""" || project_id || "." || lookup_dataset || "." || lookup_table || """`
      ) AS L
      ON SAFE_CAST(LS.FACILITY_INTEGRATION_ID AS INT64) = SAFE_CAST(L.FACILITY_INTEGRATION_ID AS INT64)
         AND TRIM(IFNULL(S.MEDIA_ZONE_CD, '')) = TRIM(IFNULL(L.MEDIA_ZONE_CD, ''))
         AND TRIM(IFNULL(S.MEDIA_SENSOR_ID, '')) = TRIM(IFNULL(L.MEDIA_SENSOR_ID, ''))
    WHERE S.JOB_ID = '""" || current_job_id || """'
    ),



    NULLFORMATVALIDATION AS (
      SELECT
        *,
        CASE WHEN RETAIL_STORE_FACILITY_NBR IS NULL OR TRIM(RETAIL_STORE_FACILITY_NBR) = '' THEN 'RETAIL_STORE_FACILITY_NBR is null/empty; ' ELSE '' END AS StoreNbrError,
        CASE WHEN MEDIA_ZONE_CD IS NULL OR TRIM(MEDIA_ZONE_CD) = '' THEN 'MEDIA_ZONE_CD is null/empty; ' ELSE '' END AS ZoneIdError,
        CASE WHEN MEDIA_SENSOR_ID IS NULL OR TRIM(MEDIA_SENSOR_ID) = '' THEN 'MEDIA_SENSOR_ID is null/empty; ' ELSE '' END AS SensorIdError,
        CASE WHEN SAFE_CAST(TRIM(INTERVAL_START_TS) AS TIMESTAMP) IS NULL THEN 'INTERVAL_START_TS is invalid; ' ELSE '' END AS StartTsError,
        CASE WHEN SAFE_CAST(TRIM(INTERVAL_END_TS) AS TIMESTAMP) IS NULL THEN 'INTERVAL_END_TS is invalid; ' ELSE '' END AS EndTsError,
        CASE WHEN SAFE_CAST(TRIM(SHOPPER_CNT) AS INT64) IS NULL THEN 'SHOPPER_CNT is invalid; ' ELSE '' END AS ShopperCntError
      FROM SOURCEDATA
    ),



    TIMESTAMPVALIDATION AS (
      SELECT
        *,
        CASE WHEN SAFE_CAST(TRIM(INTERVAL_START_TS) AS TIMESTAMP) > CURRENT_TIMESTAMP() THEN 'INTERVAL_START_TS is a future timestamp; ' ELSE '' END AS StartFutureError,
        CASE WHEN SAFE_CAST(TRIM(INTERVAL_END_TS) AS TIMESTAMP) > CURRENT_TIMESTAMP() THEN 'INTERVAL_END_TS is a future timestamp; ' ELSE '' END AS EndFutureError,
		CASE WHEN SAFE_CAST(TRIM(INTERVAL_START_TS) AS TIMESTAMP) IS NOT NULL AND SAFE_CAST(TRIM(INTERVAL_END_TS) AS TIMESTAMP) IS NOT NULL AND SAFE_CAST(TRIM(INTERVAL_START_TS) AS TIMESTAMP) > SAFE_CAST(TRIM(INTERVAL_END_TS) AS TIMESTAMP) THEN 'INTERVAL_START_TS is after INTERVAL_END_TS; ' ELSE '' END AS ArrivalAfterDepartureError
	  FROM NULLFORMATVALIDATION
    ),



    LOOKUPVALIDATION AS (
      SELECT
        *,
        CASE WHEN SAFE_CAST(FACILITY_INTEGRATION_ID AS INT64) IS NULL THEN 'Invalid FACILITY_INTEGRATION_ID; ' ELSE '' END AS StoreIdError,
        CASE WHEN MEDIA_SENSOR_FACILITY_INTEGRATION_ID IS NULL THEN 'Invalid store_id and zone_id and sensor_id mapping; ' ELSE '' END AS LookupError
      FROM TIMESTAMPVALIDATION
    ),



    COMBINEDVALIDATION AS (
      SELECT
        FACILITY_INTEGRATION_ID,
        RETAIL_STORE_FACILITY_NBR,
        MEDIA_ZONE_CD,
        MEDIA_SENSOR_ID,
        INTERVAL_START_TS,
        INTERVAL_END_TS,
        SHOPPER_CNT,
        DW_FILE_PATH,
        DW_CREATE_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID,
        CONCAT(
          StoreIdError, 
		  StoreNbrError, 
		  ZoneIdError, 
		  SensorIdError,
          StartTsError, 
		  EndTsError, 
		  ShopperCntError,
          StartFutureError, 
		  EndFutureError, 
		  ArrivalAfterDepartureError,
		  LookupError
        ) AS ERR_MSG
      FROM LOOKUPVALIDATION
    ),



    DEDUPLICATED AS (
      SELECT *,
        ROW_NUMBER() OVER (
          PARTITION BY
            FACILITY_INTEGRATION_ID,
            TRIM(RETAIL_STORE_FACILITY_NBR),
            TRIM(MEDIA_ZONE_CD),
            TRIM(MEDIA_SENSOR_ID),
            SAFE_CAST(TRIM(INTERVAL_START_TS) AS TIMESTAMP)
          ORDER BY TRIM(ERR_MSG) = '' DESC,SAFE_CAST(TRIM(INTERVAL_START_TS) AS TIMESTAMP) DESC
        ) AS RN
      FROM COMBINEDVALIDATION
    )



    SELECT
      FACILITY_INTEGRATION_ID,
      RETAIL_STORE_FACILITY_NBR,
      MEDIA_ZONE_CD,
      MEDIA_SENSOR_ID,
      INTERVAL_START_TS,
      INTERVAL_END_TS,
      SHOPPER_CNT,
      IF(RN > 1, 'Duplicate record for same FACILITY_INTEGRATION_ID,SENSOR_ID,ZONE_CD and TIMESTAMP range; ', '') || ERR_MSG AS ERR_MSG,
      DW_FILE_PATH,
      DW_CREATE_TS,
      SOURCE_APPLICATION_CD,
      JOB_ID
    FROM DEDUPLICATED;
  """;



  EXECUTE IMMEDIATE sql_string;



  -- Step 2: Merge valid records
  SET sql_string = """
    MERGE `""" || project_id || "." || confirmed_dataset || "." || mmwave_valid_data_table || """` T
    USING (
      SELECT
        FACILITY_INTEGRATION_ID,
        MEDIA_ZONE_CD,
        MEDIA_SENSOR_ID,
        INTERVAL_START_TS,
        INTERVAL_END_TS,
        SHOPPER_CNT,
        DW_CREATE_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID
      FROM MMWAVE_DATA_WITH_VALIDATION_STATUS
      WHERE TRIM(ERR_MSG) = ''
    ) S
    ON
      T.FACILITY_INTEGRATION_ID = CAST(S.FACILITY_INTEGRATION_ID AS INT64)
      AND T.MEDIA_ZONE_CD = TRIM(S.MEDIA_ZONE_CD)
      AND T.MEDIA_SENSOR_ID = TRIM(S.MEDIA_SENSOR_ID)
      AND CAST(T.INTERVAL_START_TS AS TIMESTAMP) = CAST(TRIM(S.INTERVAL_START_TS) AS TIMESTAMP)
    WHEN NOT MATCHED THEN
      INSERT (
        FACILITY_INTEGRATION_ID,
        MEDIA_ZONE_CD,
        MEDIA_SENSOR_ID,
        INTERVAL_START_TS,
        INTERVAL_END_TS,
        SHOPPER_CNT,
        DW_CREATE_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID
      )
      VALUES (
        CAST(S.FACILITY_INTEGRATION_ID AS INT64),
        TRIM(S.MEDIA_ZONE_CD),
        TRIM(S.MEDIA_SENSOR_ID),
        CAST(TRIM(S.INTERVAL_START_TS) AS TIMESTAMP),
        CAST(TRIM(S.INTERVAL_END_TS) AS TIMESTAMP),
        CAST(TRIM(S.SHOPPER_CNT) AS INT64),
        S.DW_CREATE_TS,
        S.SOURCE_APPLICATION_CD,
        S.JOB_ID
      )
  """;



  EXECUTE IMMEDIATE sql_string;



  -- Step 3: Insert invalid records if none exist for this job
  SET sql_string = """
    SELECT COUNT(1)
    FROM `""" || project_id || "." || refined_dataset || "." || mmwave_invalid_data_table || """`
    WHERE JOB_ID = '""" || current_job_id || """'
  """;
  EXECUTE IMMEDIATE sql_string INTO record_count;



  IF record_count = 0 THEN
    SET sql_string = """
      INSERT INTO `""" || project_id || "." || refined_dataset || "." || mmwave_invalid_data_table || """`
      SELECT
        RETAIL_STORE_FACILITY_NBR,
        MEDIA_ZONE_CD,
        MEDIA_SENSOR_ID,
        INTERVAL_START_TS,
        INTERVAL_END_TS,
        SHOPPER_CNT,
        ERR_MSG,
        DW_FILE_PATH,
        DW_CREATE_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID
      FROM MMWAVE_DATA_WITH_VALIDATION_STATUS
      WHERE TRIM(ERR_MSG) <> ''

      UNION ALL

      SELECT
        RETAIL_STORE_FACILITY_NBR,
        MEDIA_ZONE_CD,
        MEDIA_SENSOR_ID,
        '' AS INTERVAL_START_TS,
        '' AS INTERVAL_END_TS,
        '' AS SHOPPER_CNT,
        ERR_MSG,
        DW_FILE_PATH,
        DW_CREATE_TS,
        SOURCE_APPLICATION_CD,
        JOB_ID              
    FROM (
      SELECT DISTINCT 
        S.RETAIL_STORE_FACILITY_NBR,
        S.MEDIA_ZONE_CD,
        S.MEDIA_SENSOR_ID,
        CASE WHEN UPPER(TRIM(LOG.CONNECTION_STATUS))='DISCONNECTED' THEN 'Sensor is disconnected and no data flowing in MMWAVE_EXPOSURE table '
             WHEN UPPER(TRIM(LOG.CONNECTION_STATUS))='CONNECTED' THEN 'Sensor is connected but no data flowing in MMWAVE_EXPOSURE table '
             ELSE 'Not receiving any data for this STOREID/ZONE_ID/SENSOR_ID' END AS ERR_MSG,
        S.DW_FILE_PATH,
        S.DW_CREATE_TS,
        S.SOURCE_APPLICATION_CD,
        S.JOB_ID
      FROM 
        ( SELECT 
          DISTINCT 
          LS.RETAIL_STORE_FACILITY_NBR,
          S.FACILITY_INTEGRATION_ID, 
          S.MEDIA_ZONE_CD, 
          S.MEDIA_SENSOR_ID,
          RAW.DW_FILE_PATH,
          RAW.DW_CREATE_TS,
          RAW.SOURCE_APPLICATION_CD,
          RAW.JOB_ID 
        FROM 
          `""" || project_id || "." || lookup_dataset || "." || lookup_table || """` S 
          INNER JOIN
          (SELECT * FROM `""" || project_id || "." || lookup_dataset || "." || lookup_table_sensor_detail || """` WHERE UPPER(MEDIA_SENSOR_TYPE_CD)='MMWAVE')S1
          ON S.MEDIA_SENSOR_ID=S1.MEDIA_SENSOR_ID
          INNER JOIN
          `""" || lookup_dataset_store || "." || lookup_table_store || """` LS
          ON LS.FACILITY_INTEGRATION_ID= S.FACILITY_INTEGRATION_ID
          AND LS.DW_LOGICAL_DELETE_IND = FALSE
          CROSS JOIN
            (SELECT DISTINCT 
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID   
              FROM 
                MMWAVE_DATA_WITH_VALIDATION_STATUS
            ) RAW
          ) S
      LEFT JOIN 
        ( SELECT 
          DISTINCT  
          RETAIL_STORE_FACILITY_NBR,
          MEDIA_ZONE_CD,
          MEDIA_SENSOR_ID
        FROM MMWAVE_DATA_WITH_VALIDATION_STATUS
          ) AS RAW
            ON SAFE_CAST(S.RETAIL_STORE_FACILITY_NBR AS INT64) = SAFE_CAST(RAW.RETAIL_STORE_FACILITY_NBR AS INT64)
            AND TRIM(IFNULL(S.MEDIA_ZONE_CD, '')) = TRIM(IFNULL(RAW.MEDIA_ZONE_CD, ''))
            AND TRIM(IFNULL(S.MEDIA_SENSOR_ID, '')) = TRIM(IFNULL(RAW.MEDIA_SENSOR_ID, ''))
      LEFT JOIN 
        ( SELECT 
          DISTINCT  
          STORE_ID AS RETAIL_STORE_FACILITY_NBR,
          SENSOR_ID AS MEDIA_SENSOR_ID,
          CONNECTION_STATUS
        FROM `""" || project_id || "." || refined_dataset || "." || mmwave_mmwave_sensor_connectivity_log_table || """` 
          WHERE 
            PARSE_DATE('%Y-%m-%d',SUBSTR(_FILE_NAME,STRPOS(_FILE_NAME, 'log_') + LENGTH('log_'),(STRPOS(SUBSTR(_FILE_NAME, STRPOS(_FILE_NAME, 'log_') + LENGTH('log_')),'_') - 1))) =(SELECT MAX(DATE(DW_CREATE_TS)) 
            FROM MMWAVE_DATA_WITH_VALIDATION_STATUS)
          ) AS LOG
            ON SAFE_CAST(S.RETAIL_STORE_FACILITY_NBR AS INT64) = SAFE_CAST(LOG.RETAIL_STORE_FACILITY_NBR AS INT64)
            AND TRIM(IFNULL(S.MEDIA_SENSOR_ID, '')) = TRIM(IFNULL(LOG.MEDIA_SENSOR_ID, ''))  
            WHERE  RAW.RETAIL_STORE_FACILITY_NBR IS NULL  
    )
    """;
    EXECUTE IMMEDIATE sql_string;
  END IF;



END;
 
