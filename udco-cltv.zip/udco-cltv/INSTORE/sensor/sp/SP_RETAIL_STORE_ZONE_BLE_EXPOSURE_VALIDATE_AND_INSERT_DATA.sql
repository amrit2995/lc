CREATE OR REPLACE PROCEDURE `gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_refined.SP_RETAIL_STORE_ZONE_BLE_EXPOSURE_VALIDATE_AND_INSERT_DATA` (job_id STRING)
BEGIN
 
--  Steps:
    --  a.  Do the validation on the records in staging table.
    --      (this staging table will only contain delta records)
    --  b.  Insert valid data into valid data table.
    --  c.  Insert invalid data into invalid data table
 
    DECLARE project_id STRING;
    DECLARE project_id_lookup_store STRING;
    DECLARE lookup_dataset STRING;
    DECLARE lookup_table STRING;
    DECLARE lookup_dataset_store STRING;
    DECLARE lookup_table_store STRING;
    DECLARE refined_dataset STRING;
    DECLARE confirmed_dataset STRING;
    DECLARE sensor_raw_data_stg_table STRING;
    DECLARE sensor_valid_data_table STRING;
    DECLARE sensor_invalid_data_table STRING;
    DECLARE sql_string STRING;
    DECLARE record_count INT64;
    DECLARE current_job_id STRING;
 
    -- Set variable values
    SET project_id = 'gcp-abs-udco-bq-<<ENV>>-prj-01';
    SET project_id_lookup_store = 'gcp-abs-udco-bqvw-<<ENV>>-prj-01';
    SET lookup_dataset_store = '<<RETAILSTORE_DATASET>>';
    SET lookup_table_store = 'D1_RETAIL_STORE';
    SET lookup_dataset = 'udco_ds_cltv_confirmed';
    SET lookup_table = 'RETAIL_STORE_MEDIA_ZONE';
    SET refined_dataset = 'udco_ds_cltv_refined';
    SET confirmed_dataset = 'udco_ds_cltv_confirmed';
    SET sensor_raw_data_stg_table = 'RETAIL_STORE_ZONE_BLE_EXPOSURE_RAW_DATA_STG';
    SET sensor_valid_data_table = 'RETAIL_STORE_ZONE_BLE_EXPOSURE';
    SET sensor_invalid_data_table = 'RETAIL_STORE_ZONE_BLE_EXPOSURE_INVALID_DATA';
    SET current_job_id = job_id;
 
    ---------------------------Start of validation-------------------------------------------
    -- Below query is responsible for doing the below validations
    -- 1. null check for the columns
    -- 2. if arrival is after departure
    -- 3. if arrival or/and departure is future TIMESTAMP
    -- 4. if store_id,zone_id and register_id mapping is valid (from lookup table)
    -- 5. Duplicate record check based on tag_id and session_id combination
 
    SET sql_string = """
    CREATE TEMP TABLE SENSOR_DATA_WITH_VALIDATION_STATUS AS
    WITH
    -- CTE 1: Source Data
    SourceData AS (
        SELECT
            S.SESSION_ID,
            S.ZONE_ARRIVAL_TS,
            S.BEACON_ID,
            S.ZONE_DEPARTURE_TS,
            S.REGISTER_NBR,
            S.RETAIL_STORE_FACILITY_NBR,
            S.MEDIA_ZONE_CD,
            S.DW_FILE_PATH,
            S.DW_CREATE_TS,
            S.SOURCE_APPLICATION_CD,
            S.JOB_ID,
            TO_HEX(SHA256(CONCAT(COALESCE(S.SESSION_ID,''),SAFE_CAST(S.ZONE_ARRIVAL_TS AS TIMESTAMP),COALESCE(S.BEACON_ID,'')))) AS DW_CHECKSUM_VALUE_TXT,
            LS.FACILITY_INTEGRATION_ID,
            L.FACILITY_INTEGRATION_ID AS RETAIL_STORE_MEDIA_ZONE_FACILITY_INTEGRATION_ID
        FROM
            `""" || project_id || "." || refined_dataset || "." || sensor_raw_data_stg_table || """` AS S
        LEFT JOIN (
            SELECT DISTINCT
                FACILITY_INTEGRATION_ID,
                RETAIL_STORE_FACILITY_NBR
            FROM
                `""" || lookup_dataset_store || "." || lookup_table_store || """`
            WHERE DW_LOGICAL_DELETE_IND = FALSE
            ) AS LS
            ON TRIM(IFNULL(S.RETAIL_STORE_FACILITY_NBR,'')) = TRIM(IFNULL(LS.RETAIL_STORE_FACILITY_NBR,''))
        LEFT JOIN (
            SELECT DISTINCT
                FACILITY_INTEGRATION_ID,
                MEDIA_ZONE_CD,
                REGISTER_NBR
            FROM
                `""" || project_id || "." || lookup_dataset || "." || lookup_table || """`
            ) AS L
            ON SAFE_CAST(LS.FACILITY_INTEGRATION_ID AS INT64) = SAFE_CAST(L.FACILITY_INTEGRATION_ID AS INT64)
                AND TRIM(IFNULL(S.MEDIA_ZONE_CD, '')) = TRIM(IFNULL(L.MEDIA_ZONE_CD, ''))
                AND IFNULL(SAFE_CAST(S.REGISTER_NBR AS INT64),-1) = IFNULL(L.REGISTER_NBR,-1)
        WHERE S.JOB_ID = '""" || current_job_id || """'
    ),
 
 
    NullCheckValidation AS (
        SELECT *,
            CASE WHEN IFNULL(TRIM(BEACON_ID), '') = '' THEN 'BEACON_ID is null/empty; ' ELSE '' END AS BeaconIdError,
            CASE WHEN IFNULL(TRIM(RETAIL_STORE_FACILITY_NBR), '') = '' THEN 'RETAIL_STORE_FACILITY_NBR is null; ' ELSE '' END AS StoreIdError,
            CASE WHEN IFNULL(TRIM(MEDIA_ZONE_CD), '') = '' THEN 'MEDIA_ZONE_CD is null; ' ELSE '' END AS ZoneIdError,
            CASE WHEN ZONE_ARRIVAL_TS IS NULL THEN 'ZONE_ARRIVAL_TS is null; ' ELSE '' END AS ArrivalError,
            CASE WHEN ZONE_DEPARTURE_TS IS NULL THEN 'ZONE_DEPARTURE_TS is null; ' ELSE '' END AS DepartureError,
            CASE WHEN IFNULL(TRIM(SESSION_ID), '') = '' THEN 'SESSION_ID is null/empty; ' ELSE '' END AS SessionIdError
        FROM SourceData
    ),
    TimestampValidation AS (
        SELECT *,
            CASE WHEN SAFE_CAST(ZONE_ARRIVAL_TS AS TIMESTAMP) IS NULL AND ZONE_ARRIVAL_TS IS NOT NULL THEN 'ZONE_ARRIVAL_TS is invalid format; ' ELSE '' END AS ArrivalFormatError,
            CASE WHEN SAFE_CAST(ZONE_DEPARTURE_TS AS TIMESTAMP) IS NULL AND ZONE_DEPARTURE_TS IS NOT NULL THEN 'ZONE_DEPARTURE_TS is invalid format; ' ELSE '' END AS DepartureFormatError,
            CASE WHEN SAFE_CAST(ZONE_ARRIVAL_TS AS TIMESTAMP) IS NOT NULL AND SAFE_CAST(ZONE_DEPARTURE_TS AS TIMESTAMP) IS NOT NULL AND SAFE_CAST(ZONE_ARRIVAL_TS AS TIMESTAMP) > SAFE_CAST(ZONE_DEPARTURE_TS AS TIMESTAMP) THEN 'ZONE_ARRIVAL_TS is after ZONE_DEPARTURE_TS; ' ELSE '' END AS ArrivalAfterDepartureError,
            CASE WHEN SAFE_CAST(ZONE_ARRIVAL_TS AS TIMESTAMP) IS NOT NULL AND SAFE_CAST(ZONE_ARRIVAL_TS AS TIMESTAMP) > CURRENT_TIMESTAMP() THEN 'ZONE_ARRIVAL_TS is in the future; ' ELSE '' END AS ArrivalFutureError,
            CASE WHEN SAFE_CAST(ZONE_DEPARTURE_TS AS TIMESTAMP) IS NOT NULL AND SAFE_CAST(ZONE_DEPARTURE_TS AS TIMESTAMP) > CURRENT_TIMESTAMP() THEN 'ZONE_DEPARTURE_TS is in the future; ' ELSE '' END AS DepartureFutureError
        FROM NullCheckValidation
    ),
    LookupValidation AS (
        SELECT *,
            CASE WHEN FACILITY_INTEGRATION_ID IS NULL THEN 'Invalid FACILITY_INTEGRATION_ID; ' ELSE '' END AS LookupError,
            CASE WHEN RETAIL_STORE_MEDIA_ZONE_FACILITY_INTEGRATION_ID IS NULL THEN 'Invalid FACILITY_INTEGRATION_ID/MEDIA_ZONE_CD/REGISTER_NBR mapping; ' ELSE '' END AS LookupTableError            
            FROM TimestampValidation
    ),
    CombinedValidation AS (
        SELECT
            SESSION_ID,
            ZONE_ARRIVAL_TS,
            BEACON_ID,
            ZONE_DEPARTURE_TS,
            REGISTER_NBR,
            FACILITY_INTEGRATION_ID,
            RETAIL_STORE_FACILITY_NBR,
            MEDIA_ZONE_CD,
            DW_FILE_PATH,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID,
            DW_CHECKSUM_VALUE_TXT,
            CONCAT(
                BeaconIdError,
                StoreIdError,
                ZoneIdError,
                ArrivalError,
                DepartureError,
                SessionIdError,
                ArrivalFormatError,
                DepartureFormatError,
                ArrivalAfterDepartureError,
                ArrivalFutureError,
                DepartureFutureError,
                LookupError,
                LookupTableError
            ) AS ERR_MSG
        FROM LookupValidation
    ),
    Deduplicated_PK AS (
        SELECT *,
            ROW_NUMBER() OVER (
                PARTITION BY
                IFNULL(TRIM(SESSION_ID), ''),
                SAFE_CAST(ZONE_ARRIVAL_TS AS TIMESTAMP),
                IFNULL(TRIM(BEACON_ID), '')
                ORDER BY TRIM(ERR_MSG) = '' DESC,SAFE_CAST(ZONE_ARRIVAL_TS AS TIMESTAMP) DESC
            ) AS RN
        FROM CombinedValidation
    ),
    Deduplicated_PK_with_err_msg AS (
    SELECT
            SESSION_ID,
            ZONE_ARRIVAL_TS,
            BEACON_ID,
            ZONE_DEPARTURE_TS,
            REGISTER_NBR,
            FACILITY_INTEGRATION_ID,
            RETAIL_STORE_FACILITY_NBR,
            MEDIA_ZONE_CD,
            IF(RN > 1, 'Duplicate record - More than one record for same BEACON_ID/SESSION_ID/ARRIVAL_TS combination; ', '') || ERR_MSG AS ERR_MSG,
            DW_FILE_PATH,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID,
            DW_CHECKSUM_VALUE_TXT
    FROM Deduplicated_PK
    ),
    -- Following code is to eliminate records with different beacon_id within a session
    Deduplicated_session_id AS (
    SELECT
            SESSION_ID,
            BEACON_ID,
            ROW_NUMBER () OVER (PARTITION BY SESSION_ID ORDER BY TRIM(ERR_MSG)= '' DESC,ZONE_ARRIVAL_TS ASC) AS RN
    FROM  Deduplicated_PK_with_err_msg
    --WHERE TRIM(ERR_MSG)= ''
    ),
    Dedupicated_final AS (
    SELECT
            Deduplicated_PK_with_err_msg.*,
            CASE WHEN Deduplicated_session_id.BEACON_ID IS NULL THEN 'Duplicate BEACON_ID within a SESSION; ' || ERR_MSG
            ELSE ERR_MSG END AS ERR_MSG2
            FROM
            Deduplicated_PK_with_err_msg
            LEFT JOIN (SELECT * FROM Deduplicated_session_id WHERE RN = 1) AS Deduplicated_session_id
            ON IFNULL(TRIM(Deduplicated_PK_with_err_msg.SESSION_ID), '') = IFNULL(TRIM(Deduplicated_session_id.SESSION_ID), '')
            AND IFNULL(TRIM(Deduplicated_PK_with_err_msg.BEACON_ID), '') = IFNULL(TRIM(Deduplicated_session_id.BEACON_ID), '')
    ),
	
	 -- Check against existing records in target table to detect duplicates
     TEMP_BLE_SENSOR_DEDUPED AS 
	           ( 
            SELECT 
			TEMP.SESSION_ID,
            TEMP.ZONE_ARRIVAL_TS,
            TEMP.BEACON_ID,
            TEMP.ZONE_DEPARTURE_TS,
            TEMP.REGISTER_NBR,
            TEMP.FACILITY_INTEGRATION_ID,
            TEMP.RETAIL_STORE_FACILITY_NBR,
            TEMP.MEDIA_ZONE_CD,
			CASE 
                WHEN TARGET.BEACON_ID IS NOT NULL THEN 'Record already exists in target table;' || ERR_MSG2
                ELSE TEMP.ERR_MSG2
            END AS ERR_MSG,
            TEMP.DW_FILE_PATH,
            TEMP.DW_CREATE_TS,
            TEMP.SOURCE_APPLICATION_CD,
            TEMP.JOB_ID,
            TEMP.DW_CHECKSUM_VALUE_TXT
        FROM Dedupicated_final AS TEMP
		LEFT OUTER JOIN `""" || project_id || "." || confirmed_dataset || "." || sensor_valid_data_table || """` TARGET
            ON  TARGET.DW_CHECKSUM_VALUE_TXT  = TEMP.DW_CHECKSUM_VALUE_TXT
			)
    SELECT
            SESSION_ID,
            ZONE_ARRIVAL_TS,
            BEACON_ID,
            ZONE_DEPARTURE_TS,
            REGISTER_NBR,
            FACILITY_INTEGRATION_ID,
            RETAIL_STORE_FACILITY_NBR,
            MEDIA_ZONE_CD,
            ERR_MSG,
            DW_FILE_PATH,
            DW_CREATE_TS,
            SOURCE_APPLICATION_CD,
            JOB_ID,
            DW_CHECKSUM_VALUE_TXT
    FROM TEMP_BLE_SENSOR_DEDUPED
    ;
 
    """;
    EXECUTE IMMEDIATE sql_string;
    ---------------------------------------End of validation--------------------------
    -- INSERT valid data into table
    SET sql_string = """
        INSERT INTO
            `""" || project_id || "." || confirmed_dataset || "." || sensor_valid_data_table || """`
        (
                SESSION_ID,
                ZONE_ARRIVAL_TS,
                BEACON_ID,
                ZONE_DEPARTURE_TS,
                REGISTER_NBR,
                FACILITY_INTEGRATION_ID,
                MEDIA_ZONE_CD,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID,
                DW_CHECKSUM_VALUE_TXT
            )
            Select
                TRIM(SESSION_ID),
                SAFE_CAST(TRIM(ZONE_ARRIVAL_TS) AS TIMESTAMP),
                TRIM(BEACON_ID),
                SAFE_CAST(TRIM(ZONE_DEPARTURE_TS) AS TIMESTAMP),
                SAFE_CAST(REGISTER_NBR AS INT64),
                FACILITY_INTEGRATION_ID,
                TRIM(MEDIA_ZONE_CD),
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID,
                DW_CHECKSUM_VALUE_TXT
                FROM SENSOR_DATA_WITH_VALIDATION_STATUS
	        WHERE TRIM(ERR_MSG) = ''
        """;
    EXECUTE IMMEDIATE sql_string;
 
    -- Insert invalid data into table
    -- Check if the table has records for the given job_id
    EXECUTE IMMEDIATE FORMAT("""
        SELECT COUNT(1)
        FROM `%s.%s.%s`
        WHERE JOB_ID = '%s'
    """, project_id, refined_dataset, sensor_invalid_data_table, current_job_id)
    INTO record_count;
    -- If no records exist for the job_id, proceed with the insert
    IF record_count = 0 THEN
        SET sql_string = """
            INSERT INTO `""" || project_id || "." || refined_dataset || "." || sensor_invalid_data_table || """`
            SELECT
                SESSION_ID,
                ZONE_ARRIVAL_TS,
                BEACON_ID,
                ZONE_DEPARTURE_TS,
                REGISTER_NBR,
                RETAIL_STORE_FACILITY_NBR,
                MEDIA_ZONE_CD,
                ERR_MSG,
                DW_FILE_PATH,
                DW_CREATE_TS,
                SOURCE_APPLICATION_CD,
                JOB_ID
            FROM
            (
                -- Part 1: From SENSOR_DATA_WITH_VALIDATION_STATUS where ERR_MSG is not blank
                SELECT
                    SESSION_ID,
                    ZONE_ARRIVAL_TS,
                    BEACON_ID,
                    ZONE_DEPARTURE_TS,
                    REGISTER_NBR,
                    RETAIL_STORE_FACILITY_NBR,
                    MEDIA_ZONE_CD,
                    ERR_MSG,
                    DW_FILE_PATH,
                    DW_CREATE_TS,
                    SOURCE_APPLICATION_CD,
                    JOB_ID
                FROM SENSOR_DATA_WITH_VALIDATION_STATUS
                WHERE TRIM(ERR_MSG) <> ''
            
                UNION ALL
            
                -- Part 2: Zones/stores not receiving any data
                SELECT
                    '' AS SESSION_ID,
                    '' AS ZONE_ARRIVAL_TS,
                    '' AS BEACON_ID,
                    '' AS ZONE_DEPARTURE_TS,
                    '' AS REGISTER_NBR,
                    S.RETAIL_STORE_FACILITY_NBR,
                    S.MEDIA_ZONE_CD,
                    'Not receiving any data for this STOREID/ZONE_ID' AS ERR_MSG,
                    S.DW_FILE_PATH,
                    S.DW_CREATE_TS,
                    S.SOURCE_APPLICATION_CD,
                    S.JOB_ID
                FROM (
                    SELECT DISTINCT
                        LS.RETAIL_STORE_FACILITY_NBR,
                        S.FACILITY_INTEGRATION_ID,
                        S.MEDIA_ZONE_CD,
                        RAW.DW_FILE_PATH,
                        RAW.DW_CREATE_TS,
                        RAW.SOURCE_APPLICATION_CD,
                        RAW.JOB_ID
                    FROM
                        `""" || project_id || "." || lookup_dataset || "." || lookup_table || """` S
                    INNER JOIN
                        (SELECT * FROM gcp-abs-udco-bq-<<ENV>>-prj-01.udco_ds_cltv_confirmed.MEDIA_ZONE 
                        WHERE UPPER(MEDIA_ZONE_NM)<>'PHARMACY' AND UPPER(MEDIA_ZONE_NM) NOT LIKE '%MMWAVE%'
                        )S1
                        ON S.MEDIA_ZONE_CD=S1.MEDIA_ZONE_CD
                    INNER JOIN
                        `""" || lookup_dataset_store || "." || lookup_table_store || """` LS
                    ON LS.FACILITY_INTEGRATION_ID = S.FACILITY_INTEGRATION_ID
                    AND LS.DW_LOGICAL_DELETE_IND = FALSE
                    CROSS JOIN (
                        SELECT DISTINCT
                            DW_FILE_PATH,
                            DW_CREATE_TS,
                            SOURCE_APPLICATION_CD,
                            JOB_ID  
                        FROM
                            SENSOR_DATA_WITH_VALIDATION_STATUS
                    ) RAW
                ) S
                LEFT JOIN (
                    SELECT DISTINCT  
                        RETAIL_STORE_FACILITY_NBR,
                        MEDIA_ZONE_CD
                    FROM
                       SENSOR_DATA_WITH_VALIDATION_STATUS
                ) RAW
                ON SAFE_CAST(S.RETAIL_STORE_FACILITY_NBR AS INT64) = SAFE_CAST(RAW.RETAIL_STORE_FACILITY_NBR AS INT64)
                AND TRIM(IFNULL(S.MEDIA_ZONE_CD, '')) = TRIM(IFNULL(RAW.MEDIA_ZONE_CD, ''))
                WHERE RAW.RETAIL_STORE_FACILITY_NBR IS NULL
            )
 
                """;
    EXECUTE IMMEDIATE sql_string;
    END IF;
END