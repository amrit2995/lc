import openpyxl
from pydantic import BaseModel
from enum import Enum

class Spreadsheet:
    def __init__(self, worksheet):
        self.worksheet = worksheet

    def get_cell(self, row, column):
        return self.worksheet.cell(row=row, column=column).value

    def get_all_rows(self):
        return list(self.worksheet.iter_rows(values_only=True))

    @property
    def title(self):
        return self.worksheet.title

class Workbook:
    def __init__(self, file_path):
        # import pdb;pdb.set_trace()
        self.file_path = file_path
        self.workbook = openpyxl.load_workbook(file_path)
        self.sheets = {ws.title: Spreadsheet(ws) for ws in self.workbook.worksheets}
        # import pdb;pdb.set_trace()

    # @property
    # def name(self):
    #     import pdb;pdb.set_trace()
    #     return self.workbook.title

    # @property
    # def sheets(self, name):
    #     return self.sheets.get(name)

    @property
    def sheet_names_list(self):
        import pdb;pdb.set_trace()
        return self.workbook.sheetnames
    
    def get_sheet_by_name(self, name):
        return self.sheets[name]

    def close(self):
        self.workbook.close()