
from sql_development_scripts.scripts.new_dev.sp_gen_sdk import workbook_old
import pandas as pd

class Report:
    def __init__(self, worksheet: workbook_old.Spreadsheet):
        self.worksheet: workbook_old.Spreadsheet = worksheet
        self.col_names = self.get_cols()

    @property
    def name(self):
        return self.worksheet.title
    
    def get_cols(self):
        rows = self.worksheet.get_all_rows()
        import pdb;pdb.set_trace()
        cols = rows[0]
        import pdb;pdb.set_trace()
        return cols