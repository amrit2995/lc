import pandas as pd
from pydantic import BaseModel
from enum import Enum

class Spreadsheet:
    def __init__(self, dataframe, title):
        self.dataframe = dataframe
        self._title = title

    def get_cell(self, row, column):
        # row and column are 1-based, like Excel
        return self.dataframe.iloc[row - 1, column - 1]

    def get_all_rows(self):
        return self.dataframe.values.tolist()

    @property
    def title(self):
        return self._title

class Workbook:
    def __init__(self, file_path):
        self.file_path = file_path
        # Read all sheets into a dict of DataFrames
        self.workbook: pd.ExcelFile = pd.ExcelFile(file_path)
        import pdb;pdb.set_trace()
        # self._sheets_dict = pd.read_excel(file_path, sheet_name=None)
        # self.sheets = {title: Spreadsheet(df, title) for title, df in self._sheets_dict.items()}

    @property
    def sheet_names_list(self):
        return list(self._sheets_dict.keys())
    
    def get_sheet_by_name(self, name):
        return self.sheets[name]

    def close(self):
        # No explicit close needed for pandas, but method kept for compatibility
        pass