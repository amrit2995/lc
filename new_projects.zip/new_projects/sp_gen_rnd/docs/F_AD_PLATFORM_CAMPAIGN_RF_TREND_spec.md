# F_AD_PLATFORM_CAMPAIGN_RF_TREND — Table Specification

> **Version:** 1.3.2  
> **Source PDF:** `AD_PLATFORM_SOCIAL_CAMPAIGN_RF_TREND V1.3.2.pdf`  
> **Generated:** 2026-02-23

---

## 1. Overview

The **`F_AD_PLATFORM_CAMPAIGN_RF_TREND`** fact table captures cumulative reach & frequency (R&F) trend metrics at the **campaign** level, aggregated per performance day.

**Key Notes:**

- Accumulation happens from the platform campaign start date to the `PERFORMANCE_DAY_DT`.
- Any aggregation to a higher granularity level than defined will output **inaccurate numbers** because the counts are already cumulative per date.
- A related fact table `F_AD_PLATFORM_ADVERTISEMENT_RF_TREND` exists at a lower (advertisement) granularity and may serve as a source for campaign-level roll-ups.

---

## 2. Fact Table Columns

| #   | Column Name                                   | Data Type     | Nullable | Description                                           |
| --- | --------------------------------------------- | ------------- | -------- | ----------------------------------------------------- |
| 1   | `PERFORMANCE_DAY_ID`                          | NUMERIC       | NOT NULL | FK to D0_FISCAL_DAY — identifies the performance date |
| 2   | `PLATFORM_ADVERTISER_D1_SK`                   | NUMERIC       | NOT NULL | FK to D1_PLATFORM_ADVERTISER                          |
| 3   | `AD_MEDIA_PLATFORM_D1_SK`                     | NUMERIC       | NOT NULL | FK to D1_AD_MEDIA_PLATFORM                            |
| 4   | `AD_MEDIA_CAMPAIGN_D1_SK`                     | NUMERIC       | NOT NULL | FK to D1_AD_MEDIA_CAMPAIGN                            |
| 5   | `PLATFORM_MEDIA_CAMPAIGN_D1_SK`               | NUMERIC       | NOT NULL | FK to D1_PLATFORM_MEDIA_CAMPAIGN                      |
| 6   | `AD_MEDIA_OPPORTUNITY_D1_SK`                  | NUMERIC       | NOT NULL | FK to D1_AD_MEDIA_OPPORTUNITY                         |
| 7   | `AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK`          | NUMERIC       | NOT NULL | FK to D1_AD_MEDIA_PROMOTIONAL_CHANNEL                 |
| 8   | `CUMULATIVE_AD_CAMPAIGN_REACH_CNT`            | NUMERIC       | NOT NULL | Cumulative unique reach count for the campaign        |
| 9   | `CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT` | NUMERIC       | NOT NULL | Cumulative reach impression count                     |
| 10  | `CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT`      | NUMERIC       | NOT NULL | Cumulative reach click count                          |
| 11  | `CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT`   | NUMERIC(14,2) | NOT NULL | Cumulative average impression count                   |
| 12  | `CUMULATIVE_CLICK_CNT`                        | NUMERIC       | NOT NULL | Cumulative total click count                          |
| 13  | `CUMULATIVE_IMPRESSION_CNT`                   | NUMERIC       | NOT NULL | Cumulative total impression count                     |
| 14  | `CUMULATIVE_MEASUREMENT_REVENUE_AMT`          | NUMERIC(14,2) | NOT NULL | Cumulative measurement revenue amount                 |
| 15  | `CUMULATIVE_CPG_MEDIA_SPEND_AMT`              | NUMERIC(14,2) | NOT NULL | Cumulative CPG media spend amount                     |
| 16  | `DW_CREATE_TS`                                | TIMESTAMP     | NOT NULL | Record creation timestamp                             |
| 17  | `DW_LAST_UPDATE_TS`                           | TIMESTAMP     | NOT NULL | Record last update timestamp                          |

---

## 3. All Tables Involved

### 3.1 Target Fact Table

| #   | Table Name                            | Type                   |
| --- | ------------------------------------- | ---------------------- |
| 1   | **`F_AD_PLATFORM_CAMPAIGN_RF_TREND`** | Fact _(to be created)_ |

### 3.2 Source / Confirmed Tables (DDL files available)

| #   | Table Name                      | Type      | DDL File                                                       |
| --- | ------------------------------- | --------- | -------------------------------------------------------------- |
| 2   | **`ad_platform_campaign`**      | Confirmed | `udco-cltv/META/scripts/ddl/ddl_ad_platform_campaign.sql`      |
| 3   | **`ad_platform_advertisement`** | Confirmed | `udco-cltv/META/scripts/ddl/ddl_ad_platform_advertisement.sql` |
| 4   | **`campaign_reach_summary`**    | Confirmed | `udco-cltv/META/scripts/ddl/ddl_campaign_reach_summary.sql`    |

### 3.3 Dimension Tables (DDL files available)

| #   | Table Name                            | Join Key (SK)                        | DDL File                                                                        |
| --- | ------------------------------------- | ------------------------------------ | ------------------------------------------------------------------------------- |
| 5   | **`D1_PLATFORM_ADVERTISER`**          | `PLATFORM_ADVERTISER_D1_SK`          | `udco-cltv/META/scripts/ddl/Analytical/ddl_d1_platform_advertiser.sql`          |
| 6   | **`D1_AD_MEDIA_OPPORTUNITY`**         | `AD_MEDIA_OPPORTUNITY_D1_SK`         | `udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_opportunity.sql`         |
| 7   | **`D1_AD_MEDIA_PROMOTIONAL_CHANNEL`** | `AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK` | `udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_promotional_channel.sql` |

### 3.4 Dimension Tables (⚠️ DDL files NOT available)

| #   | Table Name                       | Join Key (SK)                   | Status         |
| --- | -------------------------------- | ------------------------------- | -------------- |
| 8   | **`D0_FISCAL_DAY`**              | `PERFORMANCE_DAY_ID`            | ❌ DDL missing |
| 9   | **`D1_AD_MEDIA_PLATFORM`**       | `AD_MEDIA_PLATFORM_D1_SK`       | ❌ DDL missing |
| 10  | **`D1_AD_MEDIA_CAMPAIGN`**       | `AD_MEDIA_CAMPAIGN_D1_SK`       | ❌ DDL missing |
| 11  | **`D1_PLATFORM_MEDIA_CAMPAIGN`** | `PLATFORM_MEDIA_CAMPAIGN_D1_SK` | ❌ DDL missing |

### 3.5 Related Fact Table (referenced in diagram)

| #   | Table Name                                 | Type                       | Status                               |
| --- | ------------------------------------------ | -------------------------- | ------------------------------------ |
| 12  | **`F_AD_PLATFORM_ADVERTISEMENT_RF_TREND`** | Fact (advertisement-level) | Referenced; lower granularity source |

---

## 4. Join Map

```
F_AD_PLATFORM_CAMPAIGN_RF_TREND
│
├── PERFORMANCE_DAY_ID ──────────────────────► D0_FISCAL_DAY.FISCAL_DAY_ID                         ❌ DDL missing
├── PLATFORM_ADVERTISER_D1_SK ───────────────► D1_PLATFORM_ADVERTISER.PLATFORM_ADVERTISER_D1_SK     ✅
├── AD_MEDIA_PLATFORM_D1_SK ─────────────────► D1_AD_MEDIA_PLATFORM.AD_MEDIA_PLATFORM_D1_SK         ❌ DDL missing
├── AD_MEDIA_CAMPAIGN_D1_SK ─────────────────► D1_AD_MEDIA_CAMPAIGN.AD_MEDIA_CAMPAIGN_D1_SK         ❌ DDL missing
├── PLATFORM_MEDIA_CAMPAIGN_D1_SK ───────────► D1_PLATFORM_MEDIA_CAMPAIGN.PLATFORM_MEDIA_CAMPAIGN_D1_SK  ❌ DDL missing
├── AD_MEDIA_OPPORTUNITY_D1_SK ──────────────► D1_AD_MEDIA_OPPORTUNITY.AD_MEDIA_OPPORTUNITY_D1_SK   ✅
└── AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK ──────► D1_AD_MEDIA_PROMOTIONAL_CHANNEL.AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK  ✅
```

---

## 5. Summary

| Category                  | Count  | Available DDLs      |
| ------------------------- | ------ | ------------------- |
| Target Fact Table         | 1      | — (to be created)   |
| Source / Confirmed Tables | 3      | ✅ 3/3              |
| Dimension Tables          | 7      | ✅ 3 / ❌ 4 missing |
| Related Fact Tables       | 1      | — (referenced only) |
| **Total**                 | **12** | **6 available**     |

ad_platform_campaign
ad_platform_advertisement
campaign_reach_summary
D1_PLATFORM_ADVERTISER
D1_AD_MEDIA_OPPORTUNITY
D1_AD_MEDIA_PROMOTIONAL_CHANNEL
D0_FISCAL_DAY
D1_AD_MEDIA_PLATFORM
D1_AD_MEDIA_CAMPAIGN
D1_PLATFORM_MEDIA_CAMPAIGN
F_AD_PLATFORM_ADVERTISEMENT_RF_TREND

/Users/amritprusty/projects/sp_gen_rnd/udco-cltv/META/scripts/ddl/Analytical

# Table Name File Path

1 D1_PLATFORM_ADVERTISER

udco_cltv/META/scripts/ddl/Analytical/ddl_d1_platform_advertiser.sql
2 D1_AD_MEDIA_OPPORTUNITY

udco_cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_opportunity.sql
3 D1_AD_MEDIA_PROMOTIONAL_CHANNEL

udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_promotional_channel.sql
4 D1_AD_MEDIA_PLATFORM

udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_platform.sql
5 D1_AD_MEDIA_CAMPAIGN

udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_campaign.sql
6 D1_PLATFORM_MEDIA_CAMPAIGN

udco-cltv/META/scripts/ddl/Analytical/ddl_d1_platform_media_campaign.sql
7 F_AD_PLATFORM_CAMPAIGN_RF_TREND

udco-cltv/META/scripts/ddl/Analytical/ddl_f_ad_platform_campaign_rf_trend.sql

udco-cltv/META/scripts/ddl/Analytical/ddl_d1_platform_advertiser.sql
udco-cltv/META/scripts/ddl/ddl_campaign_reach_summary.sql
udco-cltv/META/scripts/ddl/ddl_ad_platform_advertisement.sql
udco-cltv/META/scripts/ddl/ddl_ad_platform_campaign.sql
udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_opportunity.sql
udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_promotional_channel.sql
udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_platform.sql
udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_campaign.sql
udco-cltv/META/scripts/ddl/Analytical/ddl_d1_platform_media_campaign.sql
udco-cltv/META/scripts/ddl/Analytical/ddl_f_ad_platform_campaign_rf_trend.sql
