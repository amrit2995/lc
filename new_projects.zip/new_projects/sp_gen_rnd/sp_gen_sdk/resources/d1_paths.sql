CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN` (
		AD_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for campaign - uniquely identifies each advertising campaign record in the system."
		),
		AD_MEDIA_CAMPAIGN_ID STRING NOT NULL OPTIONS(DESCRIPTION = "AMC Media Campaign ID"),
		AD_CAMPAIGN_ID STRING NOT NULL OPTIONS(DESCRIPTION = "AMC Hub Campaign ID"),
		AD_CAMPAIGN_NM STRING NOT NULL OPTIONS(DESCRIPTION = "AMC Hub Campaign Name"),
		AD_MEDIA_CAMPAIGN_NM STRING NOT NULL OPTIONS(
			DESCRIPTION = "AMC Friendly Campaign Name from Insertion Order"
		),
		AD_CAMPAIGN_START_DT DATE NOT NULL OPTIONS(
			DESCRIPTION = "Start date for the whole Hub Campaign"
		),
		AD_CAMPAIGN_END_DT DATE NOT NULL OPTIONS(
			DESCRIPTION = "End date for the whole Hub Campaign"
		),
		AD_CAMPAIGN_BUDGT_AMT NUMERIC(14, 2) NOT NULL OPTIONS(
			DESCRIPTION = "Budget for the whole Hub Campaign"
		),
		AD_CAMPAIGN_ADVERTISED_BRAND_NM STRING NOT NULL OPTIONS(
			DESCRIPTION = "Brand(s) represented in the advertisement. These are the IRI Brand names(ampersand-delimited) that will be used for attribution. Note that for Citrus, these will not align with IRI Brand Names."
		),
		AD_CAMPAIGN_PLND_IMPRESSION_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Planned Impressions for the whole Hub Campaign"
		),
		AD_CAMPAIGN_OBJECTIVE_TXT STRING NOT NULL OPTIONS(
			DESCRIPTION = "CPG's aim with this AMC Hub Campaign"
		),
		AD_CPG ARRAY < STRUCT < AD_CAMPAIGN_PARTNER_ID STRING,
		AD_CAMPAIGN_PARTNER_NM STRING >> OPTIONS(
			DESCRIPTION = "AMC Hub Campaign ID & AMC Friendly Campaign Name from Insertion Order"
		),
		DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was created"
		),
		DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was last updated"
		),
		PRIMARY KEY (AD_MEDIA_CAMPAIGN_D1_SK) not enforced
	) OPTIONS (
		labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);
CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_ADVERTISER` (
		PLATFORM_ADVERTISER_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."
		),
		PLATFORM_CD STRING NOT NULL OPTIONS(
			DESCRIPTION = "Platform Code representing the media platform (e.g., Facebook, Pinterest, dv360 or GAN)."
		),
		PLATFORM_ADVERTISER_ID STRING NOT NULL OPTIONS(
			DESCRIPTION = "Platform Advertiser ID, same as CPG in vendor CMS."
		),
		PLATFORM_ADVERTISER_NM STRING NOT NULL OPTIONS(
			DESCRIPTION = "Platform Advertiser Name, same as CPG in vendor CMS."
		),
		DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was created"
		),
		DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was last updated"
		)
	) OPTIONS(
		DESCRIPTION = "This Table stores the mapping of advertisers to media platforms. Used to provide consistent advertiser naming and IDs, along with platform and promotional channel information.",
		labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);
CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CAMPAIGN` (
		PLATFORM_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = 'Surrogate key for platform media campaign – uniquely identifies each campaign per platform.'
		),
		PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Name"),
		PLATFORM_CAMPAIGN_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Campaign ID"),
		PLATFORM_CAMPAIGN_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Platform campaign name"),
		PLATFORM_CAMPAIGN_START_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Platform Campaign START Date"),
		PLATFORM_CAMPAIGN_END_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Platform Campaign End Date"),
		PLATFORM_BUYING_TYPE_CD STRING NOT NULL OPTIONS(
			DESCRIPTION = 'its the type of sale, if it was a direct sale from albertson or Indirect , thru partner'
		),
		PLATFORM_ACTIVATION_SPECIALIST_TXT STRING NOT NULL OPTIONS(DESCRIPTION = "Platform activation specialist"),
		IS_ALBERTSONS_MANAGED_SOLD_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "<<cocmp>> Managed sold indicator"),
		IS_SELF_SERVE_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Self serve indicator"),
		IS_COBRANDED_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Co-branded indicator"),
		DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was created"
		),
		DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was last updated"
		)
	) OPTIONS(
		DESCRIPTION = "This table stores all the descriptive information about advertising campaigns on perticular platforms like Facebook, Instagram, Pinterest, etc.Stores metadata for advertising campaigns specific to a media platform (e.g., Meta, Pinterest). Enables tracking of campaign activity at the platform level.",
		labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);
CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CAMPAIGN` (
		PLATFORM_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = 'Surrogate key for platform media campaign – uniquely identifies each campaign per platform.'
		),
		PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Name"),
		PLATFORM_CAMPAIGN_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Campaign ID"),
		PLATFORM_CAMPAIGN_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Platform campaign name"),
		PLATFORM_CAMPAIGN_START_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Platform Campaign START Date"),
		PLATFORM_CAMPAIGN_END_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Platform Campaign End Date"),
		PLATFORM_BUYING_TYPE_CD STRING NOT NULL OPTIONS(
			DESCRIPTION = 'its the type of sale, if it was a direct sale from albertson or Indirect , thru partner'
		),
		PLATFORM_ACTIVATION_SPECIALIST_TXT STRING NOT NULL OPTIONS(DESCRIPTION = "Platform activation specialist"),
		IS_ALBERTSONS_MANAGED_SOLD_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "<<cocmp>> Managed sold indicator"),
		IS_SELF_SERVE_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Self serve indicator"),
		IS_COBRANDED_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Co-branded indicator"),
		DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was created"
		),
		DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was last updated"
		)
	) OPTIONS(
		DESCRIPTION = "This table stores all the descriptive information about advertising campaigns on perticular platforms like Facebook, Instagram, Pinterest, etc.Stores metadata for advertising campaigns specific to a media platform (e.g., Meta, Pinterest). Enables tracking of campaign activity at the platform level.",
		labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);
CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_OPPORTUNITY` (
		AD_MEDIA_OPPORTUNITY_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for media opportunity relationship – ensures uniqueness for each opportunity."
		),
		AD_MEDIA_OPPORTUNITY_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Media opportunity ID."),
		AD_MEDIA_OPPORTUNITY_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Media opportunity Name."),
		AD_MEDIA_PARENT_OPPORTUNITY_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Media parent opportunity ID."),
		AD_CPG_ACCOUNT_ID STRING NOT NULL OPTIONS(
			DESCRIPTION = "CPG account ID, same as CPG in vendor CMS."
		),
		IS_PARENT_OPPORTUNITY_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Parent opportunity indicator."),
		IS_COBRANDED_IND BOOLEAN NOT NULL OPTIONS(
			DESCRIPTION = "Flag to tell if the Campaign is a joined campaign and is for Co BRAND by partners"
		),
		DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was created"
		),
		DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was last updated"
		)
	) OPTIONS(
		DESCRIPTION = "This Table stores the mapping of media opportunity.",
		labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);
CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PROMOTIONAL_CHANNEL` (
		AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK NUMERIC NOT NULL,
		PLATFORM_PROMOTIONAL_CHANNEL_CD STRING NOT NULL OPTIONS(
			DESCRIPTION = "Unique values from platform promotional channel: Display, On-Site Display, On-Site SPA, Social, Digital Instore, CTV, High Impact Display, PromoAmp, Email"
		),
		DW_CREATE_TS TIMESTAMP NOT NULL,
		DW_LAST_UPDATE_TS TIMESTAMP NOT NULL
	) OPTIONS(
		DESCRIPTION = "This table holds all possible values for advertisement channel valid for different platforms like Meta, Pinterest, GAM, DV360, Instore, Criteo, Undertone, etc.",
		labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);
CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_FISCAL_DAY` (
		PERFORMANCE_DAY_ID NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101"
		),
		CALENDAR_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Calendar Date"),
		FISCAL_WEEK_ID NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Week Identifier; Format: YYYYWW; e.g. 202101"
		),
		FISCAL_MONTH_ID NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Month Identifier; Format: YYYYMM; e.g. 202101"
		),
		FISCAL_QUARTER_ID NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Quarter Identifier; Format: YYYYQ; e.g. 20211"
		),
		FISCAL_YEAR_ID NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Year Identifier; Format: YYYY; e.g. 2021"
		),
		FISCAL_DAY_OF_WEEK_NM STRING NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Day of Week Name; e.g. Monday"
		),
		FISCAL_DAY_OF_WEEK_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Day of Week Number; e.g. 1"
		),
		FISCAL_DAY_OF_MONTH_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Day of Month Number; e.g. 1"
		),
		FISCAL_DAY_OF_QUARTER_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Day of Quarter Number; e.g. 1"
		),
		FISCAL_DAY_OF_YEAR_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Day of Year Number; e.g. 1"
		),
		FISCAL_WEEK_OF_MONTH_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Week of Month Number; e.g. 1"
		),
		FISCAL_WEEK_OF_QUARTER_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Week of Quarter Number; e.g. 1"
		),
		FISCAL_WEEK_OF_YEAR_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Week of Year Number; e.g. 1"
		),
		FISCAL_MONTH_OF_QUARTER_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Month of Quarter Number; e.g. 1"
		),
		FISCAL_MONTH_OF_YEAR_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Month of Year Number; e.g. 1"
		),
		FISCAL_QUARTER_OF_YEAR_NUMERIC NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Quarter of Year Number; e.g. 1"
		),
		FISCAL_YEAR_NUMERIC NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Fiscal Year Number; e.g. 2021"),
		DW_CREATE_TS TIMESTAMP NOT NULL,
		DW_LAST_UPDATE_TS TIMESTAMP NOT NULL
	) OPTIONS(
		DESCRIPTION = "Fact Table F_AD_PLATFORM_CAMPAIGN_RF_TREND_WRK holds the cumulative count of Reach and Impressions for a Campaign .It maintains Cumulative data at campaign level with daily loads, Important to note as these counts are cumulative per date , Any aggregation to have data at higer or lower granularity level will output inaccurate  numbers.",
		labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);