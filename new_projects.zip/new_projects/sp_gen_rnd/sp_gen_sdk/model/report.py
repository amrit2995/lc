
from sp_gen_sdk.model import workbook

class Report:
    def __init__(self, worksheet: workbook.Spreadsheet):
        self.worksheet: workbook.Spreadsheet = worksheet
        self.col_names = self.get_cols()

    @property
    def name(self):
        return self.worksheet.title
    
    def get_cols(self):
        rows = self.worksheet.get_all_rows()
        cols = rows[1]
        return cols