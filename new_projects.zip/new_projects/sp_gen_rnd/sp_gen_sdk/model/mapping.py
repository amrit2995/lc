from enum import Enum
from pydantic import BaseModel


class MappingType(str, Enum):
    DIRECT = "DIRECT"
    DERIVED = "DERIVED"
    DIM_LOOKUP = "DIM_LOOKUP"
    HARDCODED = "HARDCODED"


class MappingRow(BaseModel):
    target_col: str
    source_table: str | None = None
    source_col: str | None = None
    transformation: str | None = None
    dim_table: str | None = None
    dim_sk: str | None = None
    mapping_type: MappingType = MappingType.DIRECT
    platform: str | None = None  # sub-section label e.g. "DV360", "META"
