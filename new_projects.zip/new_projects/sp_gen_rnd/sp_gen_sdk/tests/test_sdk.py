"""
tests/test_sdk.py
-----------------
DDL parsing tests for sp_gen_sdk.model.sql.

Tests cover:
  - DDLQuery.parse()  : top-level parse flow, error handling
  - Table             : name / database / project / TableType inference
  - Column            : data_type, not_null, desc from OPTIONS(description=...)
"""

import os
import textwrap
import pytest

from sp_gen_sdk.model.sql import DDLQuery, Table, Column, TableType

# ---------------------------------------------------------------------------
# Paths to real fixture DDLs
# ---------------------------------------------------------------------------
FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")
SOURCE_DDL_PATH = os.path.join(FIXTURES, "source_table.sql")
FACT_DDL_PATH   = os.path.join(FIXTURES, "fact_table.sql")


def _read(path: str) -> str:
    with open(path) as f:
        return f.read()


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def source_ddl() -> DDLQuery:
    return DDLQuery.parse(_read(SOURCE_DDL_PATH))


@pytest.fixture(scope="module")
def fact_ddl() -> DDLQuery:
    return DDLQuery.parse(_read(FACT_DDL_PATH))


# ===========================================================================
# TestDDLQueryParse
# ===========================================================================
class TestDDLQueryParse:
    """Top-level DDLQuery.parse() behaviour."""

    def test_parse_source_ddl_returns_ddlquery(self, source_ddl):
        assert isinstance(source_ddl, DDLQuery)

    def test_parse_fact_ddl_returns_ddlquery(self, fact_ddl):
        assert isinstance(fact_ddl, DDLQuery)

    def test_table_is_not_none(self, source_ddl):
        assert source_ddl.table is not None

    def test_non_create_statement_raises_value_error(self):
        with pytest.raises(ValueError, match="not a CREATE statement"):
            DDLQuery.parse("SELECT 1")

    def test_empty_ddl_raises(self):
        with pytest.raises(Exception):
            DDLQuery.parse("")


# ===========================================================================
# TestTableParsing  — source table (GENERIC)
# ===========================================================================
class TestSourceTableParsing:
    """Table-level fields parsed from the source fixture DDL."""

    def test_table_name(self, source_ddl):
        assert source_ddl.table.name == "campaign_reach_summary"

    def test_table_database(self, source_ddl):
        assert source_ddl.table.database == "mydb"

    def test_table_project(self, source_ddl):
        assert source_ddl.table.project == "myproject"

    def test_table_type_is_generic(self, source_ddl):
        assert source_ddl.table.type == TableType.GENERIC

    def test_column_list_non_empty(self, source_ddl):
        assert len(source_ddl.table.columns) > 0

    def test_list_cols_contains_expected_columns(self, source_ddl):
        cols = source_ddl.table.list_cols()
        assert "campaign_id" in cols
        assert "impressions_cnt" in cols
        assert "dw_create_ts" in cols
        assert "dw_logical_delete_ind" in cols


# ===========================================================================
# TestFactTableParsing
# ===========================================================================
class TestFactTableParsing:
    """Table-level fields parsed from the fact fixture DDL."""

    def test_table_name(self, fact_ddl):
        assert fact_ddl.table.name == "F_AD_PLATFORM_CAMPAIGN_RF_TREND"

    def test_table_database(self, fact_ddl):
        assert fact_ddl.table.database == "mydb"

    def test_table_project(self, fact_ddl):
        assert fact_ddl.table.project == "myproject"

    def test_table_type_is_fact(self, fact_ddl):
        assert fact_ddl.table.type == TableType.FACT

    def test_list_cols_contains_expected_columns(self, fact_ddl):
        cols = fact_ddl.table.list_cols()
        assert "PERFORMANCE_DAY_ID" in cols
        assert "DW_CREATE_TS" in cols
        assert "CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT" in cols


# ===========================================================================
# TestColumnParsing  — data_type, not_null, desc
# ===========================================================================
class TestColumnParsing:
    """Column-level field parsing for both source and fact DDLs."""

    # --- helpers -----------------------------------------------------------

    def _get_col(self, ddl: DDLQuery, name: str) -> Column:
        for col in ddl.table.columns:
            if col.name == name:
                return col
        raise KeyError(f"Column {name!r} not found in parsed table")

    # --- source table columns ----------------------------------------------

    def test_string_column_data_type(self, source_ddl):
        col = self._get_col(source_ddl, "campaign_id")
        assert col.data_type.upper() == "TEXT"   # sqlglot normalises STRING -> TEXT

    def test_timestamp_column_data_type(self, source_ddl):
        col = self._get_col(source_ddl, "dw_create_ts")
        assert "TIMESTAMP" in col.data_type.upper()

    def test_int64_column_data_type(self, source_ddl):
        col = self._get_col(source_ddl, "impressions_cnt")
        assert col.data_type != ""   # sqlglot may render INT64 as BIGINT etc.

    def test_bool_column_data_type(self, source_ddl):
        col = self._get_col(source_ddl, "dw_logical_delete_ind")
        assert col.data_type != ""

    def test_not_null_true_for_constrained_column(self, source_ddl):
        col = self._get_col(source_ddl, "campaign_id")
        assert col.not_null is True

    def test_not_null_false_for_nullable_column(self, source_ddl):
        col = self._get_col(source_ddl, "reach_cnt")
        assert col.not_null is False

    def test_desc_populated_from_options(self, source_ddl):
        col = self._get_col(source_ddl, "campaign_id")
        assert "campaign" in col.desc.lower()

    def test_desc_empty_for_column_without_options(self, fact_ddl):
        # DW_CREATE_TS has no OPTIONS(description=...) in the fact fixture
        col = self._get_col(fact_ddl, "DW_CREATE_TS")
        assert col.desc == ""

    # --- fact table columns ------------------------------------------------

    def test_numeric_column_data_type(self, fact_ddl):
        col = self._get_col(fact_ddl, "PERFORMANCE_DAY_ID")
        assert "DECIMAL" in col.data_type.upper() or "NUMERIC" in col.data_type.upper()

    def test_numeric_with_precision_data_type(self, fact_ddl):
        col = self._get_col(fact_ddl, "CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT")
        assert col.data_type != ""
        # precision/scale should be captured, e.g. DECIMAL(14, 2)
        assert "14" in col.data_type

    def test_all_fact_columns_not_null(self, fact_ddl):
        for col in fact_ddl.table.columns:
            assert col.not_null is True, f"Expected NOT NULL on {col.name}"

    def test_fact_col_desc_populated(self, fact_ddl):
        col = self._get_col(fact_ddl, "PERFORMANCE_DAY_ID")
        assert len(col.desc) > 0


# ===========================================================================
# TestTableTypeFinder  — TableType.from_name unit tests
# ===========================================================================
class TestTableTypeFinder:
    """Unit tests for TableType.from_name class method."""

    def test_fact_prefix_f(self):
        assert TableType.from_name("F_MY_FACT_TABLE") == TableType.FACT

    def test_fact_prefix_fa(self):
        assert TableType.from_name("FA_MY_FACT_TABLE") == TableType.FACT

    def test_dimensional_prefix(self):
        assert TableType.from_name("D1_MY_DIM_TABLE") == TableType.DIMENSIONAL

    def test_generic_table(self):
        assert TableType.from_name("campaign_reach_summary") == TableType.GENERIC

    def test_generic_table_mixed_case(self):
        assert TableType.from_name("my_source_table") == TableType.GENERIC
