CREATE OR REPLACE TABLE `myproject.mydb.campaign_reach_summary`
(
  campaign_id              STRING      NOT NULL  OPTIONS(description="The unique identifier for the advertising campaign."),
  source_last_modified_ts  TIMESTAMP   NOT NULL  OPTIONS(description="The date and time record was modified."),
  reach_cnt                INT64                 OPTIONS(description="Estimated number of unique users exposed to the campaign."),
  impressions_cnt          INT64                 OPTIONS(description="Total number of times the campaign was served."),
  source_application_cd    STRING                OPTIONS(description="Code representing the source ad platform."),
  dw_create_ts             TIMESTAMP   NOT NULL  OPTIONS(description="The timestamp the record was inserted."),
  dw_logical_delete_ind    BOOL                  OPTIONS(description="Set to True when we receive a delete record.")
);
