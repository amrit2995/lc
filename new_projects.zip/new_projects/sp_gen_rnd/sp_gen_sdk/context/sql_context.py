from sp_gen_sdk.model.sql import DDLQuery, Table


class SqlContext:
    """
    Parses and holds DDL-defined table schemas.

    Acts as the single source of truth for SQL schema in any consumer.
    Any generator (fact, dimension, stored proc) can build a SqlContext
    from DDL files and query it by table name.
    """

    def __init__(
        self,
        source_tables: list[Table],
        dim_tables: list[Table],
        fact_table: Table,
    ):
        self.source_tables = source_tables
        self.dim_tables = dim_tables
        self.fact_table = fact_table
        self._all: dict[str, Table] = {
            t.name: t for t in [*source_tables, *dim_tables, fact_table]
        }

    @classmethod
    def _parse_ddl_file(cls, path: str) -> list[Table]:
        """Parse a file that may contain one or more CREATE TABLE statements."""
        with open(path, "r") as f:
            content = f.read()
        # Split on semicolons to handle multi-statement files
        statements = [s.strip() for s in content.split(";") if s.strip()]
        tables = []
        for stmt in statements:
            try:
                ddl = DDLQuery.parse(stmt)
                if ddl.table:
                    tables.append(ddl.table)
            except (ValueError, Exception):
                pass  # Skip non-CREATE or unparseable blocks
        return tables

    @classmethod
    def from_files(
        cls,
        source_ddl_path: str,
        dim_ddl_path: str,
        fact_ddl_path: str,
    ) -> "SqlContext":
        source_tables = cls._parse_ddl_file(source_ddl_path)
        dim_tables = cls._parse_ddl_file(dim_ddl_path)
        fact_tables = cls._parse_ddl_file(fact_ddl_path)

        if not fact_tables:
            raise ValueError(f"No valid CREATE TABLE found in fact DDL: {fact_ddl_path}")

        return cls(
            source_tables=source_tables,
            dim_tables=dim_tables,
            fact_table=fact_tables[0],
        )

    def get_table(self, name: str) -> Table:
        """Lookup a table by its unqualified name."""
        table = self._all.get(name)
        if not table:
            raise KeyError(f"Table '{name}' not found in SqlContext.")
        return table
