from sp_gen_sdk.model.workbook import Workbook, Spreadsheet


class WorkbookContext:
    """
    Loads and manages access to an Excel workbook.

    Consumers get strongly-typed Spreadsheet objects by sheet name.
    Fully decoupled from SQL and mapping domains.
    """

    def __init__(self, workbook: Workbook):
        self.workbook = workbook

    @classmethod
    def from_file(cls, path: str) -> "WorkbookContext":
        return cls(workbook=Workbook(file_path=path))

    def get_sheet(self, name: str) -> Spreadsheet:
        return self.workbook.get_sheet_by_name(name)

    def sheet_names(self) -> list[str]:
        return self.workbook.sheet_names_list

    def close(self):
        self.workbook.close()
