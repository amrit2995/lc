# sp_gen_sdk.context
# Context classes manage the state of their respective domain entities.
# They are the bridge between raw files/data and the entity models.
