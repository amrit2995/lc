from sp_gen_sdk.model.workbook import Spreadsheet
from sp_gen_sdk.model.mapping import MappingRow, MappingType


# Column index constants (0-based within a data row)
# Adjust these to match your actual workbook header layout.
_COL_TARGET = 0       # Target analytical column
_COL_SRC_TABLE = 1    # Source table
_COL_SRC_COL = 2      # Source column
_COL_TRANSFORM = 3    # Transformation / expression
_COL_DIM_TABLE = 4    # Dimension table (for DIM_LOOKUP)
_COL_DIM_SK = 5       # Surrogate key column in dim table

_HEADER_MARKER = "Target analytical Column"  # cell that marks the header row


class MappingContext:
    """
    Reads a Spreadsheet and produces a list of MappingRow entities.

    Accepts a Spreadsheet (not a file path) to keep the boundary clean —
    WorkbookContext is responsible for file I/O; MappingContext only
    knows about row-level structure.
    """

    def __init__(self, rows: list[MappingRow], sheet_name: str):
        self.rows = rows
        self.sheet_name = sheet_name

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_spreadsheet(cls, spreadsheet: Spreadsheet) -> "MappingContext":
        all_rows = spreadsheet.get_all_rows()
        header_index = cls._find_header_row(all_rows)
        if header_index is None:
            raise ValueError(
                f"Could not find header row containing '{_HEADER_MARKER}' "
                f"in sheet '{spreadsheet.title}'"
            )

        mapping_rows = cls._parse_data_rows(all_rows[header_index + 1:])
        return cls(rows=mapping_rows, sheet_name=spreadsheet.title)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _find_header_row(all_rows: list[tuple]) -> int | None:
        for i, row in enumerate(all_rows):
            if any(
                isinstance(cell, str) and _HEADER_MARKER.lower() in cell.lower()
                for cell in row
            ):
                return i
        return None

    @classmethod
    def _parse_data_rows(cls, data_rows: list[tuple]) -> list[MappingRow]:
        rows: list[MappingRow] = []
        current_platform: str | None = None

        for row in data_rows:
            # Skip fully empty rows
            if all(cell is None or str(cell).strip() == "" for cell in row):
                continue

            target_col = cls._val(row, _COL_TARGET)

            # Detect platform sub-section header rows:
            # They have a non-empty first cell but no source table / col data.
            src_table = cls._val(row, _COL_SRC_TABLE)
            src_col = cls._val(row, _COL_SRC_COL)
            if target_col and not src_table and not src_col:
                current_platform = target_col
                continue

            if not target_col:
                continue

            transform = cls._val(row, _COL_TRANSFORM)
            dim_table = cls._val(row, _COL_DIM_TABLE)
            dim_sk = cls._val(row, _COL_DIM_SK)

            mapping_type = cls._infer_type(src_table, src_col, transform, dim_table)

            rows.append(
                MappingRow(
                    target_col=target_col,
                    source_table=src_table,
                    source_col=src_col,
                    transformation=transform,
                    dim_table=dim_table,
                    dim_sk=dim_sk,
                    mapping_type=mapping_type,
                    platform=current_platform,
                )
            )
        return rows

    @staticmethod
    def _val(row: tuple, idx: int) -> str | None:
        try:
            v = row[idx]
            return str(v).strip() if v is not None and str(v).strip() else None
        except IndexError:
            return None

    @staticmethod
    def _infer_type(
        src_table: str | None,
        src_col: str | None,
        transform: str | None,
        dim_table: str | None,
    ) -> MappingType:
        if dim_table:
            return MappingType.DIM_LOOKUP
        if src_table is None and src_col is None:
            return MappingType.HARDCODED
        if transform:
            return MappingType.DERIVED
        return MappingType.DIRECT
