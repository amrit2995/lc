"""
conftest.py — builds sample_mapping.xlsx programmatically for tests.
"""
import pytest
import openpyxl
import os


FIXTURES_DIR = os.path.dirname(__file__)
SAMPLE_XLSX = os.path.join(FIXTURES_DIR, "sample_mapping.xlsx")

SOURCE_TABLE = "ad_performance"
DIM_TABLE = "D1_AD_MEDIA_CAMPAIGN"

ROWS = [
    # Header row
    ("Target analytical Column", "Source Table", "Source Column", "Transformation", "Dimension Table", "SK Column"),
    # Platform sub-section
    ("DV360", None, None, None, None, None),
    # DIRECT
    ("TOTAL_IMPRESSION_CNT", SOURCE_TABLE, "impressions_cnt", None, None, None),
    # DIRECT
    ("TOTAL_CLICK_CNT", SOURCE_TABLE, "clicks_cnt", None, None, None),
    # DIM_LOOKUP
    ("AD_MEDIA_CAMPAIGN_D1_SK", SOURCE_TABLE, "AD_CAMPAIGN_ID", None, DIM_TABLE, "AD_MEDIA_CAMPAIGN_D1_SK"),
    # DERIVED
    ("PLATFORM_LABEL", SOURCE_TABLE, "platform_cd", "UPPER(ad_performance.platform_cd)", None, None),
    # HARDCODED
    ("RECORD_SOURCE", None, None, "'FACT_LOAD'", None, None),
    # Audit
    ("DW_CREATE_TS", None, None, None, None, None),
]


@pytest.fixture(scope="session", autouse=True)
def sample_xlsx():
    """Generate sample_mapping.xlsx before the test session."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "SocialPerformance Mapping"
    for row in ROWS:
        ws.append(row)
    wb.save(SAMPLE_XLSX)
    yield SAMPLE_XLSX
    # Leave file on disk for manual inspection; remove if desired:
    # os.remove(SAMPLE_XLSX)
