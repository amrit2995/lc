"""End-to-end integration test for FactQueryContext."""
import os
import pytest
from fact_query_gen.context import FactQueryContext

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


@pytest.fixture
def ctx(sample_xlsx):
    # sample_xlsx fixture generates the file; declared as arg to ensure ordering
    return FactQueryContext.build(
        workbook_path=sample_xlsx,
        sheet_name="SocialPerformance Mapping",
        source_ddl_path=os.path.join(FIXTURES, "source_tables.sql"),
        dim_ddl_path=os.path.join(FIXTURES, "dimension_tables.sql"),
        fact_ddl_path=os.path.join(FIXTURES, "fact_table.sql"),
    )


def test_generate_sql_returns_string(ctx):
    sql = ctx.generate_sql()
    assert isinstance(sql, str)
    assert len(sql) > 0


def test_insert_into_fact_table(ctx):
    sql = ctx.generate_sql()
    assert "INSERT INTO" in sql
    assert "F_AD_PLATFORM_CAMPAIGN_TREND" in sql


def test_select_present(ctx):
    sql = ctx.generate_sql()
    assert "SELECT" in sql


def test_direct_mapping_in_output(ctx):
    sql = ctx.generate_sql()
    assert "impressions_cnt" in sql


def test_dim_join_in_output(ctx):
    sql = ctx.generate_sql()
    assert "LEFT JOIN" in sql
    assert "D1_AD_MEDIA_CAMPAIGN" in sql


def test_audit_col_in_output(ctx):
    sql = ctx.generate_sql()
    assert "CURRENT_TIMESTAMP()" in sql
