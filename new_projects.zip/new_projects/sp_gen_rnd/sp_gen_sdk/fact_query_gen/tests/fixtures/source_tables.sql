CREATE TABLE `project.dataset.ad_performance` (
  impressions_cnt INT64,
  clicks_cnt INT64,
  platform_cd STRING
);
