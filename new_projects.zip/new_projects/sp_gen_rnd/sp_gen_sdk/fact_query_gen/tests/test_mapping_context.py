"""Tests for sp_gen_sdk.context.mapping_context.MappingContext."""
import os
import pytest
import openpyxl
from io import BytesIO

from sp_gen_sdk.model.workbook import Spreadsheet, Workbook
from sp_gen_sdk.model.mapping import MappingType
from sp_gen_sdk.context.mapping_context import MappingContext


def _make_spreadsheet(rows: list[tuple]) -> Spreadsheet:
    """Helper: build an in-memory openpyxl worksheet wrapped in Spreadsheet."""
    wb = openpyxl.Workbook()
    ws = wb.active
    for row in rows:
        ws.append(row)
    return Spreadsheet(ws)


BASE_ROWS = [
    ("Target analytical Column", "Source Table", "Source Column", "Transformation", "Dimension Table", "SK Column"),
    ("TOTAL_IMPRESSION_CNT", "ad_performance", "impressions_cnt", None, None, None),
    ("PLATFORM_LABEL", "ad_performance", "platform_cd", "UPPER(platform_cd)", None, None),
    ("AD_MEDIA_CAMPAIGN_D1_SK", "ad_performance", "AD_CAMPAIGN_ID", None, "D1_AD_MEDIA_CAMPAIGN", "AD_MEDIA_CAMPAIGN_D1_SK"),
    ("RECORD_SOURCE", None, None, "'FACT_LOAD'", None, None),
]


def test_header_detection():
    ss = _make_spreadsheet(BASE_ROWS)
    ctx = MappingContext.from_spreadsheet(ss)
    assert len(ctx.rows) == len(BASE_ROWS) - 1  # excludes header


def test_direct_mapping():
    ss = _make_spreadsheet(BASE_ROWS)
    ctx = MappingContext.from_spreadsheet(ss)
    direct = next(r for r in ctx.rows if r.target_col == "TOTAL_IMPRESSION_CNT")
    assert direct.mapping_type == MappingType.DIRECT
    assert direct.source_col == "impressions_cnt"


def test_derived_mapping():
    ss = _make_spreadsheet(BASE_ROWS)
    ctx = MappingContext.from_spreadsheet(ss)
    derived = next(r for r in ctx.rows if r.target_col == "PLATFORM_LABEL")
    assert derived.mapping_type == MappingType.DERIVED
    assert derived.transformation == "UPPER(platform_cd)"


def test_dim_lookup_mapping():
    ss = _make_spreadsheet(BASE_ROWS)
    ctx = MappingContext.from_spreadsheet(ss)
    dim = next(r for r in ctx.rows if r.target_col == "AD_MEDIA_CAMPAIGN_D1_SK")
    assert dim.mapping_type == MappingType.DIM_LOOKUP
    assert dim.dim_table == "D1_AD_MEDIA_CAMPAIGN"
    assert dim.dim_sk == "AD_MEDIA_CAMPAIGN_D1_SK"


def test_hardcoded_mapping():
    ss = _make_spreadsheet(BASE_ROWS)
    ctx = MappingContext.from_spreadsheet(ss)
    hc = next(r for r in ctx.rows if r.target_col == "RECORD_SOURCE")
    assert hc.mapping_type == MappingType.HARDCODED
    assert hc.transformation == "'FACT_LOAD'"


def test_platform_subsection_tagging():
    rows = [
        ("Target analytical Column", "Source Table", "Source Column", "Transformation", "Dimension Table", "SK Column"),
        ("DV360", None, None, None, None, None),  # sub-section header
        ("TOTAL_IMPRESSION_CNT", "ad_performance", "impressions_cnt", None, None, None),
    ]
    ss = _make_spreadsheet(rows)
    ctx = MappingContext.from_spreadsheet(ss)
    assert ctx.rows[0].platform == "DV360"


def test_missing_header_raises():
    ss = _make_spreadsheet([("Col A", "Col B"), ("val1", "val2")])
    with pytest.raises(ValueError, match="header row"):
        MappingContext.from_spreadsheet(ss)
