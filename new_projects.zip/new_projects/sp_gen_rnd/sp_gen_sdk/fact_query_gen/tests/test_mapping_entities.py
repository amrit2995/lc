"""Tests for sp_gen_sdk.model.mapping entities."""
import pytest
from sp_gen_sdk.model.mapping import MappingRow, MappingType


def test_default_mapping_type():
    row = MappingRow(target_col="MY_COL", source_table="tbl", source_col="col")
    assert row.mapping_type == MappingType.DIRECT


def test_derived_mapping_type():
    row = MappingRow(target_col="X", mapping_type=MappingType.DERIVED, transformation="UPPER(x)")
    assert row.mapping_type == MappingType.DERIVED
    assert row.transformation == "UPPER(x)"


def test_dim_lookup_mapping_type():
    row = MappingRow(target_col="SK", dim_table="D1_DIM", dim_sk="SK_COL", mapping_type=MappingType.DIM_LOOKUP)
    assert row.dim_table == "D1_DIM"
    assert row.dim_sk == "SK_COL"


def test_hardcoded_mapping_type():
    row = MappingRow(target_col="SRC", mapping_type=MappingType.HARDCODED, transformation="'CONST'")
    assert row.mapping_type == MappingType.HARDCODED


def test_platform_field():
    row = MappingRow(target_col="COL", platform="DV360")
    assert row.platform == "DV360"


def test_optional_fields_default_none():
    row = MappingRow(target_col="COL")
    assert row.source_table is None
    assert row.dim_table is None
    assert row.transformation is None
