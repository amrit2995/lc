"""Tests for fact_query_gen.query_builder.build_query."""
import os
import pytest
import openpyxl

from sp_gen_sdk.context.sql_context import SqlContext
from sp_gen_sdk.context.mapping_context import MappingContext
from sp_gen_sdk.model.workbook import Spreadsheet
from sp_gen_sdk.model.mapping import MappingRow, MappingType
from fact_query_gen.query_builder import build_query

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def _sql_ctx():
    return SqlContext.from_files(
        source_ddl_path=os.path.join(FIXTURES, "source_tables.sql"),
        dim_ddl_path=os.path.join(FIXTURES, "dimension_tables.sql"),
        fact_ddl_path=os.path.join(FIXTURES, "fact_table.sql"),
    )


def _mapping_ctx(rows: list[MappingRow]) -> MappingContext:
    return MappingContext(rows=rows, sheet_name="test")


def test_direct_col_in_select():
    ctx = _mapping_ctx([MappingRow(target_col="TOTAL_IMPRESSION_CNT", source_table="ad_performance", source_col="impressions_cnt", mapping_type=MappingType.DIRECT)])
    sql = build_query(_sql_ctx(), ctx)
    assert "ad_performance.impressions_cnt AS TOTAL_IMPRESSION_CNT" in sql


def test_derived_expr_in_select():
    ctx = _mapping_ctx([MappingRow(target_col="PLATFORM_LABEL", source_table="ad_performance", source_col="platform_cd", transformation="UPPER(platform_cd)", mapping_type=MappingType.DERIVED)])
    sql = build_query(_sql_ctx(), ctx)
    assert "(UPPER(platform_cd)) AS PLATFORM_LABEL" in sql


def test_dim_join_added():
    ctx = _mapping_ctx([MappingRow(target_col="AD_MEDIA_CAMPAIGN_D1_SK", source_table="ad_performance", source_col="AD_CAMPAIGN_ID", dim_table="D1_AD_MEDIA_CAMPAIGN", dim_sk="AD_MEDIA_CAMPAIGN_D1_SK", mapping_type=MappingType.DIM_LOOKUP)])
    sql = build_query(_sql_ctx(), ctx)
    assert "LEFT JOIN D1_AD_MEDIA_CAMPAIGN" in sql


def test_null_hardcoded():
    ctx = _mapping_ctx([MappingRow(target_col="RECORD_SOURCE", mapping_type=MappingType.HARDCODED, transformation="'FACT_LOAD'")])
    sql = build_query(_sql_ctx(), ctx)
    assert "'FACT_LOAD' AS RECORD_SOURCE" in sql


def test_audit_columns_use_current_timestamp():
    ctx = _mapping_ctx([MappingRow(target_col="DW_CREATE_TS", mapping_type=MappingType.HARDCODED)])
    sql = build_query(_sql_ctx(), ctx)
    assert "CURRENT_TIMESTAMP() AS DW_CREATE_TS" in sql


def test_insert_wrapper():
    ctx = _mapping_ctx([MappingRow(target_col="TOTAL_IMPRESSION_CNT", source_table="ad_performance", source_col="impressions_cnt", mapping_type=MappingType.DIRECT)])
    sql = build_query(_sql_ctx(), ctx)
    assert sql.strip().startswith("INSERT INTO")
    assert "SELECT" in sql
