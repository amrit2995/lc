"""Tests for sp_gen_sdk.context.sql_context.SqlContext."""
import os
import pytest
from sp_gen_sdk.context.sql_context import SqlContext

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


@pytest.fixture
def sql_ctx():
    return SqlContext.from_files(
        source_ddl_path=os.path.join(FIXTURES, "source_tables.sql"),
        dim_ddl_path=os.path.join(FIXTURES, "dimension_tables.sql"),
        fact_ddl_path=os.path.join(FIXTURES, "fact_table.sql"),
    )


def test_fact_table_loaded(sql_ctx):
    assert sql_ctx.fact_table.name == "F_AD_PLATFORM_CAMPAIGN_TREND"


def test_source_tables_loaded(sql_ctx):
    assert any(t.name == "ad_performance" for t in sql_ctx.source_tables)


def test_dim_tables_loaded(sql_ctx):
    assert any(t.name == "D1_AD_MEDIA_CAMPAIGN" for t in sql_ctx.dim_tables)


def test_get_table_by_name(sql_ctx):
    tbl = sql_ctx.get_table("ad_performance")
    assert tbl is not None
    col_names = tbl.list_cols()
    assert "impressions_cnt" in col_names


def test_get_unknown_table_raises(sql_ctx):
    with pytest.raises(KeyError):
        sql_ctx.get_table("non_existent_table")


def test_fact_table_column_names(sql_ctx):
    cols = sql_ctx.fact_table.list_cols()
    assert "TOTAL_IMPRESSION_CNT" in cols
    assert "DW_CREATE_TS" in cols
