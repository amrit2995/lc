"""
context.py
----------
FactQueryContext is the top-level orchestrator for fact table SQL generation.

It wires together the three SDK contexts:
  - SqlContext       (from sp_gen_sdk)
  - WorkbookContext  (from sp_gen_sdk)
  - MappingContext   (from sp_gen_sdk)

and delegates SQL assembly to query_builder.build_query().
"""
from sp_gen_sdk.context.sql_context import SqlContext
from sp_gen_sdk.context.workbook_context import WorkbookContext
from sp_gen_sdk.context.mapping_context import MappingContext
from fact_query_gen.query_builder import build_query


class FactQueryContext:
    """
    Orchestrates fact-table SQL generation.

    Consumers only need to call FactQueryContext.build() + generate_sql().
    All domain-specific logic lives in the SDK contexts and query_builder.
    """

    def __init__(
        self,
        sql: SqlContext,
        workbook: WorkbookContext,
        mapping: MappingContext,
    ):
        self.sql = sql
        self.workbook = workbook
        self.mapping = mapping

    @classmethod
    def build(
        cls,
        workbook_path: str,
        sheet_name: str,
        source_ddl_path: str,
        dim_ddl_path: str,
        fact_ddl_path: str,
    ) -> "FactQueryContext":
        sql_ctx = SqlContext.from_files(source_ddl_path, dim_ddl_path, fact_ddl_path)
        wb_ctx = WorkbookContext.from_file(workbook_path)
        sheet = wb_ctx.get_sheet(sheet_name)
        mapping_ctx = MappingContext.from_spreadsheet(sheet)
        return cls(sql=sql_ctx, workbook=wb_ctx, mapping=mapping_ctx)

    def generate_sql(self) -> str:
        return build_query(self.sql, self.mapping)
