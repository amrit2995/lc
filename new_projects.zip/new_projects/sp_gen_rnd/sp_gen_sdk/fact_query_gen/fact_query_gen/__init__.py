"""
fact_query_gen
--------------
BigQuery INSERT/SELECT generator for fact tables.

Imports from sp_gen_sdk for all shared domain logic:
  - sp_gen_sdk.context.sql_context     → SqlContext
  - sp_gen_sdk.context.workbook_context → WorkbookContext
  - sp_gen_sdk.context.mapping_context  → MappingContext
"""
