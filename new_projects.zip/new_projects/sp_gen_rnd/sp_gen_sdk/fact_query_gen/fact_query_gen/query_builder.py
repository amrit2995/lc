"""
query_builder.py
----------------
Stateless function that assembles a BigQuery INSERT INTO ... SELECT statement
from a SqlContext (DDL schema) and a MappingContext (excel mapping rows).

No entity classes are defined here — this module only assembles SQL strings.
"""
from __future__ import annotations
from sp_gen_sdk.context.sql_context import SqlContext
from sp_gen_sdk.context.mapping_context import MappingContext
from sp_gen_sdk.model.mapping import MappingType

_AUDIT_COLS = {"DW_CREATE_TS", "DW_LAST_UPDATE_TS", "DW_UPDATE_TS"}


def build_query(sql_ctx: SqlContext, mapping_ctx: MappingContext) -> str:
    """
    Build a BigQuery INSERT INTO ... SELECT statement.

    Args:
        sql_ctx:     SqlContext holding source, dim, and fact Table objects.
        mapping_ctx: MappingContext holding the list of MappingRow objects.

    Returns:
        A formatted BigQuery SQL string.
    """
    fact = sql_ctx.fact_table
    fact_name = _qualified(fact)

    select_parts: list[str] = []
    join_clauses: list[str] = []
    seen_joins: set[str] = set()

    for row in mapping_ctx.rows:
        col = row.target_col

        # Audit columns — always use CURRENT_TIMESTAMP()
        if col.upper() in _AUDIT_COLS:
            select_parts.append(f"    CURRENT_TIMESTAMP() AS {col}")
            continue

        if row.mapping_type == MappingType.DIRECT:
            src = f"{row.source_table}.{row.source_col}" if row.source_table else row.source_col
            select_parts.append(f"    {src} AS {col}")

        elif row.mapping_type == MappingType.DERIVED:
            expr = row.transformation or "NULL"
            select_parts.append(f"    ({expr}) AS {col}")

        elif row.mapping_type == MappingType.DIM_LOOKUP:
            sk = f"{row.dim_table}.{row.dim_sk}" if row.dim_sk else f"{row.dim_table}.SK"
            select_parts.append(f"    {sk} AS {col}")

            # Add LEFT JOIN if not already added for this dim table
            if row.dim_table and row.dim_table not in seen_joins:
                # Attempt to find a natural-key join column
                join_key = _find_dim_join_key(sql_ctx, row.dim_table, row.source_table)
                join_clauses.append(
                    f"LEFT JOIN {row.dim_table}\n"
                    f"    ON {join_key}"
                )
                seen_joins.add(row.dim_table)

        elif row.mapping_type == MappingType.HARDCODED:
            literal = row.transformation if row.transformation else "NULL"
            select_parts.append(f"    {literal} AS {col}")

    # Derive source tables from mapping rows
    source_tables = list(
        dict.fromkeys(
            r.source_table
            for r in mapping_ctx.rows
            if r.source_table and r.mapping_type != MappingType.HARDCODED
        )
    )
    from_clause = source_tables[0] if source_tables else "-- TODO: add source table"
    additional_source_tables = source_tables[1:] if len(source_tables) > 1 else []
    additional_joins = "\nJOIN ".join(additional_source_tables)

    # Collect target column names (for INSERT header)
    target_cols = [r.target_col for r in mapping_ctx.rows]
    # Add audit cols missing from mapping
    for audit in _AUDIT_COLS:
        if audit in [c.upper() for c in [col.name for col in fact.columns]] and audit not in [c.upper() for c in target_cols]:
            target_cols.append(audit)
            select_parts.append(f"    CURRENT_TIMESTAMP() AS {audit}")

    col_list = ",\n    ".join(target_cols)
    select_list = ",\n".join(select_parts)
    joins_sql = ("\n" + "\n".join(join_clauses)) if join_clauses else ""
    extra_joins = ("\nJOIN " + additional_joins) if additional_joins else ""

    sql = (
        f"INSERT INTO {fact_name} (\n"
        f"    {col_list}\n"
        f")\n"
        f"SELECT\n"
        f"{select_list}\n"
        f"FROM {from_clause}"
        f"{extra_joins}"
        f"{joins_sql};"
    )
    return sql


def _qualified(table) -> str:
    parts = [p for p in [table.project, table.database, table.name] if p]
    if len(parts) > 1:
        return "`" + ".".join(parts) + "`"
    return table.name


def _find_dim_join_key(sql_ctx: SqlContext, dim_table_name: str, src_table_name: str | None) -> str:
    """Best-effort: find a matching column between dim and source for the ON clause."""
    try:
        dim = sql_ctx.get_table(dim_table_name)
        dim_cols = {c.name.upper() for c in dim.columns}
        if src_table_name:
            src = sql_ctx.get_table(src_table_name)
            for col in src.columns:
                if col.name.upper() in dim_cols:
                    return f"{src_table_name}.{col.name} = {dim_table_name}.{col.name}"
    except KeyError:
        pass
    return f"-- TODO: define join condition for {dim_table_name}"
