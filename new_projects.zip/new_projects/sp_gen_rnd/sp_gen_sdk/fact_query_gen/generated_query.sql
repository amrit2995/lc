INSERT INTO `CLTV_PROJECT_ID.ANALYTIC_DATASET.F_AD_PLATFORM_CAMPAIGN_RF_TREND` (
    PERFORMANCE_DAY_ID,
    AD_MEDIA_PR0MOTIONAL_CHANNEL_D1_SK,
    Target analytical Column,
    CUMULATIVE_AD_REACH_CNT,
    CUMULATIVE_AD_REACH_IMPRESSION_CNT,
    PERFORMANCE_DAY_ID,
    AD_MEDIA_PR0MOTIONAL_CHANNEL_D1_SK,
    Target analytical Column,
    CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    CUMULATIVE_IMPRESSION_CNT,
    CUMULATIVE_CLICK_CNT,
    CUMULATIVE_MEASUREMENT_REVENUE_AMT,
    CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    Target analytical Column,
    CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    CUMULATIVE_IMPRESSION_CNT,
    CUMULATIVE_CLICK_CNT,
    CUMULATIVE_MEASUREMENT_REVENUE_AMT,
    CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    Target analytical Column,
    CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    CUMULATIVE_IMPRESSION_CNT,
    CUMULATIVE_CLICK_CNT,
    CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    Target analytical Column,
    CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    CUMULATIVE_IMPRESSION_CNT,
    CUMULATIVE_CLICK_CNT,
    CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    DW_CREATE_TS,
    DW_LAST_UPDATE_TS
)
SELECT
    One Entry for Everyday where Campaign is Valid  
for PERFORMANCE_DAY_ID>=PLATFORM_CAMPAIGN_START_DT and 
PERFORMANCE_DAY_ID<=PLATFORM_CAMPAIGN_END_DT AS PERFORMANCE_DAY_ID,
    Use Sk for 'Social' Only AS AD_MEDIA_PR0MOTIONAL_CHANNEL_D1_SK,
    (Transformation) AS Target analytical Column,
    ad_creative_reach_summary.reach_cnt AS CUMULATIVE_AD_REACH_CNT,
    ad_creative_reach_summary.impressions_cnt AS CUMULATIVE_AD_REACH_IMPRESSION_CNT,
    One Entry for Everyday where Campaign is Valid 
For META, PINTEREST, GAM, CRITEO - 
PERFORMANCE_DAY_ID>=PLATFORM_CAMPAIGN_START_DT and 
PERFORMANCE_DAY_ID<= PLATFORM_CAMPAIGN_END_DT
For DV360 - PERFORMANCE_DAY_ID>=buying_campaign.start_dt and 
PERFORMANCE_DAY_ID<=buying_campaign.end_dt AS PERFORMANCE_DAY_ID,
    Use SK ONLY 'Display' For DV360
'Social' For Pinterest
'On-Site Display' For GAM AS AD_MEDIA_PR0MOTIONAL_CHANNEL_D1_SK,
    (Transformation) AS Target analytical Column,
    campaign_reach_summary.reach_cnt AS CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    campaign_reach_summary.impressions_cnt AS CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    (ROLL Up At Platform L1 Level and cumulative per date) AS CUMULATIVE_IMPRESSION_CNT,
    (ROLL Up At Platform L1 Level and cumulative per date) AS CUMULATIVE_CLICK_CNT,
    (ROLL Up At Platform L1 Level and cumulative per date) AS CUMULATIVE_MEASUREMENT_REVENUE_AMT,
    (ROLL Up At Platform L1 Level and cumulative per date) AS CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    (Transformation) AS Target analytical Column,
    campaign_reach_summary_pinterest.unique_reach_cnt AS CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    NA.NA AS CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    NA.NA AS CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    NA.NA AS CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    (ROLL Up At Platform L1 Level and cumulative per date) AS CUMULATIVE_IMPRESSION_CNT,
    (ROLL Up At Platform L1 Level and cumulative per date) AS CUMULATIVE_CLICK_CNT,
    (Cumulative per date) AS CUMULATIVE_MEASUREMENT_REVENUE_AMT,
    (ROLL Up At Platform L1 Level and cumulative per date) AS CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    (Transformation) AS Target analytical Column,
    campaign_reach_summary_gam.unique_reach_cnt AS CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    campaign_reach_summary_gam.unique_impression_reach_cnt AS CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    NA.NA AS CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    campaign_reach_summary_gam.unique_frequency_reach_cnt AS CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    ROLL Up At Platform L1 Level and cumulative per date AS CUMULATIVE_IMPRESSION_CNT,
    ROLL Up At Platform L1 Level and cumulative per date AS CUMULATIVE_CLICK_CNT,
    ROLL Up At Platform L1 Level and cumulative per date AS CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    (Transformation) AS Target analytical Column,
    campaign_reach_summary_dv360.unique_total_reach_cnt AS CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    campaign_reach_summary_dv360.unique_impression_reach_cnt AS CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    campaign_reach_summary_dv360.unique_click_reach_cnt AS CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    campaign_reach_summary_dv360.average_impression_freq AS CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    ROLL Up At Platform L1 Level and cumulative per date AS CUMULATIVE_IMPRESSION_CNT,
    ROLL Up At Platform L1 Level and cumulative per date AS CUMULATIVE_CLICK_CNT,
    ROLL Up At Platform L1 Level and cumulative per date AS CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    CURRENT_TIMESTAMP() AS DW_CREATE_TS,
    CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
FROM Source Table
JOIN ad_creative_reach_summary
JOIN campaign_reach_summary
JOIN ad_performance
JOIN F_AD_PLATFORM_CAMPAIGN_PERFORMANCE
JOIN campaign_reach_summary_pinterest
JOIN NA
JOIN campaign_reach_summary_gam
JOIN campaign_reach_summary_dv360;