"""
generate.py
-----------
Run this script directly to generate BigQuery SQL from your real workbook and DDL files.

Usage:
    python generate.py

Edit the CONFIG section below to point at your files.
"""

from fact_query_gen.context import FactQueryContext

# ──────────────────────────────────────────────
# CONFIG — edit these paths to match your files
# ──────────────────────────────────────────────

WORKBOOK_PATH = "/Users/amritprusty/Downloads/Ad_Platform_Campaign_Mapping_V1.3.4.1.xlsx"
SHEET_NAME    = "Social&Campaign RF MApping"

SOURCE_DDL = "/Users/amritprusty/Downloads/sp_gen_sdk/resources/source_path.sql"
DIM_DDL    = "/Users/amritprusty/Downloads/sp_gen_sdk/resources/d1_paths.sql"
FACT_DDL   = "/Users/amritprusty/Downloads/sp_gen_sdk/resources/fact_path.sql"

# ──────────────────────────────────────────────

if __name__ == "__main__":
    print(f"📥  Loading workbook: {WORKBOOK_PATH}")
    print(f"📄  Sheet: {SHEET_NAME}\n")

    ctx = FactQueryContext.build(
        workbook_path=WORKBOOK_PATH,
        sheet_name=SHEET_NAME,
        source_ddl_path=SOURCE_DDL,
        dim_ddl_path=DIM_DDL,
        fact_ddl_path=FACT_DDL,
    )

    print(f"✅  Mapping rows loaded: {len(ctx.mapping.rows)}")
    print(f"    Fact table        : {ctx.sql.fact_table.name}")
    print(f"    Source tables     : {[t.name for t in ctx.sql.source_tables]}")
    print(f"    Dim tables        : {[t.name for t in ctx.sql.dim_tables]}")
    print("\n" + "=" * 60)
    print("GENERATED SQL")
    print("=" * 60 + "\n")

    sql = ctx.generate_sql()
    print(sql)

    # Optional: write to file
    out_path = "generated_query.sql"
    with open(out_path, "w") as f:
        f.write(sql)
    print(f"\n💾  Saved to {out_path}")
