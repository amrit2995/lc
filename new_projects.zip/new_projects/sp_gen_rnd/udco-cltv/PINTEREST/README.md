# PINTEREST (Pinterest Ads)

Ingests and models Pinterest advertising data. Mirrors the META pipeline structure for the Pinterest platform, feeding into the shared analytical fact tables (`FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE` with `AD_MEDIA_PLATFORM_D1_SK = 2`).

## Pipeline Flow

```
GCS Files ──► [SToV] ──► Raw/Staging ──► [VToB SPs] ──► BIM Confirmed
                                                              │
                                            (shared with META analytical layer)
                                                              ▼
                                          FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE
```

### Pinterest vs META Differences
- Campaign-level aggregation (no line-level detail)
- Video and post-reaction metrics set to 0
- Pinterest-specific metrics: `TOTAL_PINTEREST_REPIN_CNT`, `TOTAL_PINTEREST_ENGAGEMENT_CNT`
- Measurement joined by campaign only (not by line)

## Directory Layout

```
PINTEREST/
├── README.md
├── params_dev.json / params_qa.json / params_prod.json
├── config/                         ← 10 Airflow workflow & step configs
│   ├── PINTEREST_CONF_WF.json      ← DAG definition
│   └── VToB_PINTEREST_*_BQToBQ.json  ← transform configs
└── scripts/
    ├── ddl/                        ← 15 table DDLs (main + _WRK + _LR_UPDATE)
    ├── sql/                        ← 11 stored procedures
    └── refined_history/            ← history insert scripts
```

## Key Entities

| Entity | Notes |
|--------|-------|
| Advertiser | Platform advertiser mapping |
| Campaign | Pinterest campaign metadata |
| Line Item | Ad group level |
| Creative | Pin creative details |
| Advertisement | Individual ad/pin |
| Line-Item-Creative | Junction table |
| Ad Performance | Daily performance metrics |
| Ad Action Reaction | Engagement action tracking |

## Deployment

| YAML | Scope |
|------|-------|
| `script_order_execution_pinterest.yaml` | SP updates (line item, placement) |
| `script_order_execution.yaml` | Full Pinterest confirmed pipeline |
| `script_order_execution_sveep00.yaml` | Same SP subset variant |
