CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_PINTEREST_CREATIVE_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE tgt_update_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts_history STRING;
DECLARE sql_inserts STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE row_count_tgt INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;
DECLARE lkp_tbl STRING;
DECLARE sql_records_to_expire STRING;

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_PINTEREST_CREATIVE_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.AD_PLATFORM_CREATIVE';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.AD_PLATFORM_CREATIVE_PINTEREST_WRK';    
SET tgt_update_tbl  = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.AD_PLATFORM_CREATIVE_PINTEREST_LR_UPDATE';    
SET src_tbl         = '<<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_promotion_history';
SET lkp_tbl         = '<<L_PROJECT_ID>>.<<L_DATASET>>.l_3_naming_corrections'; 

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "PINTEREST" ''' ;

BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;



SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
    (
        CREATIVE_ID
		,CREATIVE_NM
		,ADVERTISER_ID
		,CREATIVE_TYPE_NM
		,CREATIVE_REQUESTED_SZ
		,CREATIVE_DELIVERED_SZ
		,CREATIVE_VERSION_NBR
		,SOURCE_CREATED_TS
		,SOURCE_LAST_MODIFIED_TS
		,SOURCE_APPLICATION_CD
        ,DW_FIRST_EFFECTIVE_TS
		,DW_LAST_EFFECTIVE_TS
        ,DW_CURRENT_VERSION_IND
		)
		
		SELECT 
			SRC.CREATIVE_ID,
			SRC.CREATIVE_NM,
			SRC.ADVERTISER_ID,
			SRC.CREATIVE_TYPE_NM,
			SRC.CREATIVE_REQUESTED_SZ,
			SRC.CREATIVE_DELIVERED_SZ,
			SRC.CREATIVE_VERSION_NBR,
			SRC.SOURCE_CREATED_TS,
			SRC.SOURCE_LAST_MODIFIED_TS,
			SRC.SOURCE_APPLICATION_CD,
			SRC.DW_FIRST_EFFECTIVE_TS,
			CASE 
				WHEN SRC.dw_first_effective_ts = SRC.dw_last_effective_ts THEN '9999-12-31 00:00:00' 
				ELSE TIMESTAMP_SUB(SRC.dw_last_effective_ts, INTERVAL 1 SECOND) 
			END AS dw_last_effective_ts,
			CASE 
				WHEN SRC.dw_first_effective_ts = SRC.dw_last_effective_ts THEN TRUE 
				ELSE FALSE 
			END AS dw_current_version_ind
		FROM
		(
			SELECT 
			CREATIVE_ID,
			CREATIVE_NM,
			ADVERTISER_ID,
			CREATIVE_TYPE_NM,
			CREATIVE_REQUESTED_SZ,
			CREATIVE_DELIVERED_SZ,
			CREATIVE_VERSION_NBR,
			SOURCE_CREATED_TS,
			SOURCE_LAST_MODIFIED_TS,
			SOURCE_APPLICATION_CD,
			DW_FIRST_EFFECTIVE_TS,
			LAST_VALUE(SOURCE_LAST_MODIFIED_TS) OVER (record_window) AS DW_LAST_EFFECTIVE_TS
			FROM
			(	
				SELECT DISTINCT 
					src.pin_id AS CREATIVE_ID,
					SPLIT(COALESCE(lkp.updated_name, src.name), '|')[SAFE_OFFSET(7)] AS CREATIVE_NM,
					src.ad_account_id AS ADVERTISER_ID,
					src.creative_type AS CREATIVE_TYPE_NM,
					SPLIT(COALESCE(lkp.updated_name, src.name), '|')[SAFE_OFFSET(16)] AS CREATIVE_REQUESTED_SZ,
					cast(null as string) AS CREATIVE_DELIVERED_SZ,
					cast(null as string) AS CREATIVE_VERSION_NBR,
					CAST(src.created_time AS TIMESTAMP) AS SOURCE_CREATED_TS,
					CAST(src.updated_time AS TIMESTAMP) AS SOURCE_LAST_MODIFIED_TS,
					'PINTEREST' AS SOURCE_APPLICATION_CD,
					CAST(src.updated_time AS TIMESTAMP) AS DW_FIRST_EFFECTIVE_TS,
					_fivetran_synced
				FROM ''' || src_tbl || ''' src

				LEFT JOIN --- Lookup table to get updated names
				(
					SELECT id, updated_name
					FROM 
					(
						SELECT DISTINCT id, updated_name,
								ROW_NUMBER() OVER (PARTITION BY id ORDER BY _fivetran_synced DESC, _row DESC) AS rn
						FROM ''' || lkp_tbl || '''
					)
					WHERE rn = 1
				) lkp 
				ON CAST(lkp.id AS STRING) = src.pin_id
				WHERE _fivetran_synced > "''' || data_extract_start_ts || '''"
				AND SRC.updated_time IS NOT NULL
				AND SRC.PIN_ID IS NOT NULL
				QUALIFY ROW_NUMBER() OVER (PARTITION BY pin_id, updated_time ORDER BY creative_nm DESC, ad_account_id DESC, creative_type DESC, creative_requested_sz DESC) = 1
			) SRC
			WINDOW  record_window AS (PARTITION BY CREATIVE_ID ORDER BY SOURCE_LAST_MODIFIED_TS ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
		) AS SRC

		LEFT JOIN ''' || tgt_tbl || ''' TGT -- to identify Inserts and Updates
		ON SRC.CREATIVE_ID = TGT.CREATIVE_ID
		AND TGT.DW_CURRENT_VERSION_IND = TRUE
		AND TGT.SOURCE_APPLICATION_CD = SRC.SOURCE_APPLICATION_CD

		WHERE TGT.CREATIVE_ID IS NULL
		OR SRC.DW_FIRST_EFFECTIVE_TS > TGT.DW_FIRST_EFFECTIVE_TS

        ''';


--//SCD Type2 transaction begins
SET sql_begin = "BEGIN TRANSACTION";

SET sql_records_to_expire = '''INSERT INTO ''' || tgt_update_tbl || ''' 
                            (
                            CREATIVE_ID,
                            SOURCE_APPLICATION_CD,
                            DW_FIRST_EFFECTIVE_TS,
                            DW_LAST_EFFECTIVE_TS,
                            DW_CURRENT_VERSION_IND
                            )
                            SELECT  
                                TGT.CREATIVE_ID
                                ,TGT.source_application_cd
                                ,TGT.dw_first_effective_ts
                                ,TIMESTAMP_SUB(SRC.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts
                                ,FALSE AS dw_current_version_ind
                            FROM    ''' || tgt_tbl || '''  TGT
                            INNER  JOIN (
                                SELECT *
                                FROM    ''' || tgt_wrk_tbl || ''' 
                                QUALIFY ROW_NUMBER() OVER (PARTITION BY CREATIVE_ID, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
                            ) SRC
                            ON      TGT.CREATIVE_ID = SRC.CREATIVE_ID
                            AND     TGT.source_application_cd = SRC.source_application_cd
                            WHERE   TGT.dw_current_version_ind = TRUE
''';

SET sql_updates = '''--// Processing Updates of Type 2 SCD
                UPDATE ''' || tgt_tbl || ''' as TGT
                    SET  
                        DW_LAST_EFFECTIVE_TS = SRC.DW_LAST_EFFECTIVE_TS
                        ,DW_CURRENT_VERSION_IND = FALSE
                        ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                        ,DW_SOURCE_UPDATE_NM = "PINTEREST"
                    FROM ''' || tgt_update_tbl || '''  SRC 
                    WHERE TGT.CREATIVE_ID = SRC.CREATIVE_ID
                        AND TGT.SOURCE_APPLICATION_CD = SRC.SOURCE_APPLICATION_CD
                        AND TGT.dw_first_effective_ts = SRC.dw_first_effective_ts
                ''';
		

--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
                        CREATIVE_ID
						,SOURCE_APPLICATION_CD
                        ,DW_FIRST_EFFECTIVE_TS
						,DW_LAST_EFFECTIVE_TS
						,CREATIVE_NM
						,ADVERTISER_ID
						,CREATIVE_TYPE_NM
						,CREATIVE_REQUESTED_SZ
						,CREATIVE_DELIVERED_SZ
						,CREATIVE_VERSION_NBR
                        ,SOURCE_CREATED_TS
                        ,SOURCE_LAST_MODIFIED_TS
						,DW_CREATE_TS
                        ,DW_LAST_UPDATE_TS
                        ,DW_LOGICAL_DELETE_IND
                        ,DW_SOURCE_CREATE_NM
                        ,DW_SOURCE_UPDATE_NM
                        ,DW_CURRENT_VERSION_IND
                        )
                        SELECT 
                            CREATIVE_ID
							,SOURCE_APPLICATION_CD
                            ,DW_FIRST_EFFECTIVE_TS
							,DW_LAST_EFFECTIVE_TS
							,CREATIVE_NM
							,ADVERTISER_ID
							,CREATIVE_TYPE_NM
							,CREATIVE_REQUESTED_SZ
							,CREATIVE_DELIVERED_SZ
							,CREATIVE_VERSION_NBR
                            ,SOURCE_CREATED_TS
                            ,SOURCE_LAST_MODIFIED_TS
							,CURRENT_TIMESTAMP AS DW_CREATE_TS
                            ,CURRENT_TIMESTAMP AS DW_LAST_UPDATE_TS
                            ,FALSE AS DW_LOGICAL_DELETE_IND
                            ,"PINTEREST" AS DW_SOURCE_CREATE_NM
                            ,"PINTEREST" AS DW_SOURCE_UPDATE_NM  
                            ,DW_CURRENT_VERSION_IND
                        FROM ''' || tgt_wrk_tbl  || '''
						''';


SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
	EXECUTE IMMEDIATE (sql_begin);    
    IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
        EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
    END IF;       
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    EXECUTE IMMEDIATE (sql_records_to_expire);
    EXECUTE IMMEDIATE (sql_updates);
    EXECUTE IMMEDIATE (sql_inserts);
	SET row_count = @@row_count;
	EXECUTE IMMEDIATE (sql_commit);
	EXCEPTION WHEN ERROR THEN
	EXECUTE IMMEDIATE (sql_rollback);
	SET job_end  = CURRENT_TIMESTAMP();
	SET status   = "FAILED";
	SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
	RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Pinterest','Confirmed',CURRENT_DATE(),"AD_PLATFORM_CREATIVE");
END;