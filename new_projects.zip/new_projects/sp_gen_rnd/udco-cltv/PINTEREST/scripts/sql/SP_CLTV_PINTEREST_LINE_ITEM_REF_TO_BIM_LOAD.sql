CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_PINTEREST_LINE_ITEM_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE tgt_update_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts STRING;
DECLARE sql_inserts_history STRING;
DECLARE tgt_tbl STRING;
DECLARE lkp_tbl STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;
DECLARE src_tbl_ch STRING;
DECLARE sql_records_to_expire STRING;



SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_PINTEREST_LINE_ITEM_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.AD_PLATFORM_LINE_ITEM';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.AD_PLATFORM_LINE_ITEM_PINTEREST_WRK';        
SET tgt_update_tbl  = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.AD_PLATFORM_LINE_ITEM_PINTEREST_LR_UPDATE';
SET src_tbl         = '<<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.ad_group_history';  --// Source table
SET src_tbl_ch         = '<<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.campaign_history'; 
SET lkp_tbl         = '<<L_PROJECT_ID>>.<<L_DATASET>>.l_2_naming_corrections';  --// Lookup table


SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "PINTEREST" ''' ;

BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
        LINE_ITEM_ID
        ,SOURCE_APPLICATION_CD
        ,DW_FIRST_EFFECTIVE_TS
        ,DW_LAST_EFFECTIVE_TS
        ,CAMPAIGN_ID
        ,LINE_ITEM_NM
        ,LINE_ITEM_TYPE_NM
        ,UNITS_BOUGHT_CNT
        ,LINE_ITEM_SHORT_NM
        ,LINE_ITEM_BUDGET_AMT
        ,STATUS_NM
        ,START_TS
        ,END_TS
        ,AUDIENCE_NM
        ,AD_COST_TYPE_CD
        ,AD_COST_AMT
        ,DAILY_BUDGET_AMT
        ,EXPECTED_DAILY_SPEND_AMT
        ,PLANNED_IMPRESSION_CNT
        ,SOURCE_CREATED_TS
        ,SOURCE_LAST_MODIFIED_TS
        ,dw_current_version_ind
        )
	
        SELECT 
                SRC.LINE_ITEM_ID
                ,SRC.SOURCE_APPLICATION_CD
                ,SRC.DW_FIRST_EFFECTIVE_TS
                ,CASE 
                        WHEN SRC.DW_FIRST_EFFECTIVE_TS = SRC.DW_LAST_EFFECTIVE_TS THEN '9999-12-31 00:00:00' 
                        ELSE TIMESTAMP_SUB(SRC.DW_LAST_EFFECTIVE_TS, INTERVAL 1 SECOND) 
                END AS dw_last_effective_ts
                ,SRC.CAMPAIGN_ID
                ,SRC.LINE_ITEM_NM
                ,SRC.LINE_ITEM_TYPE_NM
                ,SRC.UNITS_BOUGHT_CNT
                ,SRC.LINE_ITEM_SHORT_NM
                ,SRC.LINE_ITEM_BUDGET_AMT
                ,SRC.STATUS_NM
                ,SRC.START_TS
                ,SRC.END_TS
                ,SRC.AUDIENCE_NM
                ,SRC.AD_COST_TYPE_CD
                ,SRC.AD_COST_AMT
                ,SRC.DAILY_BUDGET_AMT
                ,SRC.EXPECTED_DAILY_SPEND_AMT
                ,SRC.PLANNED_IMPRESSION_CNT
                ,SRC.SOURCE_CREATED_TS
                ,SRC.SOURCE_LAST_MODIFIED_TS
                ,CASE 
                        WHEN SRC.DW_FIRST_EFFECTIVE_TS = SRC.DW_LAST_EFFECTIVE_TS THEN TRUE 
                        ELSE FALSE 
                END AS dw_current_version_ind 
        FROM
        (
                SELECT 
                        SRC_SUB.*
                        ,LAST_VALUE(SRC_SUB.DW_FIRST_EFFECTIVE_TS) OVER (record_window) AS DW_LAST_EFFECTIVE_TS
                FROM 
                (       SELECT 
                                DISTINCT CAST(SRC.ID AS STRING) AS LINE_ITEM_ID
                                ,"PINTEREST" AS SOURCE_APPLICATION_CD
                                ,CAST(SRC.UPDATED_TIME AS TIMESTAMP) AS DW_FIRST_EFFECTIVE_TS
                                ,CAST(SRC.campaign_Id AS STRING) AS CAMPAIGN_ID
                                ,COALESCE(correction.updated_name, SRC.name) AS LINE_ITEM_NM                   --l_2_naming_correction
                                ,CAST(NULL AS STRING) AS LINE_ITEM_TYPE_NM              
                                ,CAST(NULL AS INT64) AS UNITS_BOUGHT_CNT        
                                ,SUBSTR(COALESCE(correction.updated_name, SRC.name), 0, INSTR(COALESCE(correction.updated_name, SRC.name), '|', 1, 16))  AS LINE_ITEM_SHORT_NM       --l_2_naming_correction (new field)
                                ,SAFE_CAST(SPLIT(COALESCE(correction.updated_name, SRC.name), '|')[SAFE_OFFSET(14)] as NUMERIC) AS LINE_ITEM_BUDGET_AMT      --l_2_naming_correction (new field)
                                ,Status AS STATUS_NM
                                ,TIMESTAMP(SAFE.PARSE_DATE('%m/%d/%Y',SPLIT(COALESCE(correction.updated_name, SRC.name),'|')[SAFE_OFFSET(8)])) AS START_TS                 --column name change
                                ,TIMESTAMP(SAFE.PARSE_DATE('%m/%d/%Y',SPLIT(COALESCE(correction.updated_name, SRC.name),'|')[SAFE_OFFSET(9)])) AS END_TS                 --column name change   
                                                ,CAST(SPLIT(COALESCE(correction.updated_name, SRC.name),'|')[SAFE_OFFSET(4)] AS STRING) as AUDIENCE_NM             --l_2_naming_correction new field
                                ,"CPM" AS AD_COST_TYPE_CD                               -- new field, default value
                                ,SAFE_CAST(SPLIT(COALESCE(correction.updated_name, SRC.name), '|')[SAFE_OFFSET(11)] AS NUMERIC)  AS AD_COST_AMT   --l_2_naming_correction new field
                                ,SAFE_CAST(SPLIT(COALESCE(correction.updated_name, SRC.name), '|')[SAFE_OFFSET(14)] as NUMERIC)/
                                                        (DATE_DIFF(SAFE.PARSE_DATE('%m/%d/%Y',SPLIT(COALESCE(correction.updated_name, SRC.name),'|')[SAFE_OFFSET(9)]),SAFE.PARSE_DATE('%m/%d/%Y',SPLIT(COALESCE(correction.updated_name, SRC.name),'|')[SAFE_OFFSET(8)]), DAY)) AS DAILY_BUDGET_AMT              -- new field
                                ,CH.daily_spend_cap AS EXPECTED_DAILY_SPEND_AMT   -- new field
                                ,SAFE_CAST(SPLIT(COALESCE(correction.updated_name, SRC.name), '|')[SAFE_OFFSET(10)] as INT64) AS PLANNED_IMPRESSION_CNT                -- new field
                                ,created_time AS SOURCE_CREATED_TS                          
                                ,src.updated_time AS SOURCE_LAST_MODIFIED_TS
                                ,_fivetran_synced
                        FROM
                        ''' || src_tbl || ''' SRC
                        LEFT JOIN (select distinct id, updated_time, daily_spend_cap from ''' || src_tbl_ch || ''') ch
                                on SRC.campaign_id = ch.id 
                                and SRC.updated_time >= ch.updated_time
                        LEFT JOIN (SELECT DISTINCT id,updated_name
                                FROM ''' || lkp_tbl || ''' correction
                                WHERE site='Pinterest'
                                QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY _fivetran_synced desc) = 1
                                ) correction
                                ON TRIM(CAST(SRC.id AS STRING)) = TRIM(CAST(correction.id AS STRING)) 
                        WHERE _fivetran_synced > "''' || data_extract_start_ts || '''"
                                AND SRC.ID IS NOT NULL
                                AND SRC.UPDATED_TIME IS NOT NULL
                                AND SRC.campaign_Id IS NOT NULL
                        QUALIFY ROW_NUMBER() OVER (PARTITION BY src.id, src.campaign_id, src.updated_time ORDER BY ch.updated_time DESC) = 1 ) SRC_SUB
                WINDOW  record_window AS (PARTITION BY SRC_SUB.LINE_ITEM_ID ORDER BY SRC_SUB.DW_FIRST_EFFECTIVE_TS ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        ) AS SRC

        -- TO REMOVE THE incoming records where the dw_first_effective_ts is earlier than the "current version" dw_first_effective_ts in production
        LEFT JOIN ''' || tgt_tbl || ''' TGT 
                ON SRC.LINE_ITEM_ID = TGT.LINE_ITEM_ID
                AND TGT.DW_CURRENT_VERSION_IND = TRUE
                AND SRC.SOURCE_APPLICATION_CD = TGT.SOURCE_APPLICATION_CD
        WHERE TGT.LINE_ITEM_ID IS NULL
                OR SRC.dw_first_effective_ts > TGT.dw_first_effective_ts
        ''';



--//SCD Type2 transaction begins
SET sql_begin = "BEGIN TRANSACTION";

SET sql_records_to_expire = '''INSERT INTO ''' || tgt_update_tbl || ''' 
                            (
                            LINE_ITEM_ID,
                            SOURCE_APPLICATION_CD,
                            DW_FIRST_EFFECTIVE_TS,
                            DW_LAST_EFFECTIVE_TS,
                            DW_CURRENT_VERSION_IND
                            )
                            SELECT  
                                TGT.LINE_ITEM_ID
                                ,TGT.source_application_cd
                                ,TGT.dw_first_effective_ts
                                ,TIMESTAMP_SUB(SRC.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts
                                ,FALSE AS dw_current_version_ind
                            FROM    ''' || tgt_tbl || '''  TGT
                            INNER  JOIN (
                                SELECT *
                                FROM    ''' || tgt_wrk_tbl || ''' 
                                QUALIFY ROW_NUMBER() OVER (PARTITION BY LINE_ITEM_ID, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
                            ) SRC
                            ON      TGT.LINE_ITEM_ID = SRC.LINE_ITEM_ID
                            AND     TGT.source_application_cd = SRC.source_application_cd
                            WHERE   TGT.dw_current_version_ind = TRUE
''';

SET sql_updates = '''--// Processing Updates of Type 2 SCD
                UPDATE ''' || tgt_tbl || ''' as TGT
                    SET  DW_LAST_EFFECTIVE_TS = SRC.dw_last_effective_ts   
                   ,DW_CURRENT_VERSION_IND = FALSE
                   ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                   ,DW_SOURCE_UPDATE_NM = "PINTEREST"
                FROM ''' || tgt_update_tbl || ''' AS SRC
                WHERE TGT.LINE_ITEM_ID = SRC.LINE_ITEM_ID
                        AND TGT.SOURCE_APPLICATION_CD = SRC.SOURCE_APPLICATION_CD
                        AND SRC.dw_first_effective_ts = TGT.dw_first_effective_ts
                ''';



--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
                        LINE_ITEM_ID
                        ,SOURCE_APPLICATION_CD
                        ,DW_FIRST_EFFECTIVE_TS
                        ,DW_LAST_EFFECTIVE_TS
                        ,CAMPAIGN_ID
                        ,LINE_ITEM_NM
                        ,LINE_ITEM_TYPE_NM
                        ,UNITS_BOUGHT_CNT
                        ,LINE_ITEM_SHORT_NM
                        ,LINE_ITEM_BUDGET_AMT
                        ,STATUS_NM
                        ,START_TS
                        ,END_TS
                        ,AUDIENCE_NM
                        ,AD_COST_TYPE_CD
                        ,AD_COST_AMT
                        ,DAILY_BUDGET_AMT
                        ,EXPECTED_DAILY_SPEND_AMT
                        ,PLANNED_IMPRESSION_CNT
                        ,SOURCE_CREATED_TS
                        ,SOURCE_LAST_MODIFIED_TS
                        ,DW_CREATE_TS
                        ,DW_LAST_UPDATE_TS
                        ,DW_LOGICAL_DELETE_IND
                        ,DW_SOURCE_CREATE_NM
                        ,DW_SOURCE_UPDATE_NM
                        ,DW_CURRENT_VERSION_IND
                        )
                        SELECT 
                            LINE_ITEM_ID
                            ,SOURCE_APPLICATION_CD
                            ,DW_FIRST_EFFECTIVE_TS
                            ,DW_LAST_EFFECTIVE_TS
                            ,CAMPAIGN_ID
                            ,LINE_ITEM_NM
                            ,LINE_ITEM_TYPE_NM
                            ,UNITS_BOUGHT_CNT
                            ,LINE_ITEM_SHORT_NM
                            ,LINE_ITEM_BUDGET_AMT
                            ,STATUS_NM
                            ,START_TS
                            ,END_TS
                            ,AUDIENCE_NM
                            ,AD_COST_TYPE_CD
                            ,AD_COST_AMT
                            ,DAILY_BUDGET_AMT
                            ,EXPECTED_DAILY_SPEND_AMT
                            ,PLANNED_IMPRESSION_CNT
                            ,SOURCE_CREATED_TS
                            ,SOURCE_LAST_MODIFIED_TS
                            ,CURRENT_TIMESTAMP AS DW_CREATE_TS
                            ,CURRENT_TIMESTAMP AS DW_LAST_UPDATE_TS
                            ,FALSE AS DW_LOGICAL_DELETE_IND
                            ,"PINTEREST" AS DW_SOURCE_CREATE_NM
                            ,"PINTEREST" AS DW_SOURCE_UPDATE_NM  
                            ,DW_CURRENT_VERSION_IND
                        FROM ''' || tgt_wrk_tbl  ;
                        
                        
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
        EXECUTE IMMEDIATE (sql_begin);       
        IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
                EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
        END IF;
        BEGIN
                EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
                EXCEPTION WHEN ERROR THEN
                SET job_end  = CURRENT_TIMESTAMP();
                SET status   = "FAILED";
                SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
                CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
                RAISE USING message = err_desc;
        END;
        EXECUTE IMMEDIATE (sql_records_to_expire);
        EXECUTE IMMEDIATE (sql_updates);
        EXECUTE IMMEDIATE (sql_inserts);
        SET row_count = @@row_count;
        EXECUTE IMMEDIATE (sql_commit);
        EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE (sql_rollback);
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Pinterest','Confirmed',CURRENT_DATE(),"AD_PLATFORM_LINE_ITEM");
END;
