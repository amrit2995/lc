CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_PINTEREST_AD_ACTION_REACTION_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE src_cpg_tbl STRING; 
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts STRING;
DECLARE sql_inserts_history STRING;
DECLARE lkp_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE row_count_tgt INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;


SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_PINTEREST_AD_ACTION_REACTION_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.AD_ACTION_REACTION';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.AD_ACTION_REACTION_PINTEREST_WRK';        
SET src_tbl         = '<<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_promotion_report';
SET lkp_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.action_reaction_type';


SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "PINTEREST" ''' ;

BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;



SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
         ACTION_REACTION_TYPE_ID
        ,SOURCE_APPLICATION_CD
        ,DW_FIRST_EFFECTIVE_TS
        ,DW_LAST_EFFECTIVE_TS
        ,AD_ID
        ,ACTION_REACTION_DT
        ,VALUE_NBR
        ,DML_TYPE
        )
            -- AD_ACTION_REACTION (repin)
         SELECT  
                LKP.action_reaction_type_id AS ACTION_REACTION_TYPE_ID
                ,"PINTEREST" AS SOURCE_APPLICATION_CD
                ,TIMESTAMP_TRUNC(CURRENT_TIMESTAMP(),SECOND) AS DW_FIRST_EFFECTIVE_TS
                ,CAST('9999-12-31 00:00:00' AS TIMESTAMP) AS DW_LAST_EFFECTIVE_TS
                ,cast(SRC.pin_id as string) AS AD_ID
                ,CAST(SRC.DATE AS DATE) AS ACTION_REACTION_DT
                ,SUM(SRC.repin_1) AS VALUE_NBR
                ,CASE 
                    WHEN TGT.AD_ID IS NULL THEN 'I' 
                    ELSE 'U' 
                END AS DML_TYPE
	    FROM
            ''' || src_tbl || ''' SRC
        LEFT JOIN ''' || lkp_tbl || ''' LKP
            ON 'repins' = LKP.action_reaction_cd
	    LEFT JOIN ''' || tgt_tbl || ''' TGT 
	    ON cast(SRC.pin_id as string) = TGT.AD_ID
            AND CAST(SRC.DATE AS DATE) = TGT.ACTION_REACTION_DT
            AND LKP.ACTION_REACTION_TYPE_ID = TGT.ACTION_REACTION_TYPE_ID
            AND TGT.DW_CURRENT_VERSION_IND = TRUE
            AND TGT.SOURCE_APPLICATION_CD = 'PINTEREST'
        WHERE SRC._fivetran_synced >= "''' ||  data_extract_start_ts || '''"
            AND SRC.pin_id IS NOT NULL
            AND SRC.DATE IS NOT NULL
            AND 
            ( 
                (
                    TGT.AD_ID IS NULL
                    AND TGT.ACTION_REACTION_TYPE_ID IS NULL
                    AND TGT.ACTION_REACTION_DT IS NULL
                )
                OR
                (
                    TGT.VALUE_NBR IS DISTINCT FROM SRC.repin_1
                )
            )
        GROUP BY 
                LKP.action_reaction_type_id
                ,SRC.pin_id
                ,SRC.DATE
                ,TGT.AD_ID

        UNION ALL
                        -- AD_ACTION_REACTION (engagement)
        SELECT  
                LKP.action_reaction_type_id AS ACTION_REACTION_TYPE_ID
                ,"PINTEREST" AS SOURCE_APPLICATION_CD
                ,TIMESTAMP_TRUNC(CURRENT_TIMESTAMP(),SECOND) AS DW_FIRST_EFFECTIVE_TS
                ,CAST('9999-12-31 00:00:00' AS TIMESTAMP) AS DW_LAST_EFFECTIVE_TS
                ,CAST(SRC.pin_id AS STRING) AS AD_ID
                ,CAST(SRC.DATE AS DATE) AS ACTION_REACTION_DT
                ,SUM(SRC.engagement_1) AS VALUE_NBR
                ,CASE 
                    WHEN TGT.AD_ID IS NULL THEN 'I' 
                    ELSE 'U' 
                END AS DML_TYPE
	    FROM
            ''' || src_tbl || ''' SRC
        LEFT JOIN ''' || lkp_tbl || ''' LKP
            ON 'engagements' = LKP.action_reaction_cd
	    LEFT JOIN ''' || tgt_tbl || ''' TGT 
	    ON CAST(SRC.pin_id AS STRING)= TGT.AD_ID
            AND CAST(SRC.DATE AS DATE) = TGT.ACTION_REACTION_DT
            AND LKP.ACTION_REACTION_TYPE_ID = TGT.ACTION_REACTION_TYPE_ID
            AND TGT.DW_CURRENT_VERSION_IND = TRUE
            AND TGT.SOURCE_APPLICATION_CD = 'PINTEREST'
        WHERE SRC._fivetran_synced >= "''' ||  data_extract_start_ts || '''"
            AND SRC.pin_id IS NOT NULL
            AND SRC.DATE IS NOT NULL
            AND 
            ( 
                (
                    TGT.AD_ID IS NULL
                    AND TGT.ACTION_REACTION_TYPE_ID IS NULL
                    AND TGT.ACTION_REACTION_DT IS NULL
                )
                OR
                (
                    TGT.VALUE_NBR IS DISTINCT FROM SRC.engagement_1
                )
            )
        GROUP BY
                LKP.action_reaction_type_id
                ,SRC.pin_id
                ,SRC.DATE
                ,TGT.AD_ID

                   ''';


--//Update transaction begins
SET sql_begin = "BEGIN TRANSACTION";
SET sql_updates = '''--// No updates for this tables 
                 UPDATE ''' || tgt_tbl || ''' as TGT
                    SET  
                    --- audit column updates
                   DW_LAST_EFFECTIVE_TS = TIMESTAMP_SUB(SRC.DW_FIRST_EFFECTIVE_TS, INTERVAL 1 SECOND)
                   ,DW_CURRENT_VERSION_IND = FALSE
                   ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                   ,DW_SOURCE_UPDATE_NM = "PINTEREST"
                    FROM (SELECT
                                        *
                                        FROM ''' || tgt_wrk_tbl || '''
                                        WHERE DML_TYPE IN ('U')
                          ) SRC 
                        WHERE 
                            TGT.ACTION_REACTION_TYPE_ID = SRC.ACTION_REACTION_TYPE_ID
                            AND TGT.AD_ID = SRC.AD_ID
                            AND TGT.ACTION_REACTION_DT = SRC.ACTION_REACTION_DT
                            AND TGT.SOURCE_APPLICATION_CD = 'PINTEREST'
                            AND TGT.DW_CURRENT_VERSION_IND = TRUE''';


--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
                        ACTION_REACTION_TYPE_ID
                        ,SOURCE_APPLICATION_CD
                        ,AD_ID
                        ,ACTION_REACTION_DT
                        ,DW_FIRST_EFFECTIVE_TS
                        ,DW_LAST_EFFECTIVE_TS
                        ,VALUE_NBR
                        ,DW_CREATE_TS
                        ,DW_LAST_UPDATE_TS
                        ,DW_LOGICAL_DELETE_IND
                        ,DW_SOURCE_CREATE_NM
                        ,DW_SOURCE_UPDATE_NM
                        ,DW_CURRENT_VERSION_IND
                        )
                        SELECT
                            ACTION_REACTION_TYPE_ID
                            ,SOURCE_APPLICATION_CD
                            ,AD_ID
                            ,ACTION_REACTION_DT
                            ,DW_FIRST_EFFECTIVE_TS
                            ,DW_LAST_EFFECTIVE_TS
                            ,VALUE_NBR
                            ,CURRENT_TIMESTAMP
                            ,CURRENT_TIMESTAMP
                            ,false AS DW_LOGICAL_DELETE_IND
                            ,"PINTEREST" AS DW_SOURCE_CREATE_NM
                            ,"PINTEREST" AS DW_SOURCE_UPDATE_NM
                            ,TRUE
                        FROM ''' || tgt_wrk_tbl || '''
                        WHERE DML_TYPE IN  ('I','U') 
                        ''' ;
                        

SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
    EXECUTE IMMEDIATE (sql_begin);   
    IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
        EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
    END IF;     
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    EXECUTE IMMEDIATE (sql_updates);
    EXECUTE IMMEDIATE (sql_inserts);
    SET row_count = @@row_count;
    EXECUTE IMMEDIATE (sql_commit);
    EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Pinterest','Confirmed',CURRENT_DATE(),"AD_ACTION_REACTION");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;