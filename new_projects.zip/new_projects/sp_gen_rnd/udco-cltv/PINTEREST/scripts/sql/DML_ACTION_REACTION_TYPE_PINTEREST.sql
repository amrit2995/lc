DELETE FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.action_reaction_type` WHERE SOURCE_APPLICATION_CD = 'PINTEREST';

INSERT INTO `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.action_reaction_type` (
  action_reaction_type_id,
  source_application_cd,
  action_reaction_cd,
  action_reaction_dsc,
  dw_create_ts,
  dw_last_update_ts,
  dw_logical_delete_ind,
  dw_source_create_nm,
  dw_source_update_nm,
  dw_current_version_ind
  )
VALUES
  (11, 'PINTEREST','repins', 'repins', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (12, 'PINTEREST','engagements', 'engagements', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE)
;