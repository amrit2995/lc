CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_platform_advertiser_pinterest_wrk`
(
 ADVERTISER_ID          STRING      ,
 SOURCE_APPLICATION_CD  STRING      ,
 DW_FIRST_EFFECTIVE_TS  TIMESTAMP   ,
 DW_LAST_EFFECTIVE_TS   TIMESTAMP   ,
 CURRENCY_CD            STRING      ,
 ADVERTISER_NM          STRING      ,
 ACCOUNT_STATUS_NM      STRING      ,
 DISABLE_REASON_TXT     STRING      ,
 SOURCE_CREATED_TS      TIMESTAMP   ,
 SOURCE_LAST_MODIFIED_TS TIMESTAMP  ,
 DW_CURRENT_VERSION_IND BOOLEAN
)
OPTIONS (labels = [('appcode','uddi'),('bodname','pinterest'),('domainname','collect'),('environment','<<ENV>>')]);
