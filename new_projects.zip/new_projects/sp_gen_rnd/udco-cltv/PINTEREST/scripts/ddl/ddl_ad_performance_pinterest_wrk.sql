CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_performance_pinterest_wrk`
(
 ad_id                 STRING   ,
 performance_dt        DATE   ,
 publisher_platform_nm  STRING  ,
 source_application_cd  STRING   ,
 dw_first_effective_ts   TIMESTAMP  ,
 dw_last_effective_ts    TIMESTAMP  ,
 account_id            STRING  ,
 line_item_id          STRING  ,
 campaign_id           STRING  ,
 impressions_cnt       NUMERIC  ,
 clicks_cnt            NUMERIC  ,
 platform_media_spend_amt  NUMERIC  ,
 DML_TYPE STRING 
)
OPTIONS(
  description="Represents performance metrics for an advertisement, including impressions, clicks, and spend, broken down by date and publishing platform. Each record reflects the performance of a specific ad on a given day and platform.",
  labels = [('appcode','uddi'),('bodname','pinterest'),('domainname','collect'),('environment','<<ENV>>')]);