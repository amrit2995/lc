CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_platform_advertisement_pinterest_wrk`
(
 ad_id                  STRING   ,
 source_application_cd  STRING  ,
 ad_nm                  STRING   ,
 source_created_ts      TIMESTAMP ,
 source_last_modified_ts  TIMESTAMP ,
 dw_first_effective_ts  TIMESTAMP ,
 dw_last_effective_ts   TIMESTAMP ,
 DW_CURRENT_VERSION_IND BOOL 
)
OPTIONS (labels = [('appcode','uddi'),('bodname','pinterest'),('domainname','collect'),('environment','<<ENV>>')]);
