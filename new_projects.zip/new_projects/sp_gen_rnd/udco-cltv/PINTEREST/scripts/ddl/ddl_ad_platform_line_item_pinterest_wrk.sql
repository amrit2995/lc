CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_platform_line_item_pinterest_wrk`
(
 LINE_ITEM_ID          STRING        ,
 SOURCE_APPLICATION_CD  STRING       ,
 DW_FIRST_EFFECTIVE_TS  TIMESTAMP    ,
 DW_LAST_EFFECTIVE_TS   TIMESTAMP    ,
 CAMPAIGN_ID 			STRING		 ,
 LINE_ITEM_TYPE_NM		STRING 		 ,
 LINE_ITEM_NM          STRING        ,
 LINE_ITEM_SHORT_NM    STRING        ,
 LINE_ITEM_BUDGET_AMT   NUMERIC      ,
 STATUS_NM             STRING        ,
 START_TS              TIMESTAMP     ,
 END_TS                TIMESTAMP     ,
 AUDIENCE_NM          STRING    ,
 AD_COST_TYPE_CD       STRING          ,
 AD_COST_AMT           NUMERIC   ,
 DAILY_BUDGET_AMT      NUMERIC   ,
 EXPECTED_DAILY_SPEND_AMT NUMERIC ,
 UNITS_BOUGHT_CNT      INT64            ,
 PLANNED_IMPRESSION_CNT INT64  ,
 SOURCE_CREATED_TS     TIMESTAMP          ,
 SOURCE_LAST_MODIFIED_TS  TIMESTAMP        ,
 DW_CURRENT_VERSION_IND BOOLEAN			   
)
OPTIONS (labels = [('appcode','uddi'),('bodname','pinterest'),('domainname','collect'),('environment','<<ENV>>')]);
