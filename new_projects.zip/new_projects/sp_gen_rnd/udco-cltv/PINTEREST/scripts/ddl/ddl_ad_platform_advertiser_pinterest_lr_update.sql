CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_platform_advertiser_pinterest_lr_update`
(
 ADVERTISER_ID          STRING      ,
 SOURCE_APPLICATION_CD  STRING      ,
 DW_FIRST_EFFECTIVE_TS  TIMESTAMP   ,
 DW_LAST_EFFECTIVE_TS   TIMESTAMP   ,
 DW_CURRENT_VERSION_IND BOOLEAN
)
OPTIONS (labels = [('appcode','uddi'),('bodname','pinterest'),('domainname','collect'),('environment','<<ENV>>')]);
