CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_platform_campaign_pinterest_wrk`
(
 campaign_id            STRING           ,
 source_application_cd  STRING           ,
 dw_first_effective_ts  TIMESTAMP        ,
 dw_last_effective_ts   TIMESTAMP        ,
 advertiser_id          STRING           ,
 campaign_nm            STRING           ,
 start_ts               TIMESTAMP        ,
 end_ts                 TIMESTAMP        ,
 total_budget_amt       NUMERIC(31,2)    ,
 currency_cd            STRING           ,
 status_nm              STRING           ,
 planned_impression_nbr INT64            ,
 objective_dsc          STRING           ,
 source_created_ts      TIMESTAMP        , 
 source_last_modified_ts TIMESTAMP       ,
 dw_current_version_ind  BOOLEAN			   
)
OPTIONS (labels = [('appcode','uddi'),('bodname','pinterest'),('domainname','collect'),('environment','<<ENV>>')]);
