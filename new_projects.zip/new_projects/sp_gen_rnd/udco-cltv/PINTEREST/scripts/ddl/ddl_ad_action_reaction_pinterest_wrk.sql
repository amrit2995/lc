CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_action_reaction_pinterest_wrk`
(
 action_reaction_type_id      NUMERIC ,
 ad_id                        STRING  ,
 action_reaction_dt           DATE    ,
 source_application_cd        STRING  ,
 DW_FIRST_EFFECTIVE_TS       TIMESTAMP ,
 DW_LAST_EFFECTIVE_TS        TIMESTAMP ,
 value_nbr                    FLOAT64 ,
 DML_TYPE STRING
)
OPTIONS(
  description="Represents performance metrics for an advertisement, including impressions, clicks, and spend, broken down by date and publishing platform. Each record reflects the performance of a specific ad on a given day and platform.",
  labels = [('appcode','uddi'),('bodname','pinterest'),('domainname','collect'),('environment','<<ENV>>')]);