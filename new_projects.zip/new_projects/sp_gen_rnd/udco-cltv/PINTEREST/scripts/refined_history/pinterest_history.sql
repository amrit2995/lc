--- DEV -----
--"CLTV_PROJECT_ID" replace "MKT_PROJECT_ID":"gcp-abs-udco-bq-dev-prj-01"
--"REF_DATASET" replace "PINTEREST_MKT_DATASET":"udco_ds_cltv_refined"
--"SRC_DATASET" replace "SRC_PINTEREST_DATASET":"emfi_ds_pinterest_refined"

--- QA -----
-- "MKT_PROJECT_ID":"gcp-abs-udco-bq-qa-prj-01"
-- "PINTEREST_MKT_DATASET":"udco_ds_cltv_refined"
--"SRC_PINTEREST_DATASET":"emfi_ds_pinterest_refined"

--- PROD -----
-- "MKT_PROJECT_ID":"gcp-abs-mkt-prod-01"
-- "PINTEREST_MKT_DATASET":"pinterest_ads"
--"SRC_PINTEREST_DATASET":"emfi_ds_pinterest_refined"

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.ad_group_history
(		id
,		updated_time
,		status
,		name
,		campaign_id
,		ad_account_id
,		lifetime_frequency_cap
,		billable_event
,		bid_in_micro_currency
,		start_time
,		budget_in_micro_currency
,		end_time
,		upgrade_status
,		created_time
,		budget_type
,		auto_targeting_enabled
,		placement_group
,		pacing_delivery_type
,		bid_strategy_type
,		conversion_learning_mode_type
,		summary_status
,		feed_profile_id
,		_fivetran_synced
,		targeting_spec_targeting_strategy
,		targeting_spec_audience_include
,		targeting_spec_apptype
,		targeting_spec_geo
,		targeting_spec_gender
,		targeting_spec_locale
,		targeting_spec_interest
,		targeting_spec_location
,		targeting_spec_age_bucket
,		targeting_spec_audience_exclude
,		tracking_urls_impression
)
SELECT  p.id
,		p.updated_time
,		p.status
,		p.name
,		p.campaign_id
,		p.ad_account_id
,		p.lifetime_frequency_cap
,		p.billable_event
,		p.bid_in_micro_currency
,		p.start_time
,		p.budget_in_micro_currency
,		p.end_time
,		p.upgrade_status
,		p.created_time
,		p.budget_type
,		p.auto_targeting_enabled
,		p.placement_group
,		p.pacing_delivery_type
,		p.bid_strategy_type
,		p.conversion_learning_mode_type
,		p.summary_status
,		p.feed_profile_id
,		p._fivetran_synced
,		p.targeting_spec_targeting_strategy
,		p.targeting_spec_audience_include
,		p.targeting_spec_apptype
,		p.targeting_spec_geo
,		p.targeting_spec_gender
,		p.targeting_spec_locale
,		p.targeting_spec_interest
,		p.targeting_spec_location
,		p.targeting_spec_age_bucket
,		SAFE_CAST(p.targeting_spec_audience_exclude AS INT64)
,		p.tracking_urls_impression
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.ad_group_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.ad_group_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.ad_group_report
(		ad_group_id
,		advertiser_id
,		date
,		_fivetran_synced
,		campaign_id
,		campaign_status
,		total_impression_user
,		total_impression_frequency
,		campaign_name
,		ad_group_status
,		ad_group_name
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		impression_2
,		video_p_0_combined_2
,		video_avg_watchtime_in_second_2
,		video_mrc_views_2
,		total_video_3_sec_views
,		video_3_sec_views_2
,		video_p_25_combined_2
,		video_p_50_combined_2
,		video_p_100_complete_2
,		video_p_95_combined_2
,		video_p_75_combined_2
,		total_engagement
,		engagement_2
,		impression_1
,		impression_1_gross
,		ctr
,		ecpc_in_micro_dollar
,		cpc_in_micro_dollar
,		engagement_1
,		spend_in_micro_dollar
,		clickthrough_1_gross
,		ecpm_in_micro_dollar
,		outbound_click_1
,		clickthrough_1
,		cpm_in_micro_dollar
,		paid_impression
,		ectr
,		video_p_0_combined_1
,		video_avg_watchtime_in_second_1
,		cpcv_in_micro_dollar
,		video_3_sec_views_1
,		video_p_50_combined_1
,		video_mrc_views_1
,		video_p_25_combined_1
,		video_p_100_complete_1
,		video_p_95_combined_1
,		cpv_in_micro_dollar
,		video_p_75_combined_1
,		cpcv_p_95_in_micro_dollar
,		repin_2
,		repin_1
,		ctr_2
,		clickthrough_2
,		outbound_click_2
)
SELECT  ad_group_id
,		advertiser_id
,		date
,		_fivetran_synced
,		campaign_id
,		campaign_status
,		total_impression_user
,		total_impression_frequency
,		campaign_name
,		ad_group_status
,		ad_group_name
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		impression_2
,		video_p_0_combined_2
,		video_avg_watchtime_in_second_2
,		video_mrc_views_2
,		total_video_3_sec_views
,		video_3_sec_views_2
,		video_p_25_combined_2
,		video_p_50_combined_2
,		video_p_100_complete_2
,		video_p_95_combined_2
,		video_p_75_combined_2
,		total_engagement
,		engagement_2
,		impression_1
,		impression_1_gross
,		ctr
,		ecpc_in_micro_dollar
,		cpc_in_micro_dollar
,		engagement_1
,		spend_in_micro_dollar
,		clickthrough_1_gross
,		ecpm_in_micro_dollar
,		outbound_click_1
,		clickthrough_1
,		cpm_in_micro_dollar
,		paid_impression
,		ectr
,		video_p_0_combined_1
,		video_avg_watchtime_in_second_1
,		cpcv_in_micro_dollar
,		video_3_sec_views_1
,		video_p_50_combined_1
,		video_mrc_views_1
,		video_p_25_combined_1
,		video_p_100_complete_1
,		video_p_95_combined_1
,		cpv_in_micro_dollar
,		video_p_75_combined_1
,		cpcv_p_95_in_micro_dollar
,		repin_2
,		repin_1
,		ctr_2
,		clickthrough_2
,		outbound_click_2
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.ad_group_report
WHERE   date < (SELECT MIN(date) FROM <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.ad_group_report);

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.ad_rejected_label_history
(		pin_promotion_id
,		updated_time
,		label
,		_fivetran_synced
)
SELECT  p.pin_promotion_id
,		p.updated_time
,		p.label
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.ad_rejected_label_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.ad_rejected_label_history q
ON      q.pin_promotion_id = p.pin_promotion_id
AND     q.updated_time = p.updated_time
AND     q.label = p.label
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.pin_promotion_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.advertiser_history
(		id
,		updated_time
,		country
,		currency
,		name
,		owner_username
,		owner_user_id
,		created_time
,		account_permissions
,		_fivetran_synced
)
SELECT  p.id
,		p.updated_time
,		p.country
,		p.currency
,		p.name
,		p.owner_username
,		p.owner_user_id
,		p.created_time
,       CASE WHEN p.account_permissions IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.account_permissions, '[', ''), ']', ''), '"', ''))) END
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.advertiser_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.advertiser_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.advertiser_report
(		advertiser_id
,		date
,		_fivetran_synced
,		ctr
,		video_p_0_combined_2
,		video_p_0_combined_1
,		video_p_50_combined_2
,		total_impression_user
,		ecpc_in_micro_dollar
,		impression_1
,		video_avg_watchtime_in_second_1
,		cpcv_in_micro_dollar
,		total_video_3_sec_views
,		video_avg_watchtime_in_second_2
,		cpc_in_micro_dollar
,		impression_2
,		impression_1_gross
,		video_3_sec_views_1
,		repin_2
,		repin_1
,		engagement_2
,		total_impression_frequency
,		video_3_sec_views_2
,		engagement_1
,		spend_in_micro_dollar
,		video_p_50_combined_1
,		video_mrc_views_1
,		ctr_2
,		total_engagement
,		video_p_25_combined_1
,		video_mrc_views_2
,		clickthrough_1_gross
,		ecpm_in_micro_dollar
,		video_p_25_combined_2
,		outbound_click_1
,		outbound_click_2
,		clickthrough_2
,		clickthrough_1
,		video_p_100_complete_1
,		video_p_100_complete_2
,		video_p_95_combined_2
,		video_p_95_combined_1
,		cpm_in_micro_dollar
,		cpv_in_micro_dollar
,		paid_impression
,		ectr
,		video_p_75_combined_2
,		video_p_75_combined_1
,		cpcv_p_95_in_micro_dollar
)
SELECT  advertiser_id
,		date
,		_fivetran_synced
,		ctr
,		video_p_0_combined_2
,		video_p_0_combined_1
,		video_p_50_combined_2
,		total_impression_user
,		ecpc_in_micro_dollar
,		impression_1
,		video_avg_watchtime_in_second_1
,		cpcv_in_micro_dollar
,		total_video_3_sec_views
,		video_avg_watchtime_in_second_2
,		cpc_in_micro_dollar
,		impression_2
,		impression_1_gross
,		video_3_sec_views_1
,		repin_2
,		repin_1
,		engagement_2
,		total_impression_frequency
,		video_3_sec_views_2
,		engagement_1
,		spend_in_micro_dollar
,		video_p_50_combined_1
,		video_mrc_views_1
,		ctr_2
,		total_engagement
,		video_p_25_combined_1
,		video_mrc_views_2
,		clickthrough_1_gross
,		ecpm_in_micro_dollar
,		video_p_25_combined_2
,		outbound_click_1
,		outbound_click_2
,		clickthrough_2
,		clickthrough_1
,		video_p_100_complete_1
,		video_p_100_complete_2
,		video_p_95_combined_2
,		video_p_95_combined_1
,		cpm_in_micro_dollar
,		cpv_in_micro_dollar
,		paid_impression
,		ectr
,		video_p_75_combined_2
,		video_p_75_combined_1
,		cpcv_p_95_in_micro_dollar
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.advertiser_report
WHERE   date < (SELECT MIN(date) FROM <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.advertiser_report);

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.audience_history
(		advertiser_id
,		audience_type
,		id
,		updated_time
,		description
,		name
,		rule
,		size
,		status
,		created_time
,		_fivetran_synced
)
SELECT  p.advertiser_id
,		p.audience_type
,		p.id
,		p.updated_time
,		p.description
,		p.name
,       CASE WHEN p.rule IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.rule, '[', ''), ']', ''), '"', ''))) END
,		p.size
,		p.status
,		p.created_time
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.audience_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.audience_history q
ON      q.advertiser_id = p.advertiser_id
AND     q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.advertiser_id IS NULL;

-- table is unique by _fivetran_id and there are matches between qa and production _fivetran_id
-- we can use thise to bring in history.  rows that matched on _fivetran_id has the exact same
-- data except of course on audit columns
INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.board_history
(		_fivetran_id
,		id
,		name
,		description
,		media_image_cover_url
,		owner_username
,		privacy
,		board_pins_modified_at
,		created_at
,		collaborator_count
,		pin_count
,		follower_count
,		_fivetran_synced
)
SELECT  p._fivetran_id
,		p.id
,		p.name
,		p.description
,		p.media_image_cover_url
,		p.owner_username
,		p.privacy
,		p.board_pins_modified_at
,		p.created_at
,		p.collaborator_count
,		p.pin_count
,		p.follower_count
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.board_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.board_history q
ON      q._fivetran_id = p._fivetran_id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q._fivetran_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.board_pin_thumbnail_url
(		board_id
,		url
,		_fivetran_synced
)
SELECT  p.board_id
,		p.url
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.board_pin_thumbnail_url p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.board_pin_thumbnail_url q
ON      q.board_id = p.board_id
AND     q.url = p.url
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.board_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.board_section
(		board_id
,		id
,		name
,		_fivetran_synced
)
SELECT  p.board_id
,		p.id
,		p.name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.board_section p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.board_section q
ON      q.board_id = p.board_id
AND     q.id = p.id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.board_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.campaign_history
(		id
,		updated_time
,		name
,		status
,		advertiser_id
,		summary_status
,		lifetime_spend_cap
,		daily_spend_cap
,		order_line_id
,		start_time
,		end_time
,		is_campaign_budget_optimization
,		is_flexible_daily_budgets
,		default_ad_group_budget_in_micro_currency
,		is_automated_campaign
,		created_time
,		objective_type
,		_fivetran_synced
)
SELECT  p.id
,		p.updated_time
,		p.name
,		p.status
,		p.advertiser_id
,		p.summary_status
,		p.lifetime_spend_cap
,		p.daily_spend_cap
,		p.order_line_id
,		p.start_time
,		p.end_time
,		p.is_campaign_budget_optimization
,		p.is_flexible_daily_budgets
,		p.default_ad_group_budget_in_micro_currency
,		p.is_automated_campaign
,		p.created_time
,		p.objective_type
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.campaign_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.campaign_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.campaign_report
(		advertiser_id
,		campaign_id
,		date
,		_fivetran_synced
,		campaign_status
,		total_impression_user
,		total_impression_frequency
,		campaign_name
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		impression_2
,		video_p_0_combined_2
,		video_avg_watchtime_in_second_2
,		video_mrc_views_2
,		total_video_3_sec_views
,		video_3_sec_views_2
,		video_p_25_combined_2
,		video_p_50_combined_2
,		video_p_100_complete_2
,		video_p_95_combined_2
,		video_p_75_combined_2
,		engagement_2
,		total_engagement
,		impression_1_gross
,		impression_1
,		ctr
,		ecpc_in_micro_dollar
,		clickthrough_1_gross
,		ecpm_in_micro_dollar
,		outbound_click_1
,		cpc_in_micro_dollar
,		clickthrough_1
,		engagement_1
,		cpm_in_micro_dollar
,		spend_in_micro_dollar
,		paid_impression
,		ectr
,		video_p_0_combined_1
,		video_avg_watchtime_in_second_1
,		cpcv_in_micro_dollar
,		video_3_sec_views_1
,		video_p_50_combined_1
,		video_mrc_views_1
,		video_p_25_combined_1
,		video_p_100_complete_1
,		video_p_95_combined_1
,		cpv_in_micro_dollar
,		video_p_75_combined_1
,		cpcv_p_95_in_micro_dollar
,		repin_2
,		repin_1
,		ctr_2
,		outbound_click_2
,		clickthrough_2
)
SELECT  advertiser_id
,		campaign_id
,		date
,		_fivetran_synced
,		campaign_status
,		total_impression_user
,		total_impression_frequency
,		campaign_name
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		impression_2
,		video_p_0_combined_2
,		video_avg_watchtime_in_second_2
,		video_mrc_views_2
,		total_video_3_sec_views
,		video_3_sec_views_2
,		video_p_25_combined_2
,		video_p_50_combined_2
,		video_p_100_complete_2
,		video_p_95_combined_2
,		video_p_75_combined_2
,		engagement_2
,		total_engagement
,		impression_1_gross
,		impression_1
,		ctr
,		ecpc_in_micro_dollar
,		clickthrough_1_gross
,		ecpm_in_micro_dollar
,		outbound_click_1
,		cpc_in_micro_dollar
,		clickthrough_1
,		engagement_1
,		cpm_in_micro_dollar
,		spend_in_micro_dollar
,		paid_impression
,		ectr
,		video_p_0_combined_1
,		video_avg_watchtime_in_second_1
,		cpcv_in_micro_dollar
,		video_3_sec_views_1
,		video_p_50_combined_1
,		video_mrc_views_1
,		video_p_25_combined_1
,		video_p_100_complete_1
,		video_p_95_combined_1
,		cpv_in_micro_dollar
,		video_p_75_combined_1
,		cpcv_p_95_in_micro_dollar
,		repin_2
,		repin_1
,		ctr_2
,		outbound_click_2
,		clickthrough_2
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.campaign_report
WHERE   date < (SELECT MIN(date) FROM <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.campaign_report);

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.conversion_tag_config
(		conversion_tag_fivetran_id
,		aem_enabled
,		aem_fnln_enabled
,		aem_ph_enabled
,		aem_ge_enabled
,		aem_db_enabled
,		aem_loc_enabled
,		md_frequency
,		_fivetran_synced
)
SELECT  p.conversion_tag_fivetran_id
,		p.aem_enabled
,		p.aem_fnln_enabled
,		p.aem_ph_enabled
,		p.aem_ge_enabled
,		p.aem_db_enabled
,		p.aem_loc_enabled
,		p.md_frequency
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.conversion_tag_config p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.conversion_tag_config q
ON      q.conversion_tag_fivetran_id = p.conversion_tag_fivetran_id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.conversion_tag_fivetran_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.conversion_tag_history
(		_fivetran_id
,		id
,		name
,		status
,		version
,		advertiser_id
,		code_snippet
,		enhanced_match_status
,		last_fired_time_ms
,		_fivetran_synced
)
SELECT  p._fivetran_id
,		p.id
,		p.name
,		p.status
,		p.version
,		p.advertiser_id
,		p.code_snippet
,		p.enhanced_match_status
,		p.last_fired_time_ms
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.conversion_tag_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.conversion_tag_history q
ON      q._fivetran_id = p._fivetran_id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q._fivetran_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.customer_list_history
(		id
,		updated_time
,		exceptions
,		name
,		status
,		advertiser_id
,		created_time
,		num_batches
,		num_uploaded_user_records
,		num_removed_user_records
,		_fivetran_synced
)
SELECT  p.id
,		p.updated_time
,		p.exceptions
,		p.name
,		p.status
,		p.advertiser_id
,		p.created_time
,		p.num_batches
,		p.num_uploaded_user_records
,		p.num_removed_user_records
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.customer_list_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.customer_list_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.keyword_history
(		_fivetran_id
,		archived
,		bid
,		id
,		value
,		advertiser_id
,		campaign_id
,		ad_group_id
,		match_type
,		parent_type
,		_fivetran_synced
)
SELECT  p._fivetran_id
,		p.archived
,		p.bid
,		p.id
,		p.value
,		p.advertiser_id
,		p.campaign_id
,		p.ad_group_id
,		p.match_type
,		p.parent_type
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.keyword_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.keyword_history q
ON      q._fivetran_id = p._fivetran_id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q._fivetran_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.keyword_report
(		ad_group_id
,		advertiser_id
,		campaign_id
,		date
,		keyword_id
,		pin_id
,		pin_promotion_id
,		_fivetran_synced
,		ad_group_name
,		pin_promotion_status
,		targeting_type
,		impression_2
,		pin_promotion_name
,		campaign_status
,		campaign_name
,		ad_group_status
,		targeting_value
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		impression_1
,		ecpm_in_micro_dollar
,		impression_1_gross
,		cpm_in_micro_dollar
,		spend_in_micro_dollar
,		paid_impression
,		cpv_in_micro_dollar
,		cpcv_in_micro_dollar
,		cpcv_p_95_in_micro_dollar
,		ctr
,		ecpc_in_micro_dollar
,		cpc_in_micro_dollar
,		engagement_1
,		total_engagement
,		clickthrough_1_gross
,		clickthrough_1
,		ectr
,		outbound_click_1
,		repin_1
,		ctr_2
,		clickthrough_2
,		engagement_2
)
SELECT  ad_group_id
,		advertiser_id
,		campaign_id
,		date
,		keyword_id
,		pin_id
,		pin_promotion_id
,		_fivetran_synced
,		ad_group_name
,		pin_promotion_status
,		targeting_type
,		impression_2
,		pin_promotion_name
,		campaign_status
,		campaign_name
,		ad_group_status
,		targeting_value
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		impression_1
,		ecpm_in_micro_dollar
,		impression_1_gross
,		cpm_in_micro_dollar
,		spend_in_micro_dollar
,		paid_impression
,		cpv_in_micro_dollar
,		cpcv_in_micro_dollar
,		cpcv_p_95_in_micro_dollar
,		ctr
,		ecpc_in_micro_dollar
,		cpc_in_micro_dollar
,		engagement_1
,		total_engagement
,		clickthrough_1_gross
,		clickthrough_1
,		ectr
,		outbound_click_1
,		repin_1
,		ctr_2
,		clickthrough_2
,		engagement_2
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.keyword_report
WHERE   date < (SELECT MIN(date) FROM <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.keyword_report);

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_analytics_report
(		date
,		device_type
,		id
,		advertiser_id
,		_fivetran_synced
,		profile_visit
,		save_rate
,		pin_click
,		impression
,		outbound_click
,		user_follow
,		save
)
SELECT  date
,		device_type
,		id
,		advertiser_id
,		_fivetran_synced
,		profile_visit
,		save_rate
,		pin_click
,		impression
,		outbound_click
,		user_follow
,		save
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.pin_analytics_report
WHERE   date < (SELECT MIN(date) FROM <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_analytics_report);

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_history
(		_fivetran_id
,		id
,		link
,		title
,		description
,		board_id
,		board_section_id
,		parent_pin_id
,		created_at
,		dominant_color
,		alt_text
,		ad_creative_type
,		board_owner_username
,		media_type
,		is_standard
,		_fivetran_synced
,		is_removable
,		product_tags
,		is_owner
,		has_been_promoted
)
SELECT  p._fivetran_id
,		p.id
,		p.link
,		p.title
,		p.description
,		p.board_id
,		p.board_section_id
,		p.parent_pin_id
,		p.created_at
,		p.dominant_color
,		p.alt_text
,		p.ad_creative_type
,		p.board_owner_username
,		p.media_type
,		p.is_standard
,		p._fivetran_synced
,		p.is_removable
,       CASE WHEN p.product_tags IS NULL OR p.product_tags = '[]' THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.product_tags, '[', ''), ']', ''), '"', ''))) END
,		p.is_owner
,		p.has_been_promoted
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.pin_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_history q
ON      q._fivetran_id = p._fivetran_id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q._fivetran_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_media_image
(		_fivetran_pin_id
,		_fivetran_media_id
,		property_name
,		height
,		width
,		url
,		_fivetran_synced
)
SELECT  p._fivetran_pin_id
,		p._fivetran_media_id
,		p.property_name
,		p.height
,		p.width
,		p.url
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.pin_media_image p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_media_image q
ON      q._fivetran_pin_id = p._fivetran_pin_id
AND     q.property_name = p.property_name
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q._fivetran_pin_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_promotion_history
(		id
,		updated_time
,		name
,		status
,		ad_group_id
,		campaign_id
,		pin_id
,		android_deep_link
,		click_tracking_url
,		created_time
,		destination_url
,		ios_deep_link
,		is_pin_deleted
,		is_removable
,		review_status
,		summary_status
,		creative_type
,		view_tracking_url
,		ad_account_id
,		collection_items_destination_url_template
,		_fivetran_synced
,		tracking_urls_impression
,		tracking_urls_click
)
SELECT  p.id
,		p.updated_time
,		p.name
,		p.status
,		p.ad_group_id
,		p.campaign_id
,		p.pin_id
,		p.android_deep_link
,		p.click_tracking_url
,		p.created_time
,		p.destination_url
,		p.ios_deep_link
,		p.is_pin_deleted
,		p.is_removable
,		p.review_status
,		p.summary_status
,		p.creative_type
,		p.view_tracking_url
,		p.ad_account_id
,		p.collection_items_destination_url_template
,		p._fivetran_synced
,		p.tracking_urls_impression
,		p.tracking_urls_click
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.pin_promotion_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_promotion_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_promotion_report
(		ad_group_id
,		advertiser_id
,		campaign_id
,		date
,		pin_promotion_id
,		_fivetran_synced
,		total_impression_user
,		pin_id
,		ad_group_name
,		pin_promotion_status
,		impression_2
,		pin_promotion_name
,		campaign_status
,		total_impression_frequency
,		campaign_name
,		ad_group_status
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		video_length
,		video_p_0_combined_2
,		video_mrc_views_2
,		total_video_3_sec_views
,		video_avg_watchtime_in_second_2
,		video_p_25_combined_2
,		video_3_sec_views_2
,		video_p_50_combined_2
,		video_p_75_combined_2
,		video_p_100_complete_2
,		video_p_95_combined_2
,		ctr_2
,		total_engagement
,		clickthrough_2
,		engagement_2
,		ectr
,		outbound_click_2
,		ctr
,		video_p_0_combined_1
,		ecpc_in_micro_dollar
,		impression_1
,		video_avg_watchtime_in_second_1
,		cpcv_in_micro_dollar
,		cpc_in_micro_dollar
,		impression_1_gross
,		video_3_sec_views_1
,		engagement_1
,		spend_in_micro_dollar
,		video_p_50_combined_1
,		video_mrc_views_1
,		video_p_25_combined_1
,		clickthrough_1_gross
,		ecpm_in_micro_dollar
,		clickthrough_1
,		video_p_100_complete_1
,		video_p_95_combined_1
,		cpm_in_micro_dollar
,		cpv_in_micro_dollar
,		paid_impression
,		video_p_75_combined_1
,		cpcv_p_95_in_micro_dollar
,		outbound_click_1
,		repin_1
,		repin_2
)
SELECT  ad_group_id
,		advertiser_id
,		campaign_id
,		date
,		pin_promotion_id
,		_fivetran_synced
,		total_impression_user
,		pin_id
,		ad_group_name
,		pin_promotion_status
,		impression_2
,		pin_promotion_name
,		campaign_status
,		total_impression_frequency
,		campaign_name
,		ad_group_status
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		video_length
,		video_p_0_combined_2
,		video_mrc_views_2
,		total_video_3_sec_views
,		video_avg_watchtime_in_second_2
,		video_p_25_combined_2
,		video_3_sec_views_2
,		video_p_50_combined_2
,		video_p_75_combined_2
,		video_p_100_complete_2
,		video_p_95_combined_2
,		ctr_2
,		total_engagement
,		clickthrough_2
,		engagement_2
,		ectr
,		outbound_click_2
,		ctr
,		video_p_0_combined_1
,		ecpc_in_micro_dollar
,		impression_1
,		video_avg_watchtime_in_second_1
,		cpcv_in_micro_dollar
,		cpc_in_micro_dollar
,		impression_1_gross
,		video_3_sec_views_1
,		engagement_1
,		spend_in_micro_dollar
,		video_p_50_combined_1
,		video_mrc_views_1
,		video_p_25_combined_1
,		clickthrough_1_gross
,		ecpm_in_micro_dollar
,		clickthrough_1
,		video_p_100_complete_1
,		video_p_95_combined_1
,		cpm_in_micro_dollar
,		cpv_in_micro_dollar
,		paid_impression
,		video_p_75_combined_1
,		cpcv_p_95_in_micro_dollar
,		outbound_click_1
,		repin_1
,		repin_2
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.pin_promotion_report
WHERE   date < (SELECT MIN(date) FROM <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_promotion_report);

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_promotion_targeting_report
(		ad_group_id
,		advertiser_id
,		campaign_id
,		date
,		pin_promotion_id
,		targeting_type
,		targeting_value
,		_fivetran_synced
,		pin_id
,		ad_group_name
,		pin_promotion_status
,		impression_2
,		pin_promotion_name
,		campaign_status
,		campaign_name
,		ad_group_status
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		total_engagement
,		engagement_2
,		ctr_2
,		clickthrough_2
,		ectr
,		impression_1
,		ecpm_in_micro_dollar
,		impression_1_gross
,		cpm_in_micro_dollar
,		spend_in_micro_dollar
,		paid_impression
,		ctr
,		ecpc_in_micro_dollar
,		cpc_in_micro_dollar
,		engagement_1
,		clickthrough_1_gross
,		outbound_click_1
,		clickthrough_1
,		repin_1
,		cpcv_in_micro_dollar
,		cpv_in_micro_dollar
,		cpcv_p_95_in_micro_dollar
,		outbound_click_2
,		repin_2
)
SELECT  ad_group_id
,		advertiser_id
,		campaign_id
,		date
,		pin_promotion_id
,		targeting_type
,		targeting_value
,		_fivetran_synced
,		pin_id
,		ad_group_name
,		pin_promotion_status
,		impression_2
,		pin_promotion_name
,		campaign_status
,		campaign_name
,		ad_group_status
,		campaign_lifetime_spend_cap
,		campaign_daily_spend_cap
,		total_engagement
,		engagement_2
,		ctr_2
,		clickthrough_2
,		ectr
,		impression_1
,		ecpm_in_micro_dollar
,		impression_1_gross
,		cpm_in_micro_dollar
,		spend_in_micro_dollar
,		paid_impression
,		ctr
,		ecpc_in_micro_dollar
,		cpc_in_micro_dollar
,		engagement_1
,		clickthrough_1_gross
,		outbound_click_1
,		clickthrough_1
,		repin_1
,		cpcv_in_micro_dollar
,		cpv_in_micro_dollar
,		cpcv_p_95_in_micro_dollar
,		outbound_click_2
,		repin_2
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.pin_promotion_targeting_report
WHERE   date < (SELECT MIN(date) FROM <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.pin_promotion_targeting_report);

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.product_group_history
(		_fivetran_id
,		definition
,		id
,		included
,		status
,		ad_group_id
,		parent_id
,		catalog_product_group_id
,		bid_in_micro_currency
,		collections_hero_destination_url
,		collections_hero_pin_id
,		creative_type
,		is_mdl
,		relative_definition
,		slideshow_collections_title
,		slideshow_collections_description
,		tracking_url
,		_fivetran_synced
)
SELECT  p._fivetran_id
,		p.definition
,		p.id
,		p.included
,		p.status
,		p.ad_group_id
,		p.parent_id
,		p.catalog_product_group_id
,		p.bid_in_micro_currency
,		p.collections_hero_destination_url
,		p.collections_hero_pin_id
,		p.creative_type
,		p.is_mdl
,		p.relative_definition
,		p.slideshow_collections_title
,		p.slideshow_collections_description
,		p.tracking_url
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.product_group_history p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.product_group_history q
ON      q._fivetran_id = p._fivetran_id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q._fivetran_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_age_bucket
(		id
,		name
,		_fivetran_synced
)
SELECT  p.id
,		p.name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.targeting_age_bucket p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_age_bucket q
ON      q.id = p.id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_app_type
(		id
,		name
,		_fivetran_synced
)
SELECT  p.id
,		p.name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.targeting_app_type p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_app_type q
ON      q.id = p.id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_gender
(		id
,		name
,		_fivetran_synced
)
SELECT  p.id
,		p.name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.targeting_gender p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_gender q
ON      q.id = p.id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_geo
(		country_id
,		country_name
,		_fivetran_synced
)
SELECT  p.country_id
,		p.country_name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.targeting_geo p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_geo q
ON      q.country_id = p.country_id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.country_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_geo_metro
(		metro_id
,		country_id
,		metro_name
,		_fivetran_synced
)
SELECT  p.metro_id
,		p.country_id
,		p.metro_name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.targeting_geo_metro p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_geo_metro q
ON      q.metro_id = p.metro_id
AND     q.country_id = p.country_id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.metro_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_geo_region
(		region_id
,		country_id
,		region_name
,		_fivetran_synced
)
SELECT  p.region_id
,		p.country_id
,		p.region_name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.targeting_geo_region p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_geo_region q
ON      q.region_id = p.region_id
AND     q.country_id = p.country_id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.region_id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_interest
(		id
,		parent_id
,		level
,		name
,		_fivetran_synced
)
SELECT  p.id
,		p.parent_id
,		p.level
,		p.name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.targeting_interest p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_interest q
ON      q.id = p.id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_locale
(		id
,		name
,		_fivetran_synced
)
SELECT  p.id
,		p.name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.targeting_locale p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_locale q
ON      q.id = p.id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;

INSERT INTO <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_location
(		id
,		name
,		_fivetran_synced
)
SELECT  p.id
,		p.name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<PINTEREST_MKT_DATASET>>.targeting_location p
LEFT    OUTER JOIN <<PINTEREST_EMFI_PROJECT_ID>>.<<PINTEREST_EMFI_DATASET>>.targeting_location q
ON      q.id = p.id
WHERE   p._fivetran_synced < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 DAY)
AND     q.id IS NULL;