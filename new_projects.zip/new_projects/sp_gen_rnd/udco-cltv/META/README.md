# META (Facebook / Instagram Ads)

Ingests, transforms, and models Meta advertising data across **two layers**: a **Confirmed** (BIM) layer for validated source records, and an **Analytical** layer for reporting-ready dimensions and facts.

## Pipeline Flow

```
                        ┌─────────────────────────────────────────────────┐
GCS Files               │  Confirmed Layer (BIM)      Analytical Layer    │
  │                     │                                                 │
  └─► [SToV] ──► Raw ──┼──► [VToB SPs] ──► Tables ──► [BToA SPs] ──► D1/F/FA
                        │   (SCD2 merge)                (SCD2 load)      │
                        └─────────────────────────────────────────────────┘
```

### Data Flow Detail

1. **Truncate** work tables (`_WRK`)
2. **Transform & Insert** into WRK with platform-specific CTEs
3. **Populate LR_UPDATE** — identify existing rows to expire
4. **Transaction**: Expire previous SCD2 versions → Insert new rows
5. **Cleanup** staging tables
6. **DQ Observability** & audit logging

## Directory Layout

```
META/
├── README.md
├── params_dev.json / params_qa.json / params_prod.json
├── config/
│   ├── META_CONF_WF.json              ← confirmed-layer DAG (schedule: 0 10 * * *)
│   ├── META_ANALYTICAL_WF.json        ← analytical-layer DAG (schedule: 0 11 * * *)
│   ├── VToB_META_*_BQToBQ.json        ← vault-to-BIM step configs (11 files)
│   ├── BToA_META_*_BQToBQ.json        ← BIM-to-analytics step configs (15 files)
│   └── noOptask.json                  ← DAG anchor task
└── scripts/
    ├── ddl/                           ← confirmed-layer DDLs (31 files)
    │   └── Analytical/                ← analytical-layer DDLs (31 files)
    ├── sql/                           ← confirmed-layer SPs & DMLs (16 files)
    │   └── META_ANALYTICAL/           ← analytical SPs (15 files)
    │       └── docs/                  ← SP implementation docs
    ├── views/                         ← view definitions for both layers (30 files)
    └── refinedscripts/                ← one-off / history insert scripts
```

## Key Entities

### Confirmed Layer (BIM)

| Entity             | DDL                                 | SP                            | View                                 |
| ------------------ | ----------------------------------- | ----------------------------- | ------------------------------------ |
| Advertiser         | `ddl_ad_platform_advertiser.sql`    | `SP_CLTV_*_ADVERTISER.sql`    | `view_ad_platform_advertiser.sql`    |
| Campaign           | `ddl_ad_platform_campaign.sql`      | `SP_CLTV_*_CAMPAIGN.sql`      | `view_ad_platform_campaign.sql`      |
| Line Item          | `ddl_ad_platform_line_item.sql`     | `SP_CLTV_*_LINE_ITEM.sql`     | `view_ad_platform_line_item.sql`     |
| Creative           | `ddl_ad_platform_creative.sql`      | `SP_CLTV_*_CREATIVE.sql`      | `view_ad_platform_creative.sql`      |
| Advertisement      | `ddl_ad_platform_advertisement.sql` | `SP_CLTV_*_ADVERTISEMENT.sql` | `view_ad_platform_advertisement.sql` |
| Placement          | `ddl_ad_platform_placement.sql`     | —                             | `view_ad_platform_placement.sql`     |
| Ad Performance     | `ddl_ad_performance.sql`            | —                             | `view_ad_performance.sql`            |
| Action Reaction    | `ddl_ad_action_reaction.sql`        | —                             | `view_ad_action_reaction.sql`        |
| Video Action       | `ddl_ad_video_action.sql`           | —                             | `view_ad_video_action.sql`           |
| Reach Summaries    | `ddl_*_reach_summary.sql`           | —                             | `view_*_reach_summary.sql`           |
| Line Item Creative | `ddl_line_item_creative.sql`        | —                             | `view_line_item_creative.sql`        |

### Analytical Layer

| Prefix | Type           | Key Tables                                                                                                                                                                                                                                                                                                                                               |
| ------ | -------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `D1_`  | Dimension      | `D1_AD_MEDIA_PLATFORM`, `D1_AD_MEDIA_CAMPAIGN`, `D1_AD_MEDIA_CAMPAIGN_LINE`, `D1_AD_MEDIA_OPPORTUNITY`, `D1_PLATFORM_ADVERTISER`, `D1_PLATFORM_MEDIA_CAMPAIGN`, `D1_PLATFORM_MEDIA_LINE`, `D1_PLATFORM_MEDIA_ADVERTISEMENT`, `D1_PLATFORM_MEDIA_CREATIVE`, `D1_PLATFORM_MEDIA_AD_UNIT`, `D1_PLATFORM_MEDIA_PLACEMENT`, `D1_AD_MEDIA_PROMOTIONAL_CHANNEL` |
| `F_`   | Fact           | `F_AD_PLATFORM_CAMPAIGN_TREND`, `F_AD_PLATFORM_CAMPAIGN_SOCIAL_RF_TREND`, `F_AD_PLATFORM_SOCIAL_RF_TREND`, `F_ALL_PLATFORM_MEASUREMENT`, `F_ALL_PLATFORM_MEASUREMENT_UPC`                                                                                                                                                                                |
| `FA_`  | Aggregate Fact | `FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE`                                                                                                                                                                                                                                                                                                                    |

Each entity has a main table, a `_WRK` staging table, and optionally a `_LR_UPDATE` SCD2 tracking table.

## Orchestration

### How Config Files, DAGs, and SPs Connect

Every entity has three linked artifacts. The names **must match exactly** or Airflow won't find the task:

```
 SP SQL File (scripts/sql/)                Step Config (config/)                      Workflow DAG (config/*_WF.json)
 ─────────────────────────                 ─────────────────────                      ──────────────────────────────
 SP_CLTV_BIM_TO_ANALYTICS_                 BToA_META_D1_AD_MEDIA_                     META_ANALYTICAL_WF.json
   D1_AD_MEDIA_CAMPAIGN.sql                  CAMPAIGN_BQToBQ.json                       job_level_2.noOptask: [
         │                                        │                                       "BToA_META_D1_AD_MEDIA_
         │  ┌─────────────────────────────────────┘                                          CAMPAIGN_BQToBQ",  ◄── must match
         │  │                                                                                ...                     job_name
         ▼  ▼                                                                              ]
   {
     "job_name": "BToA_META_D1_AD_MEDIA_CAMPAIGN_BQToBQ",  ◄── must match filename
     "sp": "SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN" ◄── must match SP name
   }
```

### Config Files in `config/`

```
META/config/
├── META_CONF_WF.json                 ← confirmed-layer DAG definition
├── META_ANALYTICAL_WF.json           ← analytical-layer DAG definition
├── noOptask.json                     ← dummy anchor for fan-out parallelism
│
├── VToB_META_ADVERTISER_BQToBQ.json           ┐
├── VToB_META_CAMPAIGN_BQToBQ.json             │ confirmed-layer step configs
├── VToB_META_LINE_ITEM_BQToBQ.json            │ (job_name → SP on <<CONF_DATASET>>)
├── VToB_META_CREATIVE_BQToBQ.json             │
├── VToB_META_ADVERTISEMENT_BQToBQ.json        │
├── VToB_META_LINE_ITEM_CREATIVE_BQToBQ.json   │
├── VToB_META_AD_PERFORMANCE_BQToBQ.json       │
├── VToB_META_AD_ACTION_REACTION_BQToBQ.json   │
├── VToB_META_AD_VIDEO_ACTION_BQToBQ.json      │
├── VToB_META_CAMPAIGN_REACH_SUMMARY_BQToBQ.json   │
├── VToB_META_AD_CREATIVE_REACH_SUMMARY_BQToBQ.json│
│                                                   ┘
├── BToA_META_D1_AD_MEDIA_CAMPAIGN_BQToBQ.json      ┐
├── BToA_META_D1_AD_MEDIA_CAMPAIGN_LINE_BQToBQ.json  │
├── BToA_META_D1_AD_MEDIA_OPPORTUNITY_BQToBQ.json    │ analytical-layer step configs
├── BToA_META_D1_AD_MEDIA_PLATFORM_BQToBQ.json       │ (job_name → SP on <<ANALYTIC_DATASET>>)
├── BToA_META_D1_PLATFORM_ADVERTISER_BQToBQ.json     │
├── BToA_META_D1_PLATFORM_MEDIA_AD_UNIT_BQToBQ.json  │
├── BToA_META_D1_PLATFORM_MEDIA_ADVERTISEMENT_BQToBQ.json │
├── BToA_META_D1_PLATFORM_MEDIA_CAMPAIGN_BQToBQ.json │
├── BToA_META_D1_PLATFORM_MEDIA_CREATIVE_BQToBQ.json │
├── BToA_META_D1_PLATFORM_MEDIA_LINE_BQToBQ.json     │
├── BToA_META_D1_PLATFORM_MEDIA_PLACEMENT_BQToBQ.json│
├── BToA_META_F_AD_PLATFORM_CAMPAIGN_TREND_BQToBQ.json│
├── BToA_META_F_AD_PLATFORM_CAMPAIGN_SOCIAL_RF_TREND_BQToBQ.json │
├── BToA_META_F_AD_PLATFORM_SOCIAL_RF_TREND_BQToBQ.json │
└── BToA_META_PINTEREST_FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_BQToBQ.json
                                                     ┘
```

### Workflow DAGs

**META_CONF_WF** (confirmed layer — schedule: `0 10 * * *`):

A flat DAG — all 11 VToB tasks run in parallel after the anchor:

```
Level 1: noOptask (dummy — enables fan-out)
    │
    └─► Level 2 (all parallel):
          VToB_META_ADVERTISER_BQToBQ
          VToB_META_CAMPAIGN_BQToBQ
          VToB_META_LINE_ITEM_BQToBQ
          VToB_META_CREATIVE_BQToBQ
          VToB_META_ADVERTISEMENT_BQToBQ
          VToB_META_LINE_ITEM_CREATIVE_BQToBQ
          VToB_META_AD_PERFORMANCE_BQToBQ
          VToB_META_AD_ACTION_REACTION_BQToBQ
          VToB_META_AD_VIDEO_ACTION_BQToBQ
          VToB_META_CAMPAIGN_REACH_SUMMARY_BQToBQ
          VToB_META_AD_CREATIVE_REACH_SUMMARY_BQToBQ
```

No Level 3 — all confirmed tasks are independent.

**META_ANALYTICAL_WF** (analytical layer — schedule: `0 11 * * *`):

A deep DAG — dimensions first, then facts, then aggregate facts:

```
Level 1: noOptask
    │
    └─► Level 2 (11 dimension loads — all parallel):
    │     BToA_META_D1_AD_MEDIA_CAMPAIGN_BQToBQ
    │     BToA_META_D1_AD_MEDIA_CAMPAIGN_LINE_BQToBQ
    │     BToA_META_D1_AD_MEDIA_OPPORTUNITY_BQToBQ
    │     BToA_META_D1_AD_MEDIA_PLATFORM_BQToBQ
    │     BToA_META_D1_PLATFORM_ADVERTISER_BQToBQ
    │     BToA_META_D1_PLATFORM_MEDIA_AD_UNIT_BQToBQ
    │     BToA_META_D1_PLATFORM_MEDIA_ADVERTISEMENT_BQToBQ
    │     BToA_META_D1_PLATFORM_MEDIA_CAMPAIGN_BQToBQ
    │     BToA_META_D1_PLATFORM_MEDIA_CREATIVE_BQToBQ
    │     BToA_META_D1_PLATFORM_MEDIA_LINE_BQToBQ
    │     BToA_META_D1_PLATFORM_MEDIA_PLACEMENT_BQToBQ
    │
    └─► Level 3 (waits for ALL 11 dimensions to complete):
    │     BToA_META_F_AD_PLATFORM_CAMPAIGN_TREND_BQToBQ
    │
    └─► Level 4 (waits for trend fact):
          BToA_META_PINTEREST_FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_BQToBQ
```

**Why Level 3 waits for all dimensions:** In `job_level_3`, every D1 dimension key maps to the same target `["BToA_META_F_AD_PLATFORM_CAMPAIGN_TREND_BQToBQ"]`. Airflow sees that the trend task is listed as a downstream of all 11 dimensions, so it waits for every one to finish before running.

### Step Config Anatomy

```
// File: config/BToA_META_PINTEREST_FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_BQToBQ.json
{
  "bod_name": "META",
  "job_name": "BToA_META_PINTEREST_FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_BQToBQ",
  "run_on": "bq",
  "BQToBQ": {
    "dataset": "<<ANALYTIC_DATASET>>",
    "sp": "SP_CLTV_BIM_TO_ANALYTICS_FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_LOAD"
  }
}
```

**Confirmed-layer** step configs use `<<CONF_DATASET>>` and `SP_CLTV_META_*_REF_TO_BIM_LOAD` naming:

```
// File: config/VToB_META_ADVERTISER_BQToBQ.json
{
  "bod_name": "META",
  "job_name": "VToB_META_ADVERTISER_BQToBQ",
  "run_on": "bq",
  "BQToBQ": {
    "dataset": "<<CONF_DATASET>>",
    "sp": "SP_CLTV_META_ADVERTISER_REF_TO_BIM_LOAD"
  }
}
```

### Adding a New Entity to the META Analytical DAG

Example: adding a new dimension `D1_NEW_ENTITY`:

1. **Create SQL** — `scripts/ddl/Analytical/ddl_d1_new_entity.sql`, `ddl_d1_new_entity_wrk.sql`, `scripts/sql/META_ANALYTICAL/SP_CLTV_BIM_TO_ANALYTICS_D1_NEW_ENTITY.sql`, `scripts/views/view_d1_new_entity.sql`

2. **Create step config** — `config/BToA_META_D1_NEW_ENTITY_BQToBQ.json`:

   ```json
   {
     "bod_name": "META",
     "job_name": "BToA_META_D1_NEW_ENTITY_BQToBQ",
     "run_on": "bq",
     "BQToBQ": {
       "dataset": "<<ANALYTIC_DATASET>>",
       "sp": "SP_CLTV_BIM_TO_ANALYTICS_D1_NEW_ENTITY"
     }
   }
   ```

3. **Register in DAG** — edit `META_ANALYTICAL_WF.json`:

   - **Independent dimension?** Add to `job_level_2.noOptask` array
   - **Depends on a dimension?** Add to `job_level_3` under that dimension's key
   - **Depends on a fact?** Add to `job_level_4` under that fact's key
   - **New depth needed?** Add a `job_level_5` block

4. **Add to YAML** — `script_order_execution_meta.yaml` → add DDL, view, SP paths to `files:`

Example `files:` entries to add to `script_order_execution_meta.yaml`:

```yaml
# Add the DDL, view and SP paths for the new entity
files:
  - META/scripts/ddl/Analytical/ddl_d1_new_entity.sql
  - META/scripts/views/view_d1_new_entity.sql
  - META/scripts/sql/META_ANALYTICAL/SP_CLTV_BIM_TO_ANALYTICS_D1_NEW_ENTITY.sql
```

```

## Platform-Specific Behaviour

| Aspect | META (Facebook) | PINTEREST |
|--------|-----------------|-----------|
| `AD_MEDIA_PLATFORM_D1_SK` | 1 | 2 |
| Grain | Line-level pass-through | Campaign-level aggregation |
| Video metrics | From source | Set to 0 |
| Post reactions | From source | Set to 0 |
| Pinterest metrics | Set to 0 | From source |
| Measurement join | By campaign + line | By campaign only |

## Deployment

Execution is ordered via root-level YAML files:

| YAML | Scope |
|------|-------|
| `script_order_execution_meta.yaml` | Analytical DDLs, views, SPs |
| `script_order_execution_meta_dq.yaml` | Data-quality layer |
| `script_order_execution_meta_id_an.yaml` | Analytical SP execution |
| `script_order_execution_meta_id_cn.yaml` | Confirmed-layer full pipeline |

## Implementation Docs

Detailed per-SP documentation lives in `scripts/sql/META_ANALYTICAL/docs/`:
- [FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE](scripts/sql/META_ANALYTICAL/docs/README.md) — multi-platform performance fact load with SCD2, schema details, and data flow
```
