-- ACCOUNT_HISTORY
INSERT  INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.account_history (
_fivetran_id
,	age
,	amount_spent
,	balance
,	business_city
,	business_country_code
,	business_name
,	business_state
,	business_street
,	business_street_2
,	business_zip
,	can_create_brand_lift_study
,	created_time
,	currency
,	end_advertiser
,	end_advertiser_name
,	funding_source
,	has_migrated_permissions
,	io_number
,	is_attribution_spec_system_default
,	is_direct_deals_enabled
,	is_in_3_ds_authorization_enabled_market
,	is_notifications_enabled
,	is_personal
,	is_prepay_account
,	is_tax_id_required
,	media_agency
,	min_campaign_group_spend_cap
,	min_daily_budget
,	name
,	next_bill_date
,	offsite_pixels_tos_accepted
,	owner
,	partner
,	salesforce_invoice_group_id
,	spend_cap
,	tax_id
,	tax_id_type
,	timezone_id
,	timezone_name
,	timezone_offset_hours_utc
,	account_status
,	disable_reason
,	tax_id_status
,	agency_client_declaration_agency_representing_client
,	agency_client_declaration_client_based_in_france
,	agency_client_declaration_client_city
,	agency_client_declaration_client_country_code
,	agency_client_declaration_client_email_address
,	agency_client_declaration_client_name
,	agency_client_declaration_client_postal_code
,	agency_client_declaration_client_province
,	agency_client_declaration_client_street
,	agency_client_declaration_client_street_2
,	agency_client_declaration_has_written_mandate_from_advertiser
,	agency_client_declaration_is_client_paying_invoices
,	business_manager_block_offline_analytics
,	business_manager_created_by
,	business_manager_created_time
,	business_manager_extended_updated_time
,	business_manager_is_hidden
,	business_manager_link
,	business_manager_name
,	business_manager_payment_account_id
,	business_manager_primary_page
,	business_manager_profile_picture_uri
,	business_manager_timezone_id
,	business_manager_two_factor_type
,	business_manager_updated_by
,	business_manager_update_time
,	business_manager_verification_status
,	business_manager_vertical
,	business_manager_vertical_id
,	business_manager_manager_id
,	extended_credit_invoice_group_id
,	extended_credit_invoice_group_auto_enroll
,	extended_credit_invoice_group_customer_po_number
,	extended_credit_invoice_group_email
,	extended_credit_invoice_group_emails
,	extended_credit_invoice_group_name
,	funding_source_details_id
,	funding_source_details_coupon
,	funding_source_details_coupons
,	funding_source_details_coupon_id
,	funding_source_details_amount
,	funding_source_details_currency
,	funding_source_details_display_amount
,	funding_source_details_expiration
,	funding_source_details_display_string
,	funding_source_details_campaign_ids
,	funding_source_details_original_amount
,	funding_source_details_original_display_amount
,	funding_source_details_type
,	capabilities
,	id
,	_fivetran_synced
)
SELECT _fivetran_id
,	age
,	amount_spent
,	balance
,	business_city
,	business_country_code
,	business_name
,	business_state
,	business_street
,	business_street_2
,	business_zip
,	can_create_brand_lift_study
,	created_time
,	currency
,	end_advertiser
,	end_advertiser_name
,	funding_source
,	has_migrated_permissions
,	io_number
,	is_attribution_spec_system_default
,	is_direct_deals_enabled
,	is_in_3_ds_authorization_enabled_market
,	is_notifications_enabled
,	is_personal
,	is_prepay_account
,	is_tax_id_required
,	media_agency
,	min_campaign_group_spend_cap
,	min_daily_budget
,	name
,	next_bill_date
,	offsite_pixels_tos_accepted
,	owner
,	partner
,	salesforce_invoice_group_id
,	spend_cap
,	tax_id
,	tax_id_type
,	timezone_id
,	timezone_name
,	timezone_offset_hours_utc
,	account_status
,	disable_reason
,	tax_id_status
,	agency_client_declaration_agency_representing_client
,	agency_client_declaration_client_based_in_france
,	agency_client_declaration_client_city
,	agency_client_declaration_client_country_code
,	agency_client_declaration_client_email_address
,	agency_client_declaration_client_name
,	agency_client_declaration_client_postal_code
,	agency_client_declaration_client_province
,	agency_client_declaration_client_street
,	agency_client_declaration_client_street_2
,	agency_client_declaration_has_written_mandate_from_advertiser
,	agency_client_declaration_is_client_paying_invoices
,	business_manager_block_offline_analytics
,	business_manager_created_by
,	business_manager_created_time
,	business_manager_extended_updated_time
,	business_manager_is_hidden
,	business_manager_link
,	business_manager_name
,	business_manager_payment_account_id
,	business_manager_primary_page
,	business_manager_profile_picture_uri
,	business_manager_timezone_id
,	business_manager_two_factor_type
,	business_manager_updated_by
,	business_manager_update_time
,	business_manager_verification_status
,	business_manager_vertical
,	business_manager_vertical_id
,	business_manager_manager_id
,	extended_credit_invoice_group_id
,	extended_credit_invoice_group_auto_enroll
,	extended_credit_invoice_group_customer_po_number
,	extended_credit_invoice_group_email
,   CASE WHEN extended_credit_invoice_group_emails IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(extended_credit_invoice_group_emails, '[', ''), ']', ''), '"', ''))) END
,	extended_credit_invoice_group_name
,	funding_source_details_id
,   CASE WHEN funding_source_details_coupon IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(funding_source_details_coupon, '[', ''), ']', ''), '"', ''))) END
,   CASE WHEN funding_source_details_coupons IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(funding_source_details_coupons, '[', ''), ']', ''), '"', ''))) END
,	funding_source_details_coupon_id
,	funding_source_details_amount
,	funding_source_details_currency
,	funding_source_details_display_amount
,	funding_source_details_expiration
,	funding_source_details_display_string
,   CASE WHEN funding_source_details_campaign_ids IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(funding_source_details_campaign_ids, '[', ''), ']', ''), '"', ''))) END
,	funding_source_details_original_amount
,	funding_source_details_original_display_amount
,	funding_source_details_type
,   CASE WHEN capabilities IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(capabilities, '[', ''), ']', ''), '"', ''))) END
,	id
,	_fivetran_synced
FROM <<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.account_history
WHERE   age < (SELECT MIN(age) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.account_history);


-- ACTION_REACTION
-- primary key is ad_id (ad_unit_id)
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_reaction
(ad_id
,	date
,	_fivetran_id
,	account_id
,	adset_id
,	campaign_id
,	clicks
,	impressions
,	spend
,	account_name
,	ad_name
,	adset_name
,	campaign_name
,	_fivetran_synced
)
SELECT  ad_id
,	date
,	_fivetran_id
,	account_id
,	adset_id
,	campaign_id
,	clicks
,	impressions
,	spend
,	account_name
,	ad_name
,	adset_name
,	campaign_name
,	_fivetran_synced
FROM    <<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_reaction
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_reaction);

-- ACTION_REACTION_ACTION_VALUES
-- primary key is (ad_id, date, index)
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_reaction_action_values
(   ad_id
,	date
,	_fivetran_id
,	index
,	action_reaction
,	value
,	_fivetran_synced
,	action_type
,	_1_d_view
,	_7_d_click
)
SELECT  ad_id
,	date
,	_fivetran_id
,	index
,	action_reaction
,	value
,	_fivetran_synced
,	action_type
,	_1_d_view
,	_7_d_click
FROM    <<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_reaction_action_values
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_reaction_action_values);

-- ACTION_REACTION_ACTIONS
-- primary key is (ad_id, date_index)
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_reaction_actions
(   ad_id
,	date
,	_fivetran_id
,	index
,	action_reaction
,	value
,	_fivetran_synced
,	action_type
,	_1_d_view
,	_7_d_click)
SELECT  ad_id
,	date
,	_fivetran_id
,	index
,	action_reaction
,	value
,	_fivetran_synced
,	action_type
,	_1_d_view
,	_7_d_click
FROM    <<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_reaction_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_reaction_actions);

-- ACTION_TYPE
-- primary key is (ad_id, date_index)
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type
(   ad_id
,	date
,	_fivetran_id
,	account_id
,	adset_id
,	campaign_id
,	clicks
,	impressions
,	spend
,	account_name
,	ad_name
,	adset_name
,	campaign_name
,	_fivetran_synced
,	publisher_platform)
SELECT  ad_id
,	date
,	_fivetran_id
,	account_id
,	adset_id
,	campaign_id
,	clicks
,	impressions
,	spend
,	account_name
,	ad_name
,	adset_name
,	campaign_name
,	_fivetran_synced
,	publisher_platform
FROM    <<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_type
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type);

-- ACTION_TYPE_ACTION_VALUES
-- primary key is (ad_id, date_index)
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_action_values
(       ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
,		_1_d_view
,		_7_d_click)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
,		_1_d_view
,		_7_d_click
FROM    <<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_type_action_values
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_action_values);


-- ACTION_TYPE_ACTIONS
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
,		_1_d_view
,		_7_d_click
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
,		_1_d_view
,		_7_d_click
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_type_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_actions);

--action_type_video_p_100_watched_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_p_100_watched_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_type_video_p_100_watched_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_p_100_watched_actions);

--action_type_video_p_25_watched_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_p_25_watched_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_type_video_p_25_watched_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_p_25_watched_actions);

--action_type_video_p_50_watched_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_p_50_watched_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_type_video_p_50_watched_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_p_50_watched_actions);

--action_type_video_p_75_watched_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_p_75_watched_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_type_video_p_75_watched_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_p_75_watched_actions);

--action_type_video_play_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_play_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
,		_1_d_view
,		_7_d_click
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		value
,		_fivetran_synced
,		action_type
,		_1_d_view
,		_7_d_click
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.action_type_video_play_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.action_type_video_play_actions);

--ad_campaign_issues_info
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_campaign_issues_info
(		ad_set_id
,		ad_set_updated_time
,		index
,		error_code
,		error_message
,		error_summary
,		error_type
,		level
,		_fivetran_synced
)
SELECT  ad_set_id
,		ad_set_updated_time
,		index
,		error_code
,		error_message
,		error_summary
,		error_type
,		level
,		_fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_campaign_issues_info
WHERE   ad_set_id NOT IN (SELECT ad_set_id FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_campaign_issues_info)
AND     DATE(_fivetran_synced) < CURRENT_DATE - 2;

--ad_conversion
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_conversion
(		ad_id
,		ad_updated_time
,		index
,		application
,		conversion_id
,		creative
,		dataset
,		event
,		event_type
,		fb_pixel
,		fb_pixel_event
,		leadgen
,		object
,		offer
,		offsite_pixel
,		page
,		post
,		question
,		response
,		subtype
,		action_type
,		event_creator
,		object_domain
,		offer_creator
,		page_parent
,		post_object_wall
,		post_wall
,		post_object
,		question_creator
,		_fivetran_synced
)
SELECT  p.ad_id
,		p.ad_updated_time
,		p.index
,       CASE WHEN p.application IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.application, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.conversion_id IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.conversion_id, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.creative IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.creative, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.dataset IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.dataset, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.event IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.event, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.event_type IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.event_type, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.fb_pixel IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.fb_pixel, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.fb_pixel_event IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.fb_pixel_event, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.leadgen IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.leadgen, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.object IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.object, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.offer IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.offer, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.offsite_pixel IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.offsite_pixel, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.page IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.page, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.post IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.post, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.question IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.question, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.response IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.response, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.subtype IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.subtype, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.action_type IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.action_type, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.event_creator IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.event_creator, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.object_domain IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.object_domain, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.offer_creator IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.offer_creator, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.page_parent IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.page_parent, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.post_object_wall IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.post_object_wall, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.post_wall IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.post_wall, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.post_object IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.post_object, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.question_creator IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.question_creator, '[', ''), ']', ''), '"', ''))) END
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_conversion p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_conversion q
ON      q.ad_id = p.ad_id
AND     q.ad_updated_time = p.ad_updated_time
WHERE   q.ad_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--ad_group_issues_info
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_group_issues_info
(		ad_id
,		ad_updated_time
,		index
,		error_code
,		error_message
,		error_summary
,		error_type
,		level
,		_fivetran_synced
)
SELECT  p.ad_id
,		p.ad_updated_time
,		p.index
,		p.error_code
,		p.error_message
,		p.error_summary
,		p.error_type
,		p.level
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_group_issues_info p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_group_issues_info q
ON      q.ad_id = p.ad_id
AND     q.ad_updated_time = p.ad_updated_time
WHERE   q.ad_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;



--ad_history
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_history
(		id
,		updated_time
,		account_id
,		campaign_id
,		creative_id
,		bid_amount
,		bid_type
,		configured_status
,		conversion_domain
,		created_time
,		effective_status
,		last_updated_by_app_id
,		name
,		preview_shareable_link
,		status
,		ad_set_id
,		ad_source_id
,		_fivetran_synced
,		bid_info_reach
,		bid_info_impressions
,		bid_info_actions
)
SELECT  p.id
,		p.updated_time
,		p.account_id
,		p.campaign_id
,		p.creative_id
,		p.bid_amount
,		p.bid_type
,		p.configured_status
,		p.conversion_domain
,		p.created_time
,		p.effective_status
,		p.last_updated_by_app_id
,		p.name
,		p.preview_shareable_link
,		p.status
,		p.ad_set_id
,		p.ad_source_id
,		p._fivetran_synced
,		p.bid_info_reach
,		p.bid_info_impressions
,		p.bid_info_actions
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_history p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   q.id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--ad_image_history
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_image_history
(		`hash`
,		id
,		updated_time
,		account_id
,		created_time
,		creatives
,		height
,		is_associated_creatives_in_adgroups
,		name
,		original_height
,		original_width
,		permalink_url
,		status
,		url
,		url_128
,		width
,		_fivetran_synced
)
SELECT  p.hash
,		p.id
,		p.updated_time
,		p.account_id
,		p.created_time
,       CASE WHEN p.creatives IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.creatives, '[', ''), ']', ''), '"', ''))) END
,		p.height
,		p.is_associated_creatives_in_adgroups
,		p.name
,		p.original_height
,		p.original_width
,		p.permalink_url
,		p.status
,		p.url
,		p.url_128
,		p.width
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_image_history p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_image_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   q.id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--ad_recommendation
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_recommendation
(		ad_id
,		ad_updated_time
,		index
,		code
,		blame_field
,		confidence
,		importance
,		message
,		title
,		recommendation_data
,		_fivetran_synced
)
SELECT  p.ad_id
,		p.ad_updated_time
,		p.index
,		p.code
,		p.blame_field
,		p.confidence
,		p.importance
,		p.message
,		p.title
,       CASE WHEN p.recommendation_data IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.recommendation_data, '[', ''), ']', ''), '"', ''))) END
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_recommendation p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_recommendation q
ON      q.ad_id = p.ad_id
AND     q.ad_updated_time = p.ad_updated_time
WHERE   q.ad_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--ad_set_attribution
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_set_attribution
(		ad_set_id
,		ad_set_updated_time
,		index
,		_fivetran_synced
,		event_type
,		window_days
)
SELECT  p.ad_set_id
,		p.ad_set_updated_time
,		p.index
,		p._fivetran_synced
,		p.event_type
,		p.window_days
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_set_attribution p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_set_attribution q
ON      q.ad_set_id = p.ad_set_id
AND     q.ad_set_updated_time = p.ad_set_updated_time
AND     q.index = p.index
WHERE   q.ad_set_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--ad_set_custom_audience
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_set_custom_audience
(		ad_set_id
,		ad_set_updated_time
,		custom_audience_id
,		is_excluded
,		_fivetran_synced
)
SELECT  p.ad_set_id
,		p.ad_set_updated_time
,		p.custom_audience_id
,		p.is_excluded
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_set_custom_audience p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_set_custom_audience q
ON      q.ad_set_id = p.ad_set_id
AND     q.ad_set_updated_time = p.ad_set_updated_time
AND     q.custom_audience_id = p.custom_audience_id
WHERE   q.ad_set_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--ad_set_history
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_set_history
(		id
,		updated_time
,		campaign_id
,		account_id
,		asset_feed_id
,		bid_amount
,		bid_strategy
,		billing_event
,		budget_remaining
,		configured_status
,		created_time
,		daily_budget
,		daily_min_spend_target
,		daily_spend_cap
,		destination_type
,		effective_status
,		end_time
,		instagram_actor_id
,		is_dynamic_creative
,		lifetime_budget
,		lifetime_imps
,		lifetime_min_spend_target
,		lifetime_spend_cap
,		multi_optimization_goal_weight
,		name
,		optimization_goal
,		optimization_sub_event
,		recurring_budget_semantics
,		review_feedback
,		rf_prediction_id
,		status
,		start_time
,		use_new_app_click
,		promoted_object_application_id
,		promoted_object_custom_conversion_id
,		promoted_object_custom_event_str
,		promoted_object_custom_event_type
,		promoted_object_event_id
,		promoted_object_object_store_url
,		promoted_object_offer_id
,		promoted_object_offline_conversion_data_set_id
,		promoted_object_page_id
,		promoted_object_pixel_aggregation_rule
,		promoted_object_pixel_id
,		promoted_object_pixel_rule
,		promoted_object_place_page_set_id
,		promoted_object_product_catalog_id
,		promoted_object_product_set_id
,		promoted_object_retention_days
,		learning_stage_info_attribution_windows
,		learning_stage_info_conversions
,		learning_stage_info_last_sig_edit_ts
,		learning_stage_info_status
,		targeting_app_install_state
,		targeting_age_max
,		targeting_age_min
,		targeting_genders
,		targeting_behaviors
,		targeting_interests
,		targeting_relationship_statuses
,		targeting_life_events
,		targeting_industries
,		targeting_income
,		targeting_family_statuses
,		targeting_audience_network_positions
,		targeting_connections
,		targeting_device_platforms
,		targeting_effective_audience_network_positions
,		targeting_excluded_connections
,		targeting_excluded_publisher_categories
,		targeting_excluded_publisher_list_ids
,		targeting_excluded_user_device
,		targeting_facebook_positions
,		targeting_friends_of_connections
,		targeting_instagram_positions
,		targeting_publisher_platforms
,		targeting_user_os
,		targeting_user_device
,		targeting_wireless_carrier
,		targeting_education_schools
,		targeting_education_statuses
,		targeting_college_years
,		targeting_education_majors
,		targeting_work_employers
,		targeting_work_positions
,		targeting_locales
,		targeting_user_adclusters
,		targeting_flexible_spec
,		targeting_exclusions
,		targeting_geo_locations_countries
,		targeting_geo_locations_regions
,		targeting_geo_locations_cities
,		targeting_geo_locations_zips
,		targeting_geo_locations_places
,		targeting_geo_locations_custom_locations
,		targeting_geo_locations_geo_markets
,		targeting_geo_locations_electoral_district
,		targeting_geo_locations_location_types
,		targeting_geo_locations_country_groups
,		targeting_excluded_geo_locations_countries
,		targeting_excluded_geo_locations_regions
,		targeting_excluded_geo_locations_cities
,		targeting_excluded_geo_locations_zips
,		targeting_excluded_geo_locations_places
,		targeting_excluded_geo_locations_custom_locations
,		targeting_excluded_geo_locations_geo_markets
,		targeting_excluded_geo_locations_electoral_district
,		targeting_excluded_geo_locations_location_types
,		targeting_excluded_geo_locations_country_groups
,		adset_source_id
,		_fivetran_synced
,		bid_info_reach
,		bid_info_actions
,		bid_info_impressions
,		instagram_user_id
)
SELECT  p.id
,		p.updated_time
,		p.campaign_id
,		p.account_id
,		p.asset_feed_id
,		p.bid_amount
,		p.bid_strategy
,		p.billing_event
,		p.budget_remaining
,		p.configured_status
,		p.created_time
,		p.daily_budget
,		p.daily_min_spend_target
,		p.daily_spend_cap
,		p.destination_type
,		p.effective_status
,		p.end_time
,		p.instagram_actor_id
,		p.is_dynamic_creative
,		p.lifetime_budget
,		p.lifetime_imps
,		p.lifetime_min_spend_target
,		p.lifetime_spend_cap
,		p.multi_optimization_goal_weight
,		p.name
,		p.optimization_goal
,		p.optimization_sub_event
,		p.recurring_budget_semantics
,		p.review_feedback
,		p.rf_prediction_id
,		p.status
,		p.start_time
,		p.use_new_app_click
,		p.promoted_object_application_id
,		p.promoted_object_custom_conversion_id
,		p.promoted_object_custom_event_str
,		p.promoted_object_custom_event_type
,		p.promoted_object_event_id
,		p.promoted_object_object_store_url
,		p.promoted_object_offer_id
,		p.promoted_object_offline_conversion_data_set_id
,		p.promoted_object_page_id
,		p.promoted_object_pixel_aggregation_rule
,		p.promoted_object_pixel_id
,		p.promoted_object_pixel_rule
,		p.promoted_object_place_page_set_id
,		p.promoted_object_product_catalog_id
,		p.promoted_object_product_set_id
,		p.promoted_object_retention_days
,       CASE WHEN p.learning_stage_info_attribution_windows IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.learning_stage_info_attribution_windows, '[', ''), ']', ''), '"', ''))) END
,		p.learning_stage_info_conversions
,		p.learning_stage_info_last_sig_edit_ts
,		p.learning_stage_info_status
,		p.targeting_app_install_state
,		p.targeting_age_max
,		p.targeting_age_min
,       CASE WHEN p.targeting_genders IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_genders, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_behaviors IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_behaviors, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_interests IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_interests, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_relationship_statuses IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_relationship_statuses, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_life_events IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_life_events, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_industries IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_industries, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_income IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_income, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_family_statuses IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_family_statuses, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_audience_network_positions IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_audience_network_positions, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_connections IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_connections, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_device_platforms IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_device_platforms, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_effective_audience_network_positions IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_effective_audience_network_positions, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_connections IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_connections, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_publisher_categories IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_publisher_categories, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_publisher_list_ids IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_publisher_list_ids, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_user_device IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_user_device, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_facebook_positions IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_facebook_positions, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_friends_of_connections IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_friends_of_connections, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_instagram_positions IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_instagram_positions, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_publisher_platforms IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_publisher_platforms, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_user_os IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_user_os, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_user_device IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_user_device, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_wireless_carrier IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_wireless_carrier, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_education_schools IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_education_schools, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_education_statuses IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_education_statuses, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_college_years IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_college_years, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_education_majors IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_education_majors, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_work_employers IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_work_employers, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_work_positions IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_work_positions, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_locales IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_locales, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_user_adclusters IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_user_adclusters, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_flexible_spec IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_flexible_spec, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_exclusions IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_exclusions, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_countries IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_countries, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_regions IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_regions, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_cities IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_cities, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_zips IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_zips, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_places IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_places, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_custom_locations IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_custom_locations, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_geo_markets IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_geo_markets, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_electoral_district IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_electoral_district, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_location_types IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_location_types, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_geo_locations_country_groups IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_geo_locations_country_groups, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_countries IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_countries, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_regions IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_regions, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_cities IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_cities, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_zips IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_zips, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_places IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_places, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_custom_locations IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_custom_locations, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_geo_markets IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_geo_markets, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_electoral_district IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_electoral_district, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_location_types IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_location_types, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.targeting_excluded_geo_locations_country_groups IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.targeting_excluded_geo_locations_country_groups, '[', ''), ']', ''), '"', ''))) END
,		p.adset_source_id
,		p._fivetran_synced
,		p.bid_info_reach
,		p.bid_info_actions
,		p.bid_info_impressions
,		NULL AS instagram_user_id
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_set_history p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_set_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   q.id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--ad_tracking
-- ARIS:  NEED TO REVIEW THIS QUERY. see spreadsheet ad_tracking.csv
-- primary key: ad_id, ad_updated_time, index
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_tracking
(		ad_id
,		ad_updated_time
,		index
,		application
,		conversion_id
,		creative
,		dataset
,		event
,		event_type
,		fb_pixel
,		fb_pixel_event
,		leadgen
,		object
,		offer
,		offsite_pixel
,		page
,		post
,		question
,		response
,		subtype
,		action_type
,		event_creator
,		object_domain
,		offer_creator
,		page_parent
,		post_object_wall
,		post_wall
,		post_object
,		question_creator
,		_fivetran_synced
)
SELECT  p.ad_id
,		p.ad_updated_time
,		p.index
,       CASE WHEN p.application IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.application, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.conversion_id IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.conversion_id, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.creative IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.creative, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.dataset IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.dataset, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.event IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.event, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.event_type IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.event_type, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.fb_pixel IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.fb_pixel, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.fb_pixel_event IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.fb_pixel_event, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.leadgen IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.leadgen, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.object IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.object, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.offer IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.offer, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.offsite_pixel IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.offsite_pixel, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.page IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.page, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.post IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.post, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.question IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.question, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.response IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.response, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.subtype IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.subtype, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.action_type IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.action_type, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.event_creator IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.event_creator, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.object_domain IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.object_domain, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.offer_creator IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.offer_creator, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.page_parent IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.page_parent, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.post_object_wall IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.post_object_wall, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.post_wall IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.post_wall, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.post_object IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.post_object, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.question_creator IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.question_creator, '[', ''), ']', ''), '"', ''))) END
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_tracking p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_tracking q
ON      q.ad_id = p.ad_id
AND     q.ad_updated_time = p.ad_updated_time
AND     q.index = p.index
WHERE   q.ad_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--ad_video_history
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_video_history
(		id
,		updated_time
,		account_id
,		ad_breaks
,		backdated_time
,		backdated_time_granularity
,		content_category
,		content_tags
,		created_time
,		custom_labels
,		description
,		embed_html
,		embeddable
,		event
,		format
,		icon
,		is_crosspost_video
,		is_crossposting_eligible
,		is_episode
,		is_instagram_eligible
,		is_reference_only
,		length
,		live_status
,		music_video_copyright
,		permalink_url
,		picture
,		place
,		post_views
,		premiere_living_room_status
,		privacy
,		published
,		scheduled_publish_time
,		source
,		status_processing_progress
,		status_value
,		title
,		universal_video_id
,		views
,		from_object
,		_fivetran_synced
)
SELECT  p.id
,		p.updated_time
,		p.account_id
,       CASE WHEN p.ad_breaks IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.ad_breaks, '[', ''), ']', ''), '"', ''))) END
,		p.backdated_time
,		p.backdated_time_granularity
,		p.content_category
,       CASE WHEN p.content_tags IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.content_tags, '[', ''), ']', ''), '"', ''))) END
,		p.created_time
,       CASE WHEN p.custom_labels IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.custom_labels, '[', ''), ']', ''), '"', ''))) END
,		p.description
,		p.embed_html
,		p.embeddable
,       CASE WHEN p.event IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.event, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.format IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.format, '[', ''), ']', ''), '"', ''))) END
,		p.icon
,		p.is_crosspost_video
,		p.is_crossposting_eligible
,		p.is_episode
,		p.is_instagram_eligible
,		p.is_reference_only
,		p.length
,		p.live_status
,       CASE WHEN p.music_video_copyright IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.music_video_copyright, '[', ''), ']', ''), '"', ''))) END
,		p.permalink_url
,		NULL AS picture
,       CASE WHEN p.place IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.place, '[', ''), ']', ''), '"', ''))) END
,		p.post_views
,		p.premiere_living_room_status
,       CASE WHEN p.privacy IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.privacy, '[', ''), ']', ''), '"', ''))) END
,		p.published
,		p.scheduled_publish_time
,		p.source
,		p.status_processing_progress
,		p.status_value
,		p.title
,		p.universal_video_id
,		p.views
,       CASE WHEN p.from_object IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.from_object, '[', ''), ']', ''), '"', ''))) END
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_video_history p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_video_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   q.id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;



--ad_video_thumbnail
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_video_thumbnail
(		id
,		video_id
,		height
,		is_preferred
,		name
,		scale
,		uri
,		width
,		_fivetran_synced
)
SELECT  p.id
,		p.video_id
,		p.height
,		p.is_preferred
,		p.name
,		p.scale
,		p.uri
,		p.width
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.ad_video_thumbnail p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_video_thumbnail q
ON      q.id = p.id
WHERE   q.id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--campaign_history
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.campaign_history
(		id
,		updated_time
,		account_id
,		source_campaign_id
,		bid_strategy
,		boosted_object_id
,		budget_rebalance_flag
,		budget_remaining
,		buying_type
,		can_create_brand_lift_study
,		can_use_spend_cap
,		configured_status
,		created_time
,		daily_budget
,		effective_status
,		is_skadnetwork_attribution
,		last_budget_toggling_time
,		lifetime_budget
,		name
,		objective
,		smart_promotion_type
,		special_ad_category
,		spend_cap
,		start_time
,		status
,		stop_time
,		topline_id
,		pacing_type
,		special_ad_categories
,		special_ad_category_country
,		promoted_object_application_id
,		promoted_object_custom_conversion_id
,		promoted_object_custom_event_str
,		promoted_object_custom_event_type
,		promoted_object_event_id
,		promoted_object_object_store_url
,		promoted_object_offer_id
,		promoted_object_offline_conversion_data_set_id
,		promoted_object_page_id
,		promoted_object_pixel_aggregation_rule
,		promoted_object_pixel_id
,		promoted_object_pixel_rule
,		promoted_object_place_page_set_id
,		promoted_object_product_catalog_id
,		promoted_object_product_set_id
,		promoted_object_retention_days
,		_fivetran_synced
)
SELECT  p.id
,		p.updated_time
,		p.account_id
,		p.source_campaign_id
,		p.bid_strategy
,		p.boosted_object_id
,		p.budget_rebalance_flag
,		p.budget_remaining
,		p.buying_type
,		p.can_create_brand_lift_study
,		p.can_use_spend_cap
,		p.configured_status
,		p.created_time
,		p.daily_budget
,		p.effective_status
,		p.is_skadnetwork_attribution
,		p.last_budget_toggling_time
,		p.lifetime_budget
,		p.name
,		p.objective
,		p.smart_promotion_type
,		p.special_ad_category
,		p.spend_cap
,		p.start_time
,		p.status
,		p.stop_time
,		p.topline_id
,       CASE WHEN p.pacing_type IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.pacing_type, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.special_ad_categories IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.special_ad_categories, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.special_ad_category_country IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.special_ad_category_country, '[', ''), ']', ''), '"', ''))) END
,		p.promoted_object_application_id
,		p.promoted_object_custom_conversion_id
,		p.promoted_object_custom_event_str
,		p.promoted_object_custom_event_type
,		p.promoted_object_event_id
,		p.promoted_object_object_store_url
,		p.promoted_object_offer_id
,		p.promoted_object_offline_conversion_data_set_id
,		p.promoted_object_page_id
,		p.promoted_object_pixel_aggregation_rule
,		p.promoted_object_pixel_id
,		p.promoted_object_pixel_rule
,		p.promoted_object_place_page_set_id
,		p.promoted_object_product_catalog_id
,		p.promoted_object_product_set_id
,		p.promoted_object_retention_days
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.campaign_history p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.campaign_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   q.id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;


--creative_history
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.creative_history
(		_fivetran_id
,		account_id
,		id
,		actor_id
,		applink_treatment
,		authorization_category
,		body
,		branded_content_sponsor_page_id
,		bundle_folder_id
,		call_to_action_type
,		categorization_criteria
,		category_media_source
,		destination_set_id
,		dynamic_ad_voice
,		effective_authorization_category
,		effective_instagram_media_id
,		effective_instagram_story_id
,		effective_object_story_id
,		enable_direct_install
,		image_hash
,		image_url
,		instagram_actor_id
,		instagram_permalink_url
,		instagram_story_id
,		link_destination_display_url
,		link_og_id
,		link_url
,		name
,		object_id
,		object_store_url
,		object_story_id
,		object_type
,		object_url
,		place_page_set_id
,		playable_asset_id
,		product_set_id
,		source_instagram_media_id
,		status
,		template_url
,		thumbnail_id
,		thumbnail_url
,		title
,		use_page_actor_override
,		video_id
,		carousel_ad_link
,		page_link
,		template_page_link
,		url_tags
,		object_story_link_data_caption
,		object_story_link_data_message
,		object_story_link_data_description
,		object_story_link_data_link
,		object_story_link_data_child_attachments
,		object_story_link_data_app_link_spec_android
,		object_story_link_data_app_link_spec_ios
,		object_story_link_data_app_link_spec_ipad
,		object_story_link_data_app_link_spec_iphone
,		template_caption
,		template_message
,		template_description
,		template_link
,		template_child_attachments
,		template_app_link_spec_android
,		template_app_link_spec_ios
,		template_app_link_spec_ipad
,		template_app_link_spec_iphone
,		page_message
,		video_video_id
,		video_call_to_action_value_link
,		platform_customizations_instagram_caption_ids
,		platform_customizations_instagram_image_hash
,		platform_customizations_instagram_image_url
,		platform_customizations_instagram_video_id
,		template_url_spec_android_app_name
,		template_url_spec_android_url
,		template_url_spec_android_package
,		template_url_spec_config_app_id
,		template_url_spec_ios_app_name
,		template_url_spec_ios_app_store_id
,		template_url_spec_ios_url
,		template_url_spec_iphone_app_name
,		template_url_spec_iphone_app_store_id
,		template_url_spec_iphone_url
,		template_url_spec_ipad_app_name
,		template_url_spec_ipad_app_store_id
,		template_url_spec_ipad_url
,		template_url_spec_web_should_fallback
,		template_url_spec_web_url
,		template_url_spec_windows_phone_app_id
,		template_url_spec_windows_phone_app_name
,		template_url_spec_windows_phone_url
,		asset_feed_spec_additional_data_automated_product_tags
,		asset_feed_spec_additional_data_brand_page_id
,		asset_feed_spec_additional_data_is_click_to_message
,		asset_feed_spec_additional_data_multi_share_end_card
,		asset_feed_spec_additional_data_page_welcome_message
,		asset_feed_spec_additional_data_partner_app_welcome_message_flow_id
,		asset_feed_spec_app_product_page_id
,		asset_feed_spec_optimization_type
,		asset_feed_spec_promotional_metadata_allowed_coupon_code_sources
,		asset_feed_spec_promotional_metadata_coupon_codes
,		asset_feed_spec_promotional_metadata_manual_coupon_codes
,		asset_feed_spec_call_ads_configuration
,		asset_feed_spec_reasons_to_shop
,		asset_feed_spec_shops_bundle
,		asset_feed_spec_link_urls
,		_fivetran_synced
,		instagram_user_id
)
SELECT  p._fivetran_id
,		p.account_id
,		p.id
,		p.actor_id
,		p.applink_treatment
,		p.authorization_category
,		p.body
,		p.branded_content_sponsor_page_id
,		p.bundle_folder_id
,		p.call_to_action_type
,		p.categorization_criteria
,		p.category_media_source
,		p.destination_set_id
,		p.dynamic_ad_voice
,		p.effective_authorization_category
,		p.effective_instagram_media_id
,		p.effective_instagram_story_id
,		p.effective_object_story_id
,		p.enable_direct_install
,		p.image_hash
,		p.image_url
,		p.instagram_actor_id
,		p.instagram_permalink_url
,		p.instagram_story_id
,		p.link_destination_display_url
,		p.link_og_id
,		p.link_url
,		p.name
,		p.object_id
,		p.object_store_url
,		p.object_story_id
,		p.object_type
,		p.object_url
,		p.place_page_set_id
,		p.playable_asset_id
,		p.product_set_id
,		p.source_instagram_media_id
,		p.status
,		p.template_url
,		p.thumbnail_id
,		p.thumbnail_url
,		p.title
,		p.use_page_actor_override
,		p.video_id
,		p.carousel_ad_link
,		p.page_link
,		p.template_page_link
,       CASE WHEN p.url_tags IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.url_tags, '[', ''), ']', ''), '"', ''))) END
,		p.object_story_link_data_caption
,		p.object_story_link_data_message
,		p.object_story_link_data_description
,		p.object_story_link_data_link
,       CASE WHEN p.object_story_link_data_child_attachments IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.object_story_link_data_child_attachments, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.object_story_link_data_app_link_spec_android IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.object_story_link_data_app_link_spec_android, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.object_story_link_data_app_link_spec_ios IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.object_story_link_data_app_link_spec_ios, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.object_story_link_data_app_link_spec_ipad IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.object_story_link_data_app_link_spec_ipad, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.object_story_link_data_app_link_spec_iphone IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.object_story_link_data_app_link_spec_iphone, '[', ''), ']', ''), '"', ''))) END
,		p.template_caption
,		p.template_message
,		p.template_description
,		p.template_link
,       CASE WHEN p.template_child_attachments IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.template_child_attachments, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.template_app_link_spec_android IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.template_app_link_spec_android, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.template_app_link_spec_ios IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.template_app_link_spec_ios, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.template_app_link_spec_ipad IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.template_app_link_spec_ipad, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.template_app_link_spec_iphone IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.template_app_link_spec_iphone, '[', ''), ']', ''), '"', ''))) END
,		p.page_message
,		p.video_video_id
,		p.video_call_to_action_value_link
,       CASE WHEN p.platform_customizations_instagram_caption_ids IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.platform_customizations_instagram_caption_ids, '[', ''), ']', ''), '"', ''))) END
,		p.platform_customizations_instagram_image_hash
,		p.platform_customizations_instagram_image_url
,		p.platform_customizations_instagram_video_id
,		p.template_url_spec_android_app_name
,		p.template_url_spec_android_url
,		p.template_url_spec_android_package
,		p.template_url_spec_config_app_id
,		p.template_url_spec_ios_app_name
,		p.template_url_spec_ios_app_store_id
,		p.template_url_spec_ios_url
,		p.template_url_spec_iphone_app_name
,		p.template_url_spec_iphone_app_store_id
,		p.template_url_spec_iphone_url
,		p.template_url_spec_ipad_app_name
,		p.template_url_spec_ipad_app_store_id
,		p.template_url_spec_ipad_url
,		p.template_url_spec_web_should_fallback
,		p.template_url_spec_web_url
,		p.template_url_spec_windows_phone_app_id
,		p.template_url_spec_windows_phone_app_name
,		p.template_url_spec_windows_phone_url
,		p.asset_feed_spec_additional_data_automated_product_tags
,		p.asset_feed_spec_additional_data_brand_page_id
,		p.asset_feed_spec_additional_data_is_click_to_message
,		p.asset_feed_spec_additional_data_multi_share_end_card
,		p.asset_feed_spec_additional_data_page_welcome_message
,		p.asset_feed_spec_additional_data_partner_app_welcome_message_flow_id
,		p.asset_feed_spec_app_product_page_id
,		p.asset_feed_spec_optimization_type
,       CASE WHEN p.asset_feed_spec_promotional_metadata_allowed_coupon_code_sources IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.asset_feed_spec_promotional_metadata_allowed_coupon_code_sources, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.asset_feed_spec_promotional_metadata_coupon_codes IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.asset_feed_spec_promotional_metadata_coupon_codes, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.asset_feed_spec_promotional_metadata_manual_coupon_codes IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.asset_feed_spec_promotional_metadata_manual_coupon_codes, '[', ''), ']', ''), '"', ''))) END
,       CASE WHEN p.asset_feed_spec_call_ads_configuration IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.asset_feed_spec_call_ads_configuration, '[', ''), ']', ''), '"', ''))) END
,		p.asset_feed_spec_reasons_to_shop
,		p.asset_feed_spec_shops_bundle
,       CASE WHEN p.asset_feed_spec_link_urls IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.asset_feed_spec_link_urls, '[', ''), ']', ''), '"', ''))) END
,		p._fivetran_synced
,		p.instagram_user_id
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.creative_history p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.creative_history q
ON      q._fivetran_id = p._fivetran_id
WHERE   q._fivetran_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--custom_audience_history
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.custom_audience_history
(		id
,		updated_time
,		account_id
,		approximate_count_lower_bound
,		approximate_count_upper_bound
,		customer_file_source
,		description
,		is_value_based
,		name
,		opt_out_link
,		pixel_id
,		retention_days
,		rule
,		rule_aggregation
,		subtype
,		data_source_creation_params
,		data_source_sub_type
,		data_source_type
,		delivery_status_code
,		delivery_status_description
,		external_event_source_id
,		external_event_source_automatic_matching_fields
,		external_event_source_can_proxy
,		external_event_source_code
,		external_event_source_creation_time
,		external_event_source_data_use_setting
,		external_event_source_enable_automatic_matching
,		external_event_source_first_party_cookie_status
,		external_event_source_is_created_by_business
,		external_event_source_is_crm
,		external_event_source_is_unavailable
,		external_event_source_last_fired_time
,		external_event_source_name
,		lookalike_country
,		lookalike_is_financial_service
,		lookalike_origin_event_name
,		lookalike_origin_event_source_name
,		lookalike_product_set_name
,		lookalike_ratio
,		lookalike_starting_ratio
,		lookalike_type
,		operation_status_code
,		operation_status_description
,		permission_for_actions_can_edit
,		permission_for_actions_can_see_insight
,		permission_for_actions_can_share
,		permission_for_actions_subtype_supports_lookalike
,		permission_for_actions_supports_recipient_lookalike
,		content_updated_time
,		created_time
,		_fivetran_synced
)
SELECT  p.id
,		p.updated_time
,		p.account_id
,		p.approximate_count_lower_bound
,		p.approximate_count_upper_bound
,		p.customer_file_source
,		p.description
,		p.is_value_based
,		p.name
,		p.opt_out_link
,		p.pixel_id
,		p.retention_days
,		p.rule
,		p.rule_aggregation
,		p.subtype
,		p.data_source_creation_params
,		p.data_source_sub_type
,		p.data_source_type
,		p.delivery_status_code
,		p.delivery_status_description
,		p.external_event_source_id
,       CASE WHEN p.external_event_source_automatic_matching_fields IS NULL THEN NULL ELSE TO_JSON(SPLIT(REPLACE(REPLACE(REPLACE(p.external_event_source_automatic_matching_fields, '[', ''), ']', ''), '"', ''))) END
,		p.external_event_source_can_proxy
,		p.external_event_source_code
,		p.external_event_source_creation_time
,		p.external_event_source_data_use_setting
,		p.external_event_source_enable_automatic_matching
,		p.external_event_source_first_party_cookie_status
,		p.external_event_source_is_created_by_business
,		p.external_event_source_is_crm
,		p.external_event_source_is_unavailable
,		p.external_event_source_last_fired_time
,		p.external_event_source_name
,		p.lookalike_country
,		p.lookalike_is_financial_service
,		p.lookalike_origin_event_name
,		p.lookalike_origin_event_source_name
,		p.lookalike_product_set_name
,		p.lookalike_ratio
,		p.lookalike_starting_ratio
,		p.lookalike_type
,		p.operation_status_code
,		p.operation_status_description
,		p.permission_for_actions_can_edit
,		p.permission_for_actions_can_see_insight
,		p.permission_for_actions_can_share
,		p.permission_for_actions_subtype_supports_lookalike
,		p.permission_for_actions_supports_recipient_lookalike
,		p.content_updated_time
,		p.created_time
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.custom_audience_history p 
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.custom_audience_history q
ON      q.id = p.id
AND     q.updated_time = p.updated_time
WHERE   q.id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--<<FACEBOOK_MKT_INSIGHTS_DATASET>>
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg
(		ad_id
,		date
,		_fivetran_id
,		publisher_platform
,		account_id
,		adset_id
,		campaign_id
,		clicks
,		impressions
,		inline_link_clicks
,		cost_per_unique_inline_link_click
,		spend
,		account_name
,		ad_name
,		adset_name
,		campaign_name
,		_fivetran_synced
)
SELECT  p.ad_id
,		p.date
,		p._fivetran_id
,		p.publisher_platform
,		p.account_id
,		p.adset_id
,		p.campaign_id
,		p.clicks
,		p.impressions
,		p.inline_link_clicks
,		NULL AS cost_per_unique_inline_link_click
,		p.spend
,		p.account_name
,		p.ad_name
,		p.adset_name
,		p.campaign_name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.facebook_ad_insights_cpg p
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg);


--<<FACEBOOK_MKT_INSIGHTS_DATASET>>_action_values
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_action_values
(		ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
,		_1_d_view
,		_7_d_click
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
,		_1_d_view
,		_7_d_click
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.facebook_ad_insights_cpg_action_values
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_action_values);

--<<FACEBOOK_MKT_INSIGHTS_DATASET>>_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
,		_7_d_click
,		_1_d_view
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
,		_7_d_click
,		_1_d_view
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.facebook_ad_insights_cpg_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_actions);

--<<FACEBOOK_MKT_INSIGHTS_DATASET>>_video_p_100_watched_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_100_watched_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.facebook_ad_insights_cpg_video_p_100_watched_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_100_watched_actions);

--<<FACEBOOK_MKT_INSIGHTS_DATASET>>_video_p_25_watched_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_25_watched_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.facebook_ad_insights_cpg_video_p_25_watched_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_25_watched_actions);

--<<FACEBOOK_MKT_INSIGHTS_DATASET>>_video_p_50_watched_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_50_watched_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.facebook_ad_insights_cpg_video_p_50_watched_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_50_watched_actions);


--<<FACEBOOK_MKT_INSIGHTS_DATASET>>_video_p_75_watched_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_75_watched_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.facebook_ad_insights_cpg_video_p_75_watched_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_75_watched_actions);


--<<FACEBOOK_MKT_INSIGHTS_DATASET>>_video_play_actions
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_play_actions
(		ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
,		_1_d_view
,		_7_d_click
)
SELECT  ad_id
,		date
,		_fivetran_id
,		index
,		action_type
,		value
,		_fivetran_synced
,		_1_d_view
,		_7_d_click
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.facebook_ad_insights_cpg_video_play_actions
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_play_actions);


--frequency_control
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.frequency_control
(		ad_set_id
,		ad_set_updated_time
,		index
,		event
,		interval_days
,		max_frequency
,		_fivetran_synced
)
SELECT  p.ad_set_id
,		p.ad_set_updated_time
,		p.index
,		p.event
,		p.interval_days
,		p.max_frequency
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.frequency_control p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.frequency_control q
ON      q.ad_set_id = p.ad_set_id
AND     q.ad_set_updated_time = p.ad_set_updated_time
and     q.index = p.index
WHERE   q.ad_set_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;

--lookalike_origin
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.lookalike_origin
(		custom_audience_id
,		custom_audience_updated_time
,		index
,		name
,		type
,		origin_custom_audience_id
,		_fivetran_synced
)
SELECT  p.custom_audience_id
,		p.custom_audience_updated_time
,		p.index
,		p.name
,		p.type
,		p.origin_custom_audience_id
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.lookalike_origin p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.lookalike_origin q
ON      q.custom_audience_id = p.custom_audience_id
AND     q.custom_audience_updated_time = p.custom_audience_updated_time
and     q.index = p.index
WHERE   q.custom_audience_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;


--pacing_type
INSERT INTO <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.pacing_type
(		ad_set_id
,		ad_set_updated_time
,		index
,		name
,		_fivetran_synced
)
SELECT  p.ad_set_id
,		p.ad_set_updated_time
,		p.index
,		p.name
,		p._fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_INSIGHTS_DATASET>>.pacing_type p
LEFT    OUTER JOIN <<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.pacing_type q
ON      q.ad_set_id = p.ad_set_id
AND     q.ad_set_updated_time = p.ad_set_updated_time
and     q.index = p.index
WHERE   q.ad_set_id IS NULL
AND     DATE(p._fivetran_synced) < CURRENT_DATE - 2;


--reach_frequency
-- no need to backfill, data is just repeated every day
-- there is no key that we can use

--ad_reach
--INSERT INTO gcp-abs-emfi-bq-dev-prj-01.<<FACEBOOK_MKT_REACH_DATASET>>.ad_reach
INSERT INTO <<SOURCE_PROJECT_ID>>.<<FACEBOOK_SRC_REACH_DATASET>>.ad_reach
(		ad_id
,		date
,		_fivetran_id
,		account_id
,		clicks
,		impressions
,		inline_link_clicks
,		reach
,		_fivetran_synced
)
SELECT  ad_id
,		date
,		_fivetran_id
,		account_id
,		clicks
,		impressions
,		inline_link_clicks
,		reach
,		_fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_REACH_DATASET>>.ad_reach
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<FACEBOOK_SRC_REACH_DATASET>>.ad_reach);


--campaign_reach
--INSERT INTO gcp-abs-emfi-bq-dev-prj-01.<<FACEBOOK_MKT_REACH_DATASET>>.campaign_reach
INSERT INTO <<SOURCE_PROJECT_ID>>.<<FACEBOOK_SRC_REACH_DATASET>>.campaign_reach
(		campaign_id
,		date
,		_fivetran_id
,		account_id
,		clicks
,		impressions
,		inline_link_clicks
,		reach
,		_fivetran_synced
)
SELECT  campaign_id
,		date
,		_fivetran_id
,		account_id
,		clicks
,		impressions
,		inline_link_clicks
,		reach
,		_fivetran_synced
FROM	<<MKT_PROJECT_ID>>.<<FACEBOOK_MKT_REACH_DATASET>>.campaign_reach
WHERE   date < (SELECT MIN(date) FROM <<SOURCE_PROJECT_ID>>.<<FACEBOOK_SRC_REACH_DATASET>>.campaign_reach);




