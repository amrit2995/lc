CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE`
(
	PLATFORM_MEDIA_CREATIVE_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns."),
	PLATFORM_CD OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values:Meta/Pinterest/etc."),
	PLATFORM_MEDIA_CREATIVE_ID OPTIONS(DESCRIPTION = "Unique identifier for each creative. One campaign can have multiple Line items and each Line item can have multiple Creatives. A campaign may or may not have line item. In second case when campaign doesn't have Line item then a Creative Id will be associated with Campaign Id else with Line item id and then campaign Id in Hierarchy." ),
	PLATFORM_MEDIA_CREATIVE_NM OPTIONS(DESCRIPTION = "Creative Name"),
	PLATFORM_MEDIA_CREATIVE_SZ OPTIONS(DESCRIPTION = "Creative Size. Meta/Pinterest have a 1:1 relationship between the Ad and Creative Size, so this is derived from the mapping table"),
	PLATFORM_MEDIA_CREATIVE_TYPE_CD OPTIONS(DESCRIPTION = "Creative Type"),
	DW_CREATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
    PLATFORM_MEDIA_CREATIVE_D1_SK,
	PLATFORM_CD,
	PLATFORM_MEDIA_CREATIVE_ID,
	PLATFORM_MEDIA_CREATIVE_NM,
	PLATFORM_MEDIA_CREATIVE_SZ,
	PLATFORM_MEDIA_CREATIVE_TYPE_CD,
	DW_CREATE_TS,
	DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE`