CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.D1_PLATFORM_MEDIA_AD_UNIT`
(
	PLATFORM_MEDIA_AD_UNIT_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for creative unit – uniquely identifies each creative ad placement."),
	PLATFORM_CD OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values: Meta/Pinterest/etc." ),
	PLATFORM_MEDIA_AD_UNIT_ID OPTIONS(DESCRIPTION = "UNIT ID trafficked in placement mirroring social ad. One Ad Unit Id can belong to multiple Placement Id's"),
	PLATFORM_MEDIA_AD_UNIT_NM OPTIONS(DESCRIPTION = "Name For AD_UNIT ID trafficked in placement mirroring social ad" ),
	PLATFORM_AD_UNIT_CREATIVE_VERSION_CD OPTIONS(DESCRIPTION = "The name of the creative version input to platform" ),
	DW_CREATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
    PLATFORM_MEDIA_AD_UNIT_D1_SK,
	PLATFORM_CD,
	PLATFORM_MEDIA_AD_UNIT_ID,
	PLATFORM_MEDIA_AD_UNIT_NM,
	PLATFORM_AD_UNIT_CREATIVE_VERSION_CD,
	DW_CREATE_TS,
	DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_AD_UNIT`