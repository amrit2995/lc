CREATE or REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.ad_platform_advertiser`
(
 advertiser_id         OPTIONS(description="Unique identifier of the advertiser across ad platforms"),
 source_application_cd  OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts    OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts     OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 currency_cd        OPTIONS(description="The currency code used by the advertiser (e.g., USD, EUR)"),
 advertiser_nm         OPTIONS(description="Name of the advertiser or brand"),
 account_status_nm     OPTIONS(description="Current status of the advertiser account (e.g., Active, Disabled)"),
 disable_reason_txt    OPTIONS(description="Reason for disabling the advertiser account, if applicable"),
 source_created_ts  OPTIONS(description="The date and time record was created"),
 source_last_modified_ts  OPTIONS(description="The date and time record was modified"),
 dw_create_ts                      OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts                 OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind             OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm               OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm               OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind            OPTIONS(description="Set to True to mark the latest record for the primary keys, else False")
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS 
SELECT
 advertiser_id         ,
 source_application_cd  ,
 Dw_first_effective_ts  ,
 Dw_last_effective_ts  ,
 currency_cd        ,
 advertiser_nm         ,
 account_status_nm     ,
 disable_reason_txt     ,
 source_created_ts  ,
 source_last_modified_ts  ,
 dw_create_ts                      ,
 dw_last_update_ts                 ,
 dw_logical_delete_ind             ,
 dw_source_create_nm               ,
 dw_source_update_nm               ,
 dw_current_version_ind            
FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_advertiser`;