CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.F_AD_PLATFORM_CAMPAIGN_TREND` (
		PERFORMANCE_DAY_ID OPTIONS(
			DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101"
		),
		PLATFORM_MEDIA_AD_UNIT_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for creative unit – uniquely identifies each creative ad placement."
		),
		PLATFORM_ADVERTISER_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."
		),
		AD_MEDIA_PLATFORM_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."
		),
		AD_MEDIA_CAMPAIGN_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system."
		),
		AD_MEDIA_CAMPAIGN_LINE_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for campaign line item – uniquely identifies each line item record."
		),
		PLATFORM_MEDIA_CAMPAIGN_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for platform media campaign – uniquely identifies each campaign per platform."
		),
		PLATFORM_MEDIA_LINE_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns."
		),
		PLATFORM_MEDIA_CREATIVE_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns."
		),
		PLATFORM_MEDIA_PLACEMENT_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for creative unit Placement  – uniquely identifies each creative ad placement."
		),
		AD_MEDIA_OPPORTUNITY_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system."
		),
		PLATFORM_MEDIA_ADVERTISEMENT_D1_SK OPTIONS(
			DESCRIPTION = "Surrogate key for creative unit – uniquely identifies each creative ad placement."
		),
		TOTAL_CLICK_CNT OPTIONS(DESCRIPTION = "Count of clicks on the ad"),
		TOTAL_IMPRESSION_CNT OPTIONS(
			DESCRIPTION = "Impression count for Social Performance"
		),
		TOTAL_MEDIA_SPEND_AMT OPTIONS(
			DESCRIPTION = "This reflects the amount charged by <<cocmp>> to the CPG."
		),
		VIDEO_START_CNT OPTIONS(
			DESCRIPTION = "Number of people who saw at least the start of the video."
		),
		VIDEO_25P_CNT OPTIONS(
			DESCRIPTION = "Number of people who saw at least 25% of the video."
		),
		VIDEO_50P_CNT OPTIONS(
			DESCRIPTION = "Number of people who saw at least 50% of the video."
		),
		VIDEO_75P_CNT OPTIONS(
			DESCRIPTION = "Number of people who saw at least 75% of the video."
		),
		VIDEO_COMPLETE_CNT OPTIONS(
			DESCRIPTION = "Number of people who saw at least 100% of the video."
		),
		POST_REACTION_ANGRY_CNT OPTIONS(
			DESCRIPTION = "Count of 'Angry' reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_WOW_CNT OPTIONS(
			DESCRIPTION = "Count of 'Wow' reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_LOVE_CNT OPTIONS(
			DESCRIPTION = "Count of 'Love' reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_CARE_CNT OPTIONS(
			DESCRIPTION = "Count of 'Care' reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_HAHA_CNT OPTIONS(
			DESCRIPTION = "Count of 'Haha'(Laugh) reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_LIKE_CNT OPTIONS(
			DESCRIPTION = "Count of likes across Meta properties. This metric is cumulative across Facebook & Instagram."
		),
		POST_REACTION_SAD_CNT OPTIONS(
			DESCRIPTION = "Count of 'Sad' reactions across Meta properties. This metric is cumulative across Facebook & Instagram."
		),
		TOTAL_POST_ENGAGEMENT_CNT OPTIONS(
			DESCRIPTION = "Count of engagements across Meta properties. Includes reactions, likes, comments, shares."
		),
		TOTAL_POST_COMMENT_CNT OPTIONS(
			DESCRIPTION = "Count of comments across Meta properties. This metric is cumulative across Facebook & Instagram."
		),
		TOTAL_POST_REACTION_CNT OPTIONS(
			DESCRIPTION = "Count of Reactions across Meta properties. This metric is cumulative across Facebook & Instagram."
		),
		TOTAL_PINTEREST_ENGAGEMENT_CNT OPTIONS(
			DESCRIPTION = "Count of total engagements on Pinterest. This includes people clicking on or saving a pin."
		),
		TOTAL_PINTEREST_REPINS_CNT OPTIONS(
			DESCRIPTION = "Count or “Re-Pins” on Pinterest."
		),
		CPG_MEDIA_SPEND_AMT OPTIONS(
			DESCRIPTION = "This reflects the amount charged by <<cocmp>> to the CPG."
		),
		DW_CREATE_TS OPTIONS(
			DESCRIPTION = "Timestamp when the record was created"
		),
		DW_LAST_UPDATE_TS OPTIONS(
			DESCRIPTION = "Timestamp when the record was last updated"
		)
	) OPTIONS (
		labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	) AS
SELECT PERFORMANCE_DAY_ID,
	PLATFORM_MEDIA_AD_UNIT_D1_SK,
	PLATFORM_ADVERTISER_D1_SK,
	AD_MEDIA_PLATFORM_D1_SK,
	AD_MEDIA_CAMPAIGN_D1_SK,
	AD_MEDIA_CAMPAIGN_LINE_D1_SK,
	PLATFORM_MEDIA_CAMPAIGN_D1_SK,
	PLATFORM_MEDIA_LINE_D1_SK,
	PLATFORM_MEDIA_CREATIVE_D1_SK,
	PLATFORM_MEDIA_PLACEMENT_D1_SK,
	AD_MEDIA_OPPORTUNITY_D1_SK,
	PLATFORM_MEDIA_ADVERTISEMENT_D1_SK,
	TOTAL_CLICK_CNT,
	TOTAL_IMPRESSION_CNT,
	TOTAL_MEDIA_SPEND_AMT,
	VIDEO_START_CNT,
	VIDEO_25P_CNT,
	VIDEO_50P_CNT,
	VIDEO_75P_CNT,
	VIDEO_COMPLETE_CNT,
	POST_REACTION_ANGRY_CNT,
	POST_REACTION_WOW_CNT,
	POST_REACTION_LOVE_CNT,
	POST_REACTION_CARE_CNT,
	POST_REACTION_HAHA_CNT,
	POST_REACTION_LIKE_CNT,
	POST_REACTION_SAD_CNT,
	TOTAL_POST_ENGAGEMENT_CNT,
	TOTAL_POST_COMMENT_CNT,
	TOTAL_POST_REACTION_CNT,
	TOTAL_PINTEREST_ENGAGEMENT_CNT,
	TOTAL_PINTEREST_REPINS_CNT,
	CPG_MEDIA_SPEND_AMT,
	DW_CREATE_TS,
	DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_CAMPAIGN_TREND`