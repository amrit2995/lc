CREATE or REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.ad_platform_advertisement`
(
 ad_id                    OPTIONS(description="Surrogate key, Unique Identifier."),
 source_application_cd    OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts    OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts     OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 ad_nm                    OPTIONS(description="ad name"),
 source_created_ts        OPTIONS(description="Timestamp when the campaign was created in the source system"),
 source_last_modified_ts  OPTIONS(description="The date and time record was modified"),
 dw_create_ts             OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts       OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind    OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm     OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm     OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind  OPTIONS(description="Set to True to mark the latest record for the primary keys, else False")
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS 
SELECT
 ad_id         ,
 source_application_cd  ,
 dw_first_effective_ts  ,
 dw_last_effective_ts  ,
 ad_nm        ,
 source_created_ts  ,
 source_last_modified_ts  ,
 dw_create_ts                      ,
 dw_last_update_ts                 ,
 dw_logical_delete_ind             ,
 dw_source_create_nm               ,
 dw_source_update_nm               ,
 dw_current_version_ind            
FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_advertisement`;