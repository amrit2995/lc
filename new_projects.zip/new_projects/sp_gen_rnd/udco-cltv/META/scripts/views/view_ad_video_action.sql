CREATE or REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.ad_video_action`
(
 video_action_type_id       OPTIONS(description="FK to video action type"),
 dw_first_effective_ts      OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts       OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 ad_id                      OPTIONS(description="FK to ad entity"),
 publisher_platform_nm      OPTIONS(description="Ad platform name(eg:Facebook, Instagarm)"),
 video_action_dt            OPTIONS(description="Date the video action occured"),
 source_application_cd      OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 value_nbr                  OPTIONS(description="Count of video views or watch actions for the given threshold"),
 dw_create_ts               OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind      OPTIONS(description="Set to True when we receive a delete record for the primary key"),
 dw_source_create_nm        OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm        OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind     OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be  current date -1 d.")
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS 
SELECT
 video_action_type_id       ,
 Dw_first_effective_ts      ,
 Dw_last_effective_ts       ,
 ad_id                      ,
 publisher_platform_nm      ,
 video_action_dt            ,
 source_application_cd      ,
 value_nbr                  ,
 dw_create_ts               ,
 dw_last_update_ts          ,
 dw_logical_delete_ind      ,
 dw_source_create_nm        ,
 dw_source_update_nm        ,
 dw_current_version_ind     
FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_video_action`;