CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.D1_AD_MEDIA_CAMPAIGN`
(
	AD_MEDIA_CAMPAIGN_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for campaign - uniquely identifies each advertising campaign record in the system."),
	AD_MEDIA_CAMPAIGN_ID OPTIONS(DESCRIPTION = "AMC Media Campaign ID" ),
	AD_CAMPAIGN_ID OPTIONS(DESCRIPTION = "AMC Hub Campaign ID" ),
	AD_CAMPAIGN_NM OPTIONS(DESCRIPTION = "AMC Hub Campaign Name" ),
	AD_MEDIA_CAMPAIGN_NM OPTIONS(DESCRIPTION = "AMC Friendly Campaign Name from Insertion Order" ),
	AD_CAMPAIGN_START_DT OPTIONS(DESCRIPTION = "Start date for the whole Hub Campaign" ),
	AD_CAMPAIGN_END_DT OPTIONS(DESCRIPTION = "End date for the whole Hub Campaign" ),
	AD_CAMPAIGN_BUDGT_AMT OPTIONS(DESCRIPTION = "Budget for the whole Hub Campaign" ),
	AD_CAMPAIGN_ADVERTISED_BRAND_NM OPTIONS(DESCRIPTION = "Brand(s) represented in the advertisement. These are the IRI Brand names(ampersand-delimited) that will be used for attribution. Note that for Citrus, these will not align with IRI Brand Names." ),
	AD_CAMPAIGN_PLND_IMPRESSION_CNT OPTIONS(DESCRIPTION = "Planned Impressions for the whole Hub Campaign" ),
	AD_CAMPAIGN_OBJECTIVE_TXT OPTIONS(DESCRIPTION = "CPG's aim with this AMC Hub Campaign" ),
	AD_CPG OPTIONS(DESCRIPTION = "AMC Hub Campaign ID & AMC Friendly Campaign Name from Insertion Order"),
	DW_CREATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
    AD_MEDIA_CAMPAIGN_D1_SK,
	AD_MEDIA_CAMPAIGN_ID,
	AD_CAMPAIGN_ID,
	AD_CAMPAIGN_NM,
	AD_MEDIA_CAMPAIGN_NM,
	AD_CAMPAIGN_START_DT,
	AD_CAMPAIGN_END_DT,
	AD_CAMPAIGN_BUDGT_AMT,
	AD_CAMPAIGN_ADVERTISED_BRAND_NM,
	AD_CAMPAIGN_PLND_IMPRESSION_CNT,
	AD_CAMPAIGN_OBJECTIVE_TXT,
	AD_CPG,
	DW_CREATE_TS,
	DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN`