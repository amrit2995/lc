CREATE or REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.video_action_type`
(
 video_action_type_id   OPTIONS(description="Unique ID for the video engagement type"),
 video_action_cd         OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 video_action_code_dsc  OPTIONS(description="Code for video(eg:play,p25,p50 etc)"),
 source_application_cd  OPTIONS(description="Description of the video view threshold"),
 dw_create_ts                      OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts                 OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind             OPTIONS(description="Set to True when we receive a delete record for the primary key"),
 dw_source_create_nm               OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm               OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind            OPTIONS(description="set to yes when the current record is deleted,  the Last Effective date on this record is still set to be  current date -1 d.")
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS 
SELECT
 video_action_type_id  ,
 video_action_cd       ,
 video_action_code_dsc  ,
 source_application_cd  ,
 dw_create_ts                      ,
 dw_last_update_ts                 ,
 dw_logical_delete_ind             ,
 dw_source_create_nm               ,
 dw_source_update_nm               ,
 dw_current_version_ind     
FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.video_action_type`;