CREATE or REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.ad_creative_reach_summary`
(
 ad_id             	          OPTIONS(description="The unique identifier for the individualad creative being tracked."),
 source_last_modified_ts      OPTIONS(description="The date and time record was modified"),
 dw_first_effective_ts        OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts         OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 reach_cnt                    OPTIONS(description="Estimated number of unique users who were exposedto the ad"),
 impressions_cnt              OPTIONS(description="Total number of times the ad was served, including repeats"),
 source_application_cd        OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_create_ts                 OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts            OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind        OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm          OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm          OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind       OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be current date -1 d.")
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS 
SELECT
 ad_id             	          ,
 source_last_modified_ts      ,
 dw_first_effective_ts        ,
 dw_last_effective_ts         ,
 reach_cnt                    ,
 impressions_cnt              ,
 source_application_cd        ,
 dw_create_ts                 ,
 dw_last_update_ts            ,
 dw_logical_delete_ind        ,
 dw_source_create_nm          ,
 dw_source_update_nm          ,
 dw_current_version_ind       
FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_creative_reach_summary`;