CREATE or REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.ad_platform_campaign` 
(
 campaign_id               OPTIONS(description="Unique Identifier for the campaign."),
 source_application_cd     OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts    OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts     OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 advertiser_id             OPTIONS(description="Foreign key to the advertiser that owns the campaign"),
 campaign_nm                OPTIONS(description="Original campaign name from the source platform"),
 start_ts              OPTIONS(description="Start date of the campaign flight"),
 end_ts                OPTIONS(description="End date of the campaign flight"),
 total_budget_amt OPTIONS(description="Micro Amount."), 
 currency_cd      OPTIONS(description="Currency Code"),
 status_nm         OPTIONS(description="Current status of the campaign (e.g., Active, Paused)"),
 planned_impression_nbr OPTIONS(description="Planned impression count for the campaign"),
 objective_dsc         OPTIONS(description="The objective of the campaign (e.g., BRAND_AWARENESS, LEAD_GENERATION)"),
 source_created_ts     OPTIONS(description="Timestamp when the campaign was created in the source system"),
 source_last_modified_ts   OPTIONS(description="The date and time record was modified"),
 dw_create_ts              OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts         OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind     OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm       OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm       OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind    OPTIONS(description="set to yes when the current record is deleted,  the Last Effective date on this record is still set to be  current date -1 d.")
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS 
SELECT
 campaign_id               ,
 source_application_cd     ,
 Dw_first_effective_ts     ,
 Dw_last_effective_ts      ,
 advertiser_id             ,
 campaign_nm           ,
 start_ts              ,
 end_ts                ,
 total_budget_amt , 
 currency_cd      ,
 status_nm             ,
 planned_impression_nbr ,
 objective_dsc         ,
 source_created_ts     ,
 source_last_modified_ts  ,
 dw_create_ts               ,
 dw_last_update_ts          ,
 dw_logical_delete_ind      ,
 dw_source_create_nm        ,
 dw_source_update_nm        ,
 dw_current_version_ind     
FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_campaign`;

