CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.D1_PLATFORM_MEDIA_PLACEMENT`
(
	PLATFORM_MEDIA_PLACEMENT_D1_SK   OPTIONS(DESCRIPTION = "Surrogate key for creative unit Placement  – uniquely identifies each creative ad placement." ),
	PLATFORM_CD   OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values: Meta/Pinterest/etc." ),
	PLATFORM_MEDIA_PLACEMENT_ID   OPTIONS(DESCRIPTION = "Placement ID trafficked in placement mirroring social ad One Placement Id can have multiple Ad_UNIT_ID 's" ),
	PLATFORM_MEDIA_PLACEMENT_NM   OPTIONS(DESCRIPTION = "Name For Placement ID trafficked in placement mirroring social ad" ),
	PLATFORM_MEDIA_PAGE_TYPE_CD   OPTIONS(DESCRIPTION = "Its the type, placement Id tied to. It tells  the type/category of page that is tied to ad units . Page tpe can be Search page/ checkout/ home page/product Detail page/deal page etc."),
	DW_CREATE_TS   OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS   OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
    PLATFORM_MEDIA_PLACEMENT_D1_SK,
	PLATFORM_CD,
	PLATFORM_MEDIA_PLACEMENT_ID,
	PLATFORM_MEDIA_PLACEMENT_NM,
	PLATFORM_MEDIA_PAGE_TYPE_CD,
	DW_CREATE_TS,
	DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_PLACEMENT`
