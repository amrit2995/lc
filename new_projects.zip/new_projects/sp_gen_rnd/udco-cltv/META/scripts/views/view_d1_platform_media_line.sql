CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.D1_PLATFORM_MEDIA_LINE`
(
  PLATFORM_MEDIA_LINE_D1_SK OPTIONS(DESCRIPTION = 'Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns.'),
  PLATFORM_CD OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values: Meta/Pinterest/etc."),
  PLATFORM_LINE_ITEM_ID OPTIONS(DESCRIPTION = "Unique line item id under a campaign. A campaign may or may not have Line item. Also a campaign can have multiple line items. Line items can have multiple creatives associated to it."),
  PLATFORM_LINE_ITEM_NM OPTIONS(DESCRIPTION = "Name for Unique line item id under a campaign"),
  PLATFORM_LINE_ITEM_START_DT OPTIONS(DESCRIPTION = "Start date for the individual Line Item within the Campaign"),
  PLATFORM_LINE_ITEM_END_DT OPTIONS(DESCRIPTION = "End date for the individual Line Item within the Campaign"),
  PLATFORM_LINE_ITEM_BUDGET_AMT OPTIONS(DESCRIPTION = "Budget for the individual Tactic(L2) within the Hub Campaign"),
  PLATFORM_LINE_ITEM_CPM_AMT  OPTIONS(DESCRIPTION = "Negotiated cost per 1000 impressions(CPM) rate charged to CPG. Note: For off-site, calculate media cost charged to the CPG using cpg_cpm*impressions/1000(subject to billing caps based on agreed upon delivery)"),
  PLATFORM_LINE_CHANNEL_CD OPTIONS(DESCRIPTION = "SUB Type. This column will have one of the following values at Line item level: DV360,DV360 Offsite Display - Standard Shopper,DV360 Video,Digital Instore,FAGE_Back to School Tubs_24,FB Story Ads/IG Story Ads - No Carousel,FB/IG Story Ads FB/IG Feed Images,FB/IG Story Ads FB/IG Feed Images (No Carousel),FBIG,FBIG Carousel & Product Ad,FBIG Premium Carousel & Product Ad,FBIG Product Ad,FBIG Video,Facebook & Instagram,Fees,On-Site Display,On-Site SPA,Pinterest,Pinterest Premium,Pinterest Video,Premium Carousel & Product Ad,Purchaser Extension,RMN Display,RMN Display Non-Premium,RMN,Display Premium,SM,Social,Social Media,YouTube"),
  PLATFORM_LINE_AUDIENCE_TXT OPTIONS(DESCRIPTION = "Target Audience for the Line Item within the Campaign"),
  DW_CREATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
  DW_LAST_UPDATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
  PLATFORM_MEDIA_LINE_D1_SK,
  PLATFORM_CD,
  PLATFORM_LINE_ITEM_ID,
  PLATFORM_LINE_ITEM_NM,
  PLATFORM_LINE_ITEM_START_DT,
  PLATFORM_LINE_ITEM_END_DT,
  PLATFORM_LINE_ITEM_BUDGET_AMT,
  PLATFORM_LINE_ITEM_CPM_AMT,
  PLATFORM_LINE_CHANNEL_CD,
  PLATFORM_LINE_AUDIENCE_TXT,
  DW_CREATE_TS,
  DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_LINE`