CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.D1_AD_MEDIA_PLATFORM`
(
	AD_MEDIA_PLATFORM_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations"),
	PLATFORM_CD OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values:Meta/Pinterest/etc"),
	PLATFORM_PROMOTIONAL_CHANNEL_CD OPTIONS(DESCRIPTION = "Type of advertisement. This column will have one of the following values: Social/On-Site/Display/etc"),
	DW_CREATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
    AD_MEDIA_PLATFORM_D1_SK,
	PLATFORM_CD,
	PLATFORM_PROMOTIONAL_CHANNEL_CD,
	DW_CREATE_TS,
	DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM`