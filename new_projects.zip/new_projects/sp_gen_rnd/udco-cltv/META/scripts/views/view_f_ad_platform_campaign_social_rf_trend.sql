CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.F_AD_PLATFORM_CAMPAIGN_SOCIAL_RF_TREND`
(
	PERFORMANCE_DAY_ID  OPTIONS(DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101" ),
	PLATFORM_ADVERTISER_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
	PLATFORM_MEDIA_CAMPAIGN_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for platform media campaign – uniquely identifies each campaign per platform." ),
	AD_MEDIA_PLATFORM_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
	AD_MEDIA_CAMPAIGN_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system." ),
	AD_MEDIA_OPPORTUNITY_D1_SK  OPTIONS(DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system." ),
	CUMULATIVE_AD_CAMPAIGN_REACH_CNT  OPTIONS(DESCRIPTION = "Cumulative Count of audience exposed to campaign" ),
	CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT  OPTIONS(DESCRIPTION = "Cumulative Count of ad views for a campaign" ),
	DW_CREATE_TS ,
	DW_LAST_UPDATE_TS 
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
    PERFORMANCE_DAY_ID,
    PLATFORM_ADVERTISER_D1_SK,
    PLATFORM_MEDIA_CAMPAIGN_D1_SK,
    AD_MEDIA_PLATFORM_D1_SK,
    AD_MEDIA_CAMPAIGN_D1_SK,
    AD_MEDIA_OPPORTUNITY_D1_SK,
    CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    DW_CREATE_TS,
    DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_CAMPAIGN_SOCIAL_RF_TREND`
