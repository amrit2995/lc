CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.F_AD_PLATFORM_CAMPAIGN_RF_TREND` (
        PERFORMANCE_DAY_ID OPTIONS(
            DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101"
        ),
        PLATFORM_ADVERTISER_D1_SK OPTIONS(
            DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."
        ),
        AD_MEDIA_PLATFORM_D1_SK OPTIONS(
            DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations. its a composite key with PLATFORM_CD + PLATFORM_PROMOTIONAL_CHANNEL_CD"
        ),
        AD_MEDIA_CAMPAIGN_D1_SK OPTIONS(
            DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system."
        ),
        PLATFORM_MEDIA_CAMPAIGN_D1_SK OPTIONS(
            DESCRIPTION = "Surrogate key for platform media campaign – uniquely identifies each campaign per platform."
        ),
        CUMULATIVE_AD_CAMPAIGN_REACH_CNT OPTIONS(
            DESCRIPTION = "Count of audience exposed to campaign"
        ),
        CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT OPTIONS(DESCRIPTION = "Count of ad views "),
        CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT OPTIONS(
            DESCRIPTION = "Total number of clicks generated from users who were exposed to the campaign"
        ),
        CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT OPTIONS(
            DESCRIPTION = "Average number of impressions per unique user reached by the campaign"
        ),
        CUMULATIVE_CLICK_CNT OPTIONS(DESCRIPTION = "Count of clicks on the ad"),
        CUMULATIVE_IMPRESSION_CNT OPTIONS(DESCRIPTION = "Count of ad views "),
        CUMULATIVE_MEASUREMENT_REVENUE_AMT OPTIONS(
            DESCRIPTION = "Aggregation of online, offline, and mobile revenue"
        ),
        CUMULATIVE_CPG_MEDIA_SPEND_AMT OPTIONS(
            DESCRIPTION = "This reflects the amount charged by <<cocmp>> to the CPG."
        ),
        DW_CREATE_TS,
        DW_LAST_UPDATE_TS
    ) OPTIONS (
        labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
    ) AS
SELECT PERFORMANCE_DAY_ID,
    PLATFORM_ADVERTISER_D1_SK,
    AD_MEDIA_PLATFORM_D1_SK,
    AD_MEDIA_CAMPAIGN_D1_SK,
    PLATFORM_MEDIA_CAMPAIGN_D1_SK,
    CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    CUMULATIVE_CLICK_CNT,
    CUMULATIVE_IMPRESSION_CNT,
    CUMULATIVE_MEASUREMENT_REVENUE_AMT,
    CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    DW_CREATE_TS,
    DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_CAMPAIGN_RF_TREND`