CREATE or REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.line_item_creative` 
(
 line_item_id               OPTIONS(description="Unique identifier of the campaign line item"),
 creative_id                  OPTIONS(description="Unique identifier of the creative associated with the line item") ,
 source_application_cd           OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts     OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts      OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 ad_id                    OPTIONS(description="Unique identifier of the ad associated with the creative"),
 campaign_id                      OPTIONS(description="Unique identifier of the campaign associated with the creative"),
 advertiser_id                    OPTIONS(description="Unique identifier of the advertiser associated with the creative"),
 status_nm                        OPTIONS(description="Current status of the line item (e.g., Active, Paused)"),
 source_created_ts                  OPTIONS(description="Timestamp when the campaign was created in the source system"),
 source_last_modified_ts          OPTIONS(description="The date and time record was modified"),
 dw_create_ts                    OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts                OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind          OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm                OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm              OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind       OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be current date -1 d.")
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS 
SELECT
 line_item_id               ,
 creative_id                ,
 source_application_cd      ,
 Dw_first_effective_ts      ,
 Dw_last_effective_ts       ,
 ad_id                      ,
 campaign_id                ,
 advertiser_id              ,
 status_nm                   ,
 source_created_ts          ,
 source_last_modified_ts    ,
 dw_create_ts                      ,
 dw_last_update_ts                 ,
 dw_logical_delete_ind             ,
 dw_source_create_nm               ,
 dw_source_update_nm               ,
 dw_current_version_ind            
FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.line_item_creative`;


