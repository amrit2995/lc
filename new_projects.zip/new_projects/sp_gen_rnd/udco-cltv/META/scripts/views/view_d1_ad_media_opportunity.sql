CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.D1_AD_MEDIA_OPPORTUNITY`
(
  AD_MEDIA_OPPORTUNITY_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for media opportunity relationship – ensures uniqueness for each opportunity."),
  AD_MEDIA_OPPORTUNITY_ID OPTIONS(DESCRIPTION = "Media opportunity ID."),
  AD_MEDIA_OPPORTUNITY_NM OPTIONS(DESCRIPTION = "Media opportunity Name."),
  AD_MEDIA_PARENT_OPPORTUNITY_ID OPTIONS(DESCRIPTION = "Media parent opportunity ID."),
  AD_CPG_ACCOUNT_ID OPTIONS(DESCRIPTION = "CPG account ID, same as CPG in vendor CMS."),
  IS_PARENT_OPPORTUNITY_IND OPTIONS(DESCRIPTION = "Parent opportunity indicator."),
  IS_COBRANDED_IND OPTIONS(DESCRIPTION = "Flag to tell if the Campaign is a joined campaign and is for Co BRAND by partners" ),
  DW_CREATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
  DW_LAST_UPDATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
  AD_MEDIA_OPPORTUNITY_D1_SK,
  AD_MEDIA_OPPORTUNITY_ID,
  AD_MEDIA_OPPORTUNITY_NM,
  AD_MEDIA_PARENT_OPPORTUNITY_ID,
  AD_CPG_ACCOUNT_ID,
  IS_PARENT_OPPORTUNITY_IND,
  IS_COBRANDED_IND,
  DW_CREATE_TS,
  DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_OPPORTUNITY`;