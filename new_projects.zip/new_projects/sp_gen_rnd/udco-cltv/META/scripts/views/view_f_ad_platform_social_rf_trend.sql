CREATE OR REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.F_AD_PLATFORM_SOCIAL_RF_TREND`
(
  PERFORMANCE_DAY_ID OPTIONS(DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101"),
  PLATFORM_MEDIA_ADVERTISEMENT_D1_SK OPTIONS(DESCRIPTION = "Surrogate key for creative unit - uniquely identifies each creative ad placement."),
  CUMULATIVE_AD_UNIT_REACH_CNT OPTIONS(DESCRIPTION = "Cumulative Count of audience exposed to campaign at Unit Level"),
  CUMULATIVE_AD_UNIT_REACH_IMPRESSION_CNT OPTIONS(DESCRIPTION = "Cumulative Count of ad views at Ad unit Level"),
  DW_CREATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
  DW_LAST_UPDATE_TS OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS
SELECT
  PERFORMANCE_DAY_ID,
	PLATFORM_MEDIA_ADVERTISEMENT_D1_SK,
	CUMULATIVE_AD_UNIT_REACH_CNT,
	CUMULATIVE_AD_UNIT_REACH_IMPRESSION_CNT,
	DW_CREATE_TS,
	DW_LAST_UPDATE_TS
FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_SOCIAL_RF_TREND`;
