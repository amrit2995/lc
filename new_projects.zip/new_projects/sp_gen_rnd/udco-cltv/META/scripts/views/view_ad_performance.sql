CREATE or REPLACE VIEW `<<CLTV_VIEW_PROJECT_ID>>.<<VIEW_DATASET>>.ad_performance`
(
 ad_id                      OPTIONS(description="Unique ad or creative id"),
 performance_dt             OPTIONS(description="Performance date"),
 publisher_platform_nm      OPTIONS(description="Ad platform name (e.g., Facebook, Instagram)"),
 source_application_cd      OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts      OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts       OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 account_id                 OPTIONS(description="Ad Account Id"),
 line_item_id               OPTIONS(description="Ad line item id"),
 campaign_id                OPTIONS(description="Ad campaign id"),
 impressions_cnt            OPTIONS(description="Total impression"),
 clicks_cnt                 OPTIONS(description="Total click-throughs"),
 platform_media_spend_amt   OPTIONS(description="Spend in dollars") ,
 dw_create_ts               OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind      OPTIONS(description="Set to True when we receive a delete record for the primary key"),
 dw_source_create_nm        OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm        OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind     OPTIONS(description="set to yes when the current record is deleted")
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')])
AS 
SELECT
 ad_id                    ,
 performance_dt         ,
 publisher_platform_nm    ,
 source_application_cd     ,
 dw_first_effective_ts   ,
 dw_last_effective_ts   ,
 account_id              ,
 line_item_id             ,
 campaign_id             ,
 impressions_cnt         ,
 clicks_cnt              ,
 platform_media_spend_amt               ,
 dw_create_ts                      ,
 dw_last_update_ts                 ,
 dw_logical_delete_ind             ,
 dw_source_create_nm               ,
 dw_source_update_nm               ,
 dw_current_version_ind     
FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_performance`;