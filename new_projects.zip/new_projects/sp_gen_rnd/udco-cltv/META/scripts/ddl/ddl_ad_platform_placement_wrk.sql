CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_platform_placement_wrk`
(
 placement_id           STRING              ,
 source_application_cd  STRING              ,
 dw_first_effective_ts  TIMESTAMP           ,
 dw_last_effective_ts   TIMESTAMP           ,
 placement_nm           STRING              ,
 source_created_ts      TIMESTAMP           ,
 source_last_modified_ts      TIMESTAMP   ,
 dw_logical_delete_ind  BOOLEAN			   ,
 dml_type               STRING 
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);