DROP TABLE IF EXISTS `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_advertiser`;

CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_advertiser`
(
 advertiser_id         STRING  NOT NULL  OPTIONS(description="Unique identifier of the advertiser across ad platforms"),
 source_application_cd  STRING  NOT NULL OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts  TIMESTAMP  NOT NULL              OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts   TIMESTAMP  NOT NULL               OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 currency_cd        STRING            OPTIONS(description="The currency code used by the advertiser (e.g., USD, EUR)"),
 advertiser_nm         STRING            OPTIONS(description="Name of the advertiser or brand"),
 account_status_nm     STRING            OPTIONS(description="Current status of the advertiser account (e.g., Active, Disabled)"),
 disable_reason_txt     STRING            OPTIONS(description="Reason for disabling the advertiser account, if applicable"),
 source_created_ts  TIMESTAMP      OPTIONS(description="The date and time record was created"),
 source_last_modified_ts  TIMESTAMP      OPTIONS(description="The date and time record was modified"),
 dw_create_ts                      TIMESTAMP          OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts                 TIMESTAMP          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind             BOOL            OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm               STRING             OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm               STRING             OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind            BOOL             OPTIONS(description="Set to True to mark the latest record for the primary keys, else False"),
 PRIMARY KEY (advertiser_id, source_application_cd, Dw_first_effective_ts, Dw_last_effective_ts) not enforced
) 
PARTITION BY  DATE(dw_last_update_ts)
CLUSTER BY    advertiser_id, source_application_cd
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);