CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_creative` 
(
 creative_id                STRING NOT NULL    OPTIONS(description="Unique Identifier for the creative."),
 source_application_cd      STRING  NOT NULL   OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts      TIMESTAMP NOT NULL OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts       TIMESTAMP NOT NULL OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 advertiser_id              STRING             OPTIONS(description="Descriptive name of the placement(eg.HomePage Top Banner,Pre-Roll video slot)"),
 creative_nm                STRING             OPTIONS(description="Descriptive name of the creative."),
 creative_type_nm           STRING             OPTIONS(description="creative type name"),
 creative_requested_sz      STRING             OPTIONS(description="Size the creative was designed for(eg: 300*250)"),
 creative_delivered_sz      STRING             OPTIONS(description="Actual size used in delivery,after possible transformations"),
 creative_version_nbr       STRING             OPTIONS(description="Version number to track updates or iterations of the creative asset"),
 source_created_ts          TIMESTAMP          OPTIONS(description="Timestamp when the campaign was created in the source system"),
 source_last_modified_ts    TIMESTAMP          OPTIONS(description="The date and time record was modified"),
 dw_create_ts               TIMESTAMP          OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts          TIMESTAMP          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind      BOOL               OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm        STRING             OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm        STRING             OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind     BOOL               OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be current date -1 d."),
 PRIMARY KEY (creative_id, source_application_cd, dw_first_effective_ts, dw_last_effective_ts) not enforced
)
PARTITION BY  DATE(dw_last_update_ts)
CLUSTER BY    creative_id,creative_type_nm
OPTIONS(
  description="Represents a specific advertisement asset(image,video,HTML,etc..)submitted for delivery).",
  labels = [('appcode','uddi'),('bodname','gammetadata'),('domainname','collect'),('environment','<<ENV>>')]);



