CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_action_reaction_wrk`
(
 action_reaction_type_id      NUMERIC ,
 ad_id                        STRING  ,
 action_reaction_dt           DATE    ,
 source_application_cd        STRING  ,
 DW_FIRST_EFFECTIVE_TS       TIMESTAMP ,
 DW_LAST_EFFECTIVE_TS        TIMESTAMP ,
 value_nbr                    FLOAT64 ,
 DML_TYPE STRING
)

OPTIONS(
  description="Represents reactions (such as like, love, wow, etc.) to advertisements, capturing the type of reaction, the ad, the date of the reaction, and associated metrics. Each record reflects a specific reaction event for an ad on a given day and platform.",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);