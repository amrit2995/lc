DROP TABLE IF EXISTS `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_line_item`;

CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_line_item` 
(
 line_item_id           STRING    NOT NULL     OPTIONS(description="Unique identifier of the line item in the ad platform"),
 source_application_cd  STRING    NOT NULL     OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts  TIMESTAMP NOT NULL     OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts   TIMESTAMP NOT NULL     OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 campaign_id            STRING    NOT NULL     OPTIONS(description="Foreign key to the campaign that owns this line item"),
 line_item_type_nm      STRING                 OPTIONS(description="Type name(HOUSE,NETWORK,STANDARD,AD_EXCHANGE,PRICE_PRIORITY,SPONSORSHIP)"),
 line_item_nm           STRING                 OPTIONS(description="Name of the line item as per source"),
 line_item_short_nm     STRING                 OPTIONS(description="Short name of the line item as per source"),
 line_item_budget_amt   NUMERIC(31,2)                OPTIONS(description="Total budget allocated to this line item"),
 status_nm              STRING                 OPTIONS(description="Current status of the line item (e.g., Active, Paused)"), 
 start_ts               TIMESTAMP              OPTIONS(description="Start date of the line item"),
 end_ts                 TIMESTAMP              OPTIONS(description="End date of the line item"),
 audience_nm            STRING                 OPTIONS(description="Target audience name for the line item"),
 ad_cost_type_cd        STRING                 OPTIONS(description="Type of cost model (e.g., CPM, CPC)"), 
 ad_cost_amt            NUMERIC(14,2)          OPTIONS(description="Cost value per unit (based on ad cost type)"),
 daily_budget_amt       NUMERIC(14,2)                OPTIONS(description="Daily budget allocated to this line item"),
 expected_daily_spend_amt NUMERIC(14,2)              OPTIONS(description="Expected daily spend amount for this line item"),
 Units_bought_cnt       INT64                  OPTIONS(description="Number of units bought"),
 planned_impression_cnt INT64                  OPTIONS(description="Planned impression count for the line item"),
 source_created_ts      TIMESTAMP              OPTIONS(description="Timestamp when the campaign was created in the source system"),
 source_last_modified_ts  TIMESTAMP            OPTIONS(description="The date and time record was modified"),
 dw_create_ts           TIMESTAMP              OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts      TIMESTAMP              OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind  BOOL                   OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm    STRING                 OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm    STRING                 OPTIONS(description="The data source name of this update or delete."),
dw_current_version_ind  BOOL                   OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be  current date -1 d."),
 PRIMARY KEY (line_item_id, source_application_cd, dw_first_effective_ts, dw_last_effective_ts) not enforced
)
PARTITION BY  DATE(dw_last_update_ts)
CLUSTER BY    line_item_id,campaign_id
OPTIONS(
  description="Represents a subcomponent of a campaign defining specific tactics such as audience targeting, creatives, budget allocations, and scheduling. Each line item is typically executed as a unit of ad delivery (eg: Meta Ad Set or Google Line Item).",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);