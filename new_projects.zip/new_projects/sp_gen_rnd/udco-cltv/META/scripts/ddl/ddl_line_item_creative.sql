DROP TABLE IF EXISTS `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.line_item_creative`;

CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.line_item_creative` 
(
 ad_id        STRING   NOT NULL                    OPTIONS(description="Unique identifier of the ad associated with the creative"),
 line_item_id          STRING  NOT NULL           OPTIONS(description="Unique identifier of the campaign line item"),
 creative_id           STRING  NOT NULL           OPTIONS(description="Unique identifier of the creative associated with the line item") ,
 source_application_cd  STRING  NOT NULL            OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts  TIMESTAMP NOT NULL     OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts   TIMESTAMP NOT NULL     OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 campaign_id        STRING                       OPTIONS(description="Unique identifier of the campaign associated with the creative"),
 advertiser_id        STRING                       OPTIONS(description="Unique identifier of the advertiser associated with the creative"),
 status_nm             STRING                       OPTIONS(description="Current status of the line item (e.g., Active, Paused)"),
 source_created_ts     TIMESTAMP                      OPTIONS(description="Timestamp when the campaign was created in the source system"),
 source_last_modified_ts  TIMESTAMP                   OPTIONS(description="The date and time record was modified"),
 dw_create_ts                      TIMESTAMP          OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts                 TIMESTAMP          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind             BOOL            OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm               STRING             OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm               STRING             OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind     BOOL       OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be current date -1 d."),
 PRIMARY KEY (ad_id, line_item_id, creative_id, source_application_cd, Dw_first_effective_ts, Dw_last_effective_ts) not enforced
)
PARTITION BY  DATE(dw_last_update_ts)
CLUSTER BY    ad_id,line_item_id,creative_id
OPTIONS(
  description="Associative table mapping of each ad delivery line_item to the corresponding creative assets used in the campaign.",
  labels = [('appcode','uddi'),('bodname','gammetadata'),('domainname','collect'),('environment','<<ENV>>')]);



