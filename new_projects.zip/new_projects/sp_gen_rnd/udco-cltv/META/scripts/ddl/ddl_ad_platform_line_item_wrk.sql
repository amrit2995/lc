CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_platform_line_item_wrk`
(
 LINE_ITEM_ID           STRING,
 SOURCE_APPLICATION_CD  STRING,
 DW_FIRST_EFFECTIVE_TS  TIMESTAMP,
 DW_LAST_EFFECTIVE_TS   TIMESTAMP,
 CAMPAIGN_ID 			STRING,
 LINE_ITEM_TYPE_NM		STRING,
 line_item_nm           STRING,
 line_item_short_nm     STRING,
 line_item_budget_amt   NUMERIC(31,2),
 status_nm              STRING,
 start_ts               TIMESTAMP,
 end_ts                 TIMESTAMP,
 audience_nm            STRING,
 ad_cost_type_cd        STRING,
 ad_cost_amt            NUMERIC(14,2),
 daily_budget_amt       NUMERIC(14,2),
 expected_daily_spend_amt NUMERIC(14,2),
 Units_bought_cnt       INT64,
 planned_impression_cnt INT64,
 SOURCE_CREATED_TS      TIMESTAMP,
 SOURCE_LAST_MODIFIED_TS  TIMESTAMP,
 DW_LOGICAL_DELETE_IND  BOOLEAN,
 DW_CURRENT_VERSION_IND BOOLEAN
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);