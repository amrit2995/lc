CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_video_action_wrk`
(
video_action_type_id   NUMERIC   ,
 ad_id                  STRING   ,
 publisher_platform_nm  STRING  ,
 video_action_dt        DATE  ,
 source_application_cd  STRING  ,
 dw_first_effective_ts  TIMESTAMP,
 dw_last_effective_ts   TIMESTAMP,
 value_nbr              FLOAT64  ,
 DML_TYPE               STRING
 
)

OPTIONS(
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);