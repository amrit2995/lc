CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.line_item_creative_wrk`
(
 line_item_id               STRING             ,
 creative_id                STRING             ,
 source_application_cd      STRING             ,
 ad_id                      STRING             ,
 dw_first_effective_ts      TIMESTAMP          ,
 dw_last_effective_ts       TIMESTAMP          ,
 campaign_id                STRING             ,
 advertiser_id              STRING             ,
 status_nm                  STRING             ,
 source_created_ts          TIMESTAMP          ,
 source_last_modified_ts    TIMESTAMP          ,
 dw_logical_delete_ind      BOOLEAN            ,
 dw_current_version_ind     BOOLEAN  
)
OPTIONS (labels = [('appcode','uddi'),('bodname','gammetadata'),('domainname','collect'),('environment','<<ENV>>')]);
