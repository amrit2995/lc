CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_platform_creative_wrk`
(
 creative_id            STRING      ,
 source_application_cd  STRING      ,
 dw_first_effective_ts  TIMESTAMP   ,
 dw_last_effective_ts   TIMESTAMP   ,
 advertiser_id          STRING      ,
 creative_nm            STRING      ,
 creative_type_nm       STRING      ,
 creative_requested_sz  STRING      ,
 creative_delivered_sz  STRING      ,
 creative_version_nbr   STRING      ,
 source_created_ts      TIMESTAMP   ,
 source_last_modified_ts TIMESTAMP  ,
 dw_logical_delete_ind  BOOLEAN		,
 DW_CURRENT_VERSION_IND BOOLEAN     ,
 rn                     INT64       ,
 DML_TYPE               STRING
)
OPTIONS (labels = [('appcode','uddi'),('bodname','gammetadata'),('domainname','collect'),('environment','<<ENV>>')]);
