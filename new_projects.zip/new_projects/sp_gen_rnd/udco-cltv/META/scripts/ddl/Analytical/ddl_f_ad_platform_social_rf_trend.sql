CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_SOCIAL_RF_TREND`
(
  PERFORMANCE_DAY_ID NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101"),
  PLATFORM_MEDIA_ADVERTISEMENT_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for creative unit - uniquely identifies each creative ad placement."),
  CUMULATIVE_AD_UNIT_REACH_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Cumulative Count of audience exposed to campaign at Unit Level"),
  CUMULATIVE_AD_UNIT_REACH_IMPRESSION_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Cumulative Count of ad views at Ad unit Level"),
  DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
  DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS(
	DESCRIPTION = "This Fact Table holds the cumulative count of Reach and Impressions for a Ad Unit of a Campaign.",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);
