CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE`
(
	PLATFORM_MEDIA_CREATIVE_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns."),
	PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values:Meta/Pinterest/etc."),
	PLATFORM_MEDIA_CREATIVE_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Unique identifier for each creative. One campaign can have multiple Line items and each Line item can have multiple Creatives. A campaign may or may not have line item. In second case when campaign doesn't have Line item then a Creative Id will be associated with Campaign Id else with Line item id and then campaign Id in Hierarchy." ),
	PLATFORM_MEDIA_CREATIVE_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Creative Name"),
	PLATFORM_MEDIA_CREATIVE_SZ STRING NOT NULL OPTIONS(DESCRIPTION = "Creative Size. Meta/Pinterest have a 1:1 relationship between the Ad and Creative Size, so this is derived from the mapping table"),
	PLATFORM_MEDIA_CREATIVE_TYPE_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Creative Type"),
	DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS(
	DESCRIPTION = "This table manages all the advertising content - videos, images, interactive displays, and other media that customers will see. It stores technical details like file names, media types, duration, dimensions, file size, and creation dates. Each creative asset is linked to specific LINE ITEM in a campaigns.",
    labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);