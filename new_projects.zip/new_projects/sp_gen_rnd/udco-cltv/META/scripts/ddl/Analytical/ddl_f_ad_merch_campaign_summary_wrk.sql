CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_MERCH_CAMPAIGN_SUMMARY_WRK`
(
	PERFORMANCE_DAY_ID 					NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101" ),
	AD_MEDIA_PLATFORM_D1_SK 			NUMERIC OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship - ensures uniqueness across all advertiser-platform combinations" ),
	AD_MEDIA_CAMPAIGN_D1_SK 			NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for campaign - uniquely identifies each advertising campaign record in the system" ),
	PLATFORM_MEDIA_CAMPAIGN_D1_SK 		NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for platform media campaign - uniquely identifies each campaign per platform" ),
	AD_MEDIA_CAMPAIGN_LINE_D1_SK 		NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for campaign line item - uniquely identifies each line item record" ),
	PLATFORM_MEDIA_LINE_D1_SK 			NUMERIC OPTIONS(DESCRIPTION = "Surrogate key for creative asset - uniquely identifies each creative used in platform campaigns" ),
	TOTAL_IMPRESSION_CNT 				NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Sum of daily platform_impressions within the attribution window by campaign x tactics(line item) x platform x type. For GAM, de-duped then averaged per day before summing" ),
	CPG_MEDIA_SPEND_AMT 				NUMERIC(14,2) NOT NULL OPTIONS(DESCRIPTION = "Sum of daily calculated_cpg_media_spend over the window at campaign x tactics(line item) x platform x type. For GAM, daily values are averaged after de-duplication then summed across days" ),
	TOTAL_TRANSACTION_CNT 				NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Sum of daily measurement_total_transactions over the window at campaign x tactics(line item) x platform x type" ),
	TOTAL_REVENUE_AMT 					NUMERIC(14,2) NOT NULL OPTIONS(DESCRIPTION = "Sum of daily measurement_total_revenue over the window at campaign x tactics(line item) x platform x type" ),
	NEW_BRAND_BUYER_CNT 				NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Count of converted buyers in segment 'new_brand_buyer' for campaign x platform x type" ),
	REPEAT_BRAND_BUYER_CNT 				NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Count of converted buyers in segment 'repeat_brand_buyer' for campaign x platform x type" ),
	LOYAL_BRAND_BUYER_CNT 				NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Count of converted buyers in segment 'Loyal_brand_buyer' for campaign x platform x type" ),
	LAPSED_BRAND_BUYER_CNT 				NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Count of converted buyers in segment 'lapsed_brand_buyer' for campaign x platform x type" ),
	DW_CREATE_TS 						TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "The timestamp the record was inserted" ),
	DW_LAST_UPDATE_TS 					TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "When a record is updated, this would be the current timestamp" )
)
OPTIONS(
	DESCRIPTION = "F_AD_MERCH_CAMPAIGN_SUMMARY is the central fact table that captures all end-of-flight KPIs and buyer segment counts at Campaign x Tactics x Platform grain"
	,labels = [('appcode','uddi'),('bodname','pinterest'),('domainname','collect'),('environment','<<ENV>>')]
);
