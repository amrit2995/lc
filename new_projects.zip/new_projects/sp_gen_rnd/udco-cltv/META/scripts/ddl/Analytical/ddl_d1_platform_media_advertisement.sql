CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_ADVERTISEMENT`
(
  PLATFORM_MEDIA_ADVERTISEMENT_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for media advertisement relationship – ensures uniqueness for each advertisement."),
  PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values:Meta/Pinterest/etc."),
  PLATFORM_MEDIA_ADVERTISEMENT_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Media advertisement ID."),
  PLATFORM_MEDIA_ADVERTISEMENT_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Media advertisement Name."),
  PLATFORM_AD_CREATIVE_VERSION_CD STRING NOT NULL OPTIONS(DESCRIPTION = "The name of the creative version input to platform"),
  DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
  DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS(
	DESCRIPTION = "This Table stores the mapping of media advertisement.",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);