CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN_LINE`
(
	AD_MEDIA_CAMPAIGN_LINE_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for campaign line itemuniquely identifies each line item record." ),
	AD_MEDIA_LINE_ID STRING NOT NULL OPTIONS(DESCRIPTION = "AMC Hub Tactic ID within the broader Hub Campaign ID" ),
	AD_LINE_ID STRING NOT NULL OPTIONS(DESCRIPTION = "AMC Hub Tactic ID within the broader Hub Campaign ID" ),
	AD_LINE_END_DT DATE NOT NULL OPTIONS(DESCRIPTION = "End date for the individual Tactic(L2) within the Hub Campaign" ),
	AD_LINE_START_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Start date for the individual Tactic(L2) within the Hub Campaign" ),
	AD_LINE_ITEM_PLND_IMPRESSION_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Planned Impressions for the individual Tactic(L2) within the Hub Campaign" ),
	AD_LINE_ITEM_CPM_AMT  NUMERIC(14,2) NOT NULL OPTIONS(DESCRIPTION = "Negotiated cost per 1000 impressions(CPM) rate charged to CPG. Note: For off-site, calculate media cost charged to the CPG using cpg_cpm*impressions/1000(subject to billing caps based on agreed upon delivery)" ),
	AD_LINE_ITEM_BUDGT_AMT  NUMERIC(14,2) NOT NULL OPTIONS(DESCRIPTION = "Budget for the individual Tactic(L2) within the Hub Campaign" ),
	AD_LINE_TACTIC_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Marketing tactic used" ),
	AD_LINE_AUDIENCE_TXT STRING NOT NULL OPTIONS(DESCRIPTION = "Audience/Segment targeted by Media" ),
	AD_LINE_BILLING_CATEGORY_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Billing Category Method. example- Fixed Price, MG, CPD,CPM" ),
	AD_LINE_CHANNEL_CD STRING NOT NULL OPTIONS(DESCRIPTION = "SUB Type . This column will have one of the following values at Line item level: 	DV360,DV360 Offsite Display - Standard Shopper,DV360 Video,Digital Instore,FAGE_Back to School Tubs_24,	FB Story Ads/ IG Story Ads - No Carousel,FB/IG Story Ads FB/IG Feed Images,	FBIG FBIG Carousel & Product Ad FBIG Premium Carousel & Product Ad , FBIG Product Ad , FBIG Video	Facebook & Instagram, Fees,1,On-Site Display,On-Site SPA,Pinterest,Pinterest Premium,Pinterest Video ,SM Social, Social Media , YouTube "),
	DW_CREATE_TS TIMESTAMP NOT NULL	OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" ),
 	PRIMARY KEY (AD_MEDIA_CAMPAIGN_LINE_D1_SK) not enforced
) 
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);