CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_CAMPAIGN_SOCIAL_RF_TREND`
(
	PERFORMANCE_DAY_ID NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101" ),
	PLATFORM_ADVERTISER_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
	PLATFORM_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for platform media campaign – uniquely identifies each campaign per platform." ),
	AD_MEDIA_PLATFORM_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations." ),
	AD_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system." ),
	AD_MEDIA_OPPORTUNITY_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system." ),
	CUMULATIVE_AD_CAMPAIGN_REACH_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Cumulative Count of audience exposed to campaign" ),
	CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Cumulative Count of ad views for a campaign" ),
	DW_CREATE_TS TIMESTAMP NOT NULL,
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL
)
OPTIONS(
	DESCRIPTION = "This Fact Table holds the cumulative count of Reach and Impressions for a Campaign."
	,labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);
