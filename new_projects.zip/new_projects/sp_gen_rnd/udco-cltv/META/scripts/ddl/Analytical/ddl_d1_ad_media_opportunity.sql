CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_OPPORTUNITY`
(
  AD_MEDIA_OPPORTUNITY_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for media opportunity relationship – ensures uniqueness for each opportunity."),
  AD_MEDIA_OPPORTUNITY_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Media opportunity ID."),
  AD_MEDIA_OPPORTUNITY_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Media opportunity Name."),
  AD_MEDIA_PARENT_OPPORTUNITY_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Media parent opportunity ID."),
  AD_CPG_ACCOUNT_ID STRING NOT NULL OPTIONS(DESCRIPTION = "CPG account ID, same as CPG in vendor CMS."),
  IS_PARENT_OPPORTUNITY_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Parent opportunity indicator."),
  IS_COBRANDED_IND BOOLEAN NOT NULL OPTIONS(DESCRIPTION = "Flag to tell if the Campaign is a joined campaign and is for Co BRAND by partners" ),
  DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
  DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS(
	DESCRIPTION = "This Table stores the mapping of media opportunity.",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);