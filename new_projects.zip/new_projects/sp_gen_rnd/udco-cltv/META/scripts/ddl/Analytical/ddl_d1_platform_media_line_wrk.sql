CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_PLATFORM_MEDIA_LINE_WRK`
(
  PLATFORM_MEDIA_LINE_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = 'Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns.'),
  PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values: Meta/Pinterest/etc."),
  PLATFORM_LINE_ITEM_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Unique line item id under a campaign. A campaign may or may not have Line item. Also a campaign can have multiple line items. Line items can have multiple creatives associated to it."),
	PLATFORM_LINE_ITEM_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Name for Unique line item id under a campaign"),
	PLATFORM_LINE_ITEM_START_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Start date for the individual Line Item within the Campaign"),
	PLATFORM_LINE_ITEM_END_DT DATE NOT NULL OPTIONS(DESCRIPTION = "End date for the individual Line Item within the Campaign"),
  PLATFORM_LINE_ITEM_BUDGET_AMT NUMERIC(18,2) NOT NULL OPTIONS(DESCRIPTION = "Budget for the individual Tactic(L2) within the Hub Campaign"),
  PLATFORM_LINE_ITEM_CPM_AMT NUMERIC(14,2) NOT NULL OPTIONS(DESCRIPTION = "Negotiated cost per 1000 impressions(CPM) rate charged to CPG. Note: For off-site, calculate media cost charged to the CPG using cpg_cpm*impressions/1000(subject to billing caps based on agreed upon delivery)"),
  PLATFORM_LINE_CHANNEL_CD STRING NOT NULL OPTIONS(DESCRIPTION = "SUB Type. This column will have one of the following values at Line item level: DV360,DV360 Offsite Display - Standard Shopper,DV360 Video,Digital Instore,FAGE_Back to School Tubs_24,FB Story Ads/IG Story Ads - No Carousel,FB/IG Story Ads FB/IG Feed Images,FB/IG Story Ads FB/IG Feed Images (No Carousel),FBIG,FBIG Carousel & Product Ad,FBIG Premium Carousel & Product Ad,FBIG Product Ad,FBIG Video,Facebook & Instagram,Fees,On-Site Display,On-Site SPA,Pinterest,Pinterest Premium,Pinterest Video,Premium Carousel & Product Ad,Purchaser Extension,RMN Display,RMN Display Non-Premium,RMN,Display Premium,SM,Social,Social Media,YouTube"),
  PLATFORM_LINE_AUDIENCE_TXT    STRING NOT NULL OPTIONS(DESCRIPTION = "Target Audience for the Line Item within the Campaign")
)
OPTIONS(
	DESCRIPTION = "Staging table to handle delta.",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);
