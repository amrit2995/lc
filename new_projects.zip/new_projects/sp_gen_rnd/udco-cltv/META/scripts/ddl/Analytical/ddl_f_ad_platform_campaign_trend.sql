CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_CAMPAIGN_TREND` (
		PERFORMANCE_DAY_ID NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101"
		),
		PLATFORM_MEDIA_AD_UNIT_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for creative unit – uniquely identifies each creative ad placement."
		),
		PLATFORM_ADVERTISER_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."
		),
		AD_MEDIA_PLATFORM_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."
		),
		AD_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system."
		),
		AD_MEDIA_CAMPAIGN_LINE_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for campaign line item – uniquely identifies each line item record."
		),
		PLATFORM_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for platform media campaign – uniquely identifies each campaign per platform."
		),
		PLATFORM_MEDIA_LINE_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns."
		),
		PLATFORM_MEDIA_CREATIVE_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns."
		),
		PLATFORM_MEDIA_PLACEMENT_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for creative unit Placement  – uniquely identifies each creative ad placement."
		),
		AD_MEDIA_OPPORTUNITY_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for campaign – uniquely identifies each advertising campaign record in the system."
		),
		PLATFORM_MEDIA_ADVERTISEMENT_D1_SK NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Surrogate key for creative unit – uniquely identifies each creative ad placement."
		),
		TOTAL_CLICK_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Count of clicks on the ad"),
		TOTAL_IMPRESSION_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Impression count for Social Performance"
		),
		TOTAL_MEDIA_SPEND_AMT NUMERIC(14, 2) NOT NULL OPTIONS(
			DESCRIPTION = "This reflects the amount charged by <<cocmp>> to the CPG."
		),
		VIDEO_START_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Number of people who saw at least the start of the video."
		),
		VIDEO_25P_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Number of people who saw at least 25% of the video."
		),
		VIDEO_50P_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Number of people who saw at least 50% of the video."
		),
		VIDEO_75P_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Number of people who saw at least 75% of the video."
		),
		VIDEO_COMPLETE_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Number of people who saw at least 100% of the video."
		),
		POST_REACTION_ANGRY_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of 'Angry' reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_WOW_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of 'Wow' reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_LOVE_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of 'Love' reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_CARE_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of 'Care' reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_HAHA_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of 'Haha'(Laugh) reactions on Facebook. Not present on Instagram."
		),
		POST_REACTION_LIKE_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of likes across Meta properties. This metric is cumulative across Facebook & Instagram."
		),
		POST_REACTION_SAD_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of 'Sad' reactions across Meta properties. This metric is cumulative across Facebook & Instagram."
		),
		TOTAL_POST_ENGAGEMENT_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of engagements across Meta properties. Includes reactions, likes, comments, shares."
		),
		TOTAL_POST_COMMENT_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of comments across Meta properties. This metric is cumulative across Facebook & Instagram."
		),
		TOTAL_POST_REACTION_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of Reactions across Meta properties. This metric is cumulative across Facebook & Instagram."
		),
		TOTAL_PINTEREST_ENGAGEMENT_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count of total engagements on Pinterest. This includes people clicking on or saving a pin."
		),
		TOTAL_PINTEREST_REPINS_CNT NUMERIC NOT NULL OPTIONS(
			DESCRIPTION = "Count or “Re-Pins” on Pinterest."
		),
		CPG_MEDIA_SPEND_AMT NUMERIC(14, 2) NOT NULL OPTIONS(
			DESCRIPTION = "This reflects the amount charged by <<cocmp>> to the CPG."
		),
		DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was created"
		),
		DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(
			DESCRIPTION = "Timestamp when the record was last updated"
		)
	) OPTIONS(
		DESCRIPTION = "This is where all the actual performance numbers live. Every day, for every active ad, this table captures how well it performed. This is your main source for answering questions like 'How many people saw our ads?' and 'How much did we spend?'. It captures Core Performance Metric correspond to a campaign. This fact table stores daily performance metrics (impressions, clicks, spend, video views, engagements) for each creative/ad/campaign combination. It joins all relevant dimensions (advertiser, campaign, creative, etc.) and supports trend reporting.",
		labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);