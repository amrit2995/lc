CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_ADVERTISER`
(
  	PLATFORM_ADVERTISER_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."),
	PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Code representing the media platform (e.g., Facebook, Pinterest, dv360 or GAN)."),
	PLATFORM_ADVERTISER_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Advertiser ID, same as CPG in vendor CMS."),
	PLATFORM_ADVERTISER_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Advertiser Name, same as CPG in vendor CMS."),
	DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS(
	DESCRIPTION = "This Table stores the mapping of advertisers to media platforms. Used to provide consistent advertiser naming and IDs, along with platform and promotional channel information.",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);