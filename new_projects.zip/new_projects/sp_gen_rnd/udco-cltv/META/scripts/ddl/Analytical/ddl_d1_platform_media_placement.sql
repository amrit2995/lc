CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_PLACEMENT`
(
	PLATFORM_MEDIA_PLACEMENT_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for creative unit Placement  – uniquely identifies each creative ad placement." ),
	PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values: Meta/Pinterest/etc." ),
	PLATFORM_MEDIA_PLACEMENT_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Placement ID trafficked in placement mirroring social ad One Placement Id can have multiple Ad_UNIT_ID 's" ),
	PLATFORM_MEDIA_PLACEMENT_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Name For Placement ID trafficked in placement mirroring social ad" ),
	PLATFORM_MEDIA_PAGE_TYPE_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Its the type, placement Id tied to. It tells  the type/category of page that is tied to ad units . Page tpe can be Search page/ checkout/ home page/product Detail page/deal page etc."),
	DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS(
	DESCRIPTION = "This table holds the information about type of page where the ad units are served. AD UNITS can be decided to be served based on page type.Example- SEARCH page can have different ad units served vs Home page or Deal Page.",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
	);