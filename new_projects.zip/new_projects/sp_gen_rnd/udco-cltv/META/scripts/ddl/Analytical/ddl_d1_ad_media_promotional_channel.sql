CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PROMOTIONAL_CHANNEL`
(
	AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK NUMERIC NOT NULL,
	PLATFORM_PROMOTIONAL_CHANNEL_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Unique values from platform promotional channel: Display, On-Site Display, On-Site SPA, Social, Digital Instore, CTV, High Impact Display, PromoAmp, Email"),
	DW_CREATE_TS TIMESTAMP NOT NULL,
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL
)
OPTIONS(
	DESCRIPTION = "This table holds all possible values for advertisement channel valid for different platforms like Meta, Pinterest, GAM, DV360, Instore, Criteo, Undertone, etc.",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);