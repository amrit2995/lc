-- Work Table: FA_AD_PLATFORM_FINANCE_PERFORMANCE_WRK
-- Purpose: Staging table for finance performance data transformation
-- Used by: SP_CLTV_BIM_TO_ANALYTICS_FA_AD_PLATFORM_FINANCE_PERFORMANCE

CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.FA_AD_PLATFORM_FINANCE_PERFORMANCE_WRK`
(
    DATE                                DATE        NOT NULL,
    PLATFORM                            STRING      NOT NULL,
    LINE_ITEM_ID                        STRING      NOT NULL,
    CAMPAIGN_ID                         STRING      NOT NULL,
    ADVERTISER_ID                       STRING      NOT NULL,
    OPPORTUNITY_ID                      STRING      NOT NULL,
    HUB_L2_ID                           STRING,
    MEDIA_CAMPAIGN_ID                   STRING,
    PLATFORM_IMPRESSIONS                NUMERIC     NOT NULL,
    PLATFORM_CLICKS                     NUMERIC     NOT NULL,
    PLATFORM_MEDIA_SPEND_AMT            NUMERIC(14,2) NOT NULL,
    VIDEO_TRUEVIEW_CNT                  NUMERIC     NOT NULL,
    HUB_L2_CPG_CPM                      NUMERIC(14,2) NOT NULL,
    HUB_L2_PLANNED_IMPS                 NUMERIC     NOT NULL
)
CLUSTER BY DATE, CAMPAIGN_ID, LINE_ITEM_ID
OPTIONS(
    description = "Work table for Finance Performance fact transformation",
    labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);