CREATE OR REPLACE TABLE `<<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_WRK` (
    PERFORMANCE_DAY_ID NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101'
    ),
    AD_MEDIA_PLATFORM_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations.'
    ),
    AD_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for campaign – uniquely identifies each advertising campaign record in the system.'
    ),
    AD_MEDIA_OPPORTUNITY_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for campaign – uniquely identifies each advertising campaign record in the system.'
    ),
    AD_MEDIA_CAMPAIGN_LINE_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for campaign line item – uniquely identifies each line item record.'
    ),
    DIVISION_D1_SK INT64 NOT NULL OPTIONS(
      DESCRIPTION = ' System Generated Column gets next value inserted when record gets inserted. '
    ),
    BANNER_D1_SK INT64 NOT NULL OPTIONS(
      DESCRIPTION = ' System Generated Column gets next value inserted when record gets inserted. '
    ),
    PLATFORM_ADVERTISER_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations.'
    ),
    PLATFORM_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for platform media campaign – uniquely identifies each campaign per platform.'
    ),
    PLATFORM_MEDIA_LINE_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns.'
    ),
    PLATFORM_MEDIA_ADVERTISEMENT_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for creative unit – uniquely identifies each creative ad placement.'
    ),
    PLATFORM_MEDIA_AD_UNIT_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for creative unit – uniquely identifies each creative ad placement.'
    ),
    PLATFORM_MEDIA_CREATIVE_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns.'
    ),
    PLATFORM_MEDIA_PLACEMENT_D1_SK NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Surrogate key for creative unit Placement – uniquely identifies each creative ad placement.'
    ),
    AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK NUMERIC NOT NULL,
    TOTAL_CLICK_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = 'Count of clicks on the ad'),
    TOTAL_IMPRESSION_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Impression count for Social Performance'
    ),
    TOTAL_MEDIA_SPEND_AMT NUMERIC(14, 2) NOT NULL OPTIONS(
      DESCRIPTION = 'This reflects the amount charged by <<cocmp>> to the CPG.'
    ),
    VIDEO_START_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Number of people who saw at least the start of the video.'
    ),
    VIDEO_25P_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Number of people who saw at least 25% of the video.'
    ),
    VIDEO_50P_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Number of people who saw at least 50% of the video.'
    ),
    VIDEO_75P_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Number of people who saw at least 75% of the video.'
    ),
    VIDEO_COMPLETE_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Number of people who saw at least 100% of the video.'
    ),
    VIDEO_TRUEVIEW_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'TruView counts for YouTube video campaigns (if applicable)'
    ),
    POST_REACTION_ANGRY_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of Angry reactions on Facebook. Not present on Instagram.'
    ),
    POST_REACTION_WOW_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of Wow reactions on Facebook. Not present on Instagram.'
    ),
    POST_REACTION_LOVE_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of Love reactions on Facebook. Not present on Instagram.'
    ),
    POST_REACTION_CARE_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of Care reactions on Facebook. Not present on Instagram.'
    ),
    POST_REACTION_HAHA_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of Haha(Laugh) reactions on Facebook. Not present on Instagram.'
    ),
    POST_REACTION_LIKE_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of likes across Meta properties. This metric is cumulative across Facebook & Instagram.'
    ),
    POST_REACTION_SAD_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of SAD reactions across Meta properties. This metric is cumulative across Facebook & Instagram.'
    ),
    TOTAL_POST_REACTION_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of Reactions across Meta properties. This metric is cumulative across Facebook & Instagram.'
    ),
    TOTAL_POST_COMMENT_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of comments across Meta properties. This metric is cumulative across Facebook & Instagram.'
    ),
    TOTAL_POST_ENGAGEMENT_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of engagements across Meta properties. Includes reactions, likes, comments, shares.'
    ),
    TOTAL_PINTEREST_ENGAGEMENT_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of engagements across Meta properties. Includes reactions, likes, comments, shares.'
    ),
    TOTAL_PINTEREST_REPIN_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Count of engagements across Meta properties. Includes reactions, likes, comments, shares.'
    ),
    CPG_MEDIA_SPEND_AMT NUMERIC(14, 2) NOT NULL OPTIONS(
      DESCRIPTION = 'This reflects the amount charged by <<cocmp>> to the CPG.'
    ),
    MEASUREMENT_ONLINE_TRANSACTIONS_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Number of Orders completed for given set of dimensions purchased online For DV360/GAM: Sum of online transactions\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    MEASUREMENT_ONLINE_REVENUE_AMT NUMERIC(14, 2) NOT NULL OPTIONS(
      DESCRIPTION = 'Attributed Revenue for given set of dimensions purchased online For DV360/GAM: Sum of online revenue\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    MEASUREMENT_OFFLINE_TRANSACTIONS_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'Number of Orders completed for given set of dimensions purchased instore For DV360/GAM: Sum of offline transactions\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    MEASUREMENT_OFFLINE_REVENUE_AMT NUMERIC(14, 2) NOT NULL OPTIONS(
      DESCRIPTION = 'Attributed Revenue for given set of dimensions purchased online For DV360/GAM: Sum of offline revenue\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    MEASUREMENT_MOBILE_TRANSACTIONS_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'For DV360/GAM: Sum of mobile transactions\nFor Meta: No available attributable sales\nFor Pinterest: Pinterest does not provide attributable sales by sales channel\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    MEASUREMENT_MOBILE_REVENUE_AMT NUMERIC(14, 2) NOT NULL OPTIONS(
      DESCRIPTION = 'For DV360/GAM: Sum of mobile revenue\nFor Meta: No available attributable sales\nFor Pinterest: Pinterest does not provide attributable sales by sales channel\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    MEASUREMENT_TOTAL_TRANSACTIONS_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'For DV360/GAM: Aggregation of online, offline, and mobile transactions\nFor Meta/Pinterest: No available attributable sales'
    ),
    MEASUREMENT_TOTAL_REVENUE_AMT NUMERIC(14, 2) NOT NULL OPTIONS(
      DESCRIPTION = 'For DV360/GAM: Aggregation of online, offline, and mobile revenue\nFor Meta/Pinterest: No available attributable sales'
    ),
    MEASUREMENT_ONLINE_UNITS_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'For DV360/GAM: Sum of online units\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    MEASUREMENT_OFFLINE_UNITS_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'For DV360/GAM: Sum of offline units\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    MEASUREMENT_MOBILE_UNITS_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'For DV360/GAM: Sum of mobile units\nFor Meta: No available attributable sales\nFor Pinterest: Pinterest does not provide attributable sales by sales channel\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    MEASUREMENT_TOTAL_UNITS_CNT NUMERIC NOT NULL OPTIONS(
      DESCRIPTION = 'For DV360/GAM: Aggregation of online, offline, and mobile units\nFor Meta/Pinterest: No available attributable sales\nData is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.'
    ),
    DW_CREATE_TS TIMESTAMP NOT NULL,
    DW_LAST_UPDATE_TS TIMESTAMP NOT NULL
  ) OPTIONS(
    description = "Work/staging table for FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE. Used during load process to stage transformed multi-platform campaign data before inserting into main fact table.",
    labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
  );