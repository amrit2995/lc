CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM`
(
	AD_MEDIA_PLATFORM_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations"),
	PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values:Meta/Pinterest/etc"),
	PLATFORM_PROMOTIONAL_CHANNEL_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Type of advertisement. This column will have one of the following values: Social/On-Site/Display/etc"),
	DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS(
	DESCRIPTION = "This is a simple lookup table that categorizes different advertising platforms and channels. Think of it as a reference guide that standardizes how you classify and group different advertising platforms",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);