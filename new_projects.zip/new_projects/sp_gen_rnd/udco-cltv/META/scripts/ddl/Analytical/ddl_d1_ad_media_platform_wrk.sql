CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_AD_MEDIA_PLATFORM_WRK`
(
	AD_MEDIA_PLATFORM_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations"),
	PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values:Meta/Pinterest/etc"),
	PLATFORM_PROMOTIONAL_CHANNEL_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Type of advertisement. This column will have one of the following values: Social/On-Site/Display/etc"),
)
OPTIONS(
	DESCRIPTION = "Staging table for AD media paltform",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);