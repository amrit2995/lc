CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_PLATFORM_ADVERTISER_WRK`
(
  PLATFORM_ADVERTISER_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations."),
	PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Code representing the media platform (e.g., Facebook, Pinterest, dv360 or GAM)."),
	PLATFORM_ADVERTISER_ID STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Advertiser ID, same as CPG in vendor CMS."),
	PLATFORM_ADVERTISER_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Platform Advertiser Name, same as CPG in vendor CMS.")
)
OPTIONS(
	DESCRIPTION = "Advertiser staging table to handle delta.",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);