CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN`
(
	AD_MEDIA_CAMPAIGN_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for campaign - uniquely identifies each advertising campaign record in the system."),
	AD_MEDIA_CAMPAIGN_ID STRING NOT NULL OPTIONS(DESCRIPTION = "AMC Media Campaign ID" ),
	AD_CAMPAIGN_ID STRING NOT NULL OPTIONS(DESCRIPTION = "AMC Hub Campaign ID" ),
	AD_CAMPAIGN_NM STRING NOT NULL OPTIONS(DESCRIPTION = "AMC Hub Campaign Name" ),
	AD_MEDIA_CAMPAIGN_NM STRING NOT NULL OPTIONS(DESCRIPTION = "AMC Friendly Campaign Name from Insertion Order" ),
	AD_CAMPAIGN_START_DT DATE NOT NULL OPTIONS(DESCRIPTION = "Start date for the whole Hub Campaign" ),
	AD_CAMPAIGN_END_DT DATE NOT NULL OPTIONS(DESCRIPTION = "End date for the whole Hub Campaign" ),
	AD_CAMPAIGN_BUDGT_AMT NUMERIC(14,2) NOT NULL OPTIONS(DESCRIPTION = "Budget for the whole Hub Campaign" ),
	AD_CAMPAIGN_ADVERTISED_BRAND_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Brand(s) represented in the advertisement. These are the IRI Brand names(ampersand-delimited) that will be used for attribution. Note that for Citrus, these will not align with IRI Brand Names." ),
	AD_CAMPAIGN_PLND_IMPRESSION_CNT NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Planned Impressions for the whole Hub Campaign" ),
	AD_CAMPAIGN_OBJECTIVE_TXT STRING NOT NULL OPTIONS(DESCRIPTION = "CPG's aim with this AMC Hub Campaign" ),
	AD_CPG ARRAY<STRUCT<AD_CAMPAIGN_PARTNER_ID STRING,AD_CAMPAIGN_PARTNER_NM STRING>> OPTIONS(DESCRIPTION = "AMC Hub Campaign ID & AMC Friendly Campaign Name from Insertion Order"),
	DW_CREATE_TS TIMESTAMP NOT NULL	OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL	OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" ),
	PRIMARY KEY (AD_MEDIA_CAMPAIGN_D1_SK) not enforced
) 
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);