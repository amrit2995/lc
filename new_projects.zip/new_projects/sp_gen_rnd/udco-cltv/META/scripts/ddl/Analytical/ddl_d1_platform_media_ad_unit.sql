CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_AD_UNIT`
(
	PLATFORM_MEDIA_AD_UNIT_D1_SK NUMERIC NOT NULL OPTIONS(DESCRIPTION = "Surrogate key for creative unit – uniquely identifies each creative ad placement."),
	PLATFORM_CD STRING NOT NULL OPTIONS(DESCRIPTION = "Site where advertisement is placed. This column will have one of the following values: Meta/Pinterest/etc." ),
	PLATFORM_MEDIA_AD_UNIT_ID STRING NOT NULL OPTIONS(DESCRIPTION = "UNIT ID trafficked in placement mirroring social ad. One Ad Unit Id can belong to multiple Placement Id's"),
	PLATFORM_MEDIA_AD_UNIT_NM STRING NOT NULL OPTIONS(DESCRIPTION = "Name For AD_UNIT ID trafficked in placement mirroring social ad" ),
	PLATFORM_AD_UNIT_CREATIVE_VERSION_CD STRING NOT NULL OPTIONS(DESCRIPTION = "The name of the creative version input to platform" ),
	DW_CREATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was created" ),
	DW_LAST_UPDATE_TS TIMESTAMP NOT NULL OPTIONS(DESCRIPTION = "Timestamp when the record was last updated" )
)
OPTIONS(
	DESCRIPTION = "This table holds the information like placeholder, where the ad creative will be running.  Placement ID trafficked in placement mirroring social ad.Describes the ad unit or placement (slot, position, or inventory location) where a creative is shown on a platform.",
	labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]
);