CREATE OR REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.campaign_reach_summary_wrk`
(
 campaign_id             	    STRING      ,
 source_last_modified_ts      TIMESTAMP   ,
 dw_first_effective_ts        TIMESTAMP   ,
 dw_last_effective_ts         TIMESTAMP   ,
 reach_cnt                    INT64                ,
 impressions_cnt              INT64                ,
 source_application_cd        STRING      ,
 dw_create_ts                 TIMESTAMP            ,
 dw_last_update_ts            TIMESTAMP            ,
 dw_logical_delete_ind        BOOL                 ,
 dw_source_create_nm          STRING               ,
 dw_source_update_nm          STRING               ,
 dw_current_version_ind       BOOL                 ,
 dw_dml_type                  STRING               
)
OPTIONS(
  description="Campaign reach summary work table",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);