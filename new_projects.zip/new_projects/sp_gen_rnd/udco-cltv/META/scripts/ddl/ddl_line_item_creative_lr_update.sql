CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.line_item_creative_lr_update`
(
 ad_id                  STRING   ,
 creative_id            STRING   ,
 line_item_id           STRING   ,
 source_application_cd  STRING   ,
 dw_first_effective_ts  TIMESTAMP ,
 dw_last_effective_ts   TIMESTAMP ,
 dw_current_version_ind BOOL
) 
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);