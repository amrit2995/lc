CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_platform_advertiser_wrk`
(
 ADVERTISER_ID          STRING ,
 SOURCE_APPLICATION_CD  STRING ,
 DW_FIRST_EFFECTIVE_TS  TIMESTAMP ,
 DW_LAST_EFFECTIVE_TS   TIMESTAMP ,
 currency_cd        STRING  ,
 ADVERTISER_NM 			STRING	,
 ACCOUNT_STATUS_NM		STRING 	,
 disable_reason_txt     STRING ,
 source_created_TS TIMESTAMP    ,
 SOURCE_LAST_MODIFIED_TS  TIMESTAMP ,
 DW_LOGICAL_DELETE_IND BOOLEAN,
 DML_TYPE STRING		   
)
OPTIONS (labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);