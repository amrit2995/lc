CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.ad_creative_reach_summary_wrk`
(
 ad_id             	    STRING      ,
 source_last_modified_ts      TIMESTAMP   ,
 dw_first_effective_ts        TIMESTAMP   ,
 dw_last_effective_ts         TIMESTAMP   ,
 reach_cnt                    INT64       ,
 impressions_cnt              INT64       ,
 source_application_cd        STRING      ,
 DML_TYPE                      STRING     
)
OPTIONS(
  description="Captures information about user's device setup,including device category(eg:mobile,desktop),app Id.mobile carrier,and capabilities,used for device targeting and delivery optimization.",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);
