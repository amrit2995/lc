DROP TABLE IF EXISTS `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_video_action`;

CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_video_action`
(
 video_action_type_id   NUMERIC   NOT NULL OPTIONS(description="FK to video action type"),
 ad_id                  STRING    NOT NULL OPTIONS(description="FK to ad entity"),
 publisher_platform_nm  STRING    NOT NULL OPTIONS(description="Ad platform name(eg:Facebook, Instagarm)"),
 video_action_dt        DATE      NOT NULL OPTIONS(description="Date the video action occured"),
 source_application_cd  STRING    NOT NULL OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts  TIMESTAMP NOT NULL OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts   TIMESTAMP NOT NULL OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 value_nbr              FLOAT64            OPTIONS(description="Count of video views or watch actions for the given threshold"),
 dw_create_ts           TIMESTAMP NOT NULL OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts      TIMESTAMP NOT NULL OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind  BOOL               OPTIONS(description="Set to True when we receive a delete record for the primary key"),
 dw_source_create_nm    STRING             OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm    STRING             OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind BOOL               OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be  current date -1 d."),
 
 PRIMARY KEY (video_action_type_id, ad_id, publisher_platform_nm, video_action_dt, source_application_cd,DW_FIRST_EFFECTIVE_TS, DW_LAST_EFFECTIVE_TS) not enforced
)
PARTITION BY  video_action_dt
CLUSTER BY    video_action_type_id,ad_id,publisher_platform_nm,video_action_dt 

OPTIONS(
  description="Represents data related to video actions within the Meta Ads platform.",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);
