CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_placement` 
(
 placement_id               STRING    NOT NULL OPTIONS(description="Unique Identifier for the placement."),
 source_application_cd      STRING    NOT NULL OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts      TIMESTAMP NOT NULL OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts       TIMESTAMP NOT NULL OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 placement_nm               STRING             OPTIONS(description="Descriptive name of the placement(eg.HomePage Top Banner,Pre-Roll video slot)"),
 source_created_ts          TIMESTAMP          OPTIONS(description="The date and time record was created"),
 source_last_modified_ts    TIMESTAMP          OPTIONS(description="The date and time record was modified"),
 dw_create_ts               TIMESTAMP          OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts          TIMESTAMP          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind      BOOL               OPTIONS(description="Set to True when we receive a delete record for the primary key, else False"),
 dw_source_create_nm        STRING             OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm        STRING             OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind     BOOL               OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be current date -1 d."),
 PRIMARY KEY (placement_id, source_application_cd, dw_first_effective_ts, dw_last_effective_ts) not enforced
)
PARTITION BY  DATE(dw_last_update_ts)
CLUSTER BY    placement_id
OPTIONS(
  description="Represents a subcomponent of a campaign defining specific tactics such as audience targeting, creatives, budget allocations, and scheduling. Each line item is typically executed as a unit of ad delivery (eg: Meta Ad Set or Google Line Item).",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);