DROP TABLE IF EXISTS `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_action_reaction`;

CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_action_reaction`
(
 action_reaction_type_id  NUMERIC NOT NULL    OPTIONS(description="Description of the reaction"),
 ad_id                    STRING  NOT NULL    OPTIONS(description="FK to ad entity"),
 action_reaction_dt       DATE    NOT NULL    OPTIONS(description="Date of the reaction event"),
 source_application_cd    STRING  NOT NULL    OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 Dw_first_effective_ts    TIMESTAMP    NOT NULL    OPTIONS(description="for the current record this is ''12/31/9999''.  for updated records based on the primary key of the table, this is the new current records DW_First_Effective_Dt -1 day'"),
 Dw_last_effective_ts     TIMESTAMP    NOT NULL    OPTIONS(description="The date the record was inserted.  For update Primary Keys this values is used from the prior record of the primary key';"),
 value_nbr                FLOAT64             OPTIONS(description="Number of reactions of the specified type on that date"),
 dw_create_ts             TIMESTAMP NOT NULL  OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts        TIMESTAMP NOT NULL  OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind    BOOL                OPTIONS(description="Set to True when we receive a delete record for the primary key"),
 dw_source_create_nm      STRING              OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm      STRING              OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind   BOOL                OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be current date -1 d."),
 PRIMARY KEY (action_reaction_type_id,ad_id,action_reaction_dt, source_application_cd, Dw_first_effective_ts, Dw_last_effective_ts) not enforced
)

PARTITION BY  action_reaction_dt
CLUSTER BY    action_reaction_type_id,ad_id,action_reaction_dt

OPTIONS(
  description="Represents reactions (such as like, love, wow, etc.) to advertisements, capturing the type of reaction, the ad, the date of the reaction, and associated metrics. Each record reflects a specific reaction event for an ad on a given day and platform.",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);