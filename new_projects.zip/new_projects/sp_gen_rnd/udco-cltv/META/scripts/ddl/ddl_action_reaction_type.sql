CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.action_reaction_type`
(
 action_reaction_type_id    NUMERIC  NOT NULL OPTIONS(description="Unique ID for the type of Facebook reaction"),
 source_application_cd      STRING  NOT NULL OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 action_reaction_cd         STRING  OPTIONS(description="Reaction code (eg: wow,sad,love etc.)"),
 action_reaction_dsc        STRING  OPTIONS(description="Description of the reaction"),
 dw_create_ts               TIMESTAMP          OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts          TIMESTAMP          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind      BOOL               OPTIONS(description="Set to True when we receive a delete record for the primary key"),
 dw_source_create_nm        STRING             OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm        STRING             OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind     BOOL       OPTIONS(description="set to yes when the current record is deleted, the Last Effective date on this record is still set to be current date -1 d."),
 PRIMARY KEY (action_reaction_type_id, source_application_cd) not enforced
)

PARTITION BY  DATE(dw_last_update_ts)
CLUSTER BY    action_reaction_type_id

OPTIONS(
  description="Defines the master list of possible reactions to advertisements (such as like, love, wow, etc.), including a unique identifier, code, and description for each reaction type. This table standardizes reaction types across all ad platforms and supports consistent reporting and analytics.",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);