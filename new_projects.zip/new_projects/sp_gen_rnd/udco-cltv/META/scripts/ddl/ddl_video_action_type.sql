CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.video_action_type`
(
 video_action_type_id  NUMERIC  NOT NULL OPTIONS(description="Unique ID for the video engagement type"),
 video_action_cd                 STRING OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 video_action_code_dsc  STRING OPTIONS(description="Code for video(eg:play,p25,p50 etc)"),
 source_application_cd  STRING  NOT NULL OPTIONS(description="Description of the video view threshold"),
 dw_create_ts                      TIMESTAMP          OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts                 TIMESTAMP          OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind             BOOL               OPTIONS(description="Set to True when we receive a delete record for the primary key"),
 dw_source_create_nm               STRING             OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm               STRING             OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind     	BOOL       OPTIONS(description="set to yes when the current record is deleted,  the Last Effective date on this record is still set to be  current date -1 d.")
 
)
PARTITION BY  DATE(dw_last_update_ts)
CLUSTER BY    video_action_type_id 

OPTIONS(
  description="Represents data related to different types of actions users can take when engaging with video ads.",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);
