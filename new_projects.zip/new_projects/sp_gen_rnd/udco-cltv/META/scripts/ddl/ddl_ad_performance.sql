DROP TABLE IF EXISTS `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_performance`;

CREATE or REPLACE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_performance`
(
 ad_id                      STRING    NOT NULL  OPTIONS(description="Unique ad or creative id"),
 performance_dt             DATE      NOT NULL  OPTIONS(description="Performance date"),
 publisher_platform_nm      STRING    NOT NULL  OPTIONS(description="Ad platform name (e.g., Facebook, Instagram)"),
 source_application_cd      STRING    NOT NULL  OPTIONS(description="Code representing the source ad platform (e.g., GAM, Meta, Pinterest,  DV360)"),
 dw_first_effective_ts      TIMESTAMP NOT NULL  OPTIONS(description="The first date and time on which a version is in effect.  If unknown, use midnight 01/01/0001"),
 dw_last_effective_ts       TIMESTAMP NOT NULL  OPTIONS(description="The last date and time on which a version is in effect.  If unknown, use midnight 12/31/9999"),
 account_id                 STRING              OPTIONS(description="Ad Account Id"),
 line_item_id               STRING    NOT NULL  OPTIONS(description="Ad line item id"),
 campaign_id                STRING              OPTIONS(description="Ad campaign id"),
 impressions_cnt            NUMERIC             OPTIONS(description="Total impression"),
 clicks_cnt                 NUMERIC             OPTIONS(description="Total click-throughs"),
 platform_media_spend_amt   NUMERIC(14,2)       OPTIONS(description="Spend in dollors") ,
 dw_create_ts               TIMESTAMP NOT NULL  OPTIONS(description="The timestamp the record was inserted."),
 dw_last_update_ts          TIMESTAMP NOT NULL  OPTIONS(description="When a record is updated.this would be the current timestamp"),
 dw_logical_delete_ind      BOOL                OPTIONS(description="Set to True when we receive a delete record for the primary key"),
 dw_source_create_nm        STRING              OPTIONS(description="The data source name of this insert."),
 dw_source_update_nm        STRING              OPTIONS(description="The data source name of this update or delete."),
 dw_current_version_ind     BOOL                OPTIONS(description="set to yes when the current record is deleted"),
 PRIMARY KEY (ad_id, performance_dt, publisher_platform_nm,source_application_cd, dw_first_effective_ts, dw_last_effective_ts) not enforced
)
PARTITION BY  performance_dt
CLUSTER BY    ad_id,performance_dt,publisher_platform_nm

OPTIONS(
  description="Represents performance metrics for an advertisement, including impressions, clicks, and spend, broken down by date and publishing platform. Each record reflects the performance of a specific ad on a given day and platform.",
  labels = [('appcode','uddi'),('bodname','meta'),('domainname','collect'),('environment','<<ENV>>')]);