TRUNCATE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.action_reaction_type`;

INSERT INTO `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.action_reaction_type` (
  action_reaction_type_id,
  source_application_cd,
  action_reaction_cd,
  action_reaction_dsc,
  dw_create_ts,
  dw_last_update_ts,
  dw_logical_delete_ind,
  dw_source_create_nm,
  dw_source_update_nm,
  dw_current_version_ind
  )
VALUES
  (1, 'FACEBOOK','like', 'like reaction', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (2, 'FACEBOOK','love', 'love reaction', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (3, 'FACEBOOK','haha', 'haha reaction', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (4, 'FACEBOOK','wow', 'wow reaction', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (5, 'FACEBOOK','angry', 'angry reaction', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (6, 'FACEBOOK','sad', 'sad reaction', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (7, 'FACEBOOK','care', 'care reaction', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (8, 'FACEBOOK','post_engagement', 'post enagagement', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (9, 'FACEBOOK','comment', 'comment', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (10, 'FACEBOOK','post_reaction', 'post reaction', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE)
;