CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_META_ADVERTISER_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts_history STRING;
DECLARE sql_inserts STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE row_count_tgt INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;


SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_META_ADVERTISER_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.AD_PLATFORM_ADVERTISER';
SET tgt_wrk_tbl     = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.AD_PLATFORM_ADVERTISER_WRK';        
SET src_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.account_history';


SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "FACEBOOK" ''' ;

BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;



SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
        ADVERTISER_ID
        ,SOURCE_APPLICATION_CD
        ,DW_FIRST_EFFECTIVE_TS
        ,DW_LAST_EFFECTIVE_TS
        ,ADVERTISER_NM
        ,CURRENCY_CD
        ,ACCOUNT_STATUS_NM
        ,DISABLE_REASON_TXT
        ,SOURCE_CREATED_TS
        ,SOURCE_LAST_MODIFIED_TS
        ,DW_LOGICAL_DELETE_IND
        ,DML_TYPE
        )
         SELECT DISTINCT CAST(ID AS STRING) AS ADVERTISER_ID
                ,"FACEBOOK" AS SOURCE_APPLICATION_CD
                ,TIMESTAMP_TRUNC(CURRENT_TIMESTAMP(),SECOND) AS DW_FIRST_EFFECTIVE_TS
                ,CAST('9999-12-31 00:00:00' AS TIMESTAMP) AS DW_LAST_EFFECTIVE_TS
                ,NAME AS ADVERTISER_NM
                ,currency AS CURRENCY_CD
                ,account_status as ACCOUNT_STATUS_NM
                ,disable_reason AS DISABLE_REASON_TXT
                ,created_time AS SOURCE_CREATED_TS
                ,CAST(NULL AS TIMESTAMP) AS SOURCE_LAST_MODIFIED_TS
                ,FALSE AS DW_LOGICAL_DELETE_IND
                ,CASE WHEN TGT.ADVERTISER_ID IS NULL  THEN 'I' ELSE 'U' END AS DML_TYPE
	FROM
            ''' || src_tbl || ''' SRC
	LEFT JOIN ''' || tgt_tbl || ''' TGT 
	ON CAST(SRC.ID AS STRING) = TGT.ADVERTISER_ID
        AND TGT.DW_CURRENT_VERSION_IND = TRUE
	    AND TGT.SOURCE_APPLICATION_CD = 'FACEBOOK'
        WHERE _fivetran_synced > "''' || data_extract_start_ts || '''"
        AND ID IS NOT NULL
        AND (TGT.ADVERTISER_ID IS NULL
            OR ( 
                    IFNULL(TGT.ADVERTISER_NM,'-1') <> IFNULL(SRC.NAME,'-1') OR
                    IFNULL(TGT.CURRENCY_CD,'-1') <> IFNULL(SRC.currency,'-1') OR
                    IFNULL(TGT.ACCOUNT_STATUS_NM,'-1') <> IFNULL(SRC.account_status,'-1') OR
                    IFNULL(TGT.DISABLE_REASON_TXT,'-1') <> IFNULL(SRC.disable_reason,'-1') OR
                    IFNULL(SOURCE_CREATED_TS,TIMESTAMP('1900-01-01 00:00:00')) <> IFNULL(SRC.created_time,TIMESTAMP('1900-01-01 00:00:00'))
            ))
        QUALIFY ROW_NUMBER() OVER (PARTITION BY ID ORDER BY _fivetran_synced DESC, created_time DESC) = 1
        ''';


--//SCD Type2 transaction begins
SET sql_begin = "BEGIN TRANSACTION";
SET sql_updates = '''--// Processing Updates of Type 2 SCD
                UPDATE ''' || tgt_tbl || ''' as TGT
                    SET  DW_LAST_EFFECTIVE_TS = TIMESTAMP_SUB(SRC.DW_FIRST_EFFECTIVE_TS, INTERVAL 1 SECOND)  
                   ,DW_CURRENT_VERSION_IND = FALSE
                   ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                   ,DW_SOURCE_UPDATE_NM = "FACEBOOK"
                    FROM (SELECT
                                        *
                                        FROM ''' || tgt_wrk_tbl || '''
                                        WHERE DML_TYPE = 'U'
                                        AND ADVERTISER_ID IS NOT NULL
                          ) SRC 
                        WHERE TGT.ADVERTISER_ID = SRC.ADVERTISER_ID
                        AND TGT.SOURCE_APPLICATION_CD = 'FACEBOOK'
                        AND TGT.DW_CURRENT_VERSION_IND = TRUE''';


--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
                        ADVERTISER_ID
                        ,SOURCE_APPLICATION_CD
                        ,DW_FIRST_EFFECTIVE_TS
                        ,DW_LAST_EFFECTIVE_TS
                        ,ADVERTISER_NM
                        ,ACCOUNT_STATUS_NM
                        ,CURRENCY_CD
                        ,DISABLE_REASON_TXT
                        ,SOURCE_CREATED_TS
                        ,SOURCE_LAST_MODIFIED_TS
                        ,DW_CREATE_TS
                        ,DW_LAST_UPDATE_TS
                        ,DW_LOGICAL_DELETE_IND
                        ,DW_SOURCE_CREATE_NM
                        ,DW_SOURCE_UPDATE_NM
                        ,DW_CURRENT_VERSION_IND
                        )
                        SELECT 
                            ADVERTISER_ID
                            ,SOURCE_APPLICATION_CD
                            ,DW_FIRST_EFFECTIVE_TS
                            ,DW_LAST_EFFECTIVE_TS
                            ,ADVERTISER_NM
                            ,ACCOUNT_STATUS_NM
                            ,CURRENCY_CD
                            ,DISABLE_REASON_TXT
                            ,SOURCE_CREATED_TS
                            ,SOURCE_LAST_MODIFIED_TS
                            ,CURRENT_TIMESTAMP
                            ,CURRENT_TIMESTAMP
                            ,DW_LOGICAL_DELETE_IND
                            ,"FACEBOOK" AS DW_SOURCE_CREATE_NM
                            ,"FACEBOOK" AS DW_SOURCE_UPDATE_NM  
                            ,TRUE
                        FROM ''' || tgt_wrk_tbl  ;
                        

SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
        EXECUTE IMMEDIATE (sql_begin);       
        IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
            EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
        END IF;       
        BEGIN
                EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
                EXCEPTION WHEN ERROR THEN
                SET job_end  = CURRENT_TIMESTAMP();
                SET status   = "FAILED";
                SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
                CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
                RAISE USING message = err_desc;
        END;
        EXECUTE IMMEDIATE (sql_updates);
        EXECUTE IMMEDIATE (sql_inserts);
        SET row_count = @@row_count;
        EXECUTE IMMEDIATE (sql_commit);
        EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE (sql_rollback);
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Confirmed',CURRENT_DATE(),"AD_PLATFORM_ADVERTISER");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;