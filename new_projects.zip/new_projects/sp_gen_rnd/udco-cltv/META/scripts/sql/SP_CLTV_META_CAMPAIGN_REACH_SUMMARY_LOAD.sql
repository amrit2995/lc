CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_META_CAMPAIGN_REACH_SUMMARY_LOAD`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_lr_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE campaign_reach_summary_update_expire string;
DECLARE campaign_reach_summary_final_insert string;



SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_META_CAMPAIGN_REACH_SUMMARY_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.campaign_reach_summary';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.campaign_reach_summary_wrk';        
SET src_tbl         = '<<SOURCE_PROJECT_ID>>.<<META_SRC_DATASET>>.campaign_reach';


IF DATE(max_audit_ts) = '1900-01-01' THEN
  EXECUTE IMMEDIATE ('''TRUNCATE TABLE ''' || tgt_tbl);
END IF;

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = FORMAT("""
      INSERT INTO %s
			(
        campaign_id,
        source_last_modified_ts,
        dw_first_effective_ts,
        dw_last_effective_ts,
        reach_cnt,
        impressions_cnt,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind,
        dw_dml_type
      )
      SELECT SRC.campaign_id
      ,CAST(SRC.date AS TIMESTAMP) AS source_last_modified_ts
      ,CURRENT_TIMESTAMP() AS dw_first_effective_ts
      ,CAST('9999-12-31 00:00:00' AS TIMESTAMP)  AS dw_last_effective_ts
      ,SRC.reach AS reach_cnt
      ,SRC.impressions AS impressions_cnt
      ,"FACEBOOK" AS source_application_cd
      ,CURRENT_TIMESTAMP AS dw_create_ts
      ,CURRENT_TIMESTAMP AS dw_last_update_ts
      ,FALSE  AS dw_logical_delete_ind
      ,'FACEBOOK' AS dw_source_create_nm
      ,'FACEBOOK'  AS dw_source_update_nm
      ,TRUE  AS dw_current_version_ind
      ,CASE WHEN (TGT.campaign_id IS NULL AND TGT.source_last_modified_ts IS NULL) THEN 'I' ELSE 'U' END AS dw_dml_type
      FROM %s SRC
      LEFT JOIN %s TGT
      ON SRC.campaign_id = TGT.campaign_id
      AND SRC.date = CAST(TGT.source_last_modified_ts AS DATE)
      AND  TGT.DW_CURRENT_VERSION_IND = TRUE
      WHERE SRC.campaign_id IS NOT NULL 
      AND SRC.date IS NOT NULL
      AND _fivetran_synced >= %T AND _fivetran_synced < %T
      AND ((TGT.campaign_id IS NULL AND TGT.source_last_modified_ts IS NULL)  -- New records
         OR (
          IFNULL(SRC.reach, 1) <> IFNULL(TGT.reach_cnt, 1) OR
          IFNULL(SRC.impressions, 1) <> IFNULL(TGT.impressions_cnt, 1) 
        )
      )
      QUALIFY ROW_NUMBER() OVER (PARTITION BY SRC.campaign_id,SRC.date ORDER BY _fivetran_synced DESC) = 1
""",tgt_wrk_tbl,src_tbl,tgt_tbl,data_extract_start_ts,data_extract_end_ts);

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

--RECORDS EXPIRE AND FINAL UPDATE TARGET TABLE
SET campaign_reach_summary_update_expire = FORMAT("""
      UPDATE  %s p
      SET dw_last_effective_ts = TIMESTAMP_SUB(t.dw_first_effective_ts, INTERVAL 1 SECOND),
          dw_current_version_ind = FALSE,
          dw_last_update_ts = CURRENT_TIMESTAMP,
          dw_source_update_nm = 'FACEBOOK'
      FROM ( 
      SELECT *  FROM %s WHERE dw_dml_type = 'U'
      ) t
      WHERE  p.campaign_id = t.campaign_id
      AND    p.source_last_modified_ts = t.source_last_modified_ts
      AND    p.source_application_cd = 'FACEBOOK'
      AND    p.dw_current_version_ind = TRUE
      """,tgt_tbl,tgt_wrk_tbl);

--FINAL INSERT TARGET TABLE
SET campaign_reach_summary_final_insert = FORMAT("""
      INSERT  INTO %s
      (
        campaign_id,
        source_last_modified_ts,
        dw_first_effective_ts,
        dw_last_effective_ts,
        reach_cnt,
        impressions_cnt,
        source_application_cd,
        dw_create_ts,
        dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind
      ) 
      SELECT  
        campaign_id,
        source_last_modified_ts,
        dw_first_effective_ts,
        dw_last_effective_ts,
        reach_cnt,
        impressions_cnt,
        source_application_cd,
        CURRENT_TIMESTAMP() AS dw_create_ts,
        CURRENT_TIMESTAMP() AS dw_last_update_ts,
        dw_logical_delete_ind,
        dw_source_create_nm,
        dw_source_update_nm,
        dw_current_version_ind
        FROM   %s
      """,tgt_tbl,tgt_wrk_tbl);

BEGIN
EXECUTE IMMEDIATE (sql_begin); 
EXECUTE IMMEDIATE (campaign_reach_summary_update_expire);
EXECUTE IMMEDIATE (campaign_reach_summary_final_insert);
SET record_count = @@row_count;

EXECUTE IMMEDIATE (sql_commit);
SET row_count = row_count + record_count;

EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET status  = "COMPLETED";
SET job_end = CURRENT_TIMESTAMP();
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Confirmed',CURRENT_DATE(),"CAMPAIGN_REACH_SUMMARY");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;