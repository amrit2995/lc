CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_META_AD_PERFORMANCE_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts STRING;
DECLARE sql_inserts_history STRING;
DECLARE lkp_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE row_count_tgt INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;


SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_META_AD_PERFORMANCE_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.AD_PERFORMANCE';
SET tgt_wrk_tbl     = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.AD_PERFORMANCE_WRK';        
SET src_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg';


SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "FACEBOOK" ''' ;


BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;



SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
        AD_ID
        ,DW_FIRST_EFFECTIVE_TS
        ,DW_LAST_EFFECTIVE_TS
        ,PERFORMANCE_DT
        ,PUBLISHER_PLATFORM_NM
        ,SOURCE_APPLICATION_CD
        ,LINE_ITEM_ID
        ,CAMPAIGN_ID
        ,ACCOUNT_ID
        ,IMPRESSIONS_CNT
        ,CLICKS_CNT
        ,PLATFORM_MEDIA_SPEND_AMT
        ,DML_TYPE
        )
        SELECT DISTINCT SRC.AD_ID AS ADVERTISER_ID
                ,TIMESTAMP_TRUNC(CURRENT_TIMESTAMP(),SECOND) AS DW_FIRST_EFFECTIVE_TS
                ,CAST('9999-12-31 00:00:00' AS TIMESTAMP) AS DW_LAST_EFFECTIVE_TS
                ,SRC.DATE AS PERFORMANCE_DT
                ,SRC.PUBLISHER_PLATFORM AS PUBLISHER_PLATFORM_NM
                ,"FACEBOOK" AS SOURCE_APPLICATION_CD
                ,CAST(SRC.ADSET_ID AS STRING) AS LINE_ITEM_ID
                ,CAST(SRC.CAMPAIGN_ID AS STRING) AS CAMPAIGN_ID
                ,CAST(SRC.ACCOUNT_ID AS STRING) AS ACCOUNT_ID
                ,SRC.IMPRESSIONS AS IMPRESSIONS_CNT
                ,SRC.CLICKS AS CLICKS_CNT
                ,CAST(SRC.SPEND AS NUMERIC) AS PLATFORM_MEDIA_SPEND_AMT
                ,CASE 
                    WHEN TGT.AD_ID IS NULL  THEN 'I' 
                    ELSE 'U'
                END AS DML_TYPE
	FROM
            ''' || src_tbl || ''' SRC
	
    LEFT JOIN ''' || tgt_tbl || ''' TGT 
	ON SRC.AD_ID = TGT.AD_ID
        AND SRC.DATE = TGT.PERFORMANCE_DT
        AND SRC.PUBLISHER_PLATFORM = TGT.PUBLISHER_PLATFORM_NM
        AND TGT.DW_CURRENT_VERSION_IND = TRUE
	    AND TGT.SOURCE_APPLICATION_CD = 'FACEBOOK'
    
    WHERE _fivetran_synced > "''' || data_extract_start_ts || '''" 
        AND SRC.AD_ID IS NOT NULL
        AND SRC.DATE IS NOT NULL
        AND SRC.PUBLISHER_PLATFORM IS NOT NULL
        AND SRC.adset_id IS NOT NULL
        AND (
              ( TGT.AD_ID IS NULL 
                AND TGT.PUBLISHER_PLATFORM_NM IS NULL 
                AND TGT.PERFORMANCE_DT IS NULL )
              OR 
              ( TGT.ACCOUNT_ID IS DISTINCT FROM CAST(SRC.ACCOUNT_ID AS STRING)
                OR TGT.LINE_ITEM_ID IS DISTINCT FROM CAST(SRC.ADSET_ID AS STRING)
                OR TGT.CAMPAIGN_ID IS DISTINCT FROM CAST(SRC.CAMPAIGN_ID AS STRING)
                OR TGT.IMPRESSIONS_CNT IS DISTINCT FROM SRC.IMPRESSIONS
                OR TGT.CLICKS_CNT IS DISTINCT FROM SRC.CLICKS
                OR TGT.PLATFORM_MEDIA_SPEND_AMT IS DISTINCT FROM CAST(SRC.SPEND AS NUMERIC)
              )             
            )
                   ''';

--//Update transaction begins
SET sql_begin = "BEGIN TRANSACTION";
SET sql_updates = '''--// No updates for this tables 
                 UPDATE ''' || tgt_tbl || ''' as TGT
                    SET  
                   --- audit column updates
                   DW_LAST_EFFECTIVE_TS = TIMESTAMP_SUB(SRC.DW_FIRST_EFFECTIVE_TS, INTERVAL 1 SECOND)
                   ,DW_CURRENT_VERSION_IND = FALSE
                   ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                   ,DW_SOURCE_UPDATE_NM = "FACEBOOK"
                    FROM (SELECT
                                        *
                                        FROM ''' || tgt_wrk_tbl || '''
                                        WHERE DML_TYPE IN ('U')
                          ) SRC 
                        WHERE TGT.AD_ID = SRC.AD_ID
                        AND TGT.PERFORMANCE_DT = SRC.PERFORMANCE_DT
                        AND TGT.PUBLISHER_PLATFORM_NM = SRC.PUBLISHER_PLATFORM_NM
                        AND TGT.SOURCE_APPLICATION_CD = 'FACEBOOK'
                        AND TGT.DW_CURRENT_VERSION_IND = TRUE''';


--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
                        AD_ID
                        ,PERFORMANCE_DT
                        ,PUBLISHER_PLATFORM_NM
                        ,SOURCE_APPLICATION_CD
                        ,DW_FIRST_EFFECTIVE_TS
                        ,DW_LAST_EFFECTIVE_TS
                        ,ACCOUNT_ID
                        ,CAMPAIGN_ID
                        ,LINE_ITEM_ID
                        ,IMPRESSIONS_CNT
                        ,CLICKS_CNT
                        ,PLATFORM_MEDIA_SPEND_AMT
                        ,DW_CREATE_TS
                        ,DW_LAST_UPDATE_TS
                        ,DW_LOGICAL_DELETE_IND
                        ,DW_SOURCE_CREATE_NM
                        ,DW_SOURCE_UPDATE_NM
                        ,DW_CURRENT_VERSION_IND
                        )
                        SELECT 
                            AD_ID
                            ,PERFORMANCE_DT
                            ,PUBLISHER_PLATFORM_NM
                            ,SOURCE_APPLICATION_CD
                            ,DW_FIRST_EFFECTIVE_TS
                            ,DW_LAST_EFFECTIVE_TS
                            ,ACCOUNT_ID
                            ,CAMPAIGN_ID
                            ,LINE_ITEM_ID
                            ,IMPRESSIONS_CNT
                            ,CLICKS_CNT
                            ,PLATFORM_MEDIA_SPEND_AMT
                            ,CURRENT_TIMESTAMP
                            ,CURRENT_TIMESTAMP
                            ,false AS DW_LOGICAL_DELETE_IND
                            ,"FACEBOOK" AS DW_SOURCE_CREATE_NM
                            ,CAST(NULL AS STRING) AS DW_SOURCE_UPDATE_NM  
                            ,TRUE
                        FROM ''' || tgt_wrk_tbl || '''
                        WHERE DML_TYPE IN ('I','U')
                        ''' ;
                        

SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
    EXECUTE IMMEDIATE (sql_begin); 
    IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
        EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
    END IF;       
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    EXECUTE IMMEDIATE (sql_updates);
    EXECUTE IMMEDIATE (sql_inserts);
    SET row_count = @@row_count;
    EXECUTE IMMEDIATE (sql_commit);
    EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Confirmed',CURRENT_DATE(),"AD_PERFORMANCE");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;