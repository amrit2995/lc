CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_META_CREATIVE_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts_history STRING;
DECLARE sql_inserts STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE row_count_tgt INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;
DECLARE lkp_tbl STRING;

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_META_CREATIVE_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.AD_PLATFORM_CREATIVE';
SET tgt_wrk_tbl     = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.AD_PLATFORM_CREATIVE_WRK';        
SET src_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.creative_history';
SET lkp_tbl         = '<<L_PROJECT_ID>>.<<L_DATASET>>.l_3_naming_corrections'; 

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "FACEBOOK" ''' ;

BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;



SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
        CREATIVE_ID
		,CREATIVE_NM
		,ADVERTISER_ID
		,CREATIVE_TYPE_NM
		,CREATIVE_REQUESTED_SZ
		,CREATIVE_VERSION_NBR
		,SOURCE_CREATED_TS
		,SOURCE_LAST_MODIFIED_TS
		,SOURCE_APPLICATION_CD
		,DW_FIRST_EFFECTIVE_TS
		,DW_LAST_EFFECTIVE_TS
        ,DW_LOGICAL_DELETE_IND
        ,DML_TYPE
        )
         SELECT CAST(ID AS STRING) AS CREATIVE_ID
                ,CAST(SRC.NAME AS STRING) AS CREATIVE_NM
				,CAST(SRC.ACCOUNT_ID AS STRING) AS ADVERTISER_ID
				,CAST(SRC.OBJECT_TYPE AS STRING) AS CREATIVE_TYPE_NM
				,CAST(SRC.CREATIVE_REQUESTED_SZ AS STRING) AS CREATIVE_REQUESTED_SZ
				,CAST(SRC.CREATIVE_VERSION_NBR AS STRING) AS CREATIVE_VERSION_NBR
                ,created_time AS SOURCE_CREATED_TS
                ,CAST(SRC.UPDATED_TIME AS TIMESTAMP) AS SOURCE_LAST_MODIFIED_TS
				,"FACEBOOK" AS SOURCE_APPLICATION_CD
                ,TIMESTAMP_TRUNC(CURRENT_TIMESTAMP(),SECOND) AS DW_FIRST_EFFECTIVE_TS
                ,CAST('9999-12-31 00:00:00' AS TIMESTAMP) AS DW_LAST_EFFECTIVE_TS
                ,FALSE AS DW_LOGICAL_DELETE_IND
                ,CASE WHEN TGT.CREATIVE_ID IS NULL  THEN 'I' ELSE 'U' END AS DML_TYPE
		FROM
		(
			SELECT ch.ID, ch.NAME, ch.ACCOUNT_ID, OBJECT_TYPE, CREATED_TIME, UPDATED_TIME, 
				  SPLIT(la.name, '|')[SAFE_OFFSET(16)] AS creative_requested_sz,
				  SPLIT(la.name, '|')[SAFE_OFFSET(7)] AS creative_version_nbr
			FROM ''' || src_tbl || '''  ch
			JOIN 
			(
				SELECT DISTINCT 
					ad.id,
					COALESCE(ac.updated_name, ad.name) AS name,
					ad.account_id,
					ad.ad_set_id,
					ad.campaign_id,
					ad.creative_id,
					ad.created_time, ad.updated_time,_fivetran_synced
				FROM `<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_history` ad
				LEFT JOIN 
				(
					SELECT id, updated_name
					FROM 
					(
					  SELECT DISTINCT id, updated_name,
							 ROW_NUMBER() OVER (PARTITION BY id ORDER BY _fivetran_synced DESC, _row DESC) AS rn
					  FROM ''' || lkp_tbl || '''
					)
					WHERE rn = 1
				) ac ON CAST(ac.id AS STRING) = CAST(ad.id AS STRING)
				  QUALIFY ROW_NUMBER() OVER (PARTITION BY ad.id, account_id, ad_set_id, campaign_id, creative_id  ORDER BY updated_time DESC) = 1
			) la 
				ON ch.id = la.creative_id 
				AND ch.account_id = la.account_id
			WHERE ( ch._fivetran_synced > "''' || data_extract_start_ts || '''"
			or la._fivetran_synced > "''' || data_extract_start_ts || '''" )
			QUALIFY ROW_NUMBER() OVER (PARTITION BY ch.ID ORDER BY ch._fivetran_synced DESC, created_time DESC, updated_time DESC) = 1
		) as SRC
		LEFT JOIN ''' || tgt_tbl || ''' TGT 
			ON CAST(SRC.ID AS STRING) = TGT.CREATIVE_ID
        	AND TGT.DW_CURRENT_VERSION_IND = TRUE
			AND TGT.SOURCE_APPLICATION_CD = 'FACEBOOK'    
        WHERE ID IS NOT NULL
        AND (TGT.CREATIVE_ID IS NULL
            OR ( 
					TGT.CREATIVE_ID IS DISTINCT FROM CAST(SRC.ID AS STRING) OR
					TGT.CREATIVE_NM IS DISTINCT FROM SRC.NAME OR
					TGT.ADVERTISER_ID IS DISTINCT FROM CAST(SRC.ACCOUNT_ID AS STRING) OR
					TGT.CREATIVE_TYPE_NM IS DISTINCT FROM SRC.OBJECT_TYPE OR
					TGT.CREATIVE_REQUESTED_SZ IS DISTINCT FROM SRC.CREATIVE_REQUESTED_SZ OR
					TGT.CREATIVE_VERSION_NBR IS DISTINCT FROM SRC.CREATIVE_VERSION_NBR OR
					TGT.SOURCE_CREATED_TS IS DISTINCT FROM SRC.created_time OR
					TGT.SOURCE_LAST_MODIFIED_TS IS DISTINCT FROM CAST(SRC.UPDATED_TIME AS TIMESTAMP)
            ))''';




--//SCD Type2 transaction begins
SET sql_begin = "BEGIN TRANSACTION";
SET sql_updates = '''--// Processing Updates of Type 2 SCD
                UPDATE ''' || tgt_tbl || ''' as TGT
                    SET  DW_LAST_EFFECTIVE_TS = TIMESTAMP_SUB(SRC.DW_FIRST_EFFECTIVE_TS, INTERVAL 1 SECOND)  
                   ,DW_CURRENT_VERSION_IND = FALSE
                   ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                   ,DW_SOURCE_UPDATE_NM = "FACEBOOK"
                    FROM (SELECT *
                                        FROM ''' || tgt_wrk_tbl || '''
                                        WHERE DML_TYPE = 'U'
                          ) SRC 
                        WHERE TGT.CREATIVE_ID = SRC.CREATIVE_ID
                        AND TGT.SOURCE_APPLICATION_CD = 'FACEBOOK'
                        AND TGT.DW_CURRENT_VERSION_IND = TRUE''';



--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
                        CREATIVE_ID
						,CREATIVE_NM
						,ADVERTISER_ID
						,CREATIVE_TYPE_NM
						,CREATIVE_REQUESTED_SZ
						,CREATIVE_VERSION_NBR
                        ,SOURCE_CREATED_TS
                        ,SOURCE_LAST_MODIFIED_TS
						,SOURCE_APPLICATION_CD
                        ,DW_FIRST_EFFECTIVE_TS
                        ,DW_LAST_EFFECTIVE_TS
                        ,DW_CREATE_TS
                        ,DW_LAST_UPDATE_TS
                        ,DW_LOGICAL_DELETE_IND
                        ,DW_SOURCE_CREATE_NM
                        ,DW_SOURCE_UPDATE_NM
                        ,DW_CURRENT_VERSION_IND
                        )
                        SELECT 
                            CREATIVE_ID
							,CREATIVE_NM
							,ADVERTISER_ID
							,CREATIVE_TYPE_NM
							,CREATIVE_REQUESTED_SZ
							,CREATIVE_VERSION_NBR
                            ,SOURCE_CREATED_TS
                            ,SOURCE_LAST_MODIFIED_TS
							,SOURCE_APPLICATION_CD
                            ,DW_FIRST_EFFECTIVE_TS
                        	,DW_LAST_EFFECTIVE_TS
                        	,CURRENT_TIMESTAMP
                            ,CURRENT_TIMESTAMP
                            ,DW_LOGICAL_DELETE_IND
                            ,"FACEBOOK" AS DW_SOURCE_CREATE_NM
                            ,CAST(null AS STRING) AS DW_SOURCE_UPDATE_NM  
                            ,TRUE
                        FROM ''' || tgt_wrk_tbl  ;
                        

SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
EXECUTE IMMEDIATE (sql_begin);    
    IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
        EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
    END IF;       
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    EXECUTE IMMEDIATE (sql_updates);
    EXECUTE IMMEDIATE (sql_inserts);
	SET row_count = @@row_count;
	EXECUTE IMMEDIATE (sql_commit);
	EXCEPTION WHEN ERROR THEN
	EXECUTE IMMEDIATE (sql_rollback);
	SET job_end  = CURRENT_TIMESTAMP();
	SET status   = "FAILED";
	SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
	RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Confirmed',CURRENT_DATE(),"AD_PLATFORM_CREATIVE");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;