CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_META_AD_VIDEO_ACTION_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts STRING;
DECLARE sql_inserts_history STRING;
DECLARE lkp_tbl STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE row_count_tgt INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;
DECLARE src_values_tbl STRING;
DECLARE src_p25_tbl STRING;
DECLARE src_p50_tbl STRING;
DECLARE src_p75_tbl STRING;
DECLARE src_p100_tbl STRING;

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_META_AD_VIDEO_ACTION_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.AD_VIDEO_ACTION';
SET tgt_wrk_tbl     = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.AD_VIDEO_ACTION_WRK';        
SET src_values_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_play_actions';
SET src_p25_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_25_watched_actions';
SET src_p50_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_50_watched_actions';
SET src_p75_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_75_watched_actions';
SET src_p100_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.facebook_ad_insights_cpg_video_p_100_watched_actions';

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "FACEBOOK" ''' ;

BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;



SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
         VIDEO_ACTION_TYPE_ID
        ,SOURCE_APPLICATION_CD
        ,DW_FIRST_EFFECTIVE_TS
        ,DW_LAST_EFFECTIVE_TS
        ,AD_ID
		,PUBLISHER_PLATFORM_NM
        ,VIDEO_ACTION_DT
        ,VALUE_NBR
        ,DML_TYPE
        )
         SELECT DISTINCT 
                SRC.VIDEO_ACTION_TYPE_ID AS VIDEO_ACTION_TYPE_ID
                ,"FACEBOOK" AS SOURCE_APPLICATION_CD
                ,TIMESTAMP_TRUNC(CURRENT_TIMESTAMP(),SECOND) AS DW_FIRST_EFFECTIVE_TS
                ,CAST('9999-12-31 00:00:00' AS TIMESTAMP) AS DW_LAST_EFFECTIVE_TS
                ,SRC.AD_ID AS AD_ID
				,SRC.PUBLISHER_PLATFORM AS PUBLISHER_PLATFORM_NM
                ,SRC.DATE AS VIDEO_ACTION_DT
                ,CAST(SRC.VALUE AS FLOAT64) AS VALUE_NBR
                ,CASE 
                    WHEN TGT.AD_ID IS NULL THEN 'I' 
                    ELSE 'U' 
                END AS DML_TYPE
	FROM
            (
			select 
			ad_id, 'FACEBOOK' as PUBLISHER_PLATFORM, 1 as video_action_type_id, date, sum(value) as value
			from
			''' || src_values_tbl || ''' a 
			WHERE _fivetran_synced > "''' || data_extract_start_ts || '''" 
			GROUP BY ad_id,date
			UNION ALL
			select 
			ad_id, 'FACEBOOK' as PUBLISHER_PLATFORM, 2 as video_action_type_id, date, sum(value) as value
			from
			''' || src_p25_tbl || ''' b
			WHERE _fivetran_synced > "''' || data_extract_start_ts || '''" 
			GROUP BY ad_id,date			
			UNION ALL
			select 
			ad_id, 'FACEBOOK' as PUBLISHER_PLATFORM, 3 as video_action_type_id, date, sum(value) as value
			from
			''' || src_p50_tbl || ''' b
			WHERE _fivetran_synced > "''' || data_extract_start_ts || '''" 
			GROUP BY ad_id,date			
			UNION ALL
			select 
			ad_id, 'FACEBOOK' as PUBLISHER_PLATFORM, 4 as video_action_type_id, date, sum(value) as value
			from
			''' || src_p75_tbl || ''' b
			WHERE _fivetran_synced > "''' || data_extract_start_ts || '''" 
			GROUP BY ad_id,date			
			UNION ALL
			select 
			ad_id, 'FACEBOOK' as PUBLISHER_PLATFORM, 5 as video_action_type_id, date, sum(value) as value
			from
			''' || src_p100_tbl || ''' b
			WHERE _fivetran_synced > "''' || data_extract_start_ts || '''" 
			GROUP BY ad_id,date			
			) SRC
	LEFT JOIN ''' || tgt_tbl || ''' TGT 
	ON SRC.AD_ID = TGT.AD_ID
        AND SRC.DATE = TGT.VIDEO_ACTION_DT
		AND SRC.VIDEO_ACTION_TYPE_ID = TGT.VIDEO_ACTION_TYPE_ID
        AND TGT.DW_CURRENT_VERSION_IND = TRUE
	    AND TGT.SOURCE_APPLICATION_CD = 'FACEBOOK'
    WHERE SRC.AD_ID IS NOT NULL
        AND SRC.DATE IS NOT NULL
        AND SRC.PUBLISHER_PLATFORM IS NOT NULL
        AND SRC.VIDEO_ACTION_TYPE_ID IS NOT NULL
        AND 
        (
            (
                TGT.AD_ID IS NULL
                AND TGT.VIDEO_ACTION_TYPE_ID IS NULL
                AND TGT.VIDEO_ACTION_DT IS NULL
                AND TGT.PUBLISHER_PLATFORM_NM IS NULL
            )
            OR
            (
                TGT.VALUE_NBR IS DISTINCT FROM CAST(SRC.VALUE AS FLOAT64)
            )
        )
                   ''';


--//Update transaction begins
SET sql_begin = "BEGIN TRANSACTION";
SET sql_updates = '''--// No updates for this tables 
                 UPDATE ''' || tgt_tbl || ''' as TGT
                    SET  
                    --- audit column updates
                   DW_LAST_EFFECTIVE_TS = TIMESTAMP_SUB(SRC.DW_FIRST_EFFECTIVE_TS, INTERVAL 1 SECOND)
                   ,DW_CURRENT_VERSION_IND = FALSE
                   ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                   ,DW_SOURCE_UPDATE_NM = "FACEBOOK"
                    FROM (SELECT
                                        *
                                        FROM ''' || tgt_wrk_tbl || '''
                                        WHERE DML_TYPE IN ('U')
                          ) SRC 
                        WHERE 
                            TGT.VIDEO_ACTION_TYPE_ID = SRC.VIDEO_ACTION_TYPE_ID
                            AND TGT.AD_ID = SRC.AD_ID
                            AND TGT.VIDEO_ACTION_DT = SRC.VIDEO_ACTION_DT
                            AND TGT.PUBLISHER_PLATFORM_NM = SRC.PUBLISHER_PLATFORM_NM
                            AND TGT.SOURCE_APPLICATION_CD = 'FACEBOOK'
                            AND TGT.DW_CURRENT_VERSION_IND = TRUE''';


--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
                        VIDEO_ACTION_TYPE_ID
						,SOURCE_APPLICATION_CD
						,AD_ID
						,PUBLISHER_PLATFORM_NM
						,VIDEO_ACTION_DT
						,VALUE_NBR
                        ,DW_FIRST_EFFECTIVE_TS
                        ,DW_LAST_EFFECTIVE_TS
                        ,DW_CREATE_TS
                        ,DW_LAST_UPDATE_TS
                        ,DW_LOGICAL_DELETE_IND
                        ,DW_SOURCE_CREATE_NM
                        ,DW_SOURCE_UPDATE_NM
                        ,DW_CURRENT_VERSION_IND
                        )
                        SELECT
                            VIDEO_ACTION_TYPE_ID
                            ,SOURCE_APPLICATION_CD
                            ,AD_ID
							,PUBLISHER_PLATFORM_NM
                            ,VIDEO_ACTION_DT
                            ,VALUE_NBR
                            ,DW_FIRST_EFFECTIVE_TS
                            ,DW_LAST_EFFECTIVE_TS 
                            ,CURRENT_TIMESTAMP
                            ,CURRENT_TIMESTAMP
                            ,false AS DW_LOGICAL_DELETE_IND
                            ,"FACEBOOK" AS DW_SOURCE_CREATE_NM
                            ,CAST(NULL AS STRING) AS DW_SOURCE_UPDATE_NM
                            ,TRUE
                        FROM ''' || tgt_wrk_tbl || '''
                        WHERE DML_TYPE IN ('I','U') 
                        ''' ;
                        

SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
    EXECUTE IMMEDIATE (sql_begin);
    IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
        EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
    END IF;       
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    EXECUTE IMMEDIATE (sql_updates);
    EXECUTE IMMEDIATE (sql_inserts);
    SET row_count = @@row_count;
    EXECUTE IMMEDIATE (sql_commit);
    EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Confirmed',CURRENT_DATE(),"AD_VIDEO_ACTION");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;