CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_META_LINE_ITEM_CREATIVE_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE tgt_update_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts_history STRING;
DECLARE sql_inserts STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_records_to_expire STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE row_count_tgt INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;


SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_META_LINE_ITEM_CREATIVE_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.LINE_ITEM_CREATIVE';
SET tgt_wrk_tbl     = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.LINE_ITEM_CREATIVE_WRK';
SET tgt_update_tbl  = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.LINE_ITEM_CREATIVE_LR_UPDATE';        
SET src_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_history';


SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "FACEBOOK" ''' ;


BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
        AD_ID
		,CREATIVE_ID
		,LINE_ITEM_ID
        ,DW_FIRST_EFFECTIVE_TS
        ,DW_LAST_EFFECTIVE_TS
		,CAMPAIGN_ID
		,ADVERTISER_ID
		,STATUS_NM
		,SOURCE_CREATED_TS
		,SOURCE_LAST_MODIFIED_TS
		,SOURCE_APPLICATION_CD
        ,DW_CURRENT_VERSION_IND
        )
         
        SELECT 
            SRC.AD_ID
            ,SRC.CREATIVE_ID
            ,SRC.LINE_ITEM_ID
            ,SRC.DW_FIRST_EFFECTIVE_TS
            ,CASE 
                WHEN SRC.DW_FIRST_EFFECTIVE_TS = SRC.DW_LAST_EFFECTIVE_TS THEN '9999-12-31 00:00:00' 
                ELSE TIMESTAMP_SUB(SRC.DW_LAST_EFFECTIVE_TS, INTERVAL 1 SECOND) 
                END AS DW_LAST_EFFECTIVE_TS
            ,SRC.CAMPAIGN_ID
            ,SRC.ADVERTISER_ID
            ,SRC.STATUS_NM
            ,SRC.SOURCE_CREATED_TS
            ,SRC.SOURCE_LAST_MODIFIED_TS
            ,SRC.SOURCE_APPLICATION_CD
            ,CASE WHEN SRC.DW_FIRST_EFFECTIVE_TS = SRC.DW_LAST_EFFECTIVE_TS THEN TRUE ELSE FALSE END AS DW_CURRENT_VERSION_IND
         
         FROM
         (
            SELECT CAST(ID AS STRING) AS AD_ID
                ,CAST(SRC.CREATIVE_ID AS STRING) AS CREATIVE_ID
                ,CAST(SRC.AD_SET_ID AS STRING) AS LINE_ITEM_ID
                ,CAST(SRC.CAMPAIGN_ID AS STRING) AS CAMPAIGN_ID
                ,CAST(SRC.ACCOUNT_ID AS STRING) as ADVERTISER_ID
                ,CAST(SRC.STATUS AS STRING) AS STATUS_NM
                ,created_time AS SOURCE_CREATED_TS
                ,CAST(SRC.UPDATED_TIME AS TIMESTAMP) AS SOURCE_LAST_MODIFIED_TS
                ,CAST(SRC.UPDATED_TIME AS TIMESTAMP) AS DW_FIRST_EFFECTIVE_TS
                ,LAST_VALUE(UPDATED_TIME) OVER (record_window) AS DW_LAST_EFFECTIVE_TS
				,"FACEBOOK" AS SOURCE_APPLICATION_CD
            FROM
                    ''' || src_tbl || ''' SRC
            WHERE 
                _fivetran_synced > "''' || data_extract_start_ts || '''"
                AND SRC.ID IS NOT NULL
                AND SRC.CREATIVE_ID IS NOT NULL
                AND SRC.AD_SET_ID IS NOT NULL
                AND SRC.UPDATED_TIME IS NOT NULL
            WINDOW  record_window AS (PARTITION BY ID, CREATIVE_ID, AD_SET_ID ORDER BY updated_time ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        ) AS SRC
        
        LEFT JOIN ''' || tgt_tbl || ''' TGT 
            ON SRC.AD_ID = TGT.AD_ID 
            AND SRC.LINE_ITEM_ID = TGT.LINE_ITEM_ID 
            AND SRC.CREATIVE_ID = TGT.CREATIVE_ID
            AND TGT.DW_CURRENT_VERSION_IND = TRUE
            AND SRC.SOURCE_APPLICATION_CD = TGT.SOURCE_APPLICATION_CD
        WHERE 
            TGT.AD_ID IS NULL 
            OR SRC.DW_FIRST_EFFECTIVE_TS > TGT.DW_FIRST_EFFECTIVE_TS
        ''';




--//SCD Type2 transaction begins
SET sql_begin = "BEGIN TRANSACTION";

SET sql_records_to_expire = '''INSERT INTO ''' || tgt_update_tbl || ''' 
                            (
                            AD_ID,
                            LINE_ITEM_ID,
                            CREATIVE_ID,
                            SOURCE_APPLICATION_CD,
                            DW_FIRST_EFFECTIVE_TS,
                            DW_LAST_EFFECTIVE_TS,
                            DW_CURRENT_VERSION_IND
                            )
                            SELECT  
                                TGT.AD_ID
                                ,TGT.LINE_ITEM_ID
                                ,TGT.CREATIVE_ID
                                ,TGT.source_application_cd
                                ,TGT.dw_first_effective_ts
                                ,TIMESTAMP_SUB(SRC.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts
                                ,FALSE AS dw_current_version_ind
                            FROM    ''' || tgt_tbl || '''  TGT
                            INNER  JOIN (
                                SELECT *
                                FROM    ''' || tgt_wrk_tbl || ''' 
                                QUALIFY ROW_NUMBER() OVER (PARTITION BY AD_ID, CREATIVE_ID, LINE_ITEM_ID, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
                            ) SRC
                            ON      SRC.CREATIVE_ID = TGT.CREATIVE_ID
                            AND     SRC.AD_ID = TGT.AD_ID
                            AND		SRC.LINE_ITEM_ID = TGT.LINE_ITEM_ID
                            AND     SRC.source_application_cd = TGT.source_application_cd
                            WHERE   TGT.dw_current_version_ind = TRUE
''';

SET sql_updates = '''--// Processing Updates of Type 2 SCD
                UPDATE ''' || tgt_tbl || ''' as TGT
                    SET  DW_LAST_EFFECTIVE_TS = SRC.DW_LAST_EFFECTIVE_TS  
                   ,DW_CURRENT_VERSION_IND = FALSE
                   ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                   ,DW_SOURCE_UPDATE_NM = "FACEBOOK"
                    FROM (
                          SELECT * FROM ''' || tgt_update_tbl || '''
                          QUALIFY ROW_NUMBER() OVER (PARTITION BY AD_ID,LINE_ITEM_ID,CREATIVE_ID, SOURCE_APPLICATION_CD, DW_FIRST_EFFECTIVE_TS ORDER BY DW_LAST_EFFECTIVE_TS ASC) = 1
                        ) SRC
                    WHERE TGT.AD_ID = SRC.AD_ID
						AND TGT.LINE_ITEM_ID = SRC.LINE_ITEM_ID
						AND TGT.CREATIVE_ID = SRC.CREATIVE_ID
                        AND TGT.SOURCE_APPLICATION_CD = SRC.SOURCE_APPLICATION_CD
                        AND TGT.DW_FIRST_EFFECTIVE_TS = SRC.DW_FIRST_EFFECTIVE_TS
                        ''';



--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
                        AD_ID
						,CREATIVE_ID
						,LINE_ITEM_ID
						,CAMPAIGN_ID
						,ADVERTISER_ID
						,STATUS_NM
                        ,SOURCE_CREATED_TS
                        ,SOURCE_LAST_MODIFIED_TS
						,SOURCE_APPLICATION_CD
                        ,DW_FIRST_EFFECTIVE_TS
                        ,DW_LAST_EFFECTIVE_TS
                        ,DW_CREATE_TS
                        ,DW_LAST_UPDATE_TS
                        ,DW_LOGICAL_DELETE_IND
                        ,DW_SOURCE_CREATE_NM
                        ,DW_SOURCE_UPDATE_NM
                        ,DW_CURRENT_VERSION_IND
                        )
                        SELECT 
                            AD_ID
							,CREATIVE_ID
							,LINE_ITEM_ID
							,CAMPAIGN_ID
							,ADVERTISER_ID
							,STATUS_NM
                            ,SOURCE_CREATED_TS
                            ,SOURCE_LAST_MODIFIED_TS
							,SOURCE_APPLICATION_CD
                            ,DW_FIRST_EFFECTIVE_TS
                            ,DW_LAST_EFFECTIVE_TS 
                            ,CURRENT_TIMESTAMP
                            ,CURRENT_TIMESTAMP
                            ,FALSE AS DW_LOGICAL_DELETE_IND
                            ,"FACEBOOK" AS DW_SOURCE_CREATE_NM
                            ,"FACEBOOK" AS DW_SOURCE_UPDATE_NM  
                            ,DW_CURRENT_VERSION_IND
                        FROM ''' || tgt_wrk_tbl  ;
                        

SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
EXECUTE IMMEDIATE (sql_begin);       
    IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
        EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
    END IF;       
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    EXECUTE IMMEDIATE (sql_records_to_expire);
    EXECUTE IMMEDIATE (sql_updates);
    EXECUTE IMMEDIATE (sql_inserts);
    SET row_count = @@row_count;
    EXECUTE IMMEDIATE (sql_commit);
    EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Confirmed',CURRENT_DATE(),"LINE_ITEM_CREATIVE");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;