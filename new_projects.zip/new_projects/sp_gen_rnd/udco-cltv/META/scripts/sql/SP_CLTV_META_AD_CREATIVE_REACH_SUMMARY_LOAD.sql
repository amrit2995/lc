CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_META_AD_CREATIVE_REACH_SUMMARY_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;


SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_META_AD_CREATIVE_REACH_SUMMARY_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.AD_CREATIVE_REACH_SUMMARY';
SET tgt_wrk_tbl     = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.AD_CREATIVE_REACH_SUMMARY_WRK';        
SET src_tbl         = '<<SOURCE_PROJECT_ID>>.<<META_SRC_DATASET>>.ad_reach';


SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "FACEBOOK" ''' ;

BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
          ad_id
          ,source_last_modified_ts
          ,dw_first_effective_ts
          ,dw_last_effective_ts
          ,reach_cnt
          ,impressions_cnt
          ,source_application_cd
          ,DML_TYPE
        )
	
        SELECT DISTINCT 		
                SRC.ad_id AS ad_id
                ,CAST(SRC.DATE AS TIMESTAMP) AS source_last_modified_ts
                ,TIMESTAMP_TRUNC(CURRENT_TIMESTAMP(),SECOND) AS DW_FIRST_EFFECTIVE_TS
                ,CAST('9999-12-31 00:00:00' AS TIMESTAMP) AS DW_LAST_EFFECTIVE_TS
                ,reach AS reach_cnt
                ,impressions AS impressions_cnt
                ,"FACEBOOK" AS source_application_cd
                ,CASE WHEN TGT.ad_id IS NULL  THEN 'I' ELSE 'U' END AS DML_TYPE
        FROM
            ''' || src_tbl || ''' SRC
	LEFT JOIN ''' || tgt_tbl || ''' TGT 
	        ON SRC.ad_id = TGT.ad_id
                AND TGT.source_last_modified_ts = CAST(SRC.DATE AS TIMESTAMP) 
                AND TGT.DW_CURRENT_VERSION_IND = TRUE
                AND TGT.SOURCE_APPLICATION_CD = 'FACEBOOK'
        WHERE   _fivetran_synced > "''' || data_extract_start_ts || '''" 
                AND SRC.ad_id IS NOT NULL 
                AND SRC.DATE IS NOT NULL
                AND (  
                        TGT.ad_id IS NULL 
                         OR
                        (       
                                IFNULL(TGT.reach_cnt,-1) <> IFNULL(SRC.reach,-1)
                                OR IFNULL(TGT.impressions_cnt,-1) <> IFNULL(SRC.impressions,-1)
                        )
                    )
                ''';

BEGIN
EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


--// Processing Inserts
SET sql_begin = "BEGIN TRANSACTION";

SET sql_updates = '''--// Processing Updates of Type 2 SCD
                UPDATE ''' || tgt_tbl || ''' as TGT
                    SET  DW_LAST_EFFECTIVE_TS = TIMESTAMP_SUB(SRC.DW_FIRST_EFFECTIVE_TS, INTERVAL 1 SECOND)  
                   ,DW_CURRENT_VERSION_IND = FALSE
                   ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                   ,DW_SOURCE_UPDATE_NM = "FACEBOOK"
                    FROM (SELECT
                                        *
                                        FROM ''' || tgt_wrk_tbl || '''
                                        WHERE DML_TYPE = 'U'
                          ) SRC 
                        WHERE TGT.AD_ID = SRC.AD_ID
                        AND TGT.source_last_modified_ts = SRC.source_last_modified_ts
                        AND TGT.SOURCE_APPLICATION_CD = SRC.SOURCE_APPLICATION_CD
                        AND TGT.DW_CURRENT_VERSION_IND = TRUE''';


SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
	( 
	      ad_id
              ,source_last_modified_ts
              ,Dw_first_effective_ts
              ,Dw_last_effective_ts
              ,reach_cnt
              ,impressions_cnt
              ,source_application_cd
              ,dw_create_ts
              ,dw_last_update_ts
              ,dw_logical_delete_ind
              ,dw_source_create_nm
              ,dw_source_update_nm
              ,dw_current_version_ind
	)
		SELECT 
		ad_id
                ,source_last_modified_ts
                ,Dw_first_effective_ts
                ,Dw_last_effective_ts
                ,reach_cnt
                ,impressions_cnt
                ,source_application_cd
                ,CURRENT_TIMESTAMP AS dw_create_ts
                ,CURRENT_TIMESTAMP AS dw_last_update_ts
                ,FALSE  AS dw_logical_delete_ind
                ,"FACEBOOK" as dw_source_create_nm
                ,"FACEBOOK" AS dw_source_update_nm
                ,TRUE  AS dw_current_version_ind 
         FROM ''' || tgt_wrk_tbl  ;
                        
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
EXECUTE IMMEDIATE (sql_begin);       
IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
        EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
    END IF;   
EXECUTE IMMEDIATE (sql_updates);    
EXECUTE IMMEDIATE (sql_inserts);
SET row_count = @@row_count;
EXECUTE IMMEDIATE (sql_commit);
EXCEPTION WHEN ERROR THEN
EXECUTE IMMEDIATE (sql_rollback);
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Confirmed',CURRENT_DATE(),"AD_CREATIVE_REACH_SUMMARY");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;
