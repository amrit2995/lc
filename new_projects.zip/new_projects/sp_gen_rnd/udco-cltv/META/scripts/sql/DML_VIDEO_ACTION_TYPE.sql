TRUNCATE TABLE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.video_action_type`;

INSERT INTO `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.video_action_type` (
  video_action_type_id,
  video_action_cd,
  video_action_code_dsc,
  source_application_cd,
  dw_create_ts,
  dw_last_update_ts,
  dw_logical_delete_ind,
  dw_source_create_nm,
  dw_source_update_nm,
  dw_current_version_ind
  )
VALUES
  (1, 'play','video play action', 'FACEBOOK', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (2, 'p25','25% watched', 'FACEBOOK', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (3, 'p50','50% watched', 'FACEBOOK', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (4, 'p75','75% watched', 'FACEBOOK', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE),
  (5, 'p100','100% watched', 'FACEBOOK', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), FALSE, NULL, NULL, TRUE)
;