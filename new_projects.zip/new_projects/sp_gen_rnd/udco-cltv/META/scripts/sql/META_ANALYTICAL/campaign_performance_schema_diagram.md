---
title: FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE - Detailed Schema & Data Flow
---

## Entity Relationship Diagram

![ER Diagram](campaign_performance_er_diagram.mmd)

## Data Flow Diagram

![Data Flow Diagram](campaign_performance_data_flow.mmd)

---

## Platform-Specific Transformation Details

![Transformation Details](campaign_performance_transformations.mmd)