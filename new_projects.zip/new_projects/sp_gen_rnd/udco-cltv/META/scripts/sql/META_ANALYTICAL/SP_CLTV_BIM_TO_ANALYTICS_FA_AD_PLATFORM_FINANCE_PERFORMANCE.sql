CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_FA_AD_PLATFORM_FINANCE_PERFORMANCE`(job_id STRING)
BEGIN
SET @@query_label = "<<SP_LABEL>>, spname:sp_cltv_bim_to_analytics_fa_ad_platform_finance_performance";
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_BIM_TO_ANALYTICS_FA_AD_PLATFORM_FINANCE_PERFORMANCE'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.analytical_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
                        FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.FA_AD_PLATFORM_FINANCE_PERFORMANCE';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.FA_AD_PLATFORM_FINANCE_PERFORMANCE_WRK';        

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

-- Build staging table with finance performance metrics
SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
        DATE
        ,PLATFORM
        ,LINE_ITEM_ID
        ,CAMPAIGN_ID
        ,ADVERTISER_ID
        ,OPPORTUNITY_ID
        ,HUB_L2_ID
        ,MEDIA_CAMPAIGN_ID
        ,PLATFORM_IMPRESSIONS
        ,PLATFORM_CLICKS
        ,PLATFORM_MEDIA_SPEND_AMT
        ,VIDEO_TRUEVIEW_CNT
        ,HUB_L2_CPG_CPM
        ,HUB_L2_PLANNED_IMPS
        )
        WITH line_item_hierarchy AS (
            -- CTE: Line item to OMS mapping for META and PINTEREST only
            -- Join path: ad_platform_line_item → ad_platform_campaign → buying_line_item → oms_media_campaign_line_item → oms_media_campaign
            SELECT DISTINCT
                apli.line_item_id,
                apli.source_application_cd,
                apli.campaign_id,
                apc.advertiser_id,
                bli.media_campaign_line_item_id AS hub_l2_id,
                omcli.media_campaign_id,
                omc.opportunity_id,
                omcli.effective_cost_per_thousand_impressions_amt AS cpg_cpm_amt,
                omcli.booking_qty AS planned_impression_cnt
            FROM `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_line_item` apli
            LEFT JOIN `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_campaign` apc
                ON apc.campaign_id = apli.campaign_id
                AND apc.source_application_cd = apli.source_application_cd
                AND apc.dw_current_version_ind = TRUE
            LEFT JOIN `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.buying_line_item` bli
                ON bli.ad_platform_line_item_id = apli.line_item_id
                AND bli.dw_current_version_ind = TRUE
            LEFT JOIN `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.oms_media_campaign_line_item` omcli
                ON omcli.media_campaign_line_item_id = bli.media_campaign_line_item_id
                AND omcli.dw_current_version_ind = TRUE
            LEFT JOIN `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.oms_media_campaign` omc
                ON omc.media_campaign_id = omcli.media_campaign_id
                AND omc.dw_current_version_ind = TRUE
            WHERE apli.dw_current_version_ind = TRUE
        )
        
        SELECT 
            date, 
            platform,
            line_item_id, 
            campaign_id, 
            advertiser_id,
            opportunity_id,
            hub_l2_id,
            media_campaign_id,
            CAST(SUM(COALESCE(platform_impressions, 0)) AS NUMERIC) AS platform_impressions, 
            CAST(SUM(COALESCE(platform_clicks, 0)) AS NUMERIC) AS platform_clicks, 
            CAST(SUM(COALESCE(platform_media_spend_amt, 0)) AS NUMERIC) AS platform_media_spend_amt,
            CAST(SUM(COALESCE(video_trueview_cnt, 0)) AS NUMERIC) AS video_trueview_cnt,
            CAST(MAX(COALESCE(hub_l2_cpg_cpm, 0)) AS NUMERIC) AS hub_l2_cpg_cpm,
            CAST(MAX(COALESCE(hub_l2_planned_imps, 0)) AS NUMERIC) AS hub_l2_planned_imps
        FROM (
            -- Ad Performance metrics from META and PINTEREST only
            SELECT 
                ap.performance_dt AS date,
                ap.source_application_cd AS platform,
                COALESCE(ap.line_item_id, 'N/A') AS line_item_id, 
                COALESCE(ap.campaign_id, 'N/A') AS campaign_id, 
                COALESCE(lih.advertiser_id, 'N/A') AS advertiser_id,
                COALESCE(lih.opportunity_id, 'N/A') AS opportunity_id,
                lih.hub_l2_id,
                lih.media_campaign_id,
                ap.impressions_cnt AS platform_impressions, 
                ap.clicks_cnt AS platform_clicks, 
                ap.platform_media_spend_amt AS platform_media_spend_amt,
                0 AS video_trueview_cnt,
                COALESCE(lih.cpg_cpm_amt, 0) AS hub_l2_cpg_cpm,
                COALESCE(lih.planned_impression_cnt, 0) AS hub_l2_planned_imps
            FROM `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_performance` ap
            LEFT JOIN line_item_hierarchy lih
                ON lih.line_item_id = ap.line_item_id
                AND lih.campaign_id = ap.campaign_id
                AND lih.source_application_cd = ap.source_application_cd
            WHERE ap.dw_current_version_ind = TRUE
            AND ap.source_application_cd IN ('FACEBOOK', 'PINTEREST')
            AND ap.dw_last_update_ts >= TIMESTAMP("''' || FORMAT_TIMESTAMP("%Y-%m-%d %H:%M:%S", data_extract_start_ts) || '''")
        )
        GROUP BY date, platform, line_item_id, campaign_id, advertiser_id, opportunity_id, hub_l2_id, media_campaign_id
        ''';

--//transaction begins
SET sql_begin = "BEGIN TRANSACTION";

--// Processing Inserts into Final Table with Billable Impressions calculation
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
        PERFORMANCE_DAY_ID
        ,AD_MEDIA_PLATFORM_D1_SK
        ,AD_MEDIA_CAMPAIGN_D1_SK
        ,AD_MEDIA_CAMPAIGN_LINE_D1_SK
        ,AD_MEDIA_OPPORTUNITY_D1_SK
        ,PLATFORM_ADVERTISER_D1_SK
        ,PLATFORM_MEDIA_CAMPAIGN_D1_SK
        ,PLATFORM_MEDIA_LINE_D1_SK
        ,AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK
        ,TOTAL_CLICK_CNT
        ,TOTAL_IMPRESSION_CNT
        ,TOTAL_MEDIA_SPEND_AMT
        ,VIDEO_TRUEVIEW_CNT
        ,CPG_MEDIA_SPEND_AMT
        ,BILLABLE_IMPRESSION_CNT
        ,BILLABLE_CPG_MEDIA_SPEND_AMT
        ,DW_CREATE_TS
        ,DW_LAST_UPDATE_TS
                        )
WITH finance_performance_initial AS (
    SELECT metrics.*
    FROM ''' || tgt_wrk_tbl || ''' AS metrics
),

calculated_l2_billable_impressions AS (
    SELECT
        hub_l2_id,
        date,
        CASE
            WHEN running_impressions_thru_yesterday >= hub_l2_planned_imps THEN 0
            WHEN running_impressions_thru_yesterday < hub_l2_planned_imps
                AND (running_impressions_thru_yesterday + platform_impressions) <= hub_l2_planned_imps 
                THEN platform_impressions
            WHEN running_impressions_thru_yesterday < hub_l2_planned_imps 
                AND (running_impressions_thru_yesterday + platform_impressions) >= hub_l2_planned_imps 
                THEN hub_l2_planned_imps - running_impressions_thru_yesterday
            ELSE NULL
        END AS calculated_l2_billable_impressions
    FROM (
        SELECT
            hub_l2_id,
            date,
            hub_l2_planned_imps,
            IFNULL(
                SUM(platform_impressions) OVER (
                    PARTITION BY hub_l2_id 
                    ORDER BY date ASC 
                    ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
                ), 0
            ) AS running_impressions_thru_yesterday,
            platform_impressions
        FROM (
            SELECT
                hub_l2_id,
                date,
                MAX(hub_l2_planned_imps) AS hub_l2_planned_imps,
                SUM(platform_impressions) AS platform_impressions
            FROM finance_performance_initial
            GROUP BY 1, 2
        )
    )
)

SELECT 
    CAST(dfd.FISCAL_DAY_ID AS NUMERIC) AS PERFORMANCE_DAY_ID
    ,CAST(CASE WHEN damp.PLATFORM_CD IS NOT NULL THEN damp.AD_MEDIA_PLATFORM_D1_SK ELSE -1 END AS NUMERIC) AS AD_MEDIA_PLATFORM_D1_SK
    ,CAST(CASE WHEN damc.AD_CAMPAIGN_ID IS NOT NULL THEN damc.AD_MEDIA_CAMPAIGN_D1_SK ELSE -1 END AS NUMERIC) AS AD_MEDIA_CAMPAIGN_D1_SK
    ,CAST(CASE WHEN damcl.AD_LINE_ID IS NOT NULL THEN damcl.AD_MEDIA_CAMPAIGN_LINE_D1_SK ELSE -1 END AS NUMERIC) AS AD_MEDIA_CAMPAIGN_LINE_D1_SK
    ,CAST(CASE WHEN damo.AD_MEDIA_OPPORTUNITY_ID IS NOT NULL THEN damo.AD_MEDIA_OPPORTUNITY_D1_SK ELSE -1 END AS NUMERIC) AS AD_MEDIA_OPPORTUNITY_D1_SK
    ,CAST(CASE WHEN dpa.PLATFORM_ADVERTISER_ID IS NOT NULL THEN dpa.PLATFORM_ADVERTISER_D1_SK ELSE -1 END AS NUMERIC) AS PLATFORM_ADVERTISER_D1_SK
    ,CAST(CASE WHEN dpmc.PLATFORM_CAMPAIGN_ID IS NOT NULL THEN dpmc.PLATFORM_MEDIA_CAMPAIGN_D1_SK ELSE -1 END AS NUMERIC) AS PLATFORM_MEDIA_CAMPAIGN_D1_SK
    ,CAST(CASE WHEN dpml.PLATFORM_LINE_ITEM_ID IS NOT NULL THEN dpml.PLATFORM_MEDIA_LINE_D1_SK ELSE -1 END AS NUMERIC) AS PLATFORM_MEDIA_LINE_D1_SK
    ,CAST(COALESCE(dpc.AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK, -1) AS NUMERIC) AS AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK
    ,CAST(metrics.PLATFORM_CLICKS AS NUMERIC) AS TOTAL_CLICK_CNT
    ,CAST(metrics.PLATFORM_IMPRESSIONS AS NUMERIC) AS TOTAL_IMPRESSION_CNT
    ,metrics.PLATFORM_MEDIA_SPEND_AMT AS TOTAL_MEDIA_SPEND_AMT
    ,CAST(metrics.VIDEO_TRUEVIEW_CNT AS NUMERIC) AS VIDEO_TRUEVIEW_CNT
    ,ROUND(CAST(metrics.PLATFORM_IMPRESSIONS AS NUMERIC) * metrics.HUB_L2_CPG_CPM / 1000, 2) AS CPG_MEDIA_SPEND_AMT
    ,CAST(IFNULL(billable.calculated_l2_billable_impressions, 0) AS NUMERIC) AS BILLABLE_IMPRESSION_CNT
    ,ROUND(CAST(IFNULL(billable.calculated_l2_billable_impressions, 0) AS NUMERIC) * metrics.HUB_L2_CPG_CPM / 1000, 2) AS BILLABLE_CPG_MEDIA_SPEND_AMT
    ,CURRENT_TIMESTAMP() AS DW_CREATE_TS
    ,CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
FROM finance_performance_initial AS metrics
LEFT JOIN calculated_l2_billable_impressions AS billable
    ON billable.hub_l2_id = metrics.hub_l2_id
    AND billable.date = metrics.date

-- Platform dimension lookups
LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_ADVERTISER AS dpa
    ON dpa.PLATFORM_ADVERTISER_ID = metrics.advertiser_id
    AND dpa.PLATFORM_CD = metrics.platform
LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CAMPAIGN AS dpmc
    ON dpmc.PLATFORM_CAMPAIGN_ID = metrics.campaign_id
    AND dpmc.PLATFORM_CD = metrics.platform
LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_LINE AS dpml
    ON dpml.PLATFORM_LINE_ITEM_ID = metrics.line_item_id
    AND dpml.PLATFORM_CD = metrics.platform

-- Ad Media dimension lookups
LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN AS damc
    ON damc.AD_CAMPAIGN_ID = metrics.media_campaign_id
LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN_LINE AS damcl
    ON damcl.AD_LINE_ID = metrics.hub_l2_id
LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM AS damp
    ON damp.PLATFORM_CD = metrics.platform
LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_OPPORTUNITY AS damo
    ON damo.AD_MEDIA_OPPORTUNITY_ID = metrics.opportunity_id

-- Promotional Channel dimension lookup
LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PROMOTIONAL_CHANNEL AS dpc
    ON dpc.PLATFORM_PROMOTIONAL_CHANNEL_CD = 'Social'

-- Date dimension lookup
JOIN <<CLTV_VIEW_PROJECT_ID>>.<<CALENDAR_DATASET>>.D0_FISCAL_DAY AS dfd
    ON metrics.date = dfd.CALENDAR_DT
    ''';

SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
EXECUTE IMMEDIATE (sql_begin);       
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    EXECUTE IMMEDIATE (sql_inserts);
    SET row_count = @@row_count;
    EXECUTE IMMEDIATE (sql_commit);
    EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
END;

--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','analytical',CURRENT_DATE(),"FA_AD_PLATFORM_FINANCE_PERFORMANCE");

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;
END;