CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_D1_PLATFORM_MEDIA_PLACEMENT`(job_id STRING)
BEGIN

  DECLARE sql_begin STRING;
  DECLARE sql_commit STRING;
  DECLARE sql_rollback STRING;
  DECLARE sql_truncate_tgt_tbl STRING;
  DECLARE sql_insert_full_load STRING;
  DECLARE sql_max_audit_ts STRING;

  DECLARE tgt_tbl STRING;
  DECLARE prcs_audit_tbl STRING;
  DECLARE proc_name STRING;
  DECLARE job_start TIMESTAMP;
  DECLARE job_end TIMESTAMP;
  DECLARE data_extract_start_ts TIMESTAMP;
  DECLARE data_extract_end_ts TIMESTAMP;
  DECLARE max_audit_ts TIMESTAMP;
  DECLARE row_count INT64 DEFAULT 0;
  DECLARE record_count INT64 DEFAULT 0;
  DECLARE status STRING;
  DECLARE err_desc STRING;


  SET sql_begin = "BEGIN TRANSACTION";
  SET sql_commit   = "COMMIT TRANSACTION";
  SET sql_rollback = "ROLLBACK TRANSACTION";

  SET job_start = CURRENT_TIMESTAMP();
  SET err_desc  = ''' ''';
  SET status    = '''RUNNING''';
  SET proc_name = '''SP_CLTV_BIM_TO_ANALYTICS_D1_PLATFORM_MEDIA_PLACEMENT'''; 
  SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.ANALYTICAL_PROCESS_AUDIT_CONTROL'; 
  SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
  					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

  EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
  SET data_extract_start_ts = max_audit_ts;
  SET data_extract_end_ts=CURRENT_TIMESTAMP();

  /* Audit entry for RUNNING */
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

  SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_PLACEMENT';


  SET sql_truncate_tgt_tbl = '''TRUNCATE TABLE ''' || tgt_tbl ;

  SET sql_insert_full_load = FORMAT("""
          INSERT INTO `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_PLACEMENT`
          SELECT 
          -1 AS PLATFORM_MEDIA_PLACEMENT_D1_SK,
          'N/A' AS PLATFORM_CD,
          'N/A' AS PLATFORM_MEDIA_PLACEMENT_ID,
          'N/A' AS PLATFORM_MEDIA_PLACEMENT_NM,
          'N/A' AS PLATFORM_MEDIA_PAGE_TYPE_CD,
          CURRENT_TIMESTAMP() AS DW_CREATE_TS,
  	      CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
          """);
    BEGIN
      EXECUTE IMMEDIATE (sql_begin);
	  IF max_audit_ts = "0001-01-01 01:01:01 UTC" THEN
      EXECUTE IMMEDIATE (sql_truncate_tgt_tbl);
      EXECUTE IMMEDIATE (sql_insert_full_load);
      SET record_count = @@row_count;
	  END IF;

  	  EXECUTE IMMEDIATE (sql_commit);
  	  SET row_count = row_count + record_count;

    EXCEPTION WHEN ERROR THEN
      EXECUTE IMMEDIATE (sql_rollback);
      SET job_end  = CURRENT_TIMESTAMP();
      SET status   = "FAILED";
      SET err_desc = "FULL LOAD FOR TARGET TABLE - "|| tgt_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
      CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
      RAISE USING message = err_desc;
    END;

--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','analytical',CURRENT_DATE(),"D1_PLATFORM_MEDIA_PLACEMENT");

    SET job_end = CURRENT_TIMESTAMP();
    SET status  = "COMPLETED";
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

END;

