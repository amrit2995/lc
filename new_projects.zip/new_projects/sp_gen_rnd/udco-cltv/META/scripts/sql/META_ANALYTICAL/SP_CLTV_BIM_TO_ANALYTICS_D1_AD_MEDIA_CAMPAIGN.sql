CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN`(job_id STRING)

BEGIN

	DECLARE row_count INT64;
	DECLARE status STRING;
	DECLARE cur_db STRING;
	DECLARE env STRING;
	DECLARE anl_db STRING;
	DECLARE anl_schema STRING;
	DECLARE anl_wrk_schema STRING;
	DECLARE cnf_db STRING;
	DECLARE cnf_schema STRING;
	DECLARE src_tbl STRING;
	DECLARE tgt_wrk_tbl STRING;
	DECLARE tgt_tbl STRING;
	DECLARE oms_camp_tbl STRING;
	DECLARE oms_camp_li_tbl STRING;
	DECLARE com_prom_tbl STRING;
	DECLARE sql_truncate_tgt_wrk_tbl STRING;
	DECLARE err_desc STRING;
	DECLARE sql_crt_tgt_wrk_tbl STRING;
	DECLARE sql_begin STRING;
	DECLARE sql_inserts STRING;
	DECLARE sql_updates STRING;
	DECLARE sql_commit STRING;
	DECLARE sql_rollback STRING;
	DECLARE proc_name STRING;
	DECLARE job_start TIMESTAMP;
	DECLARE job_end TIMESTAMP;
	DECLARE data_extract_start_ts TIMESTAMP;
	DECLARE data_extract_end_ts TIMESTAMP;
	DECLARE prcs_audit_tbl STRING;
	DECLARE sql_max_audit_ts STRING;
	DECLARE max_audit_ts TIMESTAMP;
	DECLARE sql_max_sk STRING;
	DECLARE sql_inserts_default STRING;
	DECLARE sql_truncate_tgt_tbl STRING;
	DECLARE max_sk NUMERIC;

	--set @@query_label="<<SP_LABEL>>,spname:sp_cltv_bim_to_analytics_d1_advertiser_platform";

	SET prcs_audit_tbl = '''<<TABLE_PROJECT_ID>>''' || '''.''' || '''<<AUDIT_DATASET>>''' || '''.ANALYTICAL_PROCESS_AUDIT_CONTROL''';

	SET job_start = CURRENT_TIMESTAMP();
	SET err_desc = ''' ''';
	SET status = '''RUNNING''';
	SET proc_name='''SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN''';  
	SET sql_max_audit_ts='''select IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) from ''' || prcs_audit_tbl ||''' where lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';


	EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
	SET data_extract_start_ts=max_audit_ts;
	SET data_extract_end_ts=CURRENT_TIMESTAMP();

	/* Audit entry for RUNNING */
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);


	SET anl_schema = '''<<ANALYTIC_DATASET>>''';
	SET anl_wrk_schema = '''<<REF_DATASET>>''';
	SET cnf_schema = '''<<CONF_DATASET>>''';
		
	SET oms_camp_tbl = '''<<TABLE_PROJECT_ID>>''' ||  "."  ||  cnf_schema  ||  "."  ||  "OMS_MEDIA_CAMPAIGN";
	SET oms_camp_li_tbl = '''<<TABLE_PROJECT_ID>>''' ||  "."  ||  cnf_schema  ||  "."  ||  "OMS_MEDIA_CAMPAIGN_LINE_ITEM";
	SET com_prom_tbl = '''<<TABLE_PROJECT_ID>>''' ||  "."  ||  cnf_schema  ||  "."  ||  "COMMERCE_PROMOTION_REFERENCE";
	SET tgt_wrk_tbl = '''<<TABLE_PROJECT_ID>>'''  ||  "."  ||  anl_wrk_schema  ||  "."  ||  "D1_AD_MEDIA_CAMPAIGN_META_WRK";
	SET tgt_tbl = '''<<TABLE_PROJECT_ID>>''' ||  "."  ||  anl_schema  ||  "."  ||  "D1_AD_MEDIA_CAMPAIGN";
		
		
			
	SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
	SET sql_truncate_tgt_tbl = '''TRUNCATE TABLE ''' || tgt_tbl ;

		
	BEGIN
		IF DATE(max_audit_ts) = '1900-01-01' THEN
			EXECUTE IMMEDIATE ( sql_truncate_tgt_tbl);
		END IF;
		EXECUTE IMMEDIATE ( sql_truncate_tgt_wrk_tbl);
		EXCEPTION WHEN ERROR THEN
			SET job_end = CURRENT_TIMESTAMP();
			SET status = "FAILED";
			SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
			CALL `<<SP_GCP_PROJECT>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
			RAISE USING message = err_desc;
	END;

	SET sql_inserts_default = '''INSERT INTO ''' || tgt_tbl || '''
			( 
			 AD_MEDIA_CAMPAIGN_D1_SK
			,AD_MEDIA_CAMPAIGN_ID
			,AD_CAMPAIGN_ID
			,AD_CAMPAIGN_NM
			,AD_MEDIA_CAMPAIGN_NM
			,AD_CAMPAIGN_START_DT
			,AD_CAMPAIGN_END_DT
			,AD_CAMPAIGN_BUDGT_AMT
			,AD_CAMPAIGN_PLND_IMPRESSION_CNT
			,AD_CAMPAIGN_OBJECTIVE_TXT
			,AD_CAMPAIGN_ADVERTISED_BRAND_NM
			,AD_CPG
			,DW_CREATE_TS
			,DW_LAST_UPDATE_TS
			)
			SELECT 
			-1 AS AD_MEDIA_CAMPAIGN_D1_SK
			,"N/A" AS AD_MEDIA_CAMPAIGN_ID
			,"N/A" AS AD_CAMPAIGN_ID
			,"N/A" AS AD_CAMPAIGN_NM
			,"N/A" AS AD_MEDIA_CAMPAIGN_NM
			,DATE('1900-01-01') AS AD_CAMPAIGN_START_DT
			,DATE('9999-12-31') AS AD_CAMPAIGN_END_DT
			,0 AS AD_CAMPAIGN_BUDGT_AMT
			,0 AS AD_CAMPAIGN_PLND_IMPRESSION_CNT
			,"N/A" AS AD_CAMPAIGN_OBJECTIVE_TXT
			,"N/A" AS AD_CAMPAIGN_ADVERTISED_BRAND_NM
			,[STRUCT('N/A' AS AD_CAMPAIGN_PARTNER_ID, 'N/A' AS AD_CAMPAIGN_PARTNER_NM)] AS AD_CPG
			,CURRENT_TIMESTAMP AS DW_CREATE_TS
			,CURRENT_TIMESTAMP AS DW_LAST_UPDATE_TS
		''';

	SET sql_crt_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || '''  
		(
		 AD_MEDIA_CAMPAIGN_ID
		 ,AD_CAMPAIGN_ID
		 ,AD_CAMPAIGN_NM
		,AD_MEDIA_CAMPAIGN_NM
		,AD_CAMPAIGN_START_DT
		,AD_CAMPAIGN_END_DT
		,AD_CAMPAIGN_BUDGT_AMT
		 ,AD_CAMPAIGN_ADVERTISED_BRAND_NM
		 ,AD_CAMPAIGN_PLND_IMPRESSION_CNT
		 ,AD_CAMPAIGN_OBJECTIVE_TXT
		 ,AD_CPG
		 ,DML_TYPE
		 )
		
		SELECT DISTINCT 
			src.media_campaign_id as AD_MEDIA_CAMPAIGN_ID
			,IFNULL(src.hub_campaign_id, 'N/A') as AD_CAMPAIGN_ID
			,"N/A" AS AD_CAMPAIGN_NM
			,IFNULL(src.media_campaign_nm,'N/A') as AD_MEDIA_CAMPAIGN_NM
			,IFNULL(src.campaign_start_dt,DATE('1900-01-01')) as AD_CAMPAIGN_START_DT
			,IFNULL(src.campaign_end_dt,DATE('1900-01-01'))  AS AD_CAMPAIGN_END_DT
			,IFNULL(src.campaign_line_item_total_amt,0)  AS AD_CAMPAIGN_BUDGT_AMT
			,IFNULL(cpr.brand_nm,'N/A') AS AD_CAMPAIGN_ADVERTISED_BRAND_NM		-- concatenation of all brands from brand_nm, grouped by MediaOrder (hub_l1_id)
			,IFNULL(ocli.booking_qty,0) AS AD_CAMPAIGN_PLND_IMPRESSION_CNT
			,IFNULL(src.objectives_txt,'N/A') AS AD_CAMPAIGN_OBJECTIVE_TXT
			,IFNULL(cpr.AD_CPG, [STRUCT('N/A' AS AD_CAMPAIGN_PARTNER_ID, 'N/A' AS AD_CAMPAIGN_PARTNER_NM)]) AS AD_CPG -- to be transformed as mentioned in mapping document
			,CASE WHEN tgt.AD_MEDIA_CAMPAIGN_ID is NULL  THEN 'I' ELSE 'U' END as DML_TYPE
			FROM ''' || oms_camp_tbl || ''' src
		LEFT JOIN (
			SELECT 
				ocli.media_campaign_id
				,CAST(SUM(booking_qty) AS NUMERIC) AS booking_qty
			FROM ''' || oms_camp_li_tbl || ''' ocli
			WHERE ocli.SOURCE_APPLICATION_CD = 'OMS'
				AND ocli.DW_CURRENT_VERSION_IND = TRUE
			GROUP BY ocli.media_campaign_id
			) ocli
			ON src.media_campaign_id = ocli.media_campaign_id
		LEFT JOIN 
			(
            SELECT 
              b.hub_campaign_id,
              b.brand_nm,
              ARRAY_AGG(STRUCT(p.AD_CAMPAIGN_PARTNER_ID, p.AD_CAMPAIGN_PARTNER_NM) 
                        ORDER BY AD_CAMPAIGN_PARTNER_ID, AD_CAMPAIGN_PARTNER_NM) AS AD_CPG
            FROM 
            (
               SELECT DISTINCT
               hub_campaign_id,
               IFNULL(partner_id, 'N/A') AS AD_CAMPAIGN_PARTNER_ID,
               IFNULL(partner_nm, 'N/A') AS AD_CAMPAIGN_PARTNER_NM
               FROM ''' || com_prom_tbl || '''
            )  p
            INNER JOIN 
            (
               SELECT 
               hub_campaign_id,
               STRING_AGG(DISTINCT IFNULL(brand_nm, 'N/A'), ', ' ORDER BY IFNULL(brand_nm, 'N/A')) AS brand_nm
               FROM ''' || com_prom_tbl || '''
               GROUP BY hub_campaign_id
            ) b
            ON p.hub_campaign_id = b.hub_campaign_id
            GROUP BY b.hub_campaign_id, b.brand_nm
			) cpr
			ON src.hub_campaign_id = cpr.hub_campaign_id
		LEFT JOIN ''' || tgt_tbl || ''' tgt
			ON src.media_campaign_id = tgt.AD_MEDIA_CAMPAIGN_ID
		WHERE 
			src.SOURCE_APPLICATION_CD = 'OMS' 
			AND src.DW_CURRENT_VERSION_IND = TRUE 
			AND (TGT.AD_MEDIA_CAMPAIGN_ID IS NULL
      OR ( 
          	TGT.AD_CAMPAIGN_ID <> IFNULL(SRC.hub_campaign_id,'N/A') OR
			TGT.AD_CAMPAIGN_NM <> 'N/A' OR
			TGT.AD_MEDIA_CAMPAIGN_NM <> IFNULL(SRC.media_campaign_nm,'N/A') OR
			TGT.AD_CAMPAIGN_START_DT <> IFNULL(SRC.campaign_start_dt,DATE('1900-01-01')) OR
          	TGT.AD_CAMPAIGN_END_DT <> IFNULL(SRC.campaign_end_dt,DATE('1900-01-01')) OR
         	TGT.AD_CAMPAIGN_BUDGT_AMT <> IFNULL(SRC.campaign_line_item_total_amt,0) OR
			TGT.AD_CAMPAIGN_ADVERTISED_BRAND_NM <> IFNULL(cpr.brand_nm,'N/A') OR
			TGT.AD_CAMPAIGN_PLND_IMPRESSION_CNT <> IFNULL(ocli.booking_qty,0) OR
			TGT.AD_CAMPAIGN_OBJECTIVE_TXT <> IFNULL(SRC.objectives_txt,'N/A') OR
			TO_JSON_STRING(TGT.AD_CPG) <> TO_JSON_STRING(IFNULL(cpr.AD_CPG, [STRUCT('N/A' AS AD_CAMPAIGN_PARTNER_ID, 'N/A' AS AD_CAMPAIGN_PARTNER_NM)]))
          ))
		''';
   
	BEGIN
		EXECUTE IMMEDIATE ( sql_crt_tgt_wrk_tbl);
		EXCEPTION WHEN ERROR THEN
		SET job_end = CURRENT_TIMESTAMP();
		SET status = "FAILED";
		SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
		CALL `<<SP_GCP_PROJECT>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
		RAISE USING message = err_desc;
	END;

  	--//SCD Type1 transaction begins
	SET sql_begin = "BEGIN TRANSACTION";
	SET sql_updates = '''--// Processing Updates of Type 1 SCD
					UPDATE ''' || tgt_tbl || ''' as TGT
						SET 
							TGT.AD_CAMPAIGN_ID						=	SRC.AD_CAMPAIGN_ID
							,TGT.AD_CAMPAIGN_NM						=	SRC.AD_CAMPAIGN_NM
							,TGT.AD_MEDIA_CAMPAIGN_NM				=	SRC.AD_MEDIA_CAMPAIGN_NM
							,TGT.AD_CAMPAIGN_START_DT				= 	SRC.AD_CAMPAIGN_START_DT
							,TGT.AD_CAMPAIGN_END_DT					=	SRC.AD_CAMPAIGN_END_DT
							,TGT.AD_CAMPAIGN_BUDGT_AMT				=	SRC.AD_CAMPAIGN_BUDGT_AMT
							,TGT.AD_CAMPAIGN_PLND_IMPRESSION_CNT	=	SRC.AD_CAMPAIGN_PLND_IMPRESSION_CNT
							,TGT.AD_CAMPAIGN_OBJECTIVE_TXT			=	SRC.AD_CAMPAIGN_OBJECTIVE_TXT
							,TGT.AD_CAMPAIGN_ADVERTISED_BRAND_NM	=	SRC.AD_CAMPAIGN_ADVERTISED_BRAND_NM
							,TGT.AD_CPG								=	SRC.AD_CPG
							,TGT.DW_LAST_UPDATE_TS 					= 	CURRENT_TIMESTAMP

						FROM (SELECT
											*
											FROM ''' || tgt_wrk_tbl || '''
											WHERE DML_TYPE = 'U'
							) SRC 
							WHERE TGT.AD_MEDIA_CAMPAIGN_ID = SRC.AD_MEDIA_CAMPAIGN_ID
							''';
	

	SET sql_max_sk ='''SELECT IFNULL(MAX(AD_MEDIA_CAMPAIGN_D1_SK),0) FROM ''' || tgt_tbl ;
  	EXECUTE IMMEDIATE (sql_max_sk) into max_sk;

		--// Processing Inserts
	SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
		( 
		 AD_MEDIA_CAMPAIGN_D1_SK
		 ,AD_MEDIA_CAMPAIGN_ID
         ,AD_CAMPAIGN_ID
		 ,AD_CAMPAIGN_NM
         ,AD_MEDIA_CAMPAIGN_NM
         ,AD_CAMPAIGN_START_DT
         ,AD_CAMPAIGN_END_DT
         ,AD_CAMPAIGN_BUDGT_AMT
         ,AD_CAMPAIGN_PLND_IMPRESSION_CNT
         ,AD_CAMPAIGN_OBJECTIVE_TXT
         ,AD_CAMPAIGN_ADVERTISED_BRAND_NM
         ,AD_CPG
         ,DW_CREATE_TS
		 ,DW_LAST_UPDATE_TS
		)
		SELECT 
			ROW_NUMBER() OVER (ORDER BY AD_MEDIA_CAMPAIGN_ID) + '''  || CAST(max_sk AS STRING) ||  ''' AS AD_MEDIA_CAMPAIGN_D1_SK
			,AD_MEDIA_CAMPAIGN_ID
			,AD_CAMPAIGN_ID
			,AD_CAMPAIGN_NM
			,AD_MEDIA_CAMPAIGN_NM
			,AD_CAMPAIGN_START_DT
			,AD_CAMPAIGN_END_DT
			,AD_CAMPAIGN_BUDGT_AMT
			,AD_CAMPAIGN_PLND_IMPRESSION_CNT
			,AD_CAMPAIGN_OBJECTIVE_TXT
			,AD_CAMPAIGN_ADVERTISED_BRAND_NM
			,AD_CPG
			,CURRENT_TIMESTAMP()
			,CURRENT_TIMESTAMP()				 
		FROM ''' || tgt_wrk_tbl || '''
		WHERE DML_TYPE = 'I'
		''';


			
	SET sql_commit = "COMMIT TRANSACTION";
	SET sql_rollback = "ROLLBACK TRANSACTION";
    
	BEGIN
        EXECUTE IMMEDIATE ( sql_begin);
		
    	IF DATE(max_audit_ts) = '1900-01-01' THEN
	   		EXECUTE IMMEDIATE ( sql_inserts_default);
		END IF;       

		EXECUTE IMMEDIATE ( sql_updates);        
        EXECUTE IMMEDIATE ( sql_inserts);
		SET row_count = @@row_count;
        EXECUTE IMMEDIATE ( sql_commit);
		EXCEPTION WHEN ERROR THEN
			EXECUTE IMMEDIATE(sql_rollback);
			SET job_end = CURRENT_TIMESTAMP();
			SET status = "FAILED";
			SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
			CALL `<<SP_GCP_PROJECT>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
			RAISE USING message = err_desc;
	END;

	SET job_end = CURRENT_TIMESTAMP();
	SET status = 'COMPLETED';
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','ANALYTICAL',CURRENT_DATE(),"D1_AD_MEDIA_CAMPAIGN");
	CALL `<<SP_GCP_PROJECT>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;
