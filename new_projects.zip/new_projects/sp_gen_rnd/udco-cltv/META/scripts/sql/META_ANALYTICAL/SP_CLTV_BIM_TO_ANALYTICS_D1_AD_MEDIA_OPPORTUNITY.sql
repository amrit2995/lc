CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_OPPORTUNITY`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_tbl STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_merge STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE load_type STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE sql_max_sk STRING;
DECLARE max_sk NUMERIC;


SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_OPPORTUNITY'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.ANALYTICAL_PROCESS_AUDIT_CONTROL'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_OPPORTUNITY';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_AD_MEDIA_OPPORTUNITY_WRK';        
SET src_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.oms_opportunity';


-- Set load_type based on audit timestamp
IF DATE(max_audit_ts) = '0001-01-01' THEN
  SET load_type = 'FULL_LOAD';
ELSE
  SET load_type = 'INCREMENTAL';
END IF;

-- Full Load Logic
IF load_type = 'FULL_LOAD' THEN

  SET sql_truncate_tgt_tbl = '''TRUNCATE TABLE ''' || tgt_tbl ;

  SET sql_insert_full_load = FORMAT("""
        INSERT INTO %s
        (
          AD_MEDIA_OPPORTUNITY_D1_SK,
          AD_MEDIA_OPPORTUNITY_ID,
          AD_MEDIA_OPPORTUNITY_NM,
          AD_MEDIA_PARENT_OPPORTUNITY_ID,
          AD_CPG_ACCOUNT_ID,
          IS_PARENT_OPPORTUNITY_IND,
          IS_COBRANDED_IND,
          DW_CREATE_TS,
          DW_LAST_UPDATE_TS
        )
        SELECT
        -1 AS AD_MEDIA_OPPORTUNITY_D1_SK
        ,'N/A' AS AD_MEDIA_OPPORTUNITY_ID
        ,'N/A' AS AD_MEDIA_OPPORTUNITY_NM
        ,'N/A' AS AD_MEDIA_PARENT_OPPORTUNITY_ID
        ,'N/A' AS AD_CPG_ACCOUNT_ID
        ,FALSE AS IS_PARENT_OPPORTUNITY_IND
        ,FALSE AS IS_COBRANDED_IND
        ,CURRENT_TIMESTAMP() AS DW_CREATE_TS
        ,CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
        UNION ALL
        SELECT 
        ROW_NUMBER() OVER (ORDER BY opportunity_id, source_application_cd) AS AD_MEDIA_OPPORTUNITY_D1_SK
        ,IFNULL(NULLIF(opportunity_id,''), 'N/A') AS AD_MEDIA_OPPORTUNITY_ID
        ,IFNULL(NULLIF(opportunity_nm,''), 'N/A') AS AD_MEDIA_OPPORTUNITY_NM
        ,IFNULL(NULLIF(parent_opportunity_id,''), 'N/A') AS AD_MEDIA_PARENT_OPPORTUNITY_ID
        ,IFNULL(NULLIF(account_id,''), 'N/A') AS AD_CPG_ACCOUNT_ID
        ,CASE WHEN parent_ind IS NULL OR CAST(parent_ind AS STRING) = '' THEN FALSE ELSE parent_ind END AS IS_PARENT_OPPORTUNITY_IND
        ,CASE WHEN co_branded_ind IS NULL OR CAST(co_branded_ind AS STRING) = '' THEN FALSE ELSE co_branded_ind END AS IS_COBRANDED_IND
        ,CURRENT_TIMESTAMP() AS DW_CREATE_TS
        ,CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
        FROM %s 
        WHERE dw_logical_delete_ind = FALSE
        AND dw_current_version_ind = TRUE
        """,tgt_tbl,src_tbl);
  BEGIN
    EXECUTE IMMEDIATE (sql_begin);
    EXECUTE IMMEDIATE (sql_truncate_tgt_tbl);
    EXECUTE IMMEDIATE (sql_insert_full_load);
    SET record_count = @@row_count;

	  EXECUTE IMMEDIATE (sql_commit);
	  SET row_count = row_count + record_count;

  EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = "FULL LOAD FOR TARGET TABLE - "|| tgt_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
  END;

  SET job_end = CURRENT_TIMESTAMP();
  SET status  = "COMPLETED";
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

ELSEIF load_type = 'INCREMENTAL' THEN
  SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
  BEGIN
  EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
  EXCEPTION WHEN ERROR THEN
  SET job_end  = CURRENT_TIMESTAMP();
  SET status   = "FAILED";
  SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
  RAISE USING message = err_desc;
  END;

  SET sql_max_sk =FORMAT("""SELECT IFNULL(MAX(AD_MEDIA_OPPORTUNITY_D1_SK),0) FROM %s""",tgt_tbl);
  EXECUTE IMMEDIATE (sql_max_sk) into max_sk; 

  SET insert_tgt_wrk_tbl = FORMAT("""
        INSERT INTO %s
        (
          AD_MEDIA_OPPORTUNITY_D1_SK,
          AD_MEDIA_OPPORTUNITY_ID,
          AD_MEDIA_OPPORTUNITY_NM,
          AD_MEDIA_PARENT_OPPORTUNITY_ID,
          AD_CPG_ACCOUNT_ID,
          IS_PARENT_OPPORTUNITY_IND,
          IS_COBRANDED_IND
        )
        WITH OPPORTUNITY_DELTA AS (
        SELECT 
        CASE WHEN TGT.AD_MEDIA_OPPORTUNITY_ID IS NULL THEN 'I' ELSE 'U' END AS DW_DML_TYPE
        ,IFNULL(TGT.AD_MEDIA_OPPORTUNITY_D1_SK, 0) AS AD_MEDIA_OPPORTUNITY_D1_SK
        ,IFNULL(NULLIF(opportunity_id,''), 'N/A') AS AD_MEDIA_OPPORTUNITY_ID
        ,IFNULL(NULLIF(opportunity_nm,''), 'N/A') AS AD_MEDIA_OPPORTUNITY_NM
        ,IFNULL(NULLIF(parent_opportunity_id,''), 'N/A') AS AD_MEDIA_PARENT_OPPORTUNITY_ID
        ,IFNULL(NULLIF(account_id,''), 'N/A') AS AD_CPG_ACCOUNT_ID
        ,CASE WHEN parent_ind IS NULL OR CAST(parent_ind AS STRING) = '' THEN FALSE ELSE parent_ind END AS IS_PARENT_OPPORTUNITY_IND
        ,CASE WHEN co_branded_ind IS NULL OR CAST(co_branded_ind AS STRING) = '' THEN FALSE ELSE co_branded_ind END AS IS_COBRANDED_IND
        FROM %s SRC
        LEFT JOIN %s TGT
        ON SRC.opportunity_id = TGT.AD_MEDIA_OPPORTUNITY_ID
	      WHERE SRC.dw_logical_delete_ind = FALSE
	      AND SRC.dw_current_version_ind = TRUE
	      AND SRC.dw_last_update_ts >= %T AND SRC.dw_last_update_ts < %T
        )
        SELECT ROW_NUMBER() OVER (ORDER BY AD_MEDIA_OPPORTUNITY_ID) + CAST('%s' AS NUMERIC) AS AD_MEDIA_OPPORTUNITY_D1_SK,
        AD_MEDIA_OPPORTUNITY_ID,
        AD_MEDIA_OPPORTUNITY_NM,
        AD_MEDIA_PARENT_OPPORTUNITY_ID,
        AD_CPG_ACCOUNT_ID,
        IS_PARENT_OPPORTUNITY_IND,
        IS_COBRANDED_IND
        FROM OPPORTUNITY_DELTA
        WHERE DW_DML_TYPE = 'I'
        UNION ALL
        SELECT AD_MEDIA_OPPORTUNITY_D1_SK,
        AD_MEDIA_OPPORTUNITY_ID,
        AD_MEDIA_OPPORTUNITY_NM,
        AD_MEDIA_PARENT_OPPORTUNITY_ID,
        AD_CPG_ACCOUNT_ID,
        IS_PARENT_OPPORTUNITY_IND,
        IS_COBRANDED_IND
        FROM OPPORTUNITY_DELTA
        WHERE DW_DML_TYPE = 'U'
      """,tgt_wrk_tbl,src_tbl,tgt_tbl,data_extract_start_ts,data_extract_end_ts,CAST(max_sk AS STRING)
      );

  BEGIN
  EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
  EXCEPTION WHEN ERROR THEN
  SET job_end  = CURRENT_TIMESTAMP();
  SET status   = "FAILED";
  SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
  RAISE USING message = err_desc;
  END;

--//SCD Type1 transaction begins

  SET sql_merge = FORMAT("""
          MERGE INTO %s AS TGT
          USING %s AS SRC
          ON TGT.AD_MEDIA_OPPORTUNITY_ID = SRC.AD_MEDIA_OPPORTUNITY_ID
          
          -- Update only if any relevant field has changed
          WHEN MATCHED AND (     
              TGT.AD_MEDIA_OPPORTUNITY_NM != SRC.AD_MEDIA_OPPORTUNITY_NM OR
              TGT.AD_MEDIA_PARENT_OPPORTUNITY_ID != SRC.AD_MEDIA_PARENT_OPPORTUNITY_ID OR
              TGT.AD_CPG_ACCOUNT_ID != SRC.AD_CPG_ACCOUNT_ID OR
              TGT.IS_PARENT_OPPORTUNITY_IND != SRC.IS_PARENT_OPPORTUNITY_IND OR
              TGT.IS_COBRANDED_IND != SRC.IS_COBRANDED_IND 
          ) THEN
            UPDATE SET
              TGT.AD_MEDIA_OPPORTUNITY_NM = SRC.AD_MEDIA_OPPORTUNITY_NM,
              TGT.AD_MEDIA_PARENT_OPPORTUNITY_ID = SRC.AD_MEDIA_PARENT_OPPORTUNITY_ID,
              TGT.AD_CPG_ACCOUNT_ID = SRC.AD_CPG_ACCOUNT_ID,
              TGT.IS_PARENT_OPPORTUNITY_IND = SRC.IS_PARENT_OPPORTUNITY_IND,
              TGT.IS_COBRANDED_IND = SRC.IS_COBRANDED_IND,
              TGT.DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP()

          -- Insert new records
          WHEN NOT MATCHED THEN
            INSERT (
              AD_MEDIA_OPPORTUNITY_D1_SK,
              AD_MEDIA_OPPORTUNITY_ID,
              AD_MEDIA_OPPORTUNITY_NM,
              AD_MEDIA_PARENT_OPPORTUNITY_ID,
              AD_CPG_ACCOUNT_ID,
              IS_PARENT_OPPORTUNITY_IND,
              IS_COBRANDED_IND,
              DW_CREATE_TS,
              DW_LAST_UPDATE_TS
            )
            VALUES (
              SRC.AD_MEDIA_OPPORTUNITY_D1_SK,
              SRC.AD_MEDIA_OPPORTUNITY_ID,
              SRC.AD_MEDIA_OPPORTUNITY_NM,
              SRC.AD_MEDIA_PARENT_OPPORTUNITY_ID,
              SRC.AD_CPG_ACCOUNT_ID,
              SRC.IS_PARENT_OPPORTUNITY_IND,
              SRC.IS_COBRANDED_IND,
              CURRENT_TIMESTAMP(),
              CURRENT_TIMESTAMP()
            )
        """,tgt_tbl,tgt_wrk_tbl);

  BEGIN
  EXECUTE IMMEDIATE (sql_begin);       
  EXECUTE IMMEDIATE (sql_merge);

  SET record_count = @@row_count;

  EXECUTE IMMEDIATE (sql_commit);
  SET row_count = row_count + record_count;
  
  EXCEPTION WHEN ERROR THEN
  EXECUTE IMMEDIATE (sql_rollback);
  SET job_end  = CURRENT_TIMESTAMP();
  SET status   = "FAILED";
  SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
  RAISE USING message = err_desc;
  END;

  SET status  = "COMPLETED";
  SET job_end = CURRENT_TIMESTAMP();
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','ANALYTICAL',CURRENT_DATE(),"D1_AD_MEDIA_OPPORTUNITY");
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

ELSE 
  SET err_desc = "Invalid load type parameter provided.";
  RAISE USING message = err_desc;
END IF;
END;
