CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_D1_PLATFORM_MEDIA_CREATIVE`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_tbl STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_merge STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE load_type STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE sql_max_sk STRING;
DECLARE max_sk NUMERIC;


SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_BIM_TO_ANALYTICS_D1_PLATFORM_MEDIA_CREATIVE'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.ANALYTICAL_PROCESS_AUDIT_CONTROL'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE_WRK';        
SET src_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_creative';



-- Set load_type based on audit timestamp
IF DATE(max_audit_ts) = '0001-01-01' THEN
  SET load_type = 'FULL_LOAD';
ELSE
  SET load_type = 'INCREMENTAL';
END IF;

-- Full Load Logic
IF load_type = 'FULL_LOAD' THEN

  SET sql_truncate_tgt_tbl = '''TRUNCATE TABLE ''' || tgt_tbl ;

  SET sql_insert_full_load = FORMAT("""
        INSERT INTO `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE`
        SELECT 
        -1 AS PLATFORM_MEDIA_CREATIVE_D1_SK,
        'N/A' AS PLATFORM_CD,
	      'N/A' AS PLATFORM_MEDIA_CREATIVE_ID,
	      'N/A' AS PLATFORM_MEDIA_CREATIVE_NM,
        'N/A' AS PLATFORM_MEDIA_CREATIVE_SZ,
        'N/A' AS PLATFORM_MEDIA_CREATIVE_TYPE_CD,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
	      CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
        UNION ALL
        SELECT 
        ROW_NUMBER() OVER (ORDER BY creative_id, source_application_cd) AS PLATFORM_MEDIA_CREATIVE_D1_SK,
        IFNULL(NULLIF(source_application_cd,''), 'N/A') AS PLATFORM_CD,
	      IFNULL(NULLIF(creative_id,''), 'N/A') AS PLATFORM_MEDIA_CREATIVE_ID,
	      IFNULL(NULLIF(creative_nm,''), 'N/A') AS PLATFORM_MEDIA_CREATIVE_NM,
        IFNULL(NULLIF(creative_requested_sz,''), 'N/A') AS PLATFORM_MEDIA_CREATIVE_SZ,
        IFNULL(NULLIF(creative_type_nm,''), 'N/A') AS PLATFORM_MEDIA_CREATIVE_TYPE_CD,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
	      CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
        FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_creative`
	      WHERE dw_logical_delete_ind = FALSE
	      AND dw_current_version_ind = TRUE
        """);
  BEGIN
    EXECUTE IMMEDIATE (sql_begin);
    EXECUTE IMMEDIATE (sql_truncate_tgt_tbl);
    EXECUTE IMMEDIATE (sql_insert_full_load);
    SET record_count = @@row_count;

	  EXECUTE IMMEDIATE (sql_commit);
	  SET row_count = row_count + record_count;

  EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = "FULL LOAD FOR TARGET TABLE - "|| tgt_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
  END;

  SET job_end = CURRENT_TIMESTAMP();
  SET status  = "COMPLETED";
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

ELSEIF load_type = 'INCREMENTAL' THEN
  SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
  BEGIN
  EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
  EXCEPTION WHEN ERROR THEN
  SET job_end  = CURRENT_TIMESTAMP();
  SET status   = "FAILED";
  SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
  RAISE USING message = err_desc;
  END;

  SET sql_max_sk ='''SELECT MAX(PLATFORM_MEDIA_CREATIVE_D1_SK) FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE`''';
  EXECUTE IMMEDIATE (sql_max_sk) into max_sk; 

  SET insert_tgt_wrk_tbl = FORMAT("""
        INSERT INTO `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE_WRK`
      (
        PLATFORM_MEDIA_CREATIVE_D1_SK,
        PLATFORM_CD,
        PLATFORM_MEDIA_CREATIVE_ID,
        PLATFORM_MEDIA_CREATIVE_NM,
        PLATFORM_MEDIA_CREATIVE_SZ,
        PLATFORM_MEDIA_CREATIVE_TYPE_CD
      )

      WITH CREATIVE_DELTA AS
      (
        SELECT 
          IFNULL(TGT.PLATFORM_MEDIA_CREATIVE_D1_SK,0) AS PLATFORM_MEDIA_CREATIVE_D1_SK,
          IFNULL(NULLIF(SRC.source_application_cd,''), 'N/A') AS PLATFORM_CD,
          IFNULL(NULLIF(SRC.creative_id,''), 'N/A') AS PLATFORM_MEDIA_CREATIVE_ID,
          IFNULL(NULLIF(SRC.creative_nm,''), 'N/A') AS PLATFORM_MEDIA_CREATIVE_NM,
          IFNULL(NULLIF(SRC.creative_requested_sz,''), 'N/A') AS PLATFORM_MEDIA_CREATIVE_SZ,
          IFNULL(NULLIF(SRC.creative_type_nm,''), 'N/A') AS PLATFORM_MEDIA_CREATIVE_TYPE_CD,
          CASE WHEN TGT.PLATFORM_MEDIA_CREATIVE_ID IS NULL THEN 'I' ELSE 'U' END AS DML_TYPE
        FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_creative` SRC
        LEFT JOIN `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE` TGT
        ON IFNULL(NULLIF(SRC.creative_id,''), 'N/A') = TGT.PLATFORM_MEDIA_CREATIVE_ID
        AND IFNULL(NULLIF(SRC.source_application_cd,''), 'N/A') = TGT.PLATFORM_CD 
        WHERE src.dw_logical_delete_ind = FALSE
        AND src.dw_current_version_ind = TRUE
        AND src.dw_last_update_ts >= CAST('%s' AS timestamp) AND src.dw_last_update_ts < CAST('%s' AS timestamp) 
      )

      SELECT 
        ROW_NUMBER() OVER (ORDER BY PLATFORM_MEDIA_CREATIVE_ID,PLATFORM_CD) + CAST('%s' AS NUMERIC) AS PLATFORM_MEDIA_CREATIVE_D1_SK,
        PLATFORM_CD,
        PLATFORM_MEDIA_CREATIVE_ID,
        PLATFORM_MEDIA_CREATIVE_NM,
        PLATFORM_MEDIA_CREATIVE_SZ,
        PLATFORM_MEDIA_CREATIVE_TYPE_CD
      FROM CREATIVE_DELTA
      WHERE DML_TYPE = 'I'
      UNION ALL
      SELECT
        PLATFORM_MEDIA_CREATIVE_D1_SK,
        PLATFORM_CD,
        PLATFORM_MEDIA_CREATIVE_ID,
        PLATFORM_MEDIA_CREATIVE_NM,
        PLATFORM_MEDIA_CREATIVE_SZ,
        PLATFORM_MEDIA_CREATIVE_TYPE_CD
      FROM CREATIVE_DELTA
      WHERE DML_TYPE = 'U'
      """,CAST(data_extract_start_ts AS STRING),CAST(data_extract_end_ts AS STRING),CAST(max_sk AS STRING)
      );

  BEGIN
  EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
  EXCEPTION WHEN ERROR THEN
  SET job_end  = CURRENT_TIMESTAMP();
  SET status   = "FAILED";
  SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
  RAISE USING message = err_desc;
  END;

--//SCD Type1 transaction begins

  SET sql_merge = FORMAT("""
          MERGE INTO `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE` AS TGT
          USING `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_PLATFORM_MEDIA_CREATIVE_WRK` AS SRC
          ON TGT.PLATFORM_MEDIA_CREATIVE_ID = SRC.PLATFORM_MEDIA_CREATIVE_ID
          AND TGT.PLATFORM_CD = SRC.PLATFORM_CD
          
          -- Update only if any relevant field has changed
          WHEN MATCHED AND (
              IFNULL(TGT.PLATFORM_MEDIA_CREATIVE_NM, 'N/A') != IFNULL(SRC.PLATFORM_MEDIA_CREATIVE_NM, 'N/A') OR
              IFNULL(TGT.PLATFORM_MEDIA_CREATIVE_SZ, 'N/A') != IFNULL(SRC.PLATFORM_MEDIA_CREATIVE_SZ, 'N/A') OR
              IFNULL(TGT.PLATFORM_MEDIA_CREATIVE_TYPE_CD, 'N/A') != IFNULL(SRC.PLATFORM_MEDIA_CREATIVE_TYPE_CD, 'N/A')
          ) THEN
            UPDATE SET
              TGT.PLATFORM_MEDIA_CREATIVE_NM = SRC.PLATFORM_MEDIA_CREATIVE_NM,
              TGT.PLATFORM_MEDIA_CREATIVE_SZ = SRC.PLATFORM_MEDIA_CREATIVE_SZ,
              TGT.PLATFORM_MEDIA_CREATIVE_TYPE_CD = SRC.PLATFORM_MEDIA_CREATIVE_TYPE_CD,
              TGT.DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP()

          -- Insert new records
          WHEN NOT MATCHED THEN
            INSERT (
              PLATFORM_MEDIA_CREATIVE_D1_SK,
              PLATFORM_CD,
              PLATFORM_MEDIA_CREATIVE_ID,
              PLATFORM_MEDIA_CREATIVE_NM,
              PLATFORM_MEDIA_CREATIVE_SZ,
              PLATFORM_MEDIA_CREATIVE_TYPE_CD,
              DW_CREATE_TS,
              DW_LAST_UPDATE_TS
            )
            VALUES (
              SRC.PLATFORM_MEDIA_CREATIVE_D1_SK,
              SRC.PLATFORM_CD,
              SRC.PLATFORM_MEDIA_CREATIVE_ID,
              SRC.PLATFORM_MEDIA_CREATIVE_NM,
              SRC.PLATFORM_MEDIA_CREATIVE_SZ,
              SRC.PLATFORM_MEDIA_CREATIVE_TYPE_CD,
              CURRENT_TIMESTAMP(),
              CURRENT_TIMESTAMP()
            )
        """);

  BEGIN
  EXECUTE IMMEDIATE (sql_begin);       
  EXECUTE IMMEDIATE (sql_merge);

  SET record_count = @@row_count;

  EXECUTE IMMEDIATE (sql_commit);
  SET row_count = row_count + record_count;
  
  EXCEPTION WHEN ERROR THEN
  EXECUTE IMMEDIATE (sql_rollback);
  SET job_end  = CURRENT_TIMESTAMP();
  SET status   = "FAILED";
  SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
  RAISE USING message = err_desc;
  END;

  SET status  = "COMPLETED";
  SET job_end = CURRENT_TIMESTAMP();
  --DQ Check
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','ANALYTICAL',CURRENT_DATE(),"D1_PLATFORM_MEDIA_CREATIVE");
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

ELSE 
  SET err_desc = "Invalid load type parameter provided.";
  RAISE USING message = err_desc;
END IF;
END;