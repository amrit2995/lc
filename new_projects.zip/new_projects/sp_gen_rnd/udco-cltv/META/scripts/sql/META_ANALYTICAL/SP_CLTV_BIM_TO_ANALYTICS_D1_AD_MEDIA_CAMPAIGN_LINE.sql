CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN_LINE`(job_id STRING)

BEGIN

	DECLARE row_count INT64;
	DECLARE status STRING;
	DECLARE cur_db STRING;
	DECLARE env STRING;
	DECLARE anl_db STRING;
	DECLARE anl_schema STRING;
	DECLARE anl_wrk_schema STRING;
	DECLARE cnf_db STRING;
	DECLARE cnf_schema STRING;
	DECLARE src_tbl STRING;
	DECLARE oms_camp_li_tbl STRING;
	DECLARE buy_ins_tbl STRING;
	DECLARE buy_li_tbl STRING;
	DECLARE li_tbl STRING;
	DECLARE tgt_wrk_tbl STRING;
	DECLARE tgt_tbl STRING;
	DECLARE sql_truncate_tgt_wrk_tbl STRING;
	DECLARE err_desc STRING;
	DECLARE sql_crt_tgt_wrk_tbl STRING;
	DECLARE sql_begin STRING;
	DECLARE sql_inserts STRING;
	DECLARE sql_updates STRING;
	DECLARE sql_commit STRING;
	DECLARE sql_rollback STRING;
	DECLARE proc_name STRING;
	DECLARE job_start TIMESTAMP;
	DECLARE job_end TIMESTAMP;
	DECLARE data_extract_start_ts TIMESTAMP;
	DECLARE data_extract_end_ts TIMESTAMP;
	DECLARE prcs_audit_tbl STRING;
	DECLARE sql_max_audit_ts STRING;
	DECLARE max_audit_ts TIMESTAMP;
	DECLARE sql_max_sk STRING;
	DECLARE sql_inserts_default STRING;
	DECLARE sql_truncate_tgt_tbl STRING;
	DECLARE max_sk NUMERIC;

	--set @@query_label="<<SP_LABEL>>,spname:sp_cltv_bim_to_analytics_d1_advertiser_platform";

	SET prcs_audit_tbl = '''<<TABLE_PROJECT_ID>>''' || '''.''' || '''<<AUDIT_DATASET>>''' || '''.ANALYTICAL_PROCESS_AUDIT_CONTROL''';

	SET job_start = CURRENT_TIMESTAMP();
	SET err_desc = ''' ''';
	SET status = '''RUNNING''';
	SET proc_name='''SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_CAMPAIGN_LINE''';  
	SET sql_max_audit_ts='''select IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) from ''' || prcs_audit_tbl ||''' where lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';


	EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
	SET data_extract_start_ts=max_audit_ts;
	SET data_extract_end_ts=CURRENT_TIMESTAMP();

	/* Audit entry for RUNNING */
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);


	SET anl_schema = '''<<ANALYTIC_DATASET>>''';
	SET anl_wrk_schema = '''<<REF_DATASET>>''';
	SET cnf_schema = '''<<CONF_DATASET>>''';
		
	SET oms_camp_li_tbl = '''<<TABLE_PROJECT_ID>>''' ||  "."  ||  cnf_schema  ||  "."  ||  "OMS_MEDIA_CAMPAIGN_LINE_ITEM";
	SET tgt_wrk_tbl = '''<<TABLE_PROJECT_ID>>'''  ||  "."  ||  anl_wrk_schema  ||  "."  ||  "D1_AD_MEDIA_CAMPAIGN_LINE_META_WRK";
	SET tgt_tbl = '''<<TABLE_PROJECT_ID>>'''  ||  "."  ||  anl_schema  ||  "."  ||  "D1_AD_MEDIA_CAMPAIGN_LINE";
		
		
			
	SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
	SET sql_truncate_tgt_tbl = '''TRUNCATE TABLE ''' || tgt_tbl ;

		
	BEGIN
		IF DATE(max_audit_ts) = '1900-01-01' THEN
			EXECUTE IMMEDIATE (sql_truncate_tgt_tbl);
		END IF; 
		EXECUTE IMMEDIATE ( sql_truncate_tgt_wrk_tbl);
		EXCEPTION WHEN ERROR THEN
			SET job_end = CURRENT_TIMESTAMP();
			SET status = "FAILED";
			SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
			CALL `<<SP_GCP_PROJECT>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
			RAISE USING message = err_desc;
	END;
	
	SET sql_inserts_default = '''INSERT INTO ''' || tgt_tbl || '''
			( 
				AD_MEDIA_CAMPAIGN_LINE_D1_SK
				,AD_MEDIA_LINE_ID
				,AD_LINE_ID
				,AD_LINE_END_DT
				,AD_LINE_START_DT
				,AD_LINE_ITEM_PLND_IMPRESSION_CNT
				,AD_LINE_ITEM_CPM_AMT
				,AD_LINE_ITEM_BUDGT_AMT
				,AD_LINE_TACTIC_NM
				,AD_LINE_AUDIENCE_TXT
				,AD_LINE_BILLING_CATEGORY_CD
				,AD_LINE_CHANNEL_CD
				,DW_CREATE_TS
				,DW_LAST_UPDATE_TS
			)
				SELECT
				-1 AS	AD_MEDIA_CAMPAIGN_LINE_D1_SK
				,"N/A" AS AD_MEDIA_LINE_ID
				,"N/A" AS AD_LINE_ID
				,DATE('9999-12-31') AS AD_LINE_END_DT
				,DATE('1900-01-01') AS AD_LINE_START_DT
				,0 AS AD_LINE_ITEM_PLND_IMPRESSION_CNT
				,0 AS AD_LINE_ITEM_CPM_AMT
				,0 AS AD_LINE_ITEM_BUDGT_AMT
				,"N/A" AS AD_LINE_TACTIC_NM
				,"N/A" AS AD_LINE_AUDIENCE_TXT
				,"N/A" AS AD_LINE_BILLING_CATEGORY_CD
				,"N/A" AS AD_LINE_CHANNEL_CD
				,CURRENT_TIMESTAMP AS DW_CREATE_TS
				,CURRENT_TIMESTAMP AS DW_LAST_UPDATE_TS
	''';



	SET sql_crt_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || '''  
		(
		 AD_MEDIA_LINE_ID
		 ,AD_LINE_ID
         ,AD_LINE_START_DT
         ,AD_LINE_END_DT
         ,AD_LINE_ITEM_BUDGT_AMT
         ,AD_LINE_ITEM_CPM_AMT
		 ,AD_LINE_ITEM_PLND_IMPRESSION_CNT
		 ,AD_LINE_AUDIENCE_TXT
		 ,AD_LINE_TACTIC_NM
		 ,AD_LINE_CHANNEL_CD
		 ,AD_LINE_BILLING_CATEGORY_CD
         ,DML_TYPE
		 )
		 		
		SELECT DISTINCT 
			src.media_campaign_line_item_id as AD_MEDIA_LINE_ID
			,IFNULL(src.line_dsc, 'N/A') as AD_LINE_ID
			,IFNULL(src.from_dt,DATE('1900-01-01')) as AD_LINE_START_DT
			,IFNULL(src.end_dt,DATE('1900-01-01')) as AD_LINE_END_DT
			,IFNULL(src.custom_b_3_amt,0) AS AD_LINE_ITEM_BUDGT_AMT
			,IFNULL(src.effective_cost_per_thousand_impressions_amt,0) AS AD_LINE_ITEM_CPM_AMT
			,IFNULL(CAST(src.booking_qty AS NUMERIC),0) AS AD_LINE_ITEM_PLND_IMPRESSION_CNT
			,IFNULL(src.targeting_criteria_txt,'N/A') AS AD_LINE_AUDIENCE_TXT
			,IFNULL(src.media_campaign_line_item_nm,'N/A') AS AD_LINE_TACTIC_NM
			,"N/A" AS AD_LINE_CHANNEL_CD
			,IFNULL(src.billing_category_cd,'N/A') AS AD_LINE_BILLING_CATEGORY_CD
			,CASE WHEN tgt.AD_MEDIA_LINE_ID is NULL  THEN 'I' ELSE 'U' END as DML_Type
         
		FROM ''' || oms_camp_li_tbl || ''' src
		LEFT JOIN ''' || tgt_tbl || ''' tgt
			ON src.media_campaign_line_item_id = tgt.AD_MEDIA_LINE_ID
		WHERE 
			SRC.DW_LAST_UPDATE_TS >= "''' || FORMAT_TIMESTAMP("%Y-%m-%d %H:%M:%S", data_extract_start_ts) || '''"
			AND SRC.DW_LAST_UPDATE_TS <= "''' || FORMAT_TIMESTAMP("%Y-%m-%d %H:%M:%S", data_extract_end_ts) || '''"
			AND src.DW_CURRENT_VERSION_IND = TRUE 
			AND src.SOURCE_APPLICATION_CD = 'OMS' 		
			AND (TGT.AD_MEDIA_LINE_ID IS NULL
            OR ( 
                    TGT.AD_LINE_ID <> IFNULL(src.line_dsc, 'N/A') OR
					TGT.AD_LINE_END_DT <> IFNULL(SRC.end_dt,DATE('1900-01-01')) OR
                    TGT.AD_LINE_START_DT <> IFNULL(SRC.from_dt,DATE('1900-01-01')) OR
                    TGT.AD_LINE_ITEM_PLND_IMPRESSION_CNT <> IFNULL(CAST(SRC.booking_qty AS NUMERIC),0) OR
                    TGT.AD_LINE_ITEM_CPM_AMT <> IFNULL(SRC.effective_cost_per_thousand_impressions_amt,0) OR
					TGT.AD_LINE_ITEM_BUDGT_AMT <> IFNULL(SRC.custom_b_3_amt,0) OR
					TGT.AD_LINE_TACTIC_NM <> IFNULL(SRC.media_campaign_line_item_nm,'N/A') OR
					TGT.AD_LINE_AUDIENCE_TXT <> IFNULL(SRC.targeting_criteria_txt,'N/A') OR
					TGT.AD_LINE_BILLING_CATEGORY_CD <> IFNULL(SRC.billing_category_cd,'N/A') OR
					TGT.AD_LINE_CHANNEL_CD <> 'N/A'
            ))
		''';
   
	BEGIN
		EXECUTE IMMEDIATE ( sql_crt_tgt_wrk_tbl);
		SET row_count = @@row_count;
		EXCEPTION WHEN ERROR THEN
		SET job_end = CURRENT_TIMESTAMP();
		SET status = "FAILED";
		SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
		CALL `<<SP_GCP_PROJECT>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
		RAISE USING message = err_desc;
	END;

  	--//SCD Type1 transaction begins
	SET sql_begin = "BEGIN TRANSACTION";
	SET sql_updates = '''--// Processing Updates of Type 1 SCD
					UPDATE ''' || tgt_tbl || ''' as TGT
						SET 
							TGT.AD_LINE_ID							=	SRC.AD_LINE_ID
							,TGT.AD_LINE_END_DT						=	SRC.AD_LINE_END_DT
							,TGT.AD_LINE_START_DT					= 	SRC.AD_LINE_START_DT
							,TGT.AD_LINE_ITEM_PLND_IMPRESSION_CNT	=	SRC.AD_LINE_ITEM_PLND_IMPRESSION_CNT
							,TGT.AD_LINE_ITEM_CPM_AMT				=	SRC.AD_LINE_ITEM_CPM_AMT
							,TGT.AD_LINE_ITEM_BUDGT_AMT				=	SRC.AD_LINE_ITEM_BUDGT_AMT
							,TGT.AD_LINE_TACTIC_NM					=	SRC.AD_LINE_TACTIC_NM
							,TGT.AD_LINE_AUDIENCE_TXT				=	SRC.AD_LINE_AUDIENCE_TXT
							,TGT.AD_LINE_BILLING_CATEGORY_CD		=	SRC.AD_LINE_BILLING_CATEGORY_CD
							,TGT.AD_LINE_CHANNEL_CD					=	SRC.AD_LINE_CHANNEL_CD
							,TGT.DW_LAST_UPDATE_TS 					= 	CURRENT_TIMESTAMP
						FROM (SELECT
											*
											FROM ''' || tgt_wrk_tbl || '''
											WHERE DML_TYPE = 'U'
							) SRC 
							WHERE TGT.AD_MEDIA_LINE_ID = SRC.AD_MEDIA_LINE_ID
							''';
	
	       
		
	SET sql_max_sk ='''SELECT IFNULL(MAX(AD_MEDIA_CAMPAIGN_LINE_D1_SK),0) FROM ''' || tgt_tbl ;
  	EXECUTE IMMEDIATE (sql_max_sk) into max_sk;

		--// Processing Inserts
	SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
		( 
		 AD_MEDIA_CAMPAIGN_LINE_D1_SK
		 ,AD_MEDIA_LINE_ID
         ,AD_LINE_ID
         ,AD_LINE_END_DT
         ,AD_LINE_START_DT
         ,AD_LINE_ITEM_PLND_IMPRESSION_CNT
         ,AD_LINE_ITEM_CPM_AMT
         ,AD_LINE_ITEM_BUDGT_AMT
         ,AD_LINE_TACTIC_NM
         ,AD_LINE_AUDIENCE_TXT
         ,AD_LINE_BILLING_CATEGORY_CD
         ,AD_LINE_CHANNEL_CD
		 ,DW_CREATE_TS
		 ,DW_LAST_UPDATE_TS
		)
		SELECT 
			ROW_NUMBER() OVER (ORDER BY AD_MEDIA_LINE_ID) + '''  || CAST(max_sk AS STRING) ||  '''  AS AD_MEDIA_CAMPAIGN_LINE_D1_SK
			,AD_MEDIA_LINE_ID
			,AD_LINE_ID
			,AD_LINE_END_DT
			,AD_LINE_START_DT
			,AD_LINE_ITEM_PLND_IMPRESSION_CNT
			,AD_LINE_ITEM_CPM_AMT
			,AD_LINE_ITEM_BUDGT_AMT
			,AD_LINE_TACTIC_NM
			,AD_LINE_AUDIENCE_TXT
			,AD_LINE_BILLING_CATEGORY_CD
			,AD_LINE_CHANNEL_CD
			,CURRENT_TIMESTAMP()
			,CURRENT_TIMESTAMP()				 
		FROM ''' || tgt_wrk_tbl || '''
		WHERE DML_TYPE = 'I'
		''';
			
	SET sql_commit = "COMMIT TRANSACTION";
	SET sql_rollback = "ROLLBACK TRANSACTION";
    
	BEGIN
        EXECUTE IMMEDIATE ( sql_begin);
		IF DATE(max_audit_ts) = '1900-01-01' THEN
	   		EXECUTE IMMEDIATE ( sql_inserts_default);
		END IF;        
		EXECUTE IMMEDIATE ( sql_updates);        
        EXECUTE IMMEDIATE ( sql_inserts);
		SET row_count = @@row_count;
        EXECUTE IMMEDIATE ( sql_commit);
		EXCEPTION WHEN ERROR THEN
			EXECUTE IMMEDIATE(sql_rollback);
			SET job_end = CURRENT_TIMESTAMP();
			SET status = "FAILED";
			SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
			CALL `<<SP_GCP_PROJECT>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
			RAISE USING message = err_desc;
	END;

	SET job_end = CURRENT_TIMESTAMP();
	SET status = 'COMPLETED';
	--DQ Check
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Analytical',CURRENT_DATE(),"D1_AD_MEDIA_CAMPAIGN_LINE");
	CALL `<<SP_GCP_PROJECT>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id ,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;
