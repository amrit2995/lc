## 🚀 SP: FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE Implementation

### 📊 Overview

Added support for loading the `FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE` table, consolidating ad campaign performance data from multiple platforms with analytics-ready metrics.

### 🔧 Key Features

- **Platform Support**: Handles both META (Facebook) and PINTEREST platforms in a single stored procedure
- **Simple Load**: Performs full load with transaction blocks for data consistency
- **Granular Processing**:
  - 📱 FACEBOOK: Line-level pass-through for detailed metrics
  - 📌 PINTEREST: Campaign-level aggregation for summarized insights
- **Measurement Integration**: Incorporates online, offline, and mobile transaction data from `F_ALL_PLATFORM_MEASUREMENT` and `F_ALL_PLATFORM_MEASUREMENT_UPC`

### 🗂️ Files Added/Updated

#### Stored Procedure

- ✅ `META/scripts/sql/META_ANALYTICAL/SP_CLTV_BIM_TO_ANALYTICS_FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_LOAD.sql` - Main loading stored procedure with platform-specific CTEs and UNION logic

#### DDL

- ✅ `META/scripts/ddl/Analytical/ddl_fa_ad_platform_campaign_performance.sql` - Main table DDL
- ✅ `META/scripts/ddl/Analytical/ddl_fa_ad_platform_campaign_performance_wrk.sql` - Work table DDL

#### Views

- ✅ `META/scripts/views/view_fa_ad_platform_campaign_performance.sql` - Analytics view on the fact table

#### Configuration Files

- ✅ `META/config/BToA_META_PINTEREST_FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_BQToBQ.json` - BigQuery-to-BigQuery job configuration (job name: `BToA_META_PINTEREST_FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_BQToBQ`)
- ✅ `META/config/META_ANALYTICAL_WF.json` - Workflow orchestration including FA campaign performance load

#### Naming note: Pinterest repin columns

The trend fact `F_AD_PLATFORM_CAMPAIGN_TREND` exposes Pinterest repins as `TOTAL_PINTEREST_REPINS_CNT` (plural). The performance aggregate fact `FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE` stores the repin total as `TOTAL_PINTEREST_REPIN_CNT` (singular). The load stored procedure `SP_CLTV_BIM_TO_ANALYTICS_FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE_LOAD` performs the aggregation (SUM) from the trend plural column into the performance singular column for Pinterest — maintainers should be aware of this mapping when troubleshooting or adding metrics.

#### Script Order Updates

- ✅ `script_order_execution_meta_id_an.yaml` - Added DDLs, view, and SP to META analytical execution order

### 📈 Data Flow

1. **Create Tables** 🏗️ - Execute DDLs for main and work tables
2. **Truncate Work Tables** 🗑️
3. **Insert Transformed Data** 📥 into work table with platform-specific logic
4. **Insert into Main Table** ➕ from work table
5. **Commit and Cleanup** ✅

### 🔗 Source Tables

- `F_AD_PLATFORM_CAMPAIGN_TREND` - Core trend data
- `F_ALL_PLATFORM_MEASUREMENT` - Transaction metrics
- `F_ALL_PLATFORM_MEASUREMENT_UPC` - Unit-level data
- `D1_AD_MEDIA_PROMOTIONAL_CHANNEL` - Promotional channel dimension (joined to derive `AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK`)

### 🎯 Key Metrics

- Impression, click, and engagement counts
- Spend amounts (total and CPG)
- Transaction data (online, offline, mobile)
- Video and post interaction metrics

### 📋 Target Table Schema

The `FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE` table schema:

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>Mode</th>
      <th>Type</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>PERFORMANCE_DAY_ID</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101</td>
    </tr>
    <tr>
      <td>AD_MEDIA_PLATFORM_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations.</td>
    </tr>
    <tr>
      <td>AD_MEDIA_CAMPAIGN_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for campaign – uniquely identifies each advertising campaign record in the system.</td>
    </tr>
    <tr>
      <td>AD_MEDIA_OPPORTUNITY_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for campaign – uniquely identifies each advertising campaign record in the system.</td>
    </tr>
    <tr>
      <td>AD_MEDIA_CAMPAIGN_LINE_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for campaign line item – uniquely identifies each line item record.</td>
    </tr>
    <tr>
      <td>DIVISION_D1_SK</td>
      <td>REQUIRED</td>
      <td>INT64</td>
      <td>System Generated Column gets next value inserted when record gets inserted.</td>
    </tr>
    <tr>
      <td>BANNER_D1_SK</td>
      <td>REQUIRED</td>
      <td>INT64</td>
      <td>System Generated Column gets next value inserted when record gets inserted.</td>
    </tr>
    <tr>
      <td>PLATFORM_ADVERTISER_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations.</td>
    </tr>
    <tr>
      <td>PLATFORM_MEDIA_CAMPAIGN_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for platform media campaign – uniquely identifies each campaign per platform.</td>
    </tr>
    <tr>
      <td>PLATFORM_MEDIA_LINE_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns.</td>
    </tr>
    <tr>
      <td>PLATFORM_MEDIA_ADVERTISEMENT_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for creative unit – uniquely identifies each creative ad placement.</td>
    </tr>
    <tr>
      <td>PLATFORM_MEDIA_AD_UNIT_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for creative unit – uniquely identifies each creative ad placement.</td>
    </tr>
    <tr>
      <td>PLATFORM_MEDIA_CREATIVE_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for creative asset – uniquely identifies each creative used in platform campaigns.</td>
    </tr>
    <tr>
      <td>PLATFORM_MEDIA_PLACEMENT_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for creative unit Placement – uniquely identifies each creative ad placement.</td>
    </tr>
    <tr>
      <td>AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for media promotional channel.</td>
    </tr>
    <tr>
      <td>TOTAL_CLICK_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of clicks on the ad</td>
    </tr>
    <tr>
      <td>TOTAL_IMPRESSION_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Impression count for Social Performance</td>
    </tr>
    <tr>
      <td>TOTAL_MEDIA_SPEND_AMT</td>
      <td>REQUIRED</td>
      <td>NUMERIC(14,2)</td>
      <td>This reflects the amount charged by <<cocmp>> to the CPG.</td>
    </tr>
    <tr>
      <td>VIDEO_START_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Number of people who saw at least the start of the video.</td>
    </tr>
    <tr>
      <td>VIDEO_25P_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Number of people who saw at least 25% of the video.</td>
    </tr>
    <tr>
      <td>VIDEO_50P_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Number of people who saw at least 50% of the video.</td>
    </tr>
    <tr>
      <td>VIDEO_75P_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Number of people who saw at least 75% of the video.</td>
    </tr>
    <tr>
      <td>VIDEO_COMPLETE_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Number of people who saw at least 100% of the video.</td>
    </tr>
    <tr>
      <td>VIDEO_TRUEVIEW_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>TruView counts for YouTube video campaigns (if applicable)</td>
    </tr>
    <tr>
      <td>POST_REACTION_ANGRY_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of Angry reactions on Facebook. Not present on Instagram.</td>
    </tr>
    <tr>
      <td>POST_REACTION_WOW_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of Wow reactions on Facebook. Not present on Instagram.</td>
    </tr>
    <tr>
      <td>POST_REACTION_LOVE_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of Love reactions on Facebook. Not present on Instagram.</td>
    </tr>
    <tr>
      <td>POST_REACTION_CARE_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of Care reactions on Facebook. Not present on Instagram.</td>
    </tr>
    <tr>
      <td>POST_REACTION_HAHA_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of Haha(Laugh) reactions on Facebook. Not present on Instagram.</td>
    </tr>
    <tr>
      <td>POST_REACTION_LIKE_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of likes across Meta properties. This metric is cumulative across Facebook & Instagram.</td>
    </tr>
    <tr>
      <td>POST_REACTION_SAD_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of SAD reactions across Meta properties. This metric is cumulative across Facebook & Instagram.</td>
    </tr>
    <tr>
      <td>TOTAL_POST_REACTION_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of Reactions across Meta properties. This metric is cumulative across Facebook & Instagram.</td>
    </tr>
    <tr>
      <td>TOTAL_POST_COMMENT_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of comments across Meta properties. This metric is cumulative across Facebook & Instagram.</td>
    </tr>
    <tr>
      <td>TOTAL_POST_ENGAGEMENT_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of engagements across Meta properties. Includes reactions, likes, comments, shares.</td>
    </tr>
    <tr>
      <td>TOTAL_PINTEREST_ENGAGEMENT_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of engagements across Meta properties. Includes reactions, likes, comments, shares.</td>
    </tr>
    <tr>
      <td>TOTAL_PINTEREST_REPIN_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Count of engagements across Meta properties. Includes reactions, likes, comments, shares.</td>
    </tr>
    <tr>
      <td>CPG_MEDIA_SPEND_AMT</td>
      <td>REQUIRED</td>
      <td>NUMERIC(14,2)</td>
      <td>This reflects the amount charged by <<cocmp>> to the CPG.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_ONLINE_TRANSACTIONS_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Number of Orders completed for given set of dimensions purchased online For DV360/GAM: Sum of online transactions For Meta/Pinterest: No available attributable sales Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_ONLINE_REVENUE_AMT</td>
      <td>REQUIRED</td>
      <td>NUMERIC(14,2)</td>
      <td>Attributed Revenue for given set of dimensions purchased online For DV360/GAM: Sum of online revenue For Meta/Pinterest: No available attributable sales Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_OFFLINE_TRANSACTIONS_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Number of Orders completed for given set of dimensions purchased instore For DV360/GAM: Sum of offline transactions For Meta/Pinterest: No available attributable sales Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_OFFLINE_REVENUE_AMT</td>
      <td>REQUIRED</td>
      <td>NUMERIC(14,2)</td>
      <td>Attributed Revenue for given set of dimensions purchased online For DV360/GAM: Sum of offline revenue For Meta/Pinterest: No available attributable sales Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_MOBILE_TRANSACTIONS_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>For DV360/GAM: Sum of mobile transactions For Meta: No available attributable sales For Pinterest: Pinterest does not provide attributable sales by sales channel Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_MOBILE_REVENUE_AMT</td>
      <td>REQUIRED</td>
      <td>NUMERIC(14,2)</td>
      <td>For DV360/GAM: Sum of mobile revenue For Meta: No available attributable sales For Pinterest: Pinterest does not provide attributable sales by sales channel Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_TOTAL_TRANSACTIONS_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>For DV360/GAM: Aggregation of online, offline, and mobile transactions For Meta/Pinterest: No available attributable sales</td>
    </tr>
    <tr>
      <td>MEASUREMENT_TOTAL_REVENUE_AMT</td>
      <td>REQUIRED</td>
      <td>NUMERIC(14,2)</td>
      <td>For DV360/GAM: Aggregation of online, offline, and mobile revenue For Meta/Pinterest: No available attributable sales</td>
    </tr>
    <tr>
      <td>MEASUREMENT_ONLINE_UNITS_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>For DV360/GAM: Sum of online units For Meta/Pinterest: No available attributable sales Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_OFFLINE_UNITS_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>For DV360/GAM: Sum of offline units For Meta/Pinterest: No available attributable sales Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_MOBILE_UNITS_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>For DV360/GAM: Sum of mobile units For Meta: No available attributable sales For Pinterest: Pinterest does not provide attributable sales by sales channel Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>MEASUREMENT_TOTAL_UNITS_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>For DV360/GAM: Aggregation of online, offline, and mobile units For Meta/Pinterest: No available attributable sales Data is aggregated by [chosen dimension, e.g., transaction category or brand]. This means the lowest granular-level transaction data is not available, and we must choose to display either the transaction category or the brand dimension.</td>
    </tr>
    <tr>
      <td>DW_CREATE_TS</td>
      <td>REQUIRED</td>
      <td>TIMESTAMP</td>
      <td>Record creation timestamp.</td>
    </tr>
    <tr>
      <td>DW_LAST_UPDATE_TS</td>
      <td>REQUIRED</td>
      <td>TIMESTAMP</td>
      <td>Last update timestamp.</td>
    </tr>
  </tbody>
</table>

### ⚙️ Configuration

- Uses `<<ANALYTIC_DATASET>>` and `<<AUDIT_DATASET>>` placeholders for environment-specific deployment
- Supports parameterized execution for different environments

### 🏷️ Tags and Metadata

- **App Code**: uddi
- **Body Name**: meta
- **Domain**: cltv
- **Environment**: dev (configurable)

This implementation ensures robust, scalable data loading with full auditability and platform differentiation. 🎉
