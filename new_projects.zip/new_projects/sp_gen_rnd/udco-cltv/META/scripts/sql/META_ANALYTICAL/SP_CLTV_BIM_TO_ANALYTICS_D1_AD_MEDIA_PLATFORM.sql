CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_PLATFORM`(job_id STRING)
BEGIN

DECLARE sql_truncate_tgt_tbl STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_merge STRING;
DECLARE tgt_tbl STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE prcs_audit_tbl STRING;
DECLARE load_type STRING;
DECLARE record_count INT64;
DECLARE sql_insert_full_load STRING;
DECLARE sql_max_sk STRING;
DECLARE max_sk NUMERIC;


SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_PLATFORM'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.ANALYTICAL_PROCESS_AUDIT_CONTROL'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","0001-01-01 01:01:01 UTC")) 
					FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';

EXECUTE IMMEDIATE (sql_max_audit_ts) into max_audit_ts ; 
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts=CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_AD_MEDIA_PLATFORM_WRK';        
SET src_tbl         = '<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.platform';
SET load_type       = 'FULL_LOAD';


-- Set load_type based on audit timestamp
-- IF DATE(max_audit_ts) = '0001-01-01' THEN
--   SET load_type = 'FULL_LOAD';
-- ELSE
--   SET load_type = 'INCREMENTAL';
-- END IF;

-- Full Load Logic
IF load_type = 'FULL_LOAD' THEN

  SET sql_truncate_tgt_tbl = '''TRUNCATE TABLE ''' || tgt_tbl ;

  SET sql_insert_full_load = FORMAT("""
        INSERT INTO `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM`
        SELECT 
        -1 AS AD_MEDIA_PLATFORM_D1_SK,
        'N/A' AS PLATFORM_CD,
        'N/A' AS PLATFORM_PROMOTIONAL_CHANNEL_CD,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
	      CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
        UNION ALL
        SELECT 
        1 AS AD_MEDIA_PLATFORM_D1_SK,
        'FACEBOOK' AS PLATFORM_CD,
	      'SOCIAL' AS PLATFORM_PROMOTIONAL_CHANNEL_CD,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
	      CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
        -- FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.platform`
	      -- WHERE dw_logical_delete_ind = FALSE
	      -- AND dw_current_version_ind = TRUE
        UNION ALL
        SELECT 
        2 AS AD_MEDIA_PLATFORM_D1_SK,
        'PINTEREST' AS PLATFORM_CD,
	      'SOCIAL' AS PLATFORM_PROMOTIONAL_CHANNEL_CD,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
	      CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
        UNION ALL
        SELECT 
        3 AS AD_MEDIA_PLATFORM_D1_SK,
        'DV360' AS PLATFORM_CD,
	      'SOCIAL' AS PLATFORM_PROMOTIONAL_CHANNEL_CD,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
	      CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
        UNION ALL
        SELECT 
        4 AS AD_MEDIA_PLATFORM_D1_SK,
        'GAM' AS PLATFORM_CD,
	      'SOCIAL' AS PLATFORM_PROMOTIONAL_CHANNEL_CD,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
	      CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
        """);
  BEGIN
    EXECUTE IMMEDIATE (sql_begin);
    EXECUTE IMMEDIATE (sql_truncate_tgt_tbl);
    EXECUTE IMMEDIATE (sql_insert_full_load);
    SET record_count = @@row_count;

	  EXECUTE IMMEDIATE (sql_commit);
	  SET row_count = row_count + record_count;

  EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = "FULL LOAD FOR TARGET TABLE - "|| tgt_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
  END;

  SET job_end = CURRENT_TIMESTAMP();
  SET status  = "COMPLETED";
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

ELSEIF load_type = 'INCREMENTAL' THEN
  SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
  BEGIN
  EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
  EXCEPTION WHEN ERROR THEN
  SET job_end  = CURRENT_TIMESTAMP();
  SET status   = "FAILED";
  SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
  RAISE USING message = err_desc;
  END;

  SET sql_max_sk ='''SELECT MAX(AD_MEDIA_PLATFORM_D1_SK) FROM `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM`''';
  EXECUTE IMMEDIATE (sql_max_sk) into max_sk; 

  SET insert_tgt_wrk_tbl = FORMAT("""
        INSERT INTO `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_AD_MEDIA_PLATFORM_WRK`
	      SELECT 
        ROW_NUMBER() OVER (ORDER BY PLATFORM_CD) + CAST('%s' AS NUMERIC) AS AD_MEDIA_PLATFORM_D1_SK,
	      'FACEBOOK' AS PLATFORM_CD,
	      'SOCIAL' AS PLATFORM_PROMOTIONAL_CHANNEL_CD,
        FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.platform`
	      WHERE dw_logical_delete_ind = FALSE
	      AND dw_current_version_ind = TRUE
	      AND dw_last_update_ts >= CAST('%s' AS timestamp) AND dw_last_update_ts < CAST('%s' AS timestamp)
      """,CAST(max_sk AS STRING),CAST(data_extract_start_ts AS STRING),CAST(data_extract_end_ts AS STRING)
      );

  BEGIN
  EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
  EXCEPTION WHEN ERROR THEN
  SET job_end  = CURRENT_TIMESTAMP();
  SET status   = "FAILED";
  SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
  RAISE USING message = err_desc;
  END;

--//SCD Type1 transaction begins

  SET sql_merge = FORMAT("""
          MERGE INTO `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM` AS TGT
          USING `<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.D1_AD_MEDIA_PLATFORM_WRK` AS SRC
          ON TGT.PLATFORM_CD = SRC.PLATFORM_CD
          
          -- Update only if any relevant field has changed
          WHEN MATCHED AND (IFNULL(TGT.PLATFORM_PROMOTIONAL_CHANNEL_CD, 'N/A') != IFNULL(SRC.PLATFORM_PROMOTIONAL_CHANNEL_CD, 'N/A') 
          ) THEN
            UPDATE SET
              TGT.PLATFORM_PROMOTIONAL_CHANNEL_CD = SRC.PLATFORM_PROMOTIONAL_CHANNEL_CD,
              TGT.DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP()

          -- Insert new records
          WHEN NOT MATCHED THEN
            INSERT (
              AD_MEDIA_PLATFORM_D1_SK,
              PLATFORM_CD,
              PLATFORM_PROMOTIONAL_CHANNEL_CD,
              DW_CREATE_TS,
              DW_LAST_UPDATE_TS
            )
            VALUES (
              SRC.AD_MEDIA_PLATFORM_D1_SK,
              SRC.PLATFORM_CD,
              SRC.PLATFORM_PROMOTIONAL_CHANNEL_CD,
              CURRENT_TIMESTAMP(),
              CURRENT_TIMESTAMP()
            )
        """);

  BEGIN
  EXECUTE IMMEDIATE (sql_begin);       
  EXECUTE IMMEDIATE (sql_merge);

  SET record_count = @@row_count;

  EXECUTE IMMEDIATE (sql_commit);
  SET row_count = row_count + record_count;
  
  EXCEPTION WHEN ERROR THEN
  EXECUTE IMMEDIATE (sql_rollback);
  SET job_end  = CURRENT_TIMESTAMP();
  SET status   = "FAILED";
  SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
  CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
  RAISE USING message = err_desc;
  END;

  SET status  = "COMPLETED";
  SET job_end = CURRENT_TIMESTAMP();
  --DQ Check
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Analytical',CURRENT_DATE(),"D1_AD_MEDIA_PLATFORM");
	CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

ELSE 
  SET err_desc = "Invalid load type parameter provided.";
  RAISE USING message = err_desc;
END IF;
END;