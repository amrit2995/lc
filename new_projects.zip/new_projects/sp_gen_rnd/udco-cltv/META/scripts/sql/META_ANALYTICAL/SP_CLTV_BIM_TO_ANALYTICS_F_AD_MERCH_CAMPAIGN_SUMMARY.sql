CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_F_AD_MERCH_CAMPAIGN_SUMMARY`(job_id STRING)
BEGIN
SET @@query_label = "<<SP_LABEL>>, spname:sp_cltv_bim_to_analytics_f_ad_merch_campaign_summary";
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_updates STRING;
DECLARE sql_inserts STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE row_count_tgt INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ' ';
SET status    = 'RUNNING';
SET proc_name = 'SP_CLTV_BIM_TO_ANALYTICS_F_AD_MERCH_CAMPAIGN_SUMMARY'; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.analytical_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_MERCH_CAMPAIGN_SUMMARY';
SET tgt_wrk_tbl     = '<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_MERCH_CAMPAIGN_SUMMARY_WRK';        

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;

--Truncate WRK Table
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || '''
(
    PERFORMANCE_DAY_ID,
    AD_MEDIA_PLATFORM_D1_SK,
    AD_MEDIA_CAMPAIGN_D1_SK,
    PLATFORM_MEDIA_CAMPAIGN_D1_SK,
    AD_MEDIA_CAMPAIGN_LINE_D1_SK,
    PLATFORM_MEDIA_LINE_D1_SK,
    TOTAL_IMPRESSION_CNT,
    CPG_MEDIA_SPEND_AMT,
    TOTAL_TRANSACTION_CNT,
    TOTAL_REVENUE_AMT,
    NEW_BRAND_BUYER_CNT,
    REPEAT_BRAND_BUYER_CNT,
    LOYAL_BRAND_BUYER_CNT,
    LAPSED_BRAND_BUYER_CNT,
    DW_CREATE_TS,
    DW_LAST_UPDATE_TS
)
-- Common base attribution logic to get Platform level attrubutions to be used later
WITH base_attribution AS (
  SELECT 
    m.campaign_id, 
    CAST(COALESCE(lic.line_item_id, m.line_item_id) AS STRING) AS line_item_id, 
    m.ad_id, 
    m.event_dt, 
    m.order_cnt, 
    m.transaction_amt, 
    RANK() OVER(
      PARTITION BY m.ad_id, m.event_dt, m.conversion_cut_value_txt 
      ORDER BY m.measurement_end_dt DESC
    ) AS Rnk 
  FROM 
    `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.meta_attribution` m 
    JOIN (
      SELECT DISTINCT ad_id, line_item_id 
      FROM `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.line_item_creative` lic 
      WHERE lic.source_application_cd IN('FACEBOOK', 'INSTAGRAM') 
        AND lic.dw_current_version_ind = TRUE
    ) lic ON(lic.ad_id = m.ad_id) 
  WHERE 
    (m.ad_object_cut_type_cd = 'ad_id' AND m.conversion_cut_type_cd = 'transaction_category') 
    AND m.dw_current_version_ind = TRUE 
  QUALIFY Rnk = 1
),
-- Calculating impressions at platform level
impressions_cnt_cte AS (
  SELECT 
    campaign_id, -- platform l1 id
    line_item_id, -- platform l2 id
    performance_dt, 
    SUM(impressions_cnt) AS impressions_cnt 
  FROM 
    `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_performance` 
  WHERE 
    dw_current_version_ind = TRUE 
    AND source_application_cd = 'FACEBOOK' 
  GROUP BY 1, 2, 3
),
-- Pre-cutoff platform l1 + hub l1 extraction from campaign name
pre_cutoff_platform_campaigns AS (
  SELECT 
    DISTINCT pc.source_application_cd AS platform, 
    pc.campaign_id, -- platform l1 id
    TRIM(SPLIT(pc.campaign_nm, '|')[SAFE_OFFSET(12)]) AS hub_l1_id,
    CAST(pc.start_ts as DATE) as platform_campaign_start_dt, 
    COALESCE(
      CAST(pc.end_ts as DATE), 
      CAST('9999-12-10' as DATE)
    ) as platform_campaign_end_dt 
  FROM 
    `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_campaign` pc 
  WHERE pc.dw_current_version_ind = True AND pc.source_application_cd IN('FACEBOOK','INSTAGRAM')
    AND pc.source_created_ts < "2025-06-24"  -- Cut-off Date for Meta & Pinterest (as per Gopi)
    AND TRIM(SPLIT(pc.campaign_nm, '|')[SAFE_OFFSET(12)]) IS NOT NULL -- to exclude invalid Hub Campaign Ids
    AND TRIM(SPLIT(pc.campaign_nm, '|')[SAFE_OFFSET(12)]) != '' -- to exclude invalid Hub Campaign Ids
   --  AND pc.source_created_ts >= "2025-06-24"  
   --  AND TRIM(SPLIT(pc.campaign_nm, '|')[SAFE_OFFSET(12)]) = 'QS32035089121578' -- QS32035089121578.011, QS32035089121578.009 -- 120233838874070307
),

-- Left Joining with OMS_MEDIA_CAMPAIGN to get platform start/end dates in case campaign start/end dates are missing
pre_cutoff_hub_campaigns AS (
  SELECT 
    pc.platform, 
    pc.campaign_id, 
    pc.hub_l1_id as hub_campaign_id,
    -- COALESCE(
    --   mc.campaign_start_dt, pc.platform_campaign_start_dt
    -- ) as campaign_start_dt, 
    pc.platform_campaign_start_dt as campaign_start_dt,
    -- COALESCE(
    --   mc.campaign_end_dt, pc.platform_campaign_end_dt
    -- ) as campaign_end_dt 
    pc.platform_campaign_end_dt as campaign_end_dt
  FROM 
    pre_cutoff_platform_campaigns pc 
    --  LEFT JOIN `gcp-abs-udco-bq-prod-prj-01.udco_ds_cltv_confirmed.oms_media_campaign` mc 
    -- ON(pc.hub_l1_id = mc.hub_campaign_id AND mc.dw_current_version_ind = True) 
    WHERE DATE_ADD(pc.platform_campaign_end_dt , INTERVAL 21 DAY) <= CURRENT_DATE - 1 
),

-- Joining with ad_platform_line_item to get hub l2 id from line item name and line item id for impressions join later
pre_cutoff_hub_tactics_campaigns AS (
  SELECT 
    DISTINCT pc.platform, 
    pc.campaign_id, -- platform l1 id
    pc.hub_campaign_id, -- hub l1 id
    pc.campaign_start_dt, 
    pc.campaign_end_dt, 
    pli.line_item_id, -- platform l2 id
    TRIM(SPLIT(pli.line_item_nm, '|')[SAFE_OFFSET(15)]) AS hub_l2_id -- hub l2 id
  FROM 
    pre_cutoff_hub_campaigns pc 
    JOIN `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_line_item` pli 
      ON(pc.campaign_id = pli.campaign_id 
      AND pc.platform = pli.source_application_cd AND pli.dw_current_version_ind = True 
      AND pli.source_created_ts < "2025-06-24") -- Cut-off Date for Meta & Pinterest (as per Gopi)
      -- AND pli.source_created_ts >= "2025-06-24" 
),

post_cutoff_base_platform_campaigns AS (
  SELECT 
    DISTINCT pc.source_application_cd AS platform, 
    pc.campaign_id, -- platform l1 id
    CAST(pc.start_ts as DATE) as platform_campaign_start_dt, 
    COALESCE(
      CAST(pc.end_ts as DATE), 
      CAST('9999-12-10' as DATE)
    ) as platform_campaign_end_dt 
  FROM 
    `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_campaign` pc 
  WHERE 
    pc.dw_current_version_ind = TRUE 
    AND pc.source_application_cd IN('FACEBOOK', 'INSTAGRAM') 
    AND pc.source_created_ts >= "2025-06-24"
),

-- Platform, hub l1, platform l1 id extraction
post_cutoff_platform_campaigns AS (
  SELECT 
    DISTINCT m.platform, 
    m.campaign_id, -- platform l1 id
    mc.hub_campaign_id, -- hub l1 id
    -- COALESCE(
    --   mc.campaign_start_dt, m.platform_campaign_start_dt
    -- ) as campaign_start_dt, 
    m.platform_campaign_start_dt as campaign_start_dt,
    -- COALESCE(
    --   mc.campaign_end_dt, m.platform_campaign_end_dt
    -- ) as campaign_end_dt, 
    m.platform_campaign_end_dt as campaign_end_dt,
    bio.buying_insertion_order_id 
  FROM 
    post_cutoff_base_platform_campaigns m 
    JOIN `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.BUYING_INSERTION_ORDER` bio ON (
      m.campaign_id = bio.ad_platform_campaign_id -- AND UPPER(bio.buying_insertion_order_nm) LIKE '%META%' 
      AND bio.dw_current_version_ind = TRUE
    ) 
    JOIN `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.OMS_MEDIA_CAMPAIGN` mc ON (
      mc.media_campaign_id = bio.media_campaign_id 
      AND mc.dw_current_version_ind = TRUE
    ) 
  WHERE 
    DATE_ADD(
      m.platform_campaign_end_dt, INTERVAL 21 DAY
    ) <= CURRENT_DATE - 1 
    AND mc.hub_campaign_id IS NOT NULL 
    AND mc.hub_campaign_id != '' -- to exclude invalid Hub Campaign Ids
), 

-- Platform l2 and hub l2 id extraction
post_cutoff_tactics_campaigns AS (
  SELECT 
    DISTINCT pli.source_application_cd AS platform, 
    pli.campaign_id, -- platform l1 id
    bli.buying_insertion_order_id, -- bridge column to join with post_cutoff_platform_campaigns
    pli.line_item_id, -- platform l2 id
    mcl.line_dsc -- hub l2 id
  FROM 
    `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_line_item` pli 
    JOIN `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.BUYING_LINE_ITEM` bli 
      ON(
      pli.line_item_id = bli.ad_platform_line_item_id 
      and bli.dw_current_version_ind = true
    ) 
    JOIN `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.OMS_MEDIA_CAMPAIGN_LINE_ITEM` mcl 
      ON(
      mcl.media_campaign_line_item_id = bli.media_campaign_line_item_id 
      and mcl.dw_current_version_ind = true
    ) 
  WHERE 
    pli.dw_current_version_ind = TRUE 
    AND pli.source_created_ts >= "2025-06-24"
),

post_cutoff_hub_tactics_campaigns AS (
  SELECT 
    pc.platform, 
    pc.campaign_id, -- platform l1 id
    pc.hub_campaign_id, -- hub l1 id
    pc.campaign_start_dt, 
    pc.campaign_end_dt, 
    pli.line_item_id, -- platform l2 id
    pli.line_dsc AS hub_l2_id
  FROM 
    post_cutoff_platform_campaigns pc 
    JOIN post_cutoff_tactics_campaigns pli 
      ON(pc.campaign_id = pli.campaign_id 
         AND pc.buying_insertion_order_id = pli.buying_insertion_order_id 
         AND pc.platform = pli.platform)
),
-- Combining pre and post cutoff campaigns and joining with base attribution to get order count and transaction amount for the campaigns.
hub_attribution AS (
  SELECT 
    pc.campaign_id,
    m.line_item_id, 
    pc.platform, 
    pc.hub_campaign_id, 
    pc.hub_l2_id, 
    m.event_dt, 
    COALESCE(m.order_cnt, 0) AS order_cnt,
    COALESCE(m.transaction_amt, 0) AS transaction_amt,
    0 AS impressions_cnt,
    'pre_cutoff' AS source_type
  FROM 
    pre_cutoff_hub_tactics_campaigns pc 
    LEFT JOIN base_attribution m 
      ON(pc.campaign_id = m.campaign_id 
         AND pc.line_item_id = m.line_item_id
         AND m.event_dt BETWEEN pc.campaign_start_dt 
           AND (CASE WHEN pc.campaign_end_dt = DATE '9999-12-31' THEN pc.campaign_end_dt 
                     ELSE DATE_ADD(pc.campaign_end_dt, INTERVAL 14 DAY) END))
  
  UNION ALL
  
  SELECT 
    pc.campaign_id,
    m.line_item_id, 
    pc.platform, 
    pc.hub_campaign_id, 
    pc.hub_l2_id, 
    m.event_dt, 
    COALESCE(m.order_cnt, 0) AS order_cnt,
    COALESCE(m.transaction_amt, 0) AS transaction_amt,
    0 AS impressions_cnt,
    'post_cutoff' AS source_type
  FROM 
    post_cutoff_hub_tactics_campaigns pc 
    LEFT JOIN base_attribution m 
      ON(pc.campaign_id = m.campaign_id 
         AND pc.line_item_id = m.line_item_id
         AND m.event_dt BETWEEN pc.campaign_start_dt 
           AND (CASE WHEN pc.campaign_end_dt = DATE '9999-12-31' THEN pc.campaign_end_dt 
                     ELSE DATE_ADD(pc.campaign_end_dt, INTERVAL 14 DAY) END))
),
-- Joining impressions with same logic as attribution to get impression counts at platform level for the same set of campaigns
hub_impressions AS (
  SELECT
    pc.campaign_id,
    pc.line_item_id, 
    pc.platform, 
    pc.hub_campaign_id, 
    pc.hub_l2_id, 
    imp.performance_dt AS event_dt, 
    0 AS order_cnt, 
    0 AS transaction_amt,
    COALESCE(imp.impressions_cnt, 0) AS impressions_cnt,
    'pre_cutoff' AS source_type
  FROM 
    pre_cutoff_hub_tactics_campaigns pc 
    LEFT JOIN impressions_cnt_cte imp 
      ON(pc.campaign_id = imp.campaign_id 
         AND pc.line_item_id = imp.line_item_id
         AND imp.performance_dt BETWEEN pc.campaign_start_dt 
           AND (CASE WHEN pc.campaign_end_dt = DATE '9999-12-31' THEN pc.campaign_end_dt 
                     ELSE DATE_ADD(pc.campaign_end_dt, INTERVAL 14 DAY) END))
  
  UNION ALL
  
  SELECT
    pc.campaign_id,
    pc.line_item_id, 
    pc.platform, 
    pc.hub_campaign_id, 
    pc.hub_l2_id, 
    imp.performance_dt AS event_dt, 
    0 AS order_cnt, 
    0 AS transaction_amt,
    COALESCE(imp.impressions_cnt, 0) AS impressions_cnt,
    'post_cutoff' AS source_type
  FROM 
    post_cutoff_hub_tactics_campaigns pc 
    LEFT JOIN impressions_cnt_cte imp 
      ON(pc.campaign_id = imp.campaign_id 
         AND pc.line_item_id = imp.line_item_id
         AND imp.performance_dt BETWEEN pc.campaign_start_dt 
           AND (CASE WHEN pc.campaign_end_dt = DATE '9999-12-31' THEN pc.campaign_end_dt 
                     ELSE DATE_ADD(pc.campaign_end_dt, INTERVAL 14 DAY) END))
),

combined_data AS (
  SELECT * FROM hub_attribution
  UNION ALL
  SELECT * FROM hub_impressions
),
-- Adding CPG media spend calculation based on impressions and CPM values from D1_AD_MEDIA_CAMPAIGN_LINE table
combined_calculated_cpg_media_spend AS (
  SELECT 
    cd.campaign_id,
    cd.line_item_id,
    cd.platform,
    cd.hub_campaign_id,
    cd.hub_l2_id,
    cd.event_dt,
    cd.order_cnt,
    cd.transaction_amt,
    cd.impressions_cnt,
    cd.source_type,
    (cd.impressions_cnt * COALESCE(mcl.AD_LINE_ITEM_CPM_AMT, 0)) / 1000 AS cpg_media_spend
  FROM 
    combined_data cd
    LEFT JOIN `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN_LINE` mcl 
      ON(cd.hub_l2_id = mcl.AD_LINE_ID)
),

unified_attribution AS (
  SELECT 
    campaign_id,
    event_dt, 
    platform, 
    line_item_id,
    hub_campaign_id, 
    hub_l2_id, 
    source_type,
    SUM(order_cnt) AS order_cnt, 
    SUM(transaction_amt) AS transaction_amt,
    SUM(impressions_cnt) AS impressions_cnt,
    SUM(cpg_media_spend) AS total_cpg_media_spend
  FROM 
    combined_calculated_cpg_media_spend
  GROUP BY 1, 2, 3, 4, 5, 6, 7
)

SELECT  
  COALESCE(dfd.FISCAL_DAY_ID, -1) AS PERFORMANCE_DAY_ID,
  COALESCE(amp.AD_MEDIA_PLATFORM_D1_SK, -1) AS AD_MEDIA_PLATFORM_D1_SK,
  COALESCE(amc.AD_MEDIA_CAMPAIGN_D1_SK, -1) AS AD_MEDIA_CAMPAIGN_D1_SK,
  COALESCE(pmc.PLATFORM_MEDIA_CAMPAIGN_D1_SK, -1) AS PLATFORM_MEDIA_CAMPAIGN_D1_SK,
  COALESCE(amcl.AD_MEDIA_CAMPAIGN_LINE_D1_SK, -1) AS AD_MEDIA_CAMPAIGN_LINE_D1_SK,
  COALESCE(pml.PLATFORM_MEDIA_LINE_D1_SK, -1) AS PLATFORM_MEDIA_LINE_D1_SK, 
  COALESCE(ua.impressions_cnt, 0) AS TOTAL_IMPRESSION_CNT,
  COALESCE(ua.total_cpg_media_spend, 0) AS CPG_MEDIA_SPEND_AMT,
  COALESCE(ua.order_cnt, 0) AS TOTAL_TRANSACTION_CNT, 
  COALESCE(ua.transaction_amt, 0) AS TOTAL_REVENUE_AMT,
  0 AS NEW_BRAND_BUYER_CNT,
  0 AS REPEAT_BRAND_BUYER_CNT,
  0 AS LOYAL_BRAND_BUYER_CNT,
  0 AS LAPSED_BRAND_BUYER_CNT,
  CURRENT_TIMESTAMP() AS DW_CREATE_TS,
  CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
FROM 
  unified_attribution ua
  LEFT JOIN `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM` amp 
    ON(ua.platform = amp.PLATFORM_CD)
  LEFT JOIN `<<CLTV_PROJECT_ID>>.udco_ds_acct_analytics.D0_FISCAL_DAY` dfd
    ON dfd.CALENDAR_DT = ua.event_dt
  LEFT JOIN `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CAMPAIGN` pmc 
    ON(ua.platform = pmc.PLATFORM_CD AND ua.campaign_id = pmc.PLATFORM_CAMPAIGN_ID)
  LEFT JOIN `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_LINE` pml 
    ON(ua.platform = pml.PLATFORM_CD AND ua.line_item_id = pml.PLATFORM_LINE_ITEM_ID)
  LEFT JOIN `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN` amc 
    ON(ua.hub_campaign_id = amc.AD_CAMPAIGN_ID)
  LEFT JOIN `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN_LINE` amcl 
    ON(ua.hub_l2_id = amcl.AD_LINE_ID)
''';

--// Processing Updates
SET sql_updates = '''UPDATE ''' || tgt_tbl || ''' as T
	SET T.TOTAL_IMPRESSION_CNT = S.TOTAL_IMPRESSION_CNT
		,T.CPG_MEDIA_SPEND_AMT = S.CPG_MEDIA_SPEND_AMT
		,T.TOTAL_TRANSACTION_CNT = S.TOTAL_TRANSACTION_CNT
		,T.TOTAL_REVENUE_AMT = S.TOTAL_REVENUE_AMT
		,T.NEW_BRAND_BUYER_CNT = S.NEW_BRAND_BUYER_CNT
		,T.REPEAT_BRAND_BUYER_CNT = S.REPEAT_BRAND_BUYER_CNT
		,T.LOYAL_BRAND_BUYER_CNT = S.LOYAL_BRAND_BUYER_CNT
		,T.LAPSED_BRAND_BUYER_CNT = S.LAPSED_BRAND_BUYER_CNT
		,T.DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP()
	FROM 
	''' || tgt_wrk_tbl  || '''  as S
	WHERE
		T.PERFORMANCE_DAY_ID = S.PERFORMANCE_DAY_ID
		AND T.AD_MEDIA_PLATFORM_D1_SK = S.AD_MEDIA_PLATFORM_D1_SK
		AND T.AD_MEDIA_CAMPAIGN_D1_SK = S.AD_MEDIA_CAMPAIGN_D1_SK
		AND T.PLATFORM_MEDIA_CAMPAIGN_D1_SK = S.PLATFORM_MEDIA_CAMPAIGN_D1_SK
		AND T.AD_MEDIA_CAMPAIGN_LINE_D1_SK = S.AD_MEDIA_CAMPAIGN_LINE_D1_SK
		AND T.PLATFORM_MEDIA_LINE_D1_SK = S.PLATFORM_MEDIA_LINE_D1_SK
	''';

	
--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
		PERFORMANCE_DAY_ID
		,AD_MEDIA_PLATFORM_D1_SK
		,AD_MEDIA_CAMPAIGN_D1_SK
		,PLATFORM_MEDIA_CAMPAIGN_D1_SK
		,AD_MEDIA_CAMPAIGN_LINE_D1_SK
		,PLATFORM_MEDIA_LINE_D1_SK
		,TOTAL_IMPRESSION_CNT
		,CPG_MEDIA_SPEND_AMT
		,TOTAL_TRANSACTION_CNT
		,TOTAL_REVENUE_AMT
		,NEW_BRAND_BUYER_CNT
		,REPEAT_BRAND_BUYER_CNT
		,LOYAL_BRAND_BUYER_CNT
		,LAPSED_BRAND_BUYER_CNT
		,DW_CREATE_TS
		,DW_LAST_UPDATE_TS
                        )
	SELECT 
		S.PERFORMANCE_DAY_ID
		,S.AD_MEDIA_PLATFORM_D1_SK
		,S.AD_MEDIA_CAMPAIGN_D1_SK
		,S.PLATFORM_MEDIA_CAMPAIGN_D1_SK
		,S.AD_MEDIA_CAMPAIGN_LINE_D1_SK
		,S.PLATFORM_MEDIA_LINE_D1_SK
		,S.TOTAL_IMPRESSION_CNT
		,S.CPG_MEDIA_SPEND_AMT
		,S.TOTAL_TRANSACTION_CNT
		,S.TOTAL_REVENUE_AMT
		,S.NEW_BRAND_BUYER_CNT
		,S.REPEAT_BRAND_BUYER_CNT
		,S.LOYAL_BRAND_BUYER_CNT
		,S.LAPSED_BRAND_BUYER_CNT
		,CURRENT_TIMESTAMP()
		,CURRENT_TIMESTAMP()
	FROM ''' || tgt_wrk_tbl  || '''  as S
	WHERE NOT EXISTS (
		SELECT 1 FROM ''' || tgt_tbl || ''' AS T
		WHERE
			T.PERFORMANCE_DAY_ID = S.PERFORMANCE_DAY_ID
			AND T.AD_MEDIA_PLATFORM_D1_SK = S.AD_MEDIA_PLATFORM_D1_SK
			AND T.AD_MEDIA_CAMPAIGN_D1_SK = S.AD_MEDIA_CAMPAIGN_D1_SK
			AND T.PLATFORM_MEDIA_CAMPAIGN_D1_SK = S.PLATFORM_MEDIA_CAMPAIGN_D1_SK
			AND T.AD_MEDIA_CAMPAIGN_LINE_D1_SK = S.AD_MEDIA_CAMPAIGN_LINE_D1_SK
			AND T.PLATFORM_MEDIA_LINE_D1_SK = S.PLATFORM_MEDIA_LINE_D1_SK
	)
	''';

SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
EXECUTE IMMEDIATE (sql_begin);       
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
		SET row_count = @@row_count;
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    EXECUTE IMMEDIATE (sql_updates);
	EXECUTE IMMEDIATE (sql_inserts);
    EXECUTE IMMEDIATE (sql_commit);
    EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
END;

--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','analytical',CURRENT_DATE(),"F_AD_MERCH_CAMPAIGN_SUMMARY");

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;
END;