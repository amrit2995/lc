# 🚀 SP: F_AD_PLATFORM_CAMPAIGN_RF_TREND Implementation

## 📊 Overview
Added comprehensive support for loading the `F_AD_PLATFORM_CAMPAIGN_RF_TREND` table, which tracks cumulative audience reach and impression metrics for social media advertising campaigns over time. This enables analysis of campaign effectiveness in reaching target audiences across social platforms.

## 🔧 Key Features
- **Platform Support**: Currently handles META (Facebook/Instagram) platform data
- **Insert-Only Pattern**: Uses simple truncate-and-load pattern for fact table population
- **Dimensional Lookups**: Joins with multiple dimension tables to derive surrogate keys
- **Audit Trail**: Full audit logging with process start/end tracking and error handling

### 📱 Processing Logic
- Joins campaign reach summary data with fiscal calendar for day identification
- Resolves platform, advertiser, and campaign surrogate keys via dimensional lookups
- Bridges to OMS media campaign through `buying_insertion_order` relationship

## 🗂️ Files Added/Updated

### Stored Procedure
- ✅ `META/scripts/sql/META_ANALYTICAL/SP_CLTV_BIM_TO_ANALYTICS_F_AD_PLATFORM_CAMPAIGN_RF_TREND.sql` - Main loading stored procedure with dimensional lookups

### DDL
- ✅ `META/scripts/ddl/Analytical/ddl_f_ad_platform_campaign_rf_trend.sql` - Main table DDL
- ✅ `META/scripts/ddl/Analytical/ddl_f_ad_platform_campaign_rf_trend_wrk.sql` - Work table DDL

### Configuration Files
- ✅ `META/config/BToA_META_F_AD_PLATFORM_CAMPAIGN_RF_TREND_BQToBQ.json` - BigQuery-to-BigQuery job configuration

## 📈 Data Flow
1. **Truncate Work Table** 🗑️ - Clear staging area for fresh load
2. **Populate Work Table** 📥 - Insert transformed data with dimensional lookups
3. **Insert to Target** ➕ - Load data from work table to main fact table
4. **Cleanup** ✅ - Truncate work table and log completion

## 🔗 Source Tables
| Table | Purpose |
|-------|---------|
| `campaign_reach_summary` | Core reach metrics (reach_cnt, impressions_cnt) |
| `D0_FISCAL_DAY` | Fiscal calendar for day identification |
| `D1_PLATFORM_MEDIA_CAMPAIGN` | Platform campaign surrogate key lookup |
| `D1_AD_MEDIA_PLATFORM` | Platform surrogate key lookup |
| `ad_platform_campaign` | Campaign-to-advertiser relationship |
| `D1_PLATFORM_ADVERTISER` | Advertiser surrogate key lookup |
| `buying_insertion_order` | Bridge to OMS media campaign |
| `oms_media_campaign` | OMS campaign details |
| `D1_AD_MEDIA_CAMPAIGN` | Ad media campaign surrogate key lookup |

## 🎯 Key Metrics
- **Reach Metrics**: Unique users exposed to campaigns
- **Impression Counts**: Total campaign impressions including repeats
- **Click Counts**: Clicks from reached audience (placeholder for future)
- **Revenue Metrics**: Measurement revenue attribution (placeholder for future)
- **Spend Metrics**: CPG media spend tracking (placeholder for future)

## 📋 Target Table Schema

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>Mode</th>
      <th>Type</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>PERFORMANCE_DAY_ID</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Fiscal Day Identifier; Format: YYYYMMDD; e.g. 20210101</td>
    </tr>
    <tr>
      <td>PLATFORM_ADVERTISER_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for advertiser-platform relationship – ensures uniqueness across all advertiser-platform combinations.</td>
    </tr>
    <tr>
      <td>PLATFORM_MEDIA_CAMPAIGN_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for platform media campaign – uniquely identifies each campaign per platform.</td>
    </tr>
    <tr>
      <td>AD_MEDIA_PLATFORM_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for advertiser-platform relationship – composite key with PLATFORM_CD + PLATFORM_PROMOTIONAL_CHANNEL_CD.</td>
    </tr>
    <tr>
      <td>AD_MEDIA_CAMPAIGN_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for campaign – uniquely identifies each advertising campaign record in the system.</td>
    </tr>
    <tr>
      <td>AD_MEDIA_OPPORTUNITY_D1_SK</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Surrogate key for opportunity – uniquely identifies each advertising opportunity record in the system.</td>
    </tr>
    <tr>
      <td>CUMULATIVE_AD_CAMPAIGN_REACH_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Estimated number of unique users who were exposed to the campaign.</td>
    </tr>
    <tr>
      <td>CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Total number of times the campaign was served, including repeats.</td>
    </tr>
    <tr>
      <td>CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Total number of clicks generated from users who were exposed to the campaign.</td>
    </tr>
    <tr>
      <td>CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC(14,2)</td>
      <td>Average number of impressions per unique user reached by the campaign.</td>
    </tr>
    <tr>
      <td>CUMULATIVE_CLICK_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Total number of clicks generated from the entire audience.</td>
    </tr>
    <tr>
      <td>CUMULATIVE_IMPRESSION_CNT</td>
      <td>REQUIRED</td>
      <td>NUMERIC</td>
      <td>Total number of impressions served to the entire audience.</td>
    </tr>
    <tr>
      <td>CUMULATIVE_MEASUREMENT_REVENUE_AMT</td>
      <td>REQUIRED</td>
      <td>NUMERIC(14,2)</td>
      <td>Total measured revenue amount attributed to the campaign.</td>
    </tr>
    <tr>
      <td>DW_CREATE_TS</td>
      <td>REQUIRED</td>
      <td>TIMESTAMP</td>
      <td>Timestamp when the record was created.</td>
    </tr>
    <tr>
      <td>DW_LAST_UPDATE_TS</td>
      <td>REQUIRED</td>
      <td>TIMESTAMP</td>
      <td>Timestamp when the record was last updated.</td>
    </tr>
  </tbody>
</table>

## ⚙️ Configuration

### Job Configuration
```json
{
    "bod_name": "META",
    "job_name": "BToA_META_F_AD_CAMPAIGN_SOCIAL_REACH_TREND_BQToBQ",
    "run_on": "bq",
    "BQToBQ": {
        "dataset": "<<ANALYTIC_DATASET>>",
        "sp": "SP_CLTV_BIM_TO_ANALYTICS_F_AD_PLATFORM_CAMPAIGN_RF_TREND"
    }
}
```

### Environment Placeholders
| Placeholder | Description |
|-------------|-------------|
| `<<CLTV_PROJECT_ID>>` | Target GCP project ID |
| `<<ANALYTIC_DATASET>>` | Analytics dataset name |
| `<<AUDIT_DATASET>>` | Audit logging dataset |
| `<<REF_DATASET>>` | Reference dataset for DDL |
| `<<ENV>>` | Environment identifier (dev/qa/prod) |

## 🏷️ Tags and Metadata
- **App Code**: udco
- **Body Name**: meta
- **Domain Name**: collect
- **Environment**: configurable via `<<ENV>>`

## 📝 Notes
- This is a **fact table** (prefix `F_`) with no SCD Type 2 versioning
- Currently filters for META platform only (`AD_MEDIA_PLATFORM_D1_SK = 1`)
- Several metrics are placeholder zeros pending future implementation (clicks, revenue, spend)
- Uses `buying_insertion_order` as bridge table to connect platform campaigns to OMS media campaigns

---

This implementation enables tracking of social media campaign reach effectiveness with full dimensional context and audit logging. 🎉
