CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_PROMOTIONAL_CHANNEL`(job_id STRING)
BEGIN
  -- =========================
  -- Declarations
  -- =========================
  DECLARE job_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP();
  DECLARE proc_name STRING   DEFAULT 'SP_CLTV_BIM_TO_ANALYTICS_D1_AD_MEDIA_PROMOTIONAL_CHANNEL';

  DECLARE tgt_tbl STRING DEFAULT '`<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PROMOTIONAL_CHANNEL`';

  DECLARE rows_affected INT64 DEFAULT 0;
  DECLARE error_desc STRING;
  DECLARE sql_platform_channel_data STRING;
  DECLARE sql_merge_insert_tgt_tbl STRING;

  -- For audit procedure calls; for this static dimension we treat the window as the job time
  DECLARE data_extract_start_ts TIMESTAMP DEFAULT job_start;
  DECLARE data_extract_end_ts   TIMESTAMP DEFAULT job_start;

  -- =========================
  -- Build the MERGE statement (hardcoded 8 rows incl. N/A)
  -- =========================

SET sql_platform_channel_data = '''
SELECT 
  -1 AS AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK,
  'NA' AS PLATFORM_PROMOTIONAL_CHANNEL_CD,
  CURRENT_TIMESTAMP() AS DW_CREATE_TS,
  CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
UNION ALL
SELECT
  ROW_NUMBER() OVER (ORDER BY pos) AS AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK,
  PLATFORM_PROMOTIONAL_CHANNEL_CD,
  CURRENT_TIMESTAMP() AS DW_CREATE_TS,
  CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
FROM UNNEST([
  'Display',
  'On-Site Display',
  'On-Site SPA',
  'Social',
  'Digital Instore',
  'CTV',
  'High Impact Display',
  'PromoAmp',
  'Email'
]) AS PLATFORM_PROMOTIONAL_CHANNEL_CD WITH OFFSET AS pos
''';

SET sql_merge_insert_tgt_tbl = '''
MERGE INTO ''' || tgt_tbl || ''' T
USING (''' || sql_platform_channel_data || ''') S
  ON T.AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK = S.AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK
  WHEN MATCHED THEN UPDATE SET
    T.PLATFORM_PROMOTIONAL_CHANNEL_CD = S.PLATFORM_PROMOTIONAL_CHANNEL_CD,
    T.DW_LAST_UPDATE_TS = S.DW_LAST_UPDATE_TS
  WHEN NOT MATCHED THEN INSERT
  (
    AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK,
    PLATFORM_PROMOTIONAL_CHANNEL_CD,
    DW_CREATE_TS,
    DW_LAST_UPDATE_TS
  )
  VALUES
  (
    S.AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK,
    S.PLATFORM_PROMOTIONAL_CHANNEL_CD,
    S.DW_CREATE_TS,
    S.DW_LAST_UPDATE_TS
  )
''';

-- Main Script
BEGIN
    -- Audit entry running
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL', job_id, proc_name, job_start, CURRENT_TIMESTAMP(), data_extract_start_ts, data_extract_end_ts, 0, '''RUNNING''', '''''');

    -- Merge data directly into target table
    BEGIN
        BEGIN TRANSACTION;
        EXECUTE IMMEDIATE sql_merge_insert_tgt_tbl;
        COMMIT TRANSACTION;
    EXCEPTION WHEN ERROR THEN
        ROLLBACK TRANSACTION;
        SET error_desc = "MERGE into target table "|| tgt_tbl ||" Failed with error: " || @@error.message;
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL', job_id, proc_name, job_start, CURRENT_TIMESTAMP(), data_extract_start_ts, data_extract_end_ts, @@row_count, '''FAILED''', error_desc);
        RAISE USING message = error_desc;
    END;

    --DQ Check
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','ANALYTICAL',CURRENT_DATE(),"F_AD_PLATFORM_CAMPAIGN_RF_TREND");
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start, CURRENT_TIMESTAMP(),data_extract_start_ts,data_extract_end_ts,@@row_count,"COMPLETED",''' Processing Completed Successfully''' );
END;
END;
