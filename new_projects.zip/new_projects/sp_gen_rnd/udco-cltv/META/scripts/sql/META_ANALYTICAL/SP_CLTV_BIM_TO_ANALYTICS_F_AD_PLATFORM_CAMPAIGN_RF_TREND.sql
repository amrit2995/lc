CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_F_AD_PLATFORM_CAMPAIGN_RF_TREND`(job_id STRING)
BEGIN
-- SET @@query_label = "<<SP_LABEL>>, spname:sp_cltv_bim_to_analytics_f_ad_platform_campaign_rf_trend";
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE tgt_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE prcs_audit_tbl STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_insert_tgt_wrk_tbl STRING;
DECLARE sql_merge_insert_tgt_tbl STRING;
DECLARE sql_commit STRING;
DECLARE sql_rollback STRING;
DECLARE row_count_tgt INT64;
DECLARE error_desc STRING;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE sql_fetch_data STRING;
DECLARE max_audit_ts TIMESTAMP;
DECLARE load_type STRING;
DECLARE platform_cd STRING;
DECLARE promotional_channel_cd STRING;


--Placeholder for Variables.
SET job_start = CURRENT_TIMESTAMP();
SET status = 'RUNNING';
SET proc_name = 'SP_CLTV_BIM_TO_ANALYTICS_F_AD_PLATFORM_CAMPAIGN_RF_TREND';

-- start and end timestamp for data extract based on last successful run of the SP.

SET sql_max_audit_ts = FORMAT('''
  SELECT IFNULL(MAX(data_extract_end_ts), TIMESTAMP("1900-01-01 00:00:00 UTC"))
  FROM `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control`
  WHERE LOWER(proc_name) = LOWER('%s')
    AND UPPER(status) = 'COMPLETED'
''', proc_name);

EXECUTE IMMEDIATE sql_max_audit_ts INTO max_audit_ts;
SET data_extract_start_ts = max_audit_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();
SET platform_cd = 'FACEBOOK';
SET promotional_channel_cd = 'Social';

-- Set load_type based on audit timestamp
IF DATE(max_audit_ts) = '0001-01-01' THEN
  SET load_type = 'FULL_LOAD';
ELSE
  SET load_type = 'INCREMENTAL';
END IF;


--Placeholder for Table names.
SET prcs_audit_tbl = '`<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.PROCESS_AUDIT_LOG`';
SET tgt_tbl = '`<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_CAMPAIGN_RF_TREND`';
SET tgt_wrk_tbl = '`<<CLTV_PROJECT_ID>>.<<REF_DATASET>>.F_AD_PLATFORM_CAMPAIGN_RF_TREND_WRK`';

-- SQL Queries
SET sql_truncate_tgt_wrk_tbl = 'TRUNCATE TABLE ' || tgt_wrk_tbl;
SET sql_commit = 'COMMIT TRANSACTION';
SET sql_rollback = 'ROLLBACK TRANSACTION';

SET sql_fetch_data = '''
WITH
-- CTE to hold job parameters for easy reference in later queries and to avoid repetition.
job_params AS (
SELECT
    "''' || platform_cd || '''" AS platform_cd,
    "''' || promotional_channel_cd || '''" AS promotional_cd,
    CAST("''' || data_extract_start_ts || '''" AS TIMESTAMP) AS data_extract_start_ts,
    CAST("''' || data_extract_end_ts || '''" AS TIMESTAMP) AS data_extract_end_ts
),

-- CTE to filter out only Facebook data and campaign modified within extraction timestamp .
-- Fetch all the campaign details with it.
filtered_campaigns AS (
SELECT
    dfd.FISCAL_DAY_ID AS PERFORMANCE_DAY_ID,
    dpmc.PLATFORM_MEDIA_CAMPAIGN_D1_SK,
    dpmc.PLATFORM_CAMPAIGN_ID,
    dpmc.PLATFORM_CAMPAIGN_START_DT,
    dpmc.PLATFORM_CAMPAIGN_END_DT,
    dpmc.PLATFORM_CD,
    dfd.calendar_dt AS PERFORMANCE_DT,
    jp.promotional_cd AS PLATFORM_PROMOTIONAL_CHANNEL_CD
FROM `<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CAMPAIGN` dpmc
JOIN job_params jp
ON dpmc.PLATFORM_CD = jp.platform_cd
JOIN `<<CALENDAR_DATASET>>_analytics.D0_FISCAL_DAY` dfd
ON DATE(jp.data_extract_end_ts) = dfd.calendar_dt
WHERE dpmc.PLATFORM_CD = jp.platform_cd
-- AND DATE(jp.data_extract_end_ts) BETWEEN dpmc.PLATFORM_CAMPAIGN_START_DT AND dpmc.PLATFORM_CAMPAIGN_END_DT
),

-- Aggregate ad performance at line item level
ad_performance_l2 AS (
    SELECT
        fc.PLATFORM_CAMPAIGN_ID,
        adp.line_item_id,
        adp.performance_dt,
        SUM(adp.impressions_cnt) AS platform_impressions,
        SUM(adp.clicks_cnt) AS platform_clicks,
        ROUND(SUM(adp.impressions_cnt * omcli.effective_cost_per_thousand_impressions_amt / 1000), 2) AS cpg_media_spend
    FROM filtered_campaigns fc
    INNER JOIN `<<CONF_DATASET>>.ad_performance` adp
        ON fc.PLATFORM_CAMPAIGN_ID = adp.campaign_id
    LEFT JOIN `<<CONF_DATASET>>.oms_media_campaign_line_item` omcli
        ON omcli.media_campaign_line_item_id = adp.line_item_id
        AND omcli.dw_current_version_ind = TRUE
    GROUP BY fc.PLATFORM_CAMPAIGN_ID, adp.line_item_id, adp.performance_dt
),

-- Aggregate to campaign level
ad_performance_l1 AS (
    SELECT
        PLATFORM_CAMPAIGN_ID,
        performance_dt,
        SUM(platform_impressions) AS platform_impressions,
        SUM(platform_clicks) AS platform_clicks,
        SUM(cpg_media_spend) AS cpg_media_spend
    FROM ad_performance_l2
    GROUP BY PLATFORM_CAMPAIGN_ID, performance_dt
),
-- Build fact table with cumulative metrics
fact_table_base AS (
    SELECT 
        COALESCE(fc.PERFORMANCE_DAY_ID, -1) AS PERFORMANCE_DAY_ID,
        COALESCE(dpa.PLATFORM_ADVERTISER_D1_SK, -1) AS PLATFORM_ADVERTISER_D1_SK,
        COALESCE(amp.AD_MEDIA_PLATFORM_D1_SK, -1) AS AD_MEDIA_PLATFORM_D1_SK,
        COALESCE(damc.AD_MEDIA_CAMPAIGN_D1_SK, -1) AS AD_MEDIA_CAMPAIGN_D1_SK,
        COALESCE(fc.PLATFORM_MEDIA_CAMPAIGN_D1_SK, -1) AS PLATFORM_MEDIA_CAMPAIGN_D1_SK,
        COALESCE(damo.AD_MEDIA_OPPORTUNITY_D1_SK, -1) AS AD_MEDIA_OPPORTUNITY_D1_SK,
        COALESCE(ampc.AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK, -1) AS AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK,
        COALESCE(crs.reach_cnt, 0) AS CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
        COALESCE(crs.impressions_cnt, 0) AS CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
        0 AS CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
        0 AS CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
        COALESCE(SUM(ap.platform_clicks) OVER (
            PARTITION BY ap.PLATFORM_CAMPAIGN_ID
            ORDER BY ap.performance_dt
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ), 0) AS CUMULATIVE_CLICK_CNT,
        COALESCE(SUM(ap.platform_impressions) OVER (
            PARTITION BY ap.PLATFORM_CAMPAIGN_ID
            ORDER BY ap.performance_dt
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ), 0) AS CUMULATIVE_IMPRESSION_CNT,
        COALESCE(SUM(fapcp.MEASUREMENT_TOTAL_REVENUE_AMT) OVER ( 
            PARTITION BY fapcp.PLATFORM_MEDIA_CAMPAIGN_D1_SK, fapcp.AD_MEDIA_PLATFORM_D1_SK
            ORDER BY fc.PERFORMANCE_DT
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ), 0) AS CUMULATIVE_MEASUREMENT_REVENUE_AMT,
        COALESCE(SUM(ap.cpg_media_spend) OVER (
            PARTITION BY ap.PLATFORM_CAMPAIGN_ID
            ORDER BY ap.performance_dt
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ), 0) AS CUMULATIVE_CPG_MEDIA_SPEND_AMT,
        CURRENT_TIMESTAMP() AS DW_CREATE_TS,
        CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
    -- To get impression and reach count.
    FROM filtered_campaigns fc
    -- To get additional perfomance metrics.
    LEFT JOIN ad_performance_l1 ap
        ON ap.PLATFORM_CAMPAIGN_ID = fc.PLATFORM_CAMPAIGN_ID
        AND ap.performance_dt = fc.PERFORMANCE_DT
    LEFT JOIN `<<CONF_DATASET>>.campaign_reach_summary` crs
        ON crs.campaign_id = fc.PLATFORM_CAMPAIGN_ID
    -- To get AD_MEDIA_PLATFORM_SK
    LEFT JOIN `<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM` amp
        ON fc.PLATFORM_CD = amp.PLATFORM_CD
    -- To Get Platform Advertiser_SK
    LEFT JOIN `<<CONF_DATASET>>.ad_platform_campaign` apc
        ON apc.campaign_id = fc.PLATFORM_CAMPAIGN_ID
        -- AND apc.source_application_cd = fc.platform_cd
        -- AND DATE(fc. BETWEEN DATE(apc.start_ts) AND DATE(apc.end_ts)
        AND apc.dw_current_version_ind = TRUE
    LEFT JOIN `<<ANALYTIC_DATASET>>.D1_PLATFORM_ADVERTISER` dpa
        ON apc.advertiser_id = dpa.PLATFORM_ADVERTISER_ID
    -- To get Ad Media Campaign_SK
    LEFT JOIN `<<CONF_DATASET>>.buying_insertion_order` bio
        ON bio.ad_platform_campaign_id = fc.PLATFORM_CAMPAIGN_ID
        AND bio.dw_current_version_ind = TRUE
    LEFT JOIN `<<CONF_DATASET>>.oms_media_campaign` omc
        ON omc.media_campaign_id = bio.media_campaign_id
        AND omc.dw_current_version_ind = TRUE
    -- To get the Oppurtunity_SK
    LEFT JOIN `<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN` damc
        ON damc.AD_MEDIA_CAMPAIGN_ID = omc.media_campaign_id
    LEFT JOIN `<<ANALYTIC_DATASET>>.D1_AD_MEDIA_OPPORTUNITY` as damo
        on damo.AD_MEDIA_OPPORTUNITY_ID = omc.opportunity_id
    -- To get revenue amt. Value
    LEFT JOIN `<<ANALYTIC_DATASET>>.FA_AD_PLATFORM_CAMPAIGN_PERFORMANCE` fapcp
        ON fapcp.PLATFORM_MEDIA_CAMPAIGN_D1_SK = fc.PLATFORM_MEDIA_CAMPAIGN_D1_SK
        AND fapcp.PERFORMANCE_DAY_ID = fc.PERFORMANCE_DAY_ID
    -- To get the Promotional Channel_SK
    LEFT JOIN `<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PROMOTIONAL_CHANNEL` AS ampc
        ON ampc.PLATFORM_PROMOTIONAL_CHANNEL_CD = fc.PLATFORM_PROMOTIONAL_CHANNEL_CD
)
select * from fact_table_base;
''';

SET sql_insert_tgt_wrk_tbl = '''
INSERT INTO ''' || tgt_wrk_tbl || '''
(
    PERFORMANCE_DAY_ID,
    PLATFORM_ADVERTISER_D1_SK,
    AD_MEDIA_PLATFORM_D1_SK,
    AD_MEDIA_CAMPAIGN_D1_SK,
    PLATFORM_MEDIA_CAMPAIGN_D1_SK,
    AD_MEDIA_OPPORTUNITY_D1_SK,
    AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK,
    CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    CUMULATIVE_CLICK_CNT,
    CUMULATIVE_IMPRESSION_CNT,
    CUMULATIVE_MEASUREMENT_REVENUE_AMT,
    CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    DW_CREATE_TS,
    DW_LAST_UPDATE_TS
)
''' || sql_fetch_data ;

SET sql_merge_insert_tgt_tbl = '''MERGE INTO ''' || tgt_tbl || ''' T
USING ''' || tgt_wrk_tbl || ''' S
ON T.PERFORMANCE_DAY_ID = S.PERFORMANCE_DAY_ID
AND T.PLATFORM_ADVERTISER_D1_SK = S.PLATFORM_ADVERTISER_D1_SK
AND T.AD_MEDIA_PLATFORM_D1_SK = S.AD_MEDIA_PLATFORM_D1_SK
AND T.AD_MEDIA_CAMPAIGN_D1_SK = S.AD_MEDIA_CAMPAIGN_D1_SK
AND T.AD_MEDIA_OPPORTUNITY_D1_SK = S.AD_MEDIA_OPPORTUNITY_D1_SK
AND T.AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK = S.AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK
AND T.PLATFORM_MEDIA_CAMPAIGN_D1_SK = S.PLATFORM_MEDIA_CAMPAIGN_D1_SK
WHEN MATCHED THEN UPDATE SET
    CUMULATIVE_AD_CAMPAIGN_REACH_CNT = S.CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT = S.CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT = S.CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT = S.CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    CUMULATIVE_CLICK_CNT = S.CUMULATIVE_CLICK_CNT,
    CUMULATIVE_IMPRESSION_CNT = S.CUMULATIVE_IMPRESSION_CNT,
    CUMULATIVE_MEASUREMENT_REVENUE_AMT = S.CUMULATIVE_MEASUREMENT_REVENUE_AMT,
    CUMULATIVE_CPG_MEDIA_SPEND_AMT = S.CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    DW_LAST_UPDATE_TS = S.DW_LAST_UPDATE_TS
WHEN NOT MATCHED THEN INSERT
(
    PERFORMANCE_DAY_ID,
    PLATFORM_ADVERTISER_D1_SK,
    AD_MEDIA_PLATFORM_D1_SK,
    AD_MEDIA_CAMPAIGN_D1_SK,
    PLATFORM_MEDIA_CAMPAIGN_D1_SK,
    AD_MEDIA_OPPORTUNITY_D1_SK,
    AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK,
    CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    CUMULATIVE_CLICK_CNT,
    CUMULATIVE_IMPRESSION_CNT,
    CUMULATIVE_MEASUREMENT_REVENUE_AMT,
    CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    DW_CREATE_TS,
    DW_LAST_UPDATE_TS
)
VALUES
(
    S.PERFORMANCE_DAY_ID,
    S.PLATFORM_ADVERTISER_D1_SK,
    S.AD_MEDIA_PLATFORM_D1_SK,
    S.AD_MEDIA_CAMPAIGN_D1_SK,
    S.PLATFORM_MEDIA_CAMPAIGN_D1_SK,
    S.AD_MEDIA_OPPORTUNITY_D1_SK,
    S.AD_MEDIA_PROMOTIONAL_CHANNEL_D1_SK,
    S.CUMULATIVE_AD_CAMPAIGN_REACH_CNT,
    S.CUMULATIVE_AD_CAMPAIGN_REACH_IMPRESSION_CNT,
    S.CUMULATIVE_AD_CAMPAIGN_REACH_CLICK_CNT,
    S.CUMULATIVE_AD_CAMPAIGN_AVG_IMPRESSION_CNT,
    S.CUMULATIVE_CLICK_CNT,
    S.CUMULATIVE_IMPRESSION_CNT,
    S.CUMULATIVE_MEASUREMENT_REVENUE_AMT,
    S.CUMULATIVE_CPG_MEDIA_SPEND_AMT,
    S.DW_CREATE_TS,
    S.DW_LAST_UPDATE_TS
);''';

-- Main Script.
BEGIN
    -- Audit entry running
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL', job_id, proc_name, job_start, CURRENT_TIMESTAMP(), data_extract_start_ts, data_extract_end_ts, 0, '''RUNNING''', '''''');

    -- Truncate target work table
    BEGIN
        EXECUTE IMMEDIATE sql_truncate_tgt_wrk_tbl;
    EXCEPTION WHEN ERROR THEN
        SET error_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message;
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL', job_id, proc_name, job_start, CURRENT_TIMESTAMP(), data_extract_start_ts, data_extract_end_ts, 0, '''FAILED''', error_desc);
        RAISE USING message = error_desc;
    END;

    -- insert data to target work table
    BEGIN
        EXECUTE IMMEDIATE sql_insert_tgt_wrk_tbl;
        SET row_count_tgt = @@row_count;
    EXCEPTION WHEN ERROR THEN
        SET error_desc = "INSERT into work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message;
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL', job_id, proc_name, job_start, CURRENT_TIMESTAMP(), data_extract_start_ts, data_extract_end_ts, 0, '''FAILED''', error_desc);
        RAISE USING message = error_desc;
    END;

    -- insert data to target table
    BEGIN
        BEGIN TRANSACTION;
        EXECUTE IMMEDIATE sql_merge_insert_tgt_tbl;
        COMMIT TRANSACTION;
    EXCEPTION WHEN ERROR THEN
        ROLLBACK TRANSACTION;
        SET error_desc = "INSERT into target table "|| tgt_tbl ||" Failed with error: " || @@error.message;
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL', job_id, proc_name, job_start, CURRENT_TIMESTAMP(), data_extract_start_ts, data_extract_end_ts, @@row_count, '''FAILED''', error_desc);
        RAISE USING message = error_desc;
    END;

    -- Truncate target work table
    BEGIN
        EXECUTE IMMEDIATE sql_truncate_tgt_wrk_tbl;
    EXCEPTION WHEN ERROR THEN
        SET error_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message;
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL', job_id, proc_name, job_start, CURRENT_TIMESTAMP(), data_extract_start_ts, data_extract_end_ts, 0, '''FAILED''', error_desc);
        RAISE USING message = error_desc;
    END;

    --DQ Check
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','ANALYTICAL',CURRENT_DATE(),"F_AD_PLATFORM_CAMPAIGN_RF_TREND");
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start, CURRENT_TIMESTAMP(),data_extract_start_ts,data_extract_end_ts,@@row_count,"COMPLETED",''' Processing Completed Successfully''' );
END;
END;