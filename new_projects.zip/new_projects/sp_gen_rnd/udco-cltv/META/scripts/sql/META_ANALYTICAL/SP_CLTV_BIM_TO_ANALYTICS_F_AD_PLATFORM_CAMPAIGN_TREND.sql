CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<ANALYTIC_DATASET>>.SP_CLTV_BIM_TO_ANALYTICS_F_AD_PLATFORM_CAMPAIGN_TREND`(job_id STRING)
BEGIN
SET @@query_label = "<<SP_LABEL>>, spname:sp_cltv_bim_to_analytics_f_ad_platform_campaign_trend";
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_truncate_tgt_wrk_tbl_2 STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE insert_tgt_wrk_tbl_2 STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE tgt_wrk_tbl_2 STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts_history STRING;
DECLARE sql_inserts STRING;
DECLARE sql_inserts_2 STRING;
DECLARE sql_updates STRING;
DECLARE tgt_tbl STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE row_count_tgt INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;

SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_BIM_TO_ANALYTICS_F_AD_PLATFORM_CAMPAIGN_TREND'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.analytical_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.F_AD_PLATFORM_CAMPAIGN_TREND';
SET tgt_wrk_tbl     = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.F_AD_PLATFORM_CAMPAIGN_TREND_TMP_WRK';  
SET tgt_wrk_tbl_2     = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.F_AD_PLATFORM_CAMPAIGN_TREND_WRK';        

SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_truncate_tgt_wrk_tbl_2 = '''TRUNCATE TABLE ''' || tgt_wrk_tbl_2 ;

--Truncate WRK Tables
BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl_2);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl_2 ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;

SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
			DATE
			,AD_ID
			,LINE_ITEM_ID
			,CAMPAIGN_ID
			,ADVERTISER_ID
			,SOURCE_APPLICATION_CD
			,PLATFORM_IMPRESSIONS
			,PLATFORM_CLICKS
			,SPEND_AMT
			,PLATFORM_VIDEO_STARTS
			,PLATFORM_VIDEO_25P
			,PLATFORM_VIDEO_50P
			,PLATFORM_VIDEO_75P
			,PLATFORM_VIDEO_COMPLETES
			,POST_REACTION_WOW_CNT
			,POST_REACTION_SAD_CNT
			,POST_REACTION_LOVE_CNT
			,POST_REACTION_HAHA_CNT
			,POST_REACTION_CARE_CNT
			,POST_REACTION_ANGRY_CNT
			,POST_REACTION_LIKE_CNT
			,PLATFORM_META_POST_ENGAGEMENTS
			,PLATFORM_META_POST_COMMENTS
			,PLATFORM_META_POST_REACTIONS
			,PINTEREST_REPIN_CNT
			,PINTEREST_ENGAGEMENT_CNT
        )
        WITH 
		core as 
		(
			select distinct ad_id, lic.source_application_cd, lic.line_item_id, li.campaign_id, c.advertiser_id, c.start_ts, c.end_ts
			FROM
			(
				select distinct ad_id, source_application_cd, line_item_id from `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.line_item_creative`
				WHERE dw_current_version_ind = TRUE AND SOURCE_APPLICATION_CD in ('FACEBOOK','PINTEREST')  
			) lic
			left join 
			(
				select distinct line_item_id, source_application_cd, CAST(campaign_id AS STRING) as campaign_id from `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_line_item`
				WHERE dw_current_version_ind = TRUE AND SOURCE_APPLICATION_CD in ('FACEBOOK','PINTEREST')  
			) li
			on lic.line_item_id = li.line_item_id
			and lic.source_application_cd = li.source_application_cd  -- // added to bring all platforms
			left join 
			(
				select distinct campaign_id, source_application_cd, advertiser_id, start_ts, end_ts from `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_campaign`
				WHERE dw_current_version_ind = TRUE AND SOURCE_APPLICATION_CD in ('FACEBOOK','PINTEREST') 
			) c
			on c.campaign_id = cast(li.campaign_id as STRING)
			and c.source_application_cd = li.source_application_cd  -- // added to bring all platforms
		),
		
		calculated_dates as 
		(
			SELECT DISTINCT performance_dt as dates, source_application_cd from <<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_performance
			WHERE DW_LAST_UPDATE_TS > "''' || data_extract_start_ts || '''" 
			UNION DISTINCT 
			SELECT DISTINCT video_action_dt as dates, source_application_cd from <<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_video_action
			WHERE DW_LAST_UPDATE_TS > "''' || data_extract_start_ts || '''" 
			UNION DISTINCT 
			SELECT DISTINCT action_reaction_dt as dates, source_application_cd from <<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_action_reaction
			WHERE DW_LAST_UPDATE_TS > "''' || data_extract_start_ts || '''"
		)
				
		select 
			date, ad_id, line_item_id, campaign_id, advertiser_id, source_application_cd,
			sum(COALESCE(platform_impressions,0)) as platform_impressions, sum(COALESCE(platform_clicks,0)) as platform_clicks, sum(COALESCE(spend_amt,0)) as spend_amt,
			sum(COALESCE(CAST(platform_video_starts as numeric),0)) as platform_video_starts, sum(COALESCE(CAST(platform_video_25p as numeric),0)) as platform_video_25p, sum(COALESCE(cast(platform_video_50p as numeric),0)) as platform_video_50p, sum(COALESCE(CAST(platform_video_75p as numeric),0)) as platform_video_75p, sum(COALESCE(cast(platform_video_completes as numeric),0)) as platform_video_completes,
			sum(COALESCE(POST_REACTION_WOW_CNT,0)) as POST_REACTION_WOW_CNT, sum(COALESCE(POST_REACTION_SAD_CNT,0)) as POST_REACTION_SAD_CNT, sum(COALESCE(POST_REACTION_LOVE_CNT,0)) as POST_REACTION_LOVE_CNT, sum(COALESCE(POST_REACTION_HAHA_CNT,0)) as POST_REACTION_HAHA_CNT, sum(COALESCE(POST_REACTION_CARE_CNT,0)) as POST_REACTION_CARE_CNT, sum(COALESCE(POST_REACTION_ANGRY_CNT,0)) as POST_REACTION_ANGRY_CNT, 
			sum(COALESCE(POST_REACTION_LIKE_CNT,0)) as POST_REACTION_LIKE_CNT, sum(COALESCE(platform_meta_post_engagements,0)) as platform_meta_post_engagements, 
			sum(COALESCE(platform_meta_post_comments,0)) as platform_meta_post_comments, sum(COALESCE(platform_meta_post_reactions,0)) as platform_meta_post_reactions,
			sum(COALESCE(pinterest_repin_cnt,0)) as pinterest_repin_cnt, sum(COALESCE(pinterest_engagement_cnt,0)) as pinterest_engagement_cnt
		from
		(	
			select ap.performance_dt as date,
				--ID
				COALESCE(ap.ad_id,'N/A') as ad_id, COALESCE(ap.line_item_id,'N/A') as line_item_id, 
				COALESCE(CAST(ap.campaign_id AS STRING),'N/A') as campaign_id, COALESCE(c.advertiser_id,'N/A') as advertiser_id, 
				COALESCE(ap.source_application_cd,'N/A') as source_application_cd,
				--ad_performance metrics
				ap.impressions_cnt as platform_impressions, ap.clicks_cnt as platform_clicks, ap.platform_media_spend_amt as spend_amt, 
				--ad_video_action metrics
				0 as platform_video_starts, 0 as platform_video_25p, 0 as platform_video_50p, 0 as platform_video_75p, 0 as platform_video_completes,
				--ad_action_reaction metrics
				0 as POST_REACTION_WOW_CNT, 0 as POST_REACTION_SAD_CNT, 0 as POST_REACTION_LOVE_CNT, 0 as POST_REACTION_HAHA_CNT, 0 as POST_REACTION_CARE_CNT, 
				0 as POST_REACTION_ANGRY_CNT, 0 as POST_REACTION_LIKE_CNT, 0 as platform_meta_post_engagements, 0 as platform_meta_post_comments, 
				0 as platform_meta_post_reactions, 0 as pinterest_repin_cnt, 0 as pinterest_engagement_cnt
			from <<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_performance ap
			INNER JOIN calculated_dates
				ON ap.performance_dt = calculated_dates.dates
				and ap.source_application_cd = calculated_dates.source_application_cd
				AND ap.DW_CURRENT_VERSION_IND = TRUE
			INNER join 	`<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_campaign` as c
				on c.campaign_id = CAST(ap.campaign_id  as STRING)
				AND c.dw_current_version_ind = TRUE
				AND ap.performance_dt between CAST(c.start_ts as DATE) and CAST(c.end_ts as DATE)
				AND c.source_application_cd = ap.source_application_cd  -- // added to bring all platforms

			union all
		
			select ava.video_action_dt as date, 
				--ID
				COALESCE(ava.ad_id,'N/A') as ad_id, COALESCE(core.line_item_id,'N/A') as line_item_id, 
				COALESCE(core.campaign_id,'N/A') as campaign_id, COALESCE(core.advertiser_id,'N/A') as advertiser_id,
				COALESCE(ava.source_application_cd,'N/A') as source_application_cd,
				--ad_performance metrics
				0 as platform_impressions, 0 as platform_clicks, 0 as spend_amt,
				--ad_video_action metrics
				case when video_action_type_id = 1 then Value_nbr end as platform_video_starts,
				case when video_action_type_id = 2 then Value_nbr end as platform_video_25p,
				case when video_action_type_id = 3 then Value_nbr end as platform_video_50p,
				case when video_action_type_id = 4 then Value_nbr end as platform_video_75p,
				case when video_action_type_id = 5 then Value_nbr end as platform_video_completes,
				--ad_action_reaction metrics
				0 as POST_REACTION_WOW_CNT, 0 as POST_REACTION_SAD_CNT, 0 as POST_REACTION_LOVE_CNT, 0 as POST_REACTION_HAHA_CNT, 
				0 as POST_REACTION_CARE_CNT, 0 as POST_REACTION_ANGRY_CNT, 0 as POST_REACTION_LIKE_CNT, 0 as platform_meta_post_engagements, 
				0 as platform_meta_post_comments, 0 as platform_meta_post_reactions, 0 as pinterest_repin_cnt, 0 as pinterest_engagement_cnt
			from <<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_video_action as ava
			INNER JOIN calculated_dates
				ON ava.video_action_dt = calculated_dates.dates
				AND ava.source_application_cd = calculated_dates.source_application_cd
				AND ava.DW_CURRENT_VERSION_IND = TRUE
			left join core
				on ava.ad_id = core.ad_id
				and ava.source_application_cd = core.source_application_cd  -- // added to bring all platforms
			where ava.video_action_dt between CAST(core.start_ts as DATE) and CAST(core.end_ts as DATE)

		-- bringing dates from campaign
		/*	INNER JOIN  `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_line_item` adli
				ON adli.dw_current_version_ind = TRUE 
				AND adli.line_item_id = core.line_item_id
				AND adli.source_application_cd = core.source_application_cd */ -- // added to bring all platforms 
				
		
			union all

			select aar.action_reaction_dt as date,
				--ID
				COALESCE(aar.ad_id,'N/A') as ad_id, COALESCE(core.line_item_id,'N/A') as line_item_id, 
				COALESCE(core.campaign_id,'N/A') as campaign_id, COALESCE(core.advertiser_id,'N/A') as advertiser_id,
				COALESCE(aar.source_application_cd,'N/A') as source_application_cd,
				--ad_performance metrics
				0 as platform_impressions, 0 as platform_clicks, 0 as spend_amt,
				--ad_video_action metrics
				0 as platform_video_starts, 0 as platform_video_25p, 0 as platform_video_50p, 0 as platform_video_75p, 0 as platform_video_completes,
				--ad_action_reaction metrics
				CAST(case when art.action_reaction_cd = 'wow' then Value_nbr else 0 end as numeric) as POST_REACTION_WOW_CNT,
				CAST(case when art.action_reaction_cd = 'sad' then Value_nbr else 0 end as numeric) as POST_REACTION_SAD_CNT,
				CAST(case when art.action_reaction_cd = 'love' then Value_nbr else 0 end as numeric) as POST_REACTION_LOVE_CNT,
				CAST(case when art.action_reaction_cd = 'haha' then Value_nbr else 0 end as numeric) as POST_REACTION_HAHA_CNT,
				CAST(case when art.action_reaction_cd = 'care' then Value_nbr else 0 end as numeric) as POST_REACTION_CARE_CNT,
				CAST(case when art.action_reaction_cd = 'angry' then Value_nbr else 0 end as numeric) as POST_REACTION_ANGRY_CNT,
				CAST(case when art.action_reaction_cd = 'like' then Value_nbr else 0 end as numeric) as POST_REACTION_LIKE_CNT,
				CAST(case when art.action_reaction_cd = 'post_engagement' then Value_nbr else 0 end as numeric) as platform_meta_post_engagements,
				CAST(case when art.action_reaction_cd = 'comment' then Value_nbr else 0 end as numeric) as platform_meta_post_comments,
				CAST(case when art.action_reaction_cd = 'post_reaction' then Value_nbr else 0 end as numeric) as platform_meta_post_reactions,
				CAST(case when art.action_reaction_cd = 'repins' then Value_nbr else 0 end as numeric) as PINTEREST_REPIN_CNT,
				CAST(case when art.action_reaction_cd = 'engagements' then Value_nbr else 0 end as numeric) as PINTEREST_ENGAGEMENT_CNT
			from <<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_action_reaction as aar
			INNER JOIN calculated_dates
				ON aar.action_reaction_dt = calculated_dates.dates
				AND aar.source_application_cd = calculated_dates.source_application_cd
				AND aar.DW_CURRENT_VERSION_IND = TRUE
			left join <<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.action_reaction_type as art
				on aar.action_reaction_type_id= art.action_reaction_type_id
			left join core
				on aar.ad_id = core.ad_id
				and aar.source_application_cd = core.source_application_cd  -- // added to bring all platforms
			where aar.action_reaction_dt between CAST(core.start_ts as DATE) and CAST(core.end_ts as DATE)
			
		/*	INNER JOIN 
				`<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.ad_platform_line_item` adli
				ON adli.dw_current_version_ind = TRUE 
				AND adli.line_item_id = core.line_item_id
				AND adli.source_application_cd = core.source_application_cd  -- // added to bring all platforms
				AND aar.action_reaction_dt between CAST(adli.start_ts as DATE) and CAST(adli.end_ts as DATE) */
		)
		GROUP BY date, ad_id, line_item_id, campaign_id, advertiser_id, source_application_cd
		''';

SET insert_tgt_wrk_tbl_2 = '''INSERT INTO ''' || tgt_wrk_tbl_2 || '''
                ( 
		PERFORMANCE_DAY_ID
		,PLATFORM_MEDIA_AD_UNIT_D1_SK
		,PLATFORM_ADVERTISER_D1_SK
		,AD_MEDIA_PLATFORM_D1_SK
		,AD_MEDIA_CAMPAIGN_D1_SK
		,AD_MEDIA_CAMPAIGN_LINE_D1_SK
		,PLATFORM_MEDIA_CAMPAIGN_D1_SK
		,PLATFORM_MEDIA_LINE_D1_SK
		,PLATFORM_MEDIA_CREATIVE_D1_SK
		,PLATFORM_MEDIA_PLACEMENT_D1_SK
		,AD_MEDIA_OPPORTUNITY_D1_SK
		,PLATFORM_MEDIA_ADVERTISEMENT_D1_SK
		,TOTAL_CLICK_CNT
		,TOTAL_IMPRESSION_CNT
		,TOTAL_MEDIA_SPEND_AMT
		,VIDEO_START_CNT
		,VIDEO_25P_CNT
		,VIDEO_50P_CNT
		,VIDEO_75P_CNT
		,VIDEO_COMPLETE_CNT
		,POST_REACTION_ANGRY_CNT
		,POST_REACTION_WOW_CNT
		,POST_REACTION_LOVE_CNT
		,POST_REACTION_CARE_CNT
		,POST_REACTION_HAHA_CNT
		,POST_REACTION_LIKE_CNT
		,POST_REACTION_SAD_CNT
		,TOTAL_POST_ENGAGEMENT_CNT
		,TOTAL_POST_COMMENT_CNT
		,TOTAL_POST_REACTION_CNT
		,TOTAL_PINTEREST_REPINS_CNT
		,TOTAL_PINTEREST_ENGAGEMENT_CNT
		,CPG_MEDIA_SPEND_AMT
		,DW_CREATE_TS
		,DW_LAST_UPDATE_TS
                        )
select 
	dfd.FISCAL_DAY_ID AS PERFORMANCE_DAY_ID
	,CASE WHEN dpmau.PLATFORM_MEDIA_AD_UNIT_ID IS NOT NULL THEN dpmau.PLATFORM_MEDIA_AD_UNIT_D1_SK ELSE -1 END AS PLATFORM_MEDIA_AD_UNIT_D1_SK
	,CASE WHEN dpa.PLATFORM_ADVERTISER_ID IS NOT NULL THEN dpa.PLATFORM_ADVERTISER_D1_SK ELSE -1 END AS PLATFORM_ADVERTISER_D1_SK
	,CASE WHEN damp.PLATFORM_CD IS NOT NULL THEN damp.AD_MEDIA_PLATFORM_D1_SK ELSE -1 END as AD_MEDIA_PLATFORM_D1_SK
	,CASE WHEN damc.AD_CAMPAIGN_ID IS NOT NULL THEN damc.AD_MEDIA_CAMPAIGN_D1_SK ELSE -1 END as AD_MEDIA_CAMPAIGN_D1_SK
	,CASE WHEN damcl.AD_LINE_ID IS NOT NULL THEN damcl.AD_MEDIA_CAMPAIGN_LINE_D1_SK ELSE -1 END as AD_MEDIA_CAMPAIGN_LINE_D1_SK
	,CASE WHEN dpmc.PLATFORM_CAMPAIGN_ID IS NOT NULL THEN dpmc.PLATFORM_MEDIA_CAMPAIGN_D1_SK ELSE -1 END AS PLATFORM_MEDIA_CAMPAIGN_D1_SK
	,CASE WHEN dpml.PLATFORM_LINE_ITEM_ID IS NOT NULL THEN dpml.PLATFORM_MEDIA_LINE_D1_SK ELSE -1 END AS PLATFORM_MEDIA_LINE_D1_SK
	,-1 as PLATFORM_MEDIA_CREATIVE_D1_SK
	,-1 as PLATFORM_MEDIA_PLACEMENT_D1_SK
	,CASE WHEN damo.AD_MEDIA_OPPORTUNITY_ID IS NOT NULL THEN damo.AD_MEDIA_OPPORTUNITY_D1_SK ELSE -1 END AS AD_MEDIA_OPPORTUNITY_D1_SK
	,CASE WHEN dpma.PLATFORM_MEDIA_ADVERTISEMENT_ID IS NOT NULL THEN dpma.PLATFORM_MEDIA_ADVERTISEMENT_D1_SK ELSE -1 END AS PLATFORM_MEDIA_ADVERTISEMENT_D1_SK
	,metrics.platform_clicks AS TOTAL_CLICK_CNT
	,metrics.platform_impressions AS TOTAL_IMPRESSION_CNT
	,metrics.spend_amt AS TOTAL_MEDIA_SPEND_AMT
	,metrics.platform_video_starts AS VIDEO_START_CNT
	,metrics.platform_video_25p AS VIDEO_25P_CNT
	,metrics.platform_video_50p AS VIDEO_50P_CNT
	,metrics.platform_video_75p AS VIDEO_75P_CNT
	,metrics.platform_video_completes AS VIDEO_COMPLETE_CNT
	,metrics.POST_REACTION_ANGRY_CNT AS POST_REACTION_ANGRY_CNT
	,metrics.POST_REACTION_WOW_CNT AS POST_REACTION_WOW_CNT
	,metrics.POST_REACTION_LOVE_CNT AS POST_REACTION_LOVE_CNT
	,metrics.POST_REACTION_CARE_CNT AS POST_REACTION_CARE_CNT
	,metrics.POST_REACTION_HAHA_CNT AS POST_REACTION_HAHA_CNT
	,metrics.POST_REACTION_LIKE_CNT AS POST_REACTION_LIKE_CNT
	,metrics.POST_REACTION_SAD_CNT AS POST_REACTION_SAD_CNT
	,metrics.platform_meta_post_engagements AS TOTAL_POST_ENGAGEMENT_CNT
	,metrics.platform_meta_post_comments AS TOTAL_POST_COMMENT_CNT
	,metrics.platform_meta_post_reactions AS TOTAL_POST_REACTION_CNT
	,metrics.pinterest_repin_cnt AS TOTAL_PINTEREST_REPINS_CNT
	,metrics.pinterest_engagement_cnt AS TOTAL_PINTEREST_ENGAGEMENT_CNT
	,IFNULL(metrics.platform_impressions, 0) * IFNULL(damcl.AD_LINE_ITEM_CPM_AMT, 0) / 1000 AS CPG_MEDIA_SPEND_AMT
	,CURRENT_TIMESTAMP() AS DW_CREATE_TS
	,CURRENT_TIMESTAMP() AS DW_LAST_UPDATE_TS
	FROM
	''' || tgt_wrk_tbl  || '''  as metrics
	
		LEFT JOIN `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.buying_line_item` bli -- 107
		ON bli.ad_platform_line_item_id = CAST(metrics.line_item_id as STRING)
		AND bli.dw_current_version_ind = TRUE
		LEFT OUTER JOIN `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.oms_media_campaign_line_item` ocli
		ON ocli.media_campaign_line_item_id = bli.media_campaign_line_item_id
		AND ocli.dw_current_version_ind = TRUE
		LEFT OUTER JOIN `<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.oms_media_campaign` omc
		ON omc.media_campaign_id = ocli.media_campaign_id
		AND omc.dw_current_version_ind = TRUE
		
		--PLATFORM TABLES
		LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_ADVERTISER as dpa
			on dpa.PLATFORM_ADVERTISER_ID = metrics.advertiser_id
			and dpa.PLATFORM_CD = metrics.source_application_cd
		LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_CAMPAIGN as dpmc
			on dpmc.PLATFORM_CAMPAIGN_ID = metrics.campaign_id
			and dpmc.PLATFORM_CD = metrics.source_application_cd
		LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_LINE as dpml
			on dpml.PLATFORM_LINE_ITEM_ID = metrics.line_item_id
			and dpml.PLATFORM_CD = metrics.source_application_cd
		LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_AD_UNIT as dpmau
			on dpmau.PLATFORM_MEDIA_AD_UNIT_ID = metrics.ad_id
			and dpmau.PLATFORM_CD = metrics.source_application_cd
		LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_PLATFORM_MEDIA_ADVERTISEMENT as dpma
			on dpma.PLATFORM_MEDIA_ADVERTISEMENT_ID = metrics.ad_id
			and dpma.PLATFORM_CD = metrics.source_application_cd

		LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN as damc
			on damc.AD_MEDIA_CAMPAIGN_ID = omc.media_campaign_id
		LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_CAMPAIGN_LINE as damcl
			on damcl.AD_MEDIA_LINE_ID = ocli.media_campaign_line_item_id
		LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_PLATFORM as damp
			on damp.PLATFORM_CD = metrics.source_application_cd
		LEFT JOIN <<TABLE_PROJECT_ID>>.<<ANALYTIC_DATASET>>.D1_AD_MEDIA_OPPORTUNITY as damo
			on damo.AD_MEDIA_OPPORTUNITY_ID = omc.opportunity_id
		
		JOIN <<CLTV_VIEW_PROJECT_ID>>.<<CALENDAR_DATASET>>.D0_FISCAL_DAY as dfd
		ON metrics.date = dfd.CALENDAR_DT
	
	''';

--// Processing Updates
SET sql_updates = '''UPDATE ''' || tgt_tbl || ''' AS T
	SET
		T.TOTAL_CLICK_CNT = S.TOTAL_CLICK_CNT
		,T.TOTAL_IMPRESSION_CNT = S.TOTAL_IMPRESSION_CNT
		,T.TOTAL_MEDIA_SPEND_AMT = S.TOTAL_MEDIA_SPEND_AMT
		,T.VIDEO_START_CNT = S.VIDEO_START_CNT
		,T.VIDEO_25P_CNT = S.VIDEO_25P_CNT
		,T.VIDEO_50P_CNT = S.VIDEO_50P_CNT
		,T.VIDEO_75P_CNT = S.VIDEO_75P_CNT
		,T.VIDEO_COMPLETE_CNT = S.VIDEO_COMPLETE_CNT
		,T.POST_REACTION_ANGRY_CNT = S.POST_REACTION_ANGRY_CNT
		,T.POST_REACTION_WOW_CNT = S.POST_REACTION_WOW_CNT
		,T.POST_REACTION_LOVE_CNT = S.POST_REACTION_LOVE_CNT
		,T.POST_REACTION_CARE_CNT = S.POST_REACTION_CARE_CNT
		,T.POST_REACTION_HAHA_CNT = S.POST_REACTION_HAHA_CNT
		,T.POST_REACTION_LIKE_CNT = S.POST_REACTION_LIKE_CNT
		,T.POST_REACTION_SAD_CNT = S.POST_REACTION_SAD_CNT
		,T.TOTAL_POST_ENGAGEMENT_CNT = S.TOTAL_POST_ENGAGEMENT_CNT
		,T.TOTAL_POST_COMMENT_CNT = S.TOTAL_POST_COMMENT_CNT
		,T.TOTAL_POST_REACTION_CNT = S.TOTAL_POST_REACTION_CNT
		,T.TOTAL_PINTEREST_REPINS_CNT = S.TOTAL_PINTEREST_REPINS_CNT
		,T.TOTAL_PINTEREST_ENGAGEMENT_CNT = S.TOTAL_PINTEREST_ENGAGEMENT_CNT
		,T.CPG_MEDIA_SPEND_AMT = S.CPG_MEDIA_SPEND_AMT
		,T.DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP()
	FROM 
	''' || tgt_wrk_tbl_2  || '''  as S
	WHERE
		T.PERFORMANCE_DAY_ID = S.PERFORMANCE_DAY_ID
		AND T.PLATFORM_MEDIA_AD_UNIT_D1_SK = S.PLATFORM_MEDIA_AD_UNIT_D1_SK
		AND T.PLATFORM_ADVERTISER_D1_SK = S.PLATFORM_ADVERTISER_D1_SK
		AND T.AD_MEDIA_PLATFORM_D1_SK = S.AD_MEDIA_PLATFORM_D1_SK
		AND T.AD_MEDIA_CAMPAIGN_D1_SK = S.AD_MEDIA_CAMPAIGN_D1_SK
		AND T.AD_MEDIA_CAMPAIGN_LINE_D1_SK = S.AD_MEDIA_CAMPAIGN_LINE_D1_SK
		AND T.PLATFORM_MEDIA_CAMPAIGN_D1_SK = S.PLATFORM_MEDIA_CAMPAIGN_D1_SK
		AND T.PLATFORM_MEDIA_LINE_D1_SK = S.PLATFORM_MEDIA_LINE_D1_SK
		AND T.PLATFORM_MEDIA_CREATIVE_D1_SK = S.PLATFORM_MEDIA_CREATIVE_D1_SK
		AND T.PLATFORM_MEDIA_PLACEMENT_D1_SK = S.PLATFORM_MEDIA_PLACEMENT_D1_SK
		AND T.AD_MEDIA_OPPORTUNITY_D1_SK = S.AD_MEDIA_OPPORTUNITY_D1_SK
		AND T.PLATFORM_MEDIA_ADVERTISEMENT_D1_SK = S.PLATFORM_MEDIA_ADVERTISEMENT_D1_SK
	''';

	
--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
		PERFORMANCE_DAY_ID
		,PLATFORM_MEDIA_AD_UNIT_D1_SK
		,PLATFORM_ADVERTISER_D1_SK
		,AD_MEDIA_PLATFORM_D1_SK
		,AD_MEDIA_CAMPAIGN_D1_SK
		,AD_MEDIA_CAMPAIGN_LINE_D1_SK
		,PLATFORM_MEDIA_CAMPAIGN_D1_SK
		,PLATFORM_MEDIA_LINE_D1_SK
		,PLATFORM_MEDIA_CREATIVE_D1_SK
		,PLATFORM_MEDIA_PLACEMENT_D1_SK
		,AD_MEDIA_OPPORTUNITY_D1_SK
		,PLATFORM_MEDIA_ADVERTISEMENT_D1_SK
		,TOTAL_CLICK_CNT
		,TOTAL_IMPRESSION_CNT
		,TOTAL_MEDIA_SPEND_AMT
		,VIDEO_START_CNT
		,VIDEO_25P_CNT
		,VIDEO_50P_CNT
		,VIDEO_75P_CNT
		,VIDEO_COMPLETE_CNT
		,POST_REACTION_ANGRY_CNT
		,POST_REACTION_WOW_CNT
		,POST_REACTION_LOVE_CNT
		,POST_REACTION_CARE_CNT
		,POST_REACTION_HAHA_CNT
		,POST_REACTION_LIKE_CNT
		,POST_REACTION_SAD_CNT
		,TOTAL_POST_ENGAGEMENT_CNT
		,TOTAL_POST_COMMENT_CNT
		,TOTAL_POST_REACTION_CNT
		,TOTAL_PINTEREST_ENGAGEMENT_CNT
		,TOTAL_PINTEREST_REPINS_CNT
		,CPG_MEDIA_SPEND_AMT
		,DW_CREATE_TS
		,DW_LAST_UPDATE_TS
                        )
select 
		PERFORMANCE_DAY_ID
		,PLATFORM_MEDIA_AD_UNIT_D1_SK
		,PLATFORM_ADVERTISER_D1_SK
		,AD_MEDIA_PLATFORM_D1_SK
		,AD_MEDIA_CAMPAIGN_D1_SK
		,AD_MEDIA_CAMPAIGN_LINE_D1_SK
		,PLATFORM_MEDIA_CAMPAIGN_D1_SK
		,PLATFORM_MEDIA_LINE_D1_SK
		,PLATFORM_MEDIA_CREATIVE_D1_SK
		,PLATFORM_MEDIA_PLACEMENT_D1_SK
		,AD_MEDIA_OPPORTUNITY_D1_SK
		,PLATFORM_MEDIA_ADVERTISEMENT_D1_SK
		,TOTAL_CLICK_CNT
		,TOTAL_IMPRESSION_CNT
		,TOTAL_MEDIA_SPEND_AMT
		,VIDEO_START_CNT
		,VIDEO_25P_CNT
		,VIDEO_50P_CNT
		,VIDEO_75P_CNT
		,VIDEO_COMPLETE_CNT
		,POST_REACTION_ANGRY_CNT
		,POST_REACTION_WOW_CNT
		,POST_REACTION_LOVE_CNT
		,POST_REACTION_CARE_CNT
		,POST_REACTION_HAHA_CNT
		,POST_REACTION_LIKE_CNT
		,POST_REACTION_SAD_CNT
		,TOTAL_POST_ENGAGEMENT_CNT
		,TOTAL_POST_COMMENT_CNT
		,TOTAL_POST_REACTION_CNT
		,TOTAL_PINTEREST_ENGAGEMENT_CNT
		,TOTAL_PINTEREST_REPINS_CNT
		,CPG_MEDIA_SPEND_AMT
		,DW_CREATE_TS
		,DW_LAST_UPDATE_TS
	FROM
	''' || tgt_wrk_tbl_2  || '''  as S
	WHERE NOT EXISTS (
    SELECT 1 FROM ''' || tgt_tbl || ''' AS T
    WHERE
        T.PERFORMANCE_DAY_ID = S.PERFORMANCE_DAY_ID
        AND T.PLATFORM_MEDIA_AD_UNIT_D1_SK = S.PLATFORM_MEDIA_AD_UNIT_D1_SK
        AND T.PLATFORM_ADVERTISER_D1_SK = S.PLATFORM_ADVERTISER_D1_SK
        AND T.AD_MEDIA_PLATFORM_D1_SK = S.AD_MEDIA_PLATFORM_D1_SK
        AND T.AD_MEDIA_CAMPAIGN_D1_SK = S.AD_MEDIA_CAMPAIGN_D1_SK
        AND T.AD_MEDIA_CAMPAIGN_LINE_D1_SK = S.AD_MEDIA_CAMPAIGN_LINE_D1_SK
        AND T.PLATFORM_MEDIA_CAMPAIGN_D1_SK = S.PLATFORM_MEDIA_CAMPAIGN_D1_SK
        AND T.PLATFORM_MEDIA_LINE_D1_SK = S.PLATFORM_MEDIA_LINE_D1_SK
        AND T.PLATFORM_MEDIA_CREATIVE_D1_SK = S.PLATFORM_MEDIA_CREATIVE_D1_SK
        AND T.PLATFORM_MEDIA_PLACEMENT_D1_SK = S.PLATFORM_MEDIA_PLACEMENT_D1_SK
		AND T.AD_MEDIA_OPPORTUNITY_D1_SK = S.AD_MEDIA_OPPORTUNITY_D1_SK
		AND T.PLATFORM_MEDIA_ADVERTISEMENT_D1_SK = S.PLATFORM_MEDIA_ADVERTISEMENT_D1_SK
		)
	
	''';

SET sql_begin = "BEGIN TRANSACTION";
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
EXECUTE IMMEDIATE (sql_begin);       
select insert_tgt_wrk_tbl;
select insert_tgt_wrk_tbl_2;
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    BEGIN
        EXECUTE IMMEDIATE (insert_tgt_wrk_tbl_2);
		SET row_count = @@row_count;
        EXCEPTION WHEN ERROR THEN
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl_2 ||" Failed with error: " || @@error.message ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
    END;
    EXECUTE IMMEDIATE (sql_updates);
	EXECUTE IMMEDIATE (sql_inserts);
    EXECUTE IMMEDIATE (sql_commit);
    EXCEPTION WHEN ERROR THEN
    EXECUTE IMMEDIATE (sql_rollback);
    SET job_end  = CURRENT_TIMESTAMP();
    SET status   = "FAILED";
    SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
    CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
    RAISE USING message = err_desc;
END;

--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','analytical',CURRENT_DATE(),"F_AD_PLATFORM_CAMPAIGN_TREND");

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('ANALYTICAL',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;
END;
