CREATE OR REPLACE PROCEDURE `<<CLTV_PROJECT_ID>>.<<CONF_DATASET>>.SP_CLTV_META_LINE_ITEM_REF_TO_BIM_LOAD`(job_id STRING)
BEGIN
DECLARE sql_commit STRING;
DECLARE sql_truncate_tgt_wrk_tbl STRING;
DECLARE sql_delete_tgt_tbl STRING;
DECLARE insert_tgt_wrk_tbl STRING;
DECLARE src_tbl STRING;
DECLARE tgt_wrk_tbl STRING;
DECLARE tgt_update_tbl STRING;
DECLARE sql_begin STRING;
DECLARE sql_inserts STRING;
DECLARE sql_inserts_history STRING;
DECLARE tgt_tbl STRING;
DECLARE lkp_tbl STRING;
DECLARE sql_records_to_expire STRING;
DECLARE sql_updates STRING;
DECLARE sql_rollback STRING;
DECLARE err_desc STRING;
DECLARE status STRING;
DECLARE proc_name STRING;
DECLARE job_start TIMESTAMP;
DECLARE job_end TIMESTAMP;
DECLARE row_count INT64 default 0;
DECLARE data_extract_start_ts TIMESTAMP;
DECLARE data_extract_end_ts TIMESTAMP;
DECLARE sql_max_audit_ts STRING;
DECLARE prcs_audit_tbl STRING;


SET job_start = CURRENT_TIMESTAMP();
SET err_desc  = ''' ''';
SET status    = '''RUNNING''';
SET proc_name = '''SP_CLTV_META_LINE_ITEM_REF_TO_BIM_LOAD'''; 
SET prcs_audit_tbl= '<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.cltv_process_audit_control'; 
SET sql_max_audit_ts ='''SELECT IFNULL(MAX(data_extract_end_ts),parse_timestamp("%F %T %Z","1900-01-01 01:01:01 UTC")) 
						FROM ''' || prcs_audit_tbl ||''' WHERE lower(proc_name)= lower("''' || proc_name || '''") and  upper(status) = "COMPLETED" ''';
EXECUTE IMMEDIATE sql_max_audit_ts INTO data_extract_start_ts;
SET data_extract_end_ts = CURRENT_TIMESTAMP();

/* Audit entry for RUNNING */
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);

SET tgt_tbl         = '<<TABLE_PROJECT_ID>>.<<CONF_DATASET>>.AD_PLATFORM_LINE_ITEM';
SET tgt_wrk_tbl     = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.AD_PLATFORM_LINE_ITEM_WRK';    
SET tgt_update_tbl  = '<<TABLE_PROJECT_ID>>.<<REF_DATASET>>.AD_PLATFORM_LINE_ITEM_LR_UPDATE';     
SET src_tbl         = '<<SOURCE_PROJECT_ID>>.<<SRC_DATASET>>.ad_set_history';  --// Source table
SET lkp_tbl         = '<<L_PROJECT_ID>>.<<L_DATASET>>.l_2_naming_corrections';  --// Lookup table


SET sql_truncate_tgt_wrk_tbl = '''TRUNCATE TABLE ''' || tgt_wrk_tbl ;
SET sql_delete_tgt_tbl = '''DELETE FROM ''' || tgt_tbl || ''' WHERE SOURCE_APPLICATION_CD = "FACEBOOK" ''' ;

BEGIN
EXECUTE IMMEDIATE (sql_truncate_tgt_wrk_tbl);
EXCEPTION WHEN ERROR THEN
SET job_end  = CURRENT_TIMESTAMP();
SET status   = "FAILED";
SET err_desc = "TRUNCATE of work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
RAISE USING message = err_desc;
END;


SET insert_tgt_wrk_tbl = '''INSERT INTO ''' || tgt_wrk_tbl || ''' 
        (
        LINE_ITEM_ID
        ,SOURCE_APPLICATION_CD
        ,DW_FIRST_EFFECTIVE_TS
        ,DW_LAST_EFFECTIVE_TS
        ,CAMPAIGN_ID
        ,LINE_ITEM_NM
        ,LINE_ITEM_TYPE_NM
        ,UNITS_BOUGHT_CNT
        ,LINE_ITEM_SHORT_NM
        ,LINE_ITEM_BUDGET_AMT
        ,STATUS_NM
        ,START_TS
        ,END_TS
        ,AUDIENCE_NM
        ,AD_COST_TYPE_CD
        ,AD_COST_AMT
        ,DAILY_BUDGET_AMT
        ,EXPECTED_DAILY_SPEND_AMT
        ,PLANNED_IMPRESSION_CNT
        ,SOURCE_CREATED_TS
        ,SOURCE_LAST_MODIFIED_TS
        ,DW_CURRENT_VERSION_IND
        )
               
        SELECT SRC.LINE_ITEM_ID
                ,SRC.SOURCE_APPLICATION_CD
                ,SRC.DW_FIRST_EFFECTIVE_TS
                ,CASE 
                        WHEN SRC.dw_first_effective_ts = SRC.dw_last_effective_ts THEN '9999-12-31 00:00:00' 
                        ELSE TIMESTAMP_SUB(SRC.dw_last_effective_ts, INTERVAL 1 SECOND) 
                        END AS DW_LAST_EFFECTIVE_TS
                ,SRC.CAMPAIGN_ID
                ,SRC.LINE_ITEM_NM
                ,SRC.LINE_ITEM_TYPE_NM
                ,SRC.UNITS_BOUGHT_CNT
                ,SRC.LINE_ITEM_SHORT_NM
                ,SRC.LINE_ITEM_BUDGET_AMT
                ,SRC.STATUS_NM
                ,SRC.START_TS
                ,SRC.END_TS
                ,SRC.AUDIENCE_NM
                ,SRC.AD_COST_TYPE_CD
                ,SRC.AD_COST_AMT
                ,SRC.DAILY_BUDGET_AMT
                ,SRC.EXPECTED_DAILY_SPEND_AMT
                ,SRC.PLANNED_IMPRESSION_CNT
                ,SRC.SOURCE_CREATED_TS
                ,SRC.SOURCE_LAST_MODIFIED_TS
                ,CASE WHEN SRC.dw_first_effective_ts = SRC.dw_last_effective_ts THEN TRUE ELSE FALSE END AS DW_CURRENT_VERSION_IND
        FROM
        (
                SELECT DISTINCT CAST(SRC.ID AS STRING) AS LINE_ITEM_ID
                        ,"FACEBOOK" AS SOURCE_APPLICATION_CD
                        ,CAST(UPDATED_TIME AS TIMESTAMP) AS dw_first_effective_ts
                        ,LAST_VALUE(updated_time) OVER (record_window) AS dw_last_effective_ts
                        ,CAST(SRC.campaign_Id AS STRING) AS CAMPAIGN_ID
                        ,COALESCE(correction.updated_name, SRC.name) AS LINE_ITEM_NM                   --l_2_naming_correction
                        ,CAST(NULL AS STRING) AS LINE_ITEM_TYPE_NM              
                        ,CAST(NULL AS INT64) AS UNITS_BOUGHT_CNT        
                        ,SUBSTR(COALESCE(correction.updated_name, SRC.name), 0, INSTR(COALESCE(correction.updated_name, SRC.name), '|', 1, 15))  AS LINE_ITEM_SHORT_NM       --l_2_naming_correction (new field)
                        ,SAFE_CAST(SPLIT(COALESCE(correction.updated_name, SRC.name), '|')[SAFE_OFFSET(14)] as NUMERIC) AS LINE_ITEM_BUDGET_AMT      --l_2_naming_correction (new field)
                        ,Status AS STATUS_NM
                        ,start_time AS START_TS                         --column name change
                        ,end_time AS END_TS                      --column name change   
                        ,SPLIT(COALESCE(correction.updated_name, SRC.name), '|')[SAFE_OFFSET(4)]  as AUDIENCE_NM                  --l_2_naming_correction new field
                        ,"CPM" AS AD_COST_TYPE_CD                               -- new field, default value
                        ,CAST(SPLIT(COALESCE(correction.updated_name, SRC.name), '|')[SAFE_OFFSET(11)] AS NUMERIC)  AS AD_COST_AMT   --l_2_naming_correction new field
                        ,CAST(daily_budget AS NUMERIC) AS DAILY_BUDGET_AMT              -- new field
                        ,daily_spend_cap AS EXPECTED_DAILY_SPEND_AMT   -- new field
                        ,SAFE_CAST(SPLIT(COALESCE(correction.updated_name, SRC.name), '|')[SAFE_OFFSET(10)] as INT64) AS PLANNED_IMPRESSION_CNT                -- new field
                        ,created_time AS SOURCE_CREATED_TS                          
                        ,updated_time AS SOURCE_LAST_MODIFIED_TS
                FROM
                ''' || src_tbl || ''' SRC
                LEFT JOIN (SELECT DISTINCT id,updated_name
                        FROM ''' || lkp_tbl || ''' correction
                        WHERE site='Facebook'
                        QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY _fivetran_synced desc) = 1
                        ) correction
                ON TRIM(CAST(SRC.id AS STRING)) = TRIM(CAST(correction.id AS STRING)) 
                WHERE _fivetran_synced > "''' || data_extract_start_ts || '''"
                AND updated_time IS NOT NULL
                WINDOW  record_window AS (PARTITION BY src.id ORDER BY updated_time ASC ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)
        ) SRC
	LEFT JOIN ''' || tgt_tbl || ''' TGT 
	        ON SRC.LINE_ITEM_ID = TGT.LINE_ITEM_ID
                AND SRC.source_application_cd = TGT.source_application_cd
                AND TGT.DW_CURRENT_VERSION_IND = TRUE
        WHERE TGT.LINE_ITEM_ID IS NULL
              OR SRC.DW_FIRST_EFFECTIVE_TS > TGT.DW_FIRST_EFFECTIVE_TS
        ''';



--//SCD Type2 transaction begins
SET sql_begin = "BEGIN TRANSACTION";
SET sql_records_to_expire = '''INSERT INTO ''' || tgt_update_tbl || ''' 
                            (
                            LINE_ITEM_ID,
                            SOURCE_APPLICATION_CD,
                            DW_FIRST_EFFECTIVE_TS,
                            DW_LAST_EFFECTIVE_TS,
                            DW_CURRENT_VERSION_IND
                            )
                            SELECT  
                                TGT.LINE_ITEM_ID
                                ,TGT.source_application_cd
                                ,TGT.dw_first_effective_ts
                                ,TIMESTAMP_SUB(SRC.dw_first_effective_ts, INTERVAL 1 SECOND) AS dw_last_effective_ts
                                ,FALSE AS dw_current_version_ind
                            FROM    ''' || tgt_tbl || '''  TGT
                            INNER  JOIN (
                                SELECT *
                                FROM    ''' || tgt_wrk_tbl || ''' 
                                QUALIFY ROW_NUMBER() OVER (PARTITION BY LINE_ITEM_ID, source_application_cd ORDER BY dw_first_effective_ts ASC) = 1
                            ) SRC
                            ON      TGT.LINE_ITEM_ID = SRC.LINE_ITEM_ID
                            AND     TGT.source_application_cd = SRC.source_application_cd
                            WHERE   TGT.dw_current_version_ind = TRUE
''';


SET sql_updates = '''--// Processing Updates of Type 2 SCD
                UPDATE ''' || tgt_tbl || ''' as TGT
                    
                    SET  
                    --- audit column updates
                   DW_LAST_EFFECTIVE_TS = SRC.DW_LAST_EFFECTIVE_TS
                   ,DW_CURRENT_VERSION_IND = FALSE
                   ,DW_LAST_UPDATE_TS = CURRENT_TIMESTAMP
                   ,DW_SOURCE_UPDATE_NM = "FACEBOOK"

                    FROM ''' || tgt_update_tbl || ''' SRC
                        WHERE TGT.LINE_ITEM_ID = SRC.LINE_ITEM_ID
                        AND TGT.SOURCE_APPLICATION_CD = SRC.SOURCE_APPLICATION_CD
                        AND TGT.DW_FIRST_EFFECTIVE_TS = SRC.DW_FIRST_EFFECTIVE_TS
                        ''';


--// Processing Inserts
SET sql_inserts = '''INSERT INTO ''' || tgt_tbl || '''
                ( 
                        LINE_ITEM_ID
                        ,SOURCE_APPLICATION_CD
                        ,DW_FIRST_EFFECTIVE_TS
                        ,DW_LAST_EFFECTIVE_TS
                        ,CAMPAIGN_ID
                        ,LINE_ITEM_NM
                        ,LINE_ITEM_TYPE_NM
                        ,UNITS_BOUGHT_CNT
                        ,LINE_ITEM_SHORT_NM
                        ,LINE_ITEM_BUDGET_AMT
                        ,STATUS_NM
                        ,START_TS
                        ,END_TS
                        ,AUDIENCE_NM
                        ,AD_COST_TYPE_CD
                        ,AD_COST_AMT
                        ,DAILY_BUDGET_AMT
                        ,EXPECTED_DAILY_SPEND_AMT
                        ,PLANNED_IMPRESSION_CNT
                        ,SOURCE_CREATED_TS
                        ,SOURCE_LAST_MODIFIED_TS
                        ,DW_CREATE_TS
                        ,DW_LAST_UPDATE_TS
                        ,DW_LOGICAL_DELETE_IND
                        ,DW_SOURCE_CREATE_NM
                        ,DW_SOURCE_UPDATE_NM
                        ,DW_CURRENT_VERSION_IND
                        )
                        SELECT 
                            LINE_ITEM_ID
                            ,SOURCE_APPLICATION_CD
                            ,DW_FIRST_EFFECTIVE_TS
                            ,DW_LAST_EFFECTIVE_TS
                            ,CAMPAIGN_ID
                            ,LINE_ITEM_NM
                            ,LINE_ITEM_TYPE_NM
                            ,UNITS_BOUGHT_CNT
                            ,LINE_ITEM_SHORT_NM
                            ,LINE_ITEM_BUDGET_AMT
                            ,STATUS_NM
                            ,START_TS
                            ,END_TS
                            ,AUDIENCE_NM
                            ,AD_COST_TYPE_CD
                            ,AD_COST_AMT
                            ,DAILY_BUDGET_AMT
                            ,EXPECTED_DAILY_SPEND_AMT
                            ,PLANNED_IMPRESSION_CNT
                            ,SOURCE_CREATED_TS
                            ,SOURCE_LAST_MODIFIED_TS
                            ,CURRENT_TIMESTAMP
                            ,CURRENT_TIMESTAMP
                            ,FALSE AS DW_LOGICAL_DELETE_IND
                            ,"FACEBOOK" AS DW_SOURCE_CREATE_NM
                            ,"FACEBOOK" AS DW_SOURCE_UPDATE_NM  
                            ,DW_CURRENT_VERSION_IND
                        FROM ''' || tgt_wrk_tbl  ;
                        
                        
SET sql_commit   = "COMMIT TRANSACTION";
SET sql_rollback = "ROLLBACK TRANSACTION";
    
BEGIN
        EXECUTE IMMEDIATE (sql_begin);       
        IF data_extract_start_ts = "1900-01-01 01:01:01 UTC" THEN
        EXECUTE IMMEDIATE (sql_delete_tgt_tbl);
        END IF;       
        BEGIN
                EXECUTE IMMEDIATE (insert_tgt_wrk_tbl);
                EXCEPTION WHEN ERROR THEN
                SET job_end  = CURRENT_TIMESTAMP();
                SET status   = "FAILED";
                SET err_desc = "Creation of Target Work table "|| tgt_wrk_tbl ||" Failed with error: " || @@error.message ;    --// return a error message.
                CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
                RAISE USING message = err_desc;
        END;    
        EXECUTE IMMEDIATE (sql_records_to_expire);
        EXECUTE IMMEDIATE (sql_updates);
        EXECUTE IMMEDIATE (sql_inserts);
        SET row_count = @@row_count;
        EXECUTE IMMEDIATE (sql_commit);
        EXCEPTION WHEN ERROR THEN
        EXECUTE IMMEDIATE (sql_rollback);
        SET job_end  = CURRENT_TIMESTAMP();
        SET status   = "FAILED";
        SET err_desc = '''Loading of table ''' || tgt_tbl || ''' Failed with error: ''' || @@error.message  ;    --// return a error message.
        CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
        RAISE USING message = err_desc;
END;

SET job_end = CURRENT_TIMESTAMP();
SET status  = "COMPLETED";
--DQ Check
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_observability`('Meta','Confirmed',CURRENT_DATE(),"AD_PLATFORM_LINE_ITEM");
CALL `<<CLTV_PROJECT_ID>>.<<AUDIT_DATASET>>.SP_PROCESS_AUDIT_CONTROL`('CLTV',job_id,proc_name,job_start,job_end,data_extract_start_ts,data_extract_end_ts,row_count,status,err_desc);
END;