import sys
import os

WORKING_DIR = '/Users/amritprusty/projects/sp_gen_rnd'
sys.path.append(WORKING_DIR)

from sp_gen_sdk.model import sql, workbook



LIST_SQL_DDL_PATHS = [
    "udco-cltv/META/scripts/ddl/Analytical/ddl_d1_platform_advertiser.sql",
    "udco-cltv/META/scripts/ddl/ddl_campaign_reach_summary.sql",
    "udco-cltv/META/scripts/ddl/ddl_ad_platform_advertisement.sql",
    "udco-cltv/META/scripts/ddl/ddl_ad_platform_campaign.sql",
    "udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_opportunity.sql",
    "udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_promotional_channel.sql",
    "udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_platform.sql",
    "udco-cltv/META/scripts/ddl/Analytical/ddl_d1_ad_media_campaign.sql",
    "udco-cltv/META/scripts/ddl/Analytical/ddl_d1_platform_media_campaign.sql",
    "udco-cltv/META/scripts/ddl/Analytical/ddl_f_ad_platform_campaign_rf_trend.sql"
]

WORKBOOK_PATH = os.path.join(WORKING_DIR, "Ad_Platform_Campaign_Mapping_V1.3.4.1.xlsx")



# import json

# ddl_queries: list[sql.DDLQuery] = []

# for path in LIST_SQL_DDL_PATHS:
#     full_path = os.path.join(WORKING_DIR, path)
#     with open(full_path, 'r') as f:
#         ddl_text = f.read()
#     try:
#         parsed = sql.DDLQuery.parse(ddl_text)
#         parsed.ddl_loc = path
#         ddl_queries.append(parsed)
#     except Exception as e:
#         print(f"Error parsing {path}: {e}")

# # Save output to misc/ folder
# output_dir = os.path.join(WORKING_DIR, 'misc')
# os.makedirs(output_dir, exist_ok=True)

# output_data = [ddl.model_dump() for ddl in ddl_queries]
# output_path = os.path.join(output_dir, 'ddl_parsed_output.json')

# with open(output_path, 'w') as f:
#     json.dump(output_data, f, indent=2, default=str)

# print(f"Saved {len(ddl_queries)} parsed DDL queries to {output_path}")


# --- Test Workbook & Spreadsheet ---

SHEET_NAME = "Social&Campaign RF MApping"
wb = workbook.Workbook(WORKBOOK_PATH)


# Test sheet_names_list
print("=== Sheet Names ===")
print(wb.sheet_names_list)
sheet = wb.get_sheet_by_name(SHEET_NAME)
# print(sheet.get_all_rows())
# print(wb.get_sheet_by_name("prod_campaign_performance").get_all_rows())

# # Test get_sheet_by_name and Spreadsheet methods for each sheet
# for name in wb.sheet_names_list:
#     sheet = wb.get_sheet_by_name(name)

#     print(f"\n{'='*60}")
#     print(f"Sheet: {sheet.title}")
#     print(f"{'='*60}")

#     # Test get_cell - read first 3 cells of row 1 (headers)
#     print("First 3 header cells:")
#     for col in range(1, 4):
#         print(f"  ({1},{col}): {sheet.get_cell(1, col)}")

#     # Test get_all_rows - show first 3 rows
#     rows = sheet.get_all_rows()
#     print(f"Total rows: {len(rows)}")
#     print("First 3 rows:")
#     for row in rows[:3]:
#         print(f"  {row}")

# wb.close()
# print("\nWorkbook closed successfully.")
